import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";

const DeliveryLineDetails = () => (
  <>
    <Layout
      className="delivery-line-details"
      pageTitle="Delivery Line Details"
    >
      <Button
      // onClick={function noRefCheck(){}}
      >
        View Current Line
      </Button>
      <Dialog
        dataTestId="test-id"
        escapeExits
        id="element-id"
        // onClose={function noRefCheck(){}}
        returnFocusOnDeactivate
        title="Delivery Line Details"
      >
        <DialogContent>
          <Grid
            container
            className="marginb15"
          >
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label">Part Number</div>
                <div className="mt-12">001</div>
              </div>
            </GridItem>
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label">Item Description</div>
                <div className="mt-12">Test Description</div>
              </div>
            </GridItem>
          </Grid>
          <Grid
            container
            className="marginb15"
          >
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label">Quantity Ordered</div>
                <div className="mt-12">250</div>
              </div>
            </GridItem>
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label">Quantity Outstanding</div>
                <div className="mt-12">50</div>
              </div>
            </GridItem>
          </Grid>
          <Grid
            container
            className="marginb15"
          >
            <GridItem
              sm={12}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <div className="essui-form-label">Quantity Delivered</div>
                <div className="mt-12">200</div>
              </div>
            </GridItem>
          </Grid>
        </DialogContent>
        <DialogFooter>
          <Grid container>
            <GridItem
              sm={3}
              md={4}
              lg={6}
              xl={6}
            >
              <div>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Tertiary}
                >
                  Help
                </Button>
              </div>
            </GridItem>
            <GridItem
              sm={5}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="rightbtn">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Primary}
                >
                  Close
                </Button>
              </div>
            </GridItem>
          </Grid>
        </DialogFooter>
      </Dialog>
    </Layout>
  </>
);
export default DeliveryLineDetails;
