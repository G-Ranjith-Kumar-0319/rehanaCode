import PreviewSection from "@/shared/components/Preview/PreviewSection";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { Loader, LoaderType } from "@essnextgen/ui-kit";
import useTransactionPreview from "./useTransactionPreview";

const TransactionPreviewPage = () => {
  const { t } = useTranslation();
  const { convertToCsv, convertToPdf, convertToXml, fileObj, isLoading } = useTransactionPreview();

  return (
    <>
      {isLoading ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Downloading file..."
          isLoaderModal
        />
      ) : null}
      <PreviewSection
        pageTitle={t("generalLedgerSetup.preview")}
        isBreadcrumbRequired
        className="report-preview wrapper__radius--0"
        pdfSrc={fileObj?.fileData}
        onPdfClick={convertToPdf}
        onCsvClick={convertToCsv}
        onXmlClick={convertToXml}
        isLoading={isLoading}
      />
    </>
  );
};

export default TransactionPreviewPage;
