import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  Divider,
  Grid,
  GridItem,
  Loader,
  LoaderType
} from "@essnextgen/ui-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { getDate } from "@/utils/getDataSource";
import { useParams, useHistory } from "react-router-dom";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import CustomCell from "./Grid/CustomCell";
import transactionSelectPeriodDef from "./Grid/columnDef";
import useTransactionSelectPeriod from "../TransactionSelectPeriod/useTransactionSelectPeriod";
import { getTransactionDetails, actions as brsAction } from "../state/ChartOfAccountsReviewList.slice";

const TransactionDetails = () => {
  const { transactionDetails, tranStatus } = useAppSelector((state) => state.chartOfAccountsReviewList);
  const dispatch = useDispatch<AppDispatch>();
  const { t, selectedTransactionRow, selectedRowHandler } = useTransactionSelectPeriod();
  const { fromDate, toDate } = useParams<{ fromDate: string; toDate: string }>();
  const journalHeaderDetails = transactionDetails?.journalHeaderDetails;
  const history = useHistory();
  const historyState = history.location.state as any;

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const onCloseHandler = () => {
    history.push({
      pathname: `/general-ledger/chart-accounts-review/transaction-period/from/${fromDate}/to/${toDate}`,
      state: {
        ...historyState
      }
    });
  };

  useEffect(() => {
    dispatch(
      getTransactionDetails({
        journalId: historyState?.transactionBrowseRow?.journal_id
      })
    );
  }, []);

  const handlePreviewClick = () => {
    history.push(`${history.location.pathname}/preview`, { ...historyState });
  };

  return (
    <>
      {tranStatus === STATUS.LOADING ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        <>
          <Layout
            pageTitle="Transaction Details"
            isBreadcrumbRequired
          >
            <Grid className="mt-8">
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">Period</div>
                  <div className="mt-8">
                    {journalHeaderDetails?.period_no} {journalHeaderDetails?.description}
                  </div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">Date</div>
                  <div className="mt-8">{getDate(journalHeaderDetails?.journal_date)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">Debit</div>
                  <div className="mt-8">{numberFormatter.format(journalHeaderDetails?.debit)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">Credit</div>
                  <div className="mt-8">{numberFormatter.format(journalHeaderDetails?.credit)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">Type</div>
                  <div className="mt-8">{journalHeaderDetails?.journal_type_mapping}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">User</div>
                  <div className="mt-8">{journalHeaderDetails?.user_code}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">Journal No</div>
                  <div className="mt-8">{journalHeaderDetails?.det_num}</div>
                </div>
              </GridItem>
              <GridItem
                lg={12}
                xl={12}
                sm={4}
              >
                <div className="">
                  <div className="essui-form-label">Narrative</div>
                  <div className="mt-8">{`${journalHeaderDetails?.narrative} ${
                    journalHeaderDetails?.pct_narrative || ""
                  }`}</div>
                </div>
              </GridItem>
            </Grid>
          </Layout>

          <Layout isBreadcrumbRequired={false}>
            <GridTableNew
              columnDef={transactionSelectPeriodDef}
              dataSource={transactionDetails?.journalDetails || []}
              isLoading={false}
              customCell={CustomCell}
              selectedRow={selectedTransactionRow}
              selectedRowHandler={selectedRowHandler as any}
              isScrollable
            />
          </Layout>

          <Layout isBreadcrumbRequired={false}>
            <Grid
              className=""
              justify="space-between"
            >
              <GridItem
                sm={8}
                lg={6}
                md={4}
              >
                <HelpButton
                  identifier="testIdentifier"
                  labelName={t("common.help")}
                />
              </GridItem>

              <GridItem
                sm={4}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="d-flex justify-end gap-8">
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={onCloseHandler}
                  >
                    {t("generalLedgerSetup.close")}
                  </Button>
                  <Button
                    size={ButtonSize.Small}
                    onClick={handlePreviewClick}
                  >
                    {t("generalLedgerSetup.preview")}
                  </Button>
                </div>
              </GridItem>
            </Grid>
          </Layout>
        </>
      )}
    </>
  );
};

export default TransactionDetails;
