import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import columnDef from "../ChartOfAccountsReview/Grid/columnDef";

export type AccountReviewListType = { [key: string]: any }[];
export type ChartAccountType = {
  accountReviewDetails?: { [key: string]: any }[];
};

export type AccountReviewDetailsType = {
  accountReviewDetails: AccountReviewListType;
  budget: number;
  commitment: number;
  invoiced: number;
  actual: number;
  total: number;
  remaining: number;
};

type intialStateType = {
  status?: STATUS;
  tranStatus?: STATUS;
  chartOfAccountsReviewList: AccountReviewDetailsType;
  columnDef: TColumnDef;
  selectedRow?: { [key: string]: any };
  enablePanel: boolean;
  isPreviousYearData: boolean;
  transactionDetails: { [key: string]: any };
};

const initialState: intialStateType = {
  columnDef,
  enablePanel: false,
  isPreviousYearData: false,
  chartOfAccountsReviewList: {
    accountReviewDetails: [],
    budget: 0.0,
    commitment: 0.0,
    invoiced: 0.0,
    actual: 0.0,
    total: 0.0,
    remaining: 0.0
  },
  transactionDetails: {}
};

/** Thunks */

export const getAcctReviewList = createAsyncThunk(
  "gl-acct-review/acct-review-list",
  async (
    {
      costId,
      leddefId,
      fundId,
      includePreviousYearData,
      callback
    }: {
      costId?: number;
      leddefId?: number;
      fundId?: number;
      includePreviousYearData: boolean;
      callback?: (data: any) => void;
    },
    thunkAPI
  ) => {
    try {
      const response = await client.get(`${apiRoot}/gl-acct-review/acct-review-list`, {
        params: {
          costId,
          leddefId,
          fundId,
          includePreviousYearData
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getTransactionDetails = createAsyncThunk(
  "get/transaction-details",
  async (
    {
      journalId
    }: {
      journalId?: number;
    },
    thunkAPI
  ) => {
    try {
      const response = await client.get(`${apiRoot}/gl-acct-review/acct-review-tran-journal?journalId=${journalId}`);
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getTransactionPDF = createAsyncThunk(
  "get/transaction-details/pdf",
  async (
    {
      payload
    }: {
      payload: {
        costId: string;
        leddefId: string;
        fundId: string;
        costDescription: string;
        ledgerDescription: string;
        fundDescription: string;
        fromPeriod: string;
        toPeriod: string;
        fromPeriodDescription: string;
        toPeriodDescription: string;
      };
    },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-transaction-print-pdf`, payload, {
        responseType: "blob"
      });
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");
      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getTransactionCSV = createAsyncThunk(
  "document/acct-review-transaction-print-csv",
  async (
    {
      payload
    }: {
      payload: {
        costId: string;
        leddefId: string;
        fundId: string;
        costDescription: string;
        ledgerDescription: string;
        fundDescription: string;
        fromPeriod: string;
        toPeriod: string;
        fromPeriodDescription: string;
        toPeriodDescription: string;
      };
    },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-transaction-print-csv`, payload, {
        responseType: "blob"
      });
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");
      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getTransactionXML = createAsyncThunk(
  "document/acct-review-transaction-print-xml",
  async (
    {
      payload
    }: {
      payload: {
        costId: string;
        leddefId: string;
        fundId: string;
        costDescription: string;
        ledgerDescription: string;
        fundDescription: string;
        fromPeriod: string;
        toPeriod: string;
        fromPeriodDescription: string;
        toPeriodDescription: string;
      };
    },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-transaction-print-xml`, payload, {
        responseType: "blob"
      });
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");
      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getTransactionDetailsPDF = createAsyncThunk(
  "document/acct-review-transaction-journal-print-pdf",
  async (
    {
      payload
    }: {
      payload: {
        journalId: string;
        period: string;
        date: string;
        credit: string;
        debit: string;
        type: string;
        user: string;
        journalNo: string;
        narrative: string;
      };
    },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-transaction-journal-print-pdf`, payload, {
        responseType: "blob"
      });
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getTransactionDetailsCSV = createAsyncThunk(
  "document/acct-review-transaction-journal-print-csv",
  async (
    {
      payload
    }: {
      payload: {
        journalId: string;
        period: string;
        date: string;
        credit: string;
        debit: string;
        type: string;
        user: string;
        journalNo: string;
        narrative: string;
      };
    },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-transaction-journal-print-csv`, payload);
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getTransactionDetailsXML = createAsyncThunk(
  "document/acct-review-transaction-journal-print-xml",
  async (
    {
      payload
    }: {
      payload: {
        journalId: string;
        period: string;
        date: string;
        credit: string;
        debit: string;
        type: string;
        user: string;
        journalNo: string;
        narrative: string;
      };
    },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-transaction-journal-print-xml`, payload);
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getLedgerBrowsePDF = createAsyncThunk(
  "document/acct-review-ledger-browse-print-pdf",
  async (
    {
      payload
    }: {
      payload: {
        costId: number;
        costCentreDescription: string;
        type: string;
        typeDescription: string | undefined;
        groupId: number;
        groupDescription: string | undefined;
        excludeNonZeroValues: boolean;
        excludeBalanceSheetAccounts: boolean;
      };
    },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-ledger-browse-print-pdf`, payload, {
        responseType: "blob"
      });
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getLedgerBrowseCSV = createAsyncThunk(
  "document/acct-review-ledger-code-print-csv",
  async (
    {
      payload
    }: {
      payload: {
        costId: number;
        costCentreDescription: string;
        type: string;
        typeDescription: string | undefined;
        groupId: number;
        groupDescription: string | undefined;
        excludeNonZeroValues: boolean;
        excludeBalanceSheetAccounts: boolean;
      };
    },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-ledger-code-print-csv`, payload);
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getLedgerBrowseXML = createAsyncThunk(
  "document/acct-review-ledger-code-print-xml",
  async (
    {
      payload
    }: {
      payload: {
        costId: number;
        costCentreDescription: string;
        type: string;
        typeDescription: string | undefined;
        groupId: number;
        groupDescription: string | undefined;
        excludeNonZeroValues: boolean;
        excludeBalanceSheetAccounts: boolean;
      };
    },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/document/acct-review-ledger-code-print-xml`, payload);
      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      return { data: response.data, fileName };
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

/**
 * This slice of state is responsible for storing BRC details state
 */
const slice = createSlice({
  initialState,
  name: "chartOfAccountReviewList",
  extraReducers: (builder) => {
    /** BRC details state */
    builder
      .addCase(getAcctReviewList.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getAcctReviewList.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.chartOfAccountsReviewList = action.payload;
      })
      .addCase(getAcctReviewList.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getTransactionDetails.pending, (state) => {
        state.tranStatus = STATUS.LOADING;
      })
      .addCase(getTransactionDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.tranStatus = STATUS.SUCCESS;
        state.transactionDetails = action.payload;
      })
      .addCase(getTransactionDetails.rejected, (state, action: PayloadAction<any>) => {
        state.tranStatus = STATUS.FAILED;
      });
  },
  reducers: {
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    },
    setEnablePanel: (state, action: PayloadAction<boolean>) => {
      state.enablePanel = action.payload;
    },
    setIncludePreviousYearData: (state, action: PayloadAction<boolean>) => {
      state.isPreviousYearData = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
