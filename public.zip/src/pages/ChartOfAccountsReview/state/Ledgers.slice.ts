import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { client, apiRoot } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import { RootState } from "@/store/store";
import { ledgerGroupActions } from "./LedgerGroups.slice";

export type LedgersFiltersType = {
  pageNumber: number;
  pageSize: number;
  costId?: number;
  ledgerType?: string;
  groupId?: number;
  excludeNonZeroValues: boolean;
  excludeBalanceSheetAccounts: boolean;
  lookingFor?: string;
  highLightedRecord?: string;
};

type intialStateType = {
  ledgers?: any;
  error?: string;
  status?: STATUS;
  filterState: LedgersFiltersType;
  selectedLedger?: RowType;
};

const initialState: intialStateType = {
  filterState: {
    pageNumber: 1,
    pageSize: 10,
    costId: undefined,
    ledgerType: "",
    groupId: undefined,
    excludeNonZeroValues: false,
    excludeBalanceSheetAccounts: false,
    lookingFor: "",
    highLightedRecord: ""
  }
};

/** Thunks */
export const getLedgers = createAsyncThunk(
  "ledgers/get",
  async (
    { filterState, callback }: { filterState: LedgersFiltersType | undefined; callback?: (data: any) => void },
    thunkAPI
  ) => {
    const { dispatch } = thunkAPI;
    const response = await client.post(`${apiRoot}/gl-acct-review/acct-review-ledger-browse`, { ...filterState });
    if (response.data) {
      const data: RowType = response?.data;
      const row = data?.ledgerCodes.find((l: RowType) => l.ledger_code === data?.highLightValue);
      dispatch(ledgersActions.selectRow(row));
    }
    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * # Ledgers Slice
 * This slice of state is responsible for storing ledgers details
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** getFinancialPeriods API cases */
    builder
      .addCase(getLedgers.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getLedgers.fulfilled, (state, action: PayloadAction<any>) => {
        state.ledgers = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getLedgers.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  initialState,
  name: "ledgers",
  reducers: {
    selectRow: (state, action: PayloadAction<any>) => {
      state.selectedLedger = action.payload;
    },
    setFilters: (state, action: PayloadAction<LedgersFiltersType>) => {
      state.filterState = {
        ...state.filterState,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filterState = {
        ...initialState.filterState
      };
    }
  }
});

export const { actions: ledgersActions, reducer: ledgerBrowseReducer } = slice;
export default ledgerBrowseReducer;
