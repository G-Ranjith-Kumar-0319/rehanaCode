import { cellRendererType } from "@/components/GridTable/GridTable";

const CustomCell = ({ field, row }: cellRendererType) => {
  const getContent = () => {
    if (field === "period_no") {
      return <>{row?.period_no === 0 ? 0 : row?.period_no}</>;
    }
    return null;
  };
  return getContent();
};

export default CustomCell;
