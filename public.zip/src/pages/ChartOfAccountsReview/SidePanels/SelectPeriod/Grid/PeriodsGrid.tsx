import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import { useAppSelector } from "@/store/store";
import React, { SetStateAction, useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { STATUS } from "@/types/UseStateType";
import { useFormContext } from "react-hook-form";
import FooterActions from "./FooterActions";
import { financialPeriodActions } from "../../../state/financialPeriod.slice";
import Filters from "./Filters";
import CustomCell from "./CustomCell";

type PropsType = {
  setIsOpen: (value: SetStateAction<boolean>) => void;
  id?: string;
};

const PeriodsGrid: React.FC<PropsType> = ({ setIsOpen, id }) => {
  const { periods, status, columnDef, selectedPeriodFrom, selectedPeriodTo } = useAppSelector(
    (state) => state.financialPeriods
  );
  const dispatch = useDispatch();
  const [row, setRow] = useState<RowType | undefined>(id === "selectFrom" ? selectedPeriodFrom : selectedPeriodTo);
  const { setValue } = useFormContext();

  useEffect(() => {
    dispatch(financialPeriodActions.resetFilters());
    return () => {
      dispatch(financialPeriodActions.resetFilters());
    };
  }, []);

  const onSelect = () => {
    if (id === "selectFrom") {
      dispatch(financialPeriodActions.selectFrom(row));
      setValue("from", row?.period_no);
      setValue("fromDescription", row?.description);
    } else {
      dispatch(financialPeriodActions.selectTo(row));
      setValue("to", row?.period_no);
      setValue("toDescription", row?.description);
    }
    setIsOpen(false);
  };

  return (
    <GridTableNew
      dataTestId="periodsGrid"
      filters={<Filters selectRow={setRow} />}
      columnDef={columnDef}
      dataSource={periods || []}
      isLoading={status === STATUS.LOADING && id !== ""}
      selectedRow={row}
      selectedRowHandler={setRow}
      onEnterKeyPress={onSelect}
      customCell={CustomCell}
      useDeepSearch
      enableScrollIntoView
      actions={
        <FooterActions
          onSelect={onSelect}
          onCancel={() => {
            setIsOpen(false);
          }}
        />
      }
    />
  );
};

PeriodsGrid.defaultProps = {
  id: undefined
};

export default PeriodsGrid;
