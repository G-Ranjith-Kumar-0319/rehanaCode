import { TextInput, Button, ButtonColor, ButtonSize, Icon, IconColor, IconSize } from "@essnextgen/ui-kit";
import { SyntheticEvent, FC, PropsWithChildren } from "react";

type PropsType = { value?: string; onClick?: (e: SyntheticEvent<Element, Event>) => void } & PropsWithChildren;

const InputButton: FC<PropsType> = ({ value, onClick, children }) => (
  <>
    {value !== undefined && (
      <TextInput
        className="read-only"
        value={value || ""}
        disabled
      />
    )}
    <Button
      color={ButtonColor.Secondary}
      size={ButtonSize.Small}
      className="essui-button-icon-only--small"
      onClick={onClick}
    >
      {children || (
        <Icon
          color={IconColor.Primary500}
          size={IconSize.Medium}
          name="search"
        />
      )}
    </Button>
  </>
);

InputButton.defaultProps = {
  value: undefined,
  onClick: undefined
};

export default InputButton;
