import { RowType, TColumnDef } from "@/components/GridTableNew/GridTableNew";
import useDebounce from "@/hooks/useDebounce";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import findNearest from "@/utils/nearestSearch";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  Grid,
  GridItem,
  FormLabel,
  TextInput,
  TextInputSize,
  RadioButton,
  RadioLabelPosition
} from "@essnextgen/ui-kit";
import { Dispatch, SetStateAction, useEffect, useState, ChangeEvent } from "react";
import { useDispatch } from "react-redux";
import useNearestSearch from "@/hooks/useNearestSearch";
import { financialPeriodActions } from "../../../state/financialPeriod.slice";
import columnDef from "./ColumnDef";

const Filters = ({ selectRow }: { selectRow: Dispatch<SetStateAction<RowType | undefined>> }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const dispatch = useDispatch<AppDispatch>();
  const { status, periods, filters } = useAppSelector((state) => state.financialPeriods);
  const debouncedValue = useDebounce(filters?.lookingFor!, 600);
  useNearestSearch({
    key: filters?.sequenceValue!,
    value: debouncedValue,
    rows: periods,
    dataTestId: "periodsGrid",
    selectRow
  });
  const handleLookingForChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(financialPeriodActions.setFilters({ lookingFor: value.toUpperCase() }));
  };

  const handleSequenceChange = (value?: string) => {
    columnDef.map((col, index) => {
      if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });
    setColumn([...columnDef]);
    dispatch(financialPeriodActions.setColumnDef(columns));
  };

  useEffect(() => {
    handleSequenceChange(filters?.sequenceValue);
  }, [filters?.sequenceValue]);

  return (
    <Grid
      className="custom-table"
      align="center"
    >
      <GridItem
        sm={12}
        md={4}
        xl={4}
      >
        <div className="essui-global-typography-default-h2">
          <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              autoFocus
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              id="looking-for"
              value={filters?.lookingFor}
              onChange={(e) => handleLookingForChange(e)}
              size={TextInputSize.Medium}
              readOnly={status === STATUS.LOADING}
            />
          </div>
        </div>
      </GridItem>

      <GridItem
        sm={12}
        md={4}
        xl={5}
      >
        <div className="essui-global-typography-default-h2">
          <FormLabel>{t("purchaseOrder.sequence")}</FormLabel>
          <div className="essui-textinput sequence">
            {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
              const sequenceId = `sequence=${index + 1}`;
              return (
                <RadioButton
                  label={column.sequenceName ? column.sequenceName : column.headerName}
                  name={column.field}
                  labelPosition={RadioLabelPosition.Right}
                  value={column.field}
                  onChange={() => {
                    dispatch(
                      financialPeriodActions.setFilters({
                        lookingFor: "",
                        sequenceValue: String(column.field),
                        sequenceIndex: String(index)
                      })
                    );
                  }}
                  isSelected={filters?.sequenceValue === column.field}
                  key={sequenceId}
                />
              );
            })}
          </div>
        </div>
      </GridItem>
    </Grid>
  );
};

export default Filters;
