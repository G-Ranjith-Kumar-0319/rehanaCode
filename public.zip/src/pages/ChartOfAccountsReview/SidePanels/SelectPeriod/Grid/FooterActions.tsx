import { useAppContext } from "@/routes/Routes";
import { Grid, GridItem, Button, ButtonSize, ButtonColor } from "@essnextgen/ui-kit";
import React from "react";
import classnames from "classnames";
import HelpButton from "@/components/OpenLinkButton/HelpButton";

type PropsType = {
  onSelect: () => void;
  onCancel: () => void;
  onHelp?: () => void;
  className?: string;
};
const FooterActions: React.FC<PropsType> = ({ onSelect, onCancel, onHelp, className }) => {
  const { translate: locale } = useAppContext();
  const classes = classnames("width100", className && className);

  return (
    <Grid
      container
      className={classes}
      justify="space-between"
    >
      <GridItem>
        <HelpButton
          identifier="help-button"
          labelName={locale("common.help")}
        />
      </GridItem>
      <GridItem>
        <div className="d-flex justify-end">
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Secondary}
            className="mr-4"
            onClick={onCancel}
          >
            {locale("common.cancel")}
          </Button>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Primary}
            className="ml-4"
            onClick={onSelect}
          >
            {locale("common.selectButton")}
          </Button>
        </div>
      </GridItem>
    </Grid>
  );
};

FooterActions.defaultProps = {
  onHelp: undefined,
  className: undefined
};

export default FooterActions;
