import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

export default [
  {
    headerName: "Period",
    field: "period_no",
    align: "left",
    sequence: true,
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Description",
    field: "description",
    sequence: true,
    align: "left"
  }
] as TColumnDef;
