import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import { useHistory } from "react-router-dom";
import { useForm } from "react-hook-form";
import BodyUtil from "@/shared/utils/NoScroll";
import { getAcctReviewList, actions } from "../state/ChartOfAccountsReviewList.slice";
import { ccBrowseActions } from "../state/CostCentreBrowse.slice";

const useChartOfAccountsReview = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const [showAllPrevYrMovement, setShowAllPrevYrMovement] = useState<boolean>(false);

  /* eslint-disable camelcase */
  type FormData = {
    cost_des: string;
  };

  const formMethods = useForm<FormData>({
    defaultValues: {
      cost_des: ""
    }
  });

  const { setValue, watch, getValues } = formMethods;

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const formatNumberWithCommas = (number: any) => number?.toString()?.replace(/\B(?=(\d{3})+(?!\d))/g, ",");

  const { status, selectedRow, isPreviousYearData } = useAppSelector((state) => state.chartOfAccountsReviewList);
  const { enablePanel } = useAppSelector((state) => state.chartOfAccountsReviewList);
  const selectedRowHandler = (row: RowType) => dispatch(actions.setSelectedRow(row));

  const { accountReviewDetails, budget, commitment, invoiced, actual, total, remaining } = useAppSelector(
    ({ chartOfAccountsReviewList }) => chartOfAccountsReviewList?.chartOfAccountsReviewList
  );

  const { selectedfundCode } = useAppSelector((state) => state.fundCode);
  const history = useHistory();
  const historyState = history.location.state as any;

  const unblock = history.block((location, action) => {
    if (!location.pathname.includes("chart-accounts-review")) {
      dispatch(ccBrowseActions.resetFilters());
      dispatch(actions.setIncludePreviousYearData(false));
      location.state = {};
    }
  });

  const handlePreviewClick = () => {
    history.push("/general-ledger/chart-accounts-review/preview", {
      ...historyState,
      isPreviousYearData
    });
  };

  useEffect(() => {
    dispatch(
      getAcctReviewList({
        costId: historyState?.costCentreRecord?.cost_id,
        leddefId: historyState?.ledgerRecord?.leddef_id,
        fundId: selectedfundCode?.fund_id,
        includePreviousYearData: isPreviousYearData,
        callback: (data) => {
          dispatch(actions.setSelectedRow(data.accountReviewDetails.at(0)));
        }
      })
    );
    return () => {
      unblock();
      dispatch(actions.setEnablePanel(false));
    };
  }, [selectedfundCode]);

  useEffect(() => {
    if (enablePanel) {
      BodyUtil.NoScroll.add();
    } else {
      BodyUtil.NoScroll.remove();
    }
  }, [enablePanel]);

  useEffect(
    () => () => {
      BodyUtil.NoScroll.remove();
    },
    []
  );

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      const focusButton = document.getElementById("viewTransactionsButton");
      if (focusButton) {
        focusButton.focus({ preventScroll: true });
      }
    }, 10);
    return () => clearTimeout(timeoutId);
  }, [status]);

  const onSelectPrevYearCheckBox = (e: any) => {
    dispatch(actions.setIncludePreviousYearData(e.target.checked));
    dispatch(
      getAcctReviewList({
        costId: historyState?.costCentreRecord?.cost_id,
        leddefId: historyState?.ledgerRecord?.leddef_id,
        fundId: selectedfundCode?.fund_id,
        includePreviousYearData: e.target.checked,
        callback: (data) => {
          dispatch(actions.setSelectedRow(data.accountReviewDetails.at(0)));
        }
      })
    );
  };

  return {
    t,
    accountReviewDetails,
    budget,
    commitment,
    invoiced,
    actual,
    total,
    remaining,
    selectedRow,
    status,
    showAllPrevYrMovement,
    setShowAllPrevYrMovement,
    onSelectPrevYearCheckBox,
    enablePanel,
    numberFormatter,
    selectedRowHandler,
    dispatch,
    formMethods,
    watch,
    handlePreviewClick,
    formatNumberWithCommas
  };
};

export default useChartOfAccountsReview;
