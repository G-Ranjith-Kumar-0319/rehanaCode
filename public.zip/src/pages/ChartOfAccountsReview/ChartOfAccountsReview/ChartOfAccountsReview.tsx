import { Button, ButtonColor, ButtonSize, FormLabel, Grid, GridItem } from "@essnextgen/ui-kit";
import Layout from "@/components/Layout/Layout";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import { FormProvider } from "react-hook-form";
import { useHistory } from "react-router-dom";
import { useEffect, useState } from "react";
import useChartOfAccountsReview from "./useChartOfAccountsReview";
import CustomCell from "./Grid/CustomCell";
import ChartOfAccountsReviewFilters from "./Grid/ChartOfAccountsReviewFilters";
import chartOfAccountsReviewDef from "./Grid/columnDef";
import SelectPeriodRangeModal from "../SidePanels/SelectPeriod/SelectPeriodRangeModal";
import { actions } from "../state/ChartOfAccountsReviewList.slice";

const ChartsAccountsReview = () => {
  const [isFundCodeModalOpen, setFundCodeModalOpen] = useState<boolean>(false);
  const {
    t,
    accountReviewDetails,
    budget,
    commitment,
    invoiced,
    actual,
    total,
    remaining,
    selectedRow,
    status,
    showAllPrevYrMovement,
    onSelectPrevYearCheckBox,
    numberFormatter,
    enablePanel,
    selectedRowHandler,
    dispatch,
    formMethods,
    handlePreviewClick,
    formatNumberWithCommas
  } = useChartOfAccountsReview();
  return (
    <>
      <FormProvider {...formMethods}>
        <Layout
          pageTitle={t("generalLedgerSetup.chartOfAccountsReview")}
          isBreadcrumbRequired
          type="transparent"
          className="charts-accounts-review"
        >
          <GridTableNew
            dataTestId="chartsOfAccountReviewGrid"
            id="chartsOfAccountReviewGrid"
            filters={
              <ChartOfAccountsReviewFilters
                showAllPrevYrMovement={showAllPrevYrMovement}
                onSelectPrevYearCheckBox={onSelectPrevYearCheckBox}
                isFundCodeModalOpen={isFundCodeModalOpen}
                setFundCodeModalOpen={setFundCodeModalOpen}
              />
            }
            columnDef={chartOfAccountsReviewDef}
            dataSource={accountReviewDetails || []}
            isLoading={status === STATUS.LOADING}
            customCell={CustomCell}
            selectedRow={selectedRow}
            selectedRowHandler={selectedRowHandler as any}
            footer={
              <>
                <div className="button-right">
                  <Button
                    id="viewTransactionsButton"
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      dispatch(actions.setEnablePanel(true));
                    }}
                  >
                    {t("generalLedgerSetup.viewTransactions")}
                  </Button>
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={handlePreviewClick}
                  >
                    {t("generalLedgerSetup.preview")}
                  </Button>
                </div>
              </>
            }
            isRowSelectionEnabled={isFundCodeModalOpen === false}
          />
        </Layout>
        <Layout isBreadcrumbRequired={false}>
          <div className="container">
            <Grid
              container
              className="mt-12 justify__content--between row-gap-16 ml-60 mr-60"
            >
              <GridItem>
                <FormLabel className="mb-5">{t("generalLedgerSetup.budget")}</FormLabel>
                <div>{numberFormatter.format(budget)}</div>
              </GridItem>
              <GridItem>
                <FormLabel className="mb-5">{t("generalLedgerSetup.commitment")}</FormLabel>
                <div>{numberFormatter.format(commitment)}</div>
              </GridItem>
              <GridItem className="d-flex align-end">
                <b>+</b>
              </GridItem>
              <GridItem>
                <FormLabel className="mb-5">{t("generalLedgerSetup.invoiced")}</FormLabel>
                <div>{numberFormatter.format(invoiced)}</div>
              </GridItem>
              <GridItem className="d-flex align-end">
                <b>+</b>
              </GridItem>
              <GridItem>
                <FormLabel className="mb-5">{t("generalLedgerSetup.actual")}</FormLabel>
                <div>{numberFormatter.format(actual)}</div>
              </GridItem>
              <GridItem className="d-flex align-end">
                <b>=</b>
              </GridItem>
              <GridItem>
                <FormLabel className="mb-5">{t("generalLedgerSetup.total")}</FormLabel>
                <div>{numberFormatter.format(total)}</div>
              </GridItem>
              <GridItem>
                <FormLabel className="mb-5">{t("generalLedgerSetup.remaining")}</FormLabel>
                <div>{numberFormatter.format(remaining)}</div>
              </GridItem>
            </Grid>
          </div>
        </Layout>

        {enablePanel ? (
          <SelectPeriodRangeModal
            enable={enablePanel}
            setEnable={(flag) => {
              dispatch(actions.setEnablePanel(flag));
            }}
            row={selectedRow}
          />
        ) : undefined}
      </FormProvider>
    </>
  );
};
export default ChartsAccountsReview;
