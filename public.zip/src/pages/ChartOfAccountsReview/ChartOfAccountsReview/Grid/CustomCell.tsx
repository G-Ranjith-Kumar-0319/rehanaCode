import { cellRendererType } from "@/components/GridTable/GridTable";
import { Button, ButtonColor } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { AppDispatch } from "@/store/store";
import { useDispatch } from "react-redux";
import { actions } from "../../state/ChartOfAccountsReviewList.slice";

const CustomCell = ({ field, row }: cellRendererType) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const formatNumberWithCommas = (number: any) => number?.toString()?.replace(/\B(?=(\d{3})+(?!\d))/g, ",");

  const getContent = () => {
    if (field === "actions") {
      return (
        <>
          <Button
            color={ButtonColor.Utility}
            className="segments-buttons"
            onClick={() => {
              dispatch(actions.setSelectedRow(row));
              dispatch(actions.setEnablePanel(true));
            }}
          >
            {t("common.view02")}
          </Button>
        </>
      );
    }
    if (field === "period_no") {
      const formattedPeriodNo = row?.period_no !== KEYBOARD_STRING.Zero ? row?.period_no : KEYBOARD_STRING.Zero;
      return <>{formattedPeriodNo}</>;
    }
    if (field === "actual") {
      return <>{numberFormatter.format(row?.actual)}</>;
    }
    if (field === "curr_bud") {
      return <>{numberFormatter.format(row?.curr_bud)}</>;
    }
    if (field === "orig_bud") {
      return <>{numberFormatter.format(row?.orig_bud)}</>;
    }
    if (field === "variance_curr_bud") {
      const varCurrBud = row?.curr_bud - row?.actual;
      const formattedVarCurrBud = numberFormatter.format(varCurrBud);
      return <>{formattedVarCurrBud}</>;
    }
    if (field === "variance_orig_bud") {
      const varOrigBud = row?.orig_bud - row?.actual;
      const varOrigBudValue = numberFormatter.format(varOrigBud);
      return <>{varOrigBudValue}</>;
    }
    if (field === "prev_act") {
      const formattedPrevAct =
        row?.prev_act !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.prev_act) : specialCharacters.zero;
      return <>{formattedPrevAct}</>;
    }
    if (field === "variance") {
      return (
        <>{row?.variance !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.variance) : specialCharacters.zero}</>
      );
    }
    return null;
  };
  return getContent();
};

export default CustomCell;
