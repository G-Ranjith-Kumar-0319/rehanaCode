import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const chartOfAccountsReviewDef: TColumnDef = [
  {
    headerName: "Period",
    field: "period_no",
    align: "center",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "",
    field: "description"
  },
  {
    headerName: "Actual",
    field: "actual",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Current Budget",
    field: "curr_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Variance C.Bud-Act",
    field: "variance_curr_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Original Budget",
    field: "orig_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Variance O.Bud-Act",
    field: "variance_orig_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Prev.Year Actual",
    field: "prev_act",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Variance(Actuals)",
    field: "variance",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "",
    field: "actions",
    cellRenderer: "GridCellLink"
  }
];

export default chartOfAccountsReviewDef;
