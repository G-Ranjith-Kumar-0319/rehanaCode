import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { client, apiRoot } from "@/config";
import { STATUS } from "@/types/UseStateType";
import fundCodeColumnDef from "./ColumnDefs";

export type TFundCodes = {
  fundCodes: { [key: string]: any }[];
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
};
type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type fundCodesState = {
  fundCodes: { [key: string]: any }[];
  selectedfundCode?: { [key: string]: any };
  error?: string;
  status?: STATUS;
  columnDef: TColumnDef;
  filters?: TFilters;
};

const initialState: fundCodesState = {
  columnDef: fundCodeColumnDef,
  fundCodes: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined
  }
};

/** Thunks */
export const getFundCodes = createAsyncThunk(
  "fundCodes/getFundCodes",
  async ({ financialYear }: { financialYear: string }) => {
    const response = await client.get(`${apiRoot}/gl-acct-review/acct-review-fund-browse`, {
      headers: {
        accept: "text/plain",
        FinancialYear: financialYear
      }
    });

    return response.data;
  }
);

const slice = createSlice({
  extraReducers: (builder) => {
    builder
      .addCase(getFundCodes.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getFundCodes.fulfilled, (state, action: PayloadAction<any>) => {
        state.fundCodes = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getFundCodes.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  initialState,
  name: "fundCode",
  reducers: {
    resetToInitial: (state) => {
      state.fundCodes = [];
    },
    selectRow: (state, action: PayloadAction<any>) => {
      state.selectedfundCode = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (fundCodeColumnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    },
    reset: (state) => {
      state.fundCodes = initialState.fundCodes;
      state.filters = initialState.filters;
      state.selectedfundCode = initialState.selectedfundCode;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
