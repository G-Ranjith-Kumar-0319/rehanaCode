import { TColumnDef } from "@/components/GridTable/GridTable";

const columnDef: TColumnDef = [
  {
    headerName: "Code",
    field: "fund_code",
    align: "left"
  },
  {
    headerName: "Description",
    field: "ledger_des",
    align: "left"
  }
];

export default columnDef;
