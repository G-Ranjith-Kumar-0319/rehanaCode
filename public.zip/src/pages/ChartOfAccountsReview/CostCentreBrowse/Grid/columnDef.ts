import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const costCentreBrowseDef: TColumnDef = [
  {
    headerName: "Code",
    field: "cost_code"
  },
  {
    headerName: "Description",
    field: "cost_des"
  },
  {
    headerName: "Fixed Budget",
    field: "orig_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Current Budget",
    field: "curr_bud",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Commitment",
    field: "commitment",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Invoiced",
    field: "unpaid",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "Actual",
    field: "act",
    cellRenderer: "GridCellLink",
    align: "right"
  },
  {
    headerName: "C + I + A",
    field: "cia",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Remain. Budget",
    field: "remaining",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "",
    field: "actions",
    cellRenderer: "GridCellLink"
  }
];

export default costCentreBrowseDef;
