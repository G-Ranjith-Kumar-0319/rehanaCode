import { cellRendererType } from "@/components/GridTable/GridTable";
import { Button, ButtonColor } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { AppDispatch } from "@/store/store";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";

const CustomCell = ({ field, row }: cellRendererType) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const formatNumberWithCommas = (number: any) => number?.toString()?.replace(/\B(?=(\d{3})+(?!\d))/g, ",");

  const getContent = () => {
    if (field === "actions") {
      return (
        <>
          <Button
            color={ButtonColor.Utility}
            className="segments-buttons"
            onClick={() => {
              history.push(
                {
                  pathname: "/general-ledger/chart-accounts-review"
                },
                { ...historyState, costCentreRecord: row, from: "cost centre browse" }
              );
            }}
          >
            {t("generalLedgerSetup.select")}
          </Button>
        </>
      );
    }
    if (field === "orig_bud") {
      return <>{numberFormatter.format(row?.orig_bud)}</>;
    }
    if (field === "curr_bud") {
      return <>{numberFormatter.format(row?.curr_bud)}</>;
    }
    if (field === "commitment") {
      const commitment =
        row?.commitment !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.commitment) : specialCharacters.zero;
      return <>{commitment}</>;
    }
    if (field === "unpaid") {
      const unpaid =
        row?.unpaid !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.unpaid) : specialCharacters.zero;
      return <>{unpaid}</>;
    }
    if (field === "act") {
      const actual = row?.act !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.act) : specialCharacters.zero;
      return <>{actual}</>;
    }
    if (field === "cia") {
      const cia = row?.cia !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.cia) : specialCharacters.zero;
      return <>{cia}</>;
    }
    if (field === "remaining") {
      const remaining =
        row?.remaining !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.remaining) : specialCharacters.zero;
      return <>{remaining}</>;
    }
    return null;
  };
  return getContent();
};

export default CustomCell;
