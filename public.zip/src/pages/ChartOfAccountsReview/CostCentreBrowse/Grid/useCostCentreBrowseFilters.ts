import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useState } from "react";

const useCostCentreBrowseFilters = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const { filterState } = useAppSelector((state) => state.ccBrowse);

  return {
    t,
    filterState
  };
};

export default useCostCentreBrowseFilters;
