import { CheckBox, FormLabel, Grid, GridItem, TextInput } from "@essnextgen/ui-kit";
import "../Style.scss";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import useCostCentreBrowseFilters from "./useCostCentreBrowseFilters";

const CostCentreBrowseFilters = (props: any) => {
  const { t, filterState } = useCostCentreBrowseFilters();

  const { onSelectCostCentresCheckBox, lookingFor, lookingForChangehandler } = props;
  return (
    <Grid className="chart-accounts-review-filters">
      <GridItem>
        <div className="essui-global-typography-default-h2 looking-for-container">
          <FormLabel forId="looking-for">{t("common.lookingFor")}</FormLabel>
          <TextInput
            autoFocus
            onKeyDown={(event) => {
              // eslint-disable-next-line
              if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                event.preventDefault();
              }
            }}
            value={lookingFor}
            id="looking-for"
            onChange={lookingForChangehandler}
            className="w-100"
            autoComplete={false}
          />
        </div>
      </GridItem>
      <GridItem>
        <div className="essui-global-typography-default-h2 mr-t20">
          <CheckBox
            label={t("generalLedgerSetup.excludeCostCentres")}
            value={filterState?.excludeZero as any}
            isSelected={filterState?.excludeZero}
            onChange={onSelectCostCentresCheckBox}
          />
        </div>
      </GridItem>
    </Grid>
  );
};

export default CostCentreBrowseFilters;
