import Layout from "@/components/Layout/Layout";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, Pagination } from "@essnextgen/ui-kit";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { STATUS } from "@/types/UseStateType";
import useCostCentreBrowse from "./useCostCentreBrowse";
import CostCentreBrowseFilters from "./Grid/CostCentreBrowseFilters";
import costCentreBrowseDef from "./Grid/columnDef";
import CustomCell from "./Grid/CustomCell";

const CostCentreBrowse = () => {
  const {
    t,
    tranDetails,
    currentPage,
    totalPages,
    selectedRow,
    costCentreBrowseStatus,
    onSelectCostCentresCheckBox,
    onChangeHandler,
    selectedRowHandler,
    onSelectCostCentreRecord,
    onCancel,
    lookingFor,
    lookingForChangehandler,
    history,
    historyState,
    filterState
  } = useCostCentreBrowse();

  return (
    <>
      <Layout
        pageTitle={t("generalLedgerSetup.costCentreBrowse")}
        isBreadcrumbRequired
        type="transparent"
        className="cost-centre-browse"
      >
        <GridTableNew
          filters={
            <CostCentreBrowseFilters
              lookingFor={lookingFor}
              lookingForChangehandler={lookingForChangehandler}
              onSelectCostCentresCheckBox={onSelectCostCentresCheckBox}
            />
          }
          columnDef={costCentreBrowseDef}
          dataSource={tranDetails || []}
          isLoading={costCentreBrowseStatus === STATUS.LOADING}
          customCell={CustomCell}
          selectedRow={selectedRow}
          selectedRowHandler={selectedRowHandler as any}
          footer={
            <Pagination
              count={totalPages}
              page={currentPage}
              onChange={onChangeHandler}
            />
          }
          onEnterKeyPress={() => {
            history.push(
              {
                pathname: "/general-ledger/chart-accounts-review"
              },
              { ...historyState, costCentreRecord: selectedRow, from: "cost centre browse" }
            );
          }}
        />
      </Layout>
      <Layout isBreadcrumbRequired={false}>
        <Grid
          justify="space-between"
          className="mt-8"
        >
          <GridItem
            sm={8}
            lg={8}
            md={4}
          >
            <HelpButton
              identifier="testIdentifier"
              labelName={t("common.help")}
            />
          </GridItem>
          <GridItem>
            <Grid
              className="action-buttons"
              justify="space-between"
            >
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={onCancel}
              >
                {t("generalLedgerSetup.cancel")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={() => {
                  history.push(`${history.location.pathname}/preview`, {
                    ...historyState,
                    excludeZeroOfCostCenter: filterState?.excludeZero,
                    allCostCenters: tranDetails ?? []
                  });
                }}
              >
                {t("generalLedgerSetup.preview")}
              </Button>
              <Button
                size={ButtonSize.Small}
                onClick={onSelectCostCentreRecord}
              >
                {t("generalLedgerSetup.select")}
              </Button>
            </Grid>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};

export default CostCentreBrowse;
