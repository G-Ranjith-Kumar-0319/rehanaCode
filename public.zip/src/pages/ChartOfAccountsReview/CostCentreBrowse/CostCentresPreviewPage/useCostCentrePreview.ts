import { AppDispatch, useAppSelector } from "@/store/store";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import {
  getCostCentresCsvData,
  getCostCentresPDFData,
  getCostCentresXMLData
} from "../../state/CostCentreBrowse.slice";

interface MyResponseType {
  payload: string;
}
const useCostCentrePreview = () => {
  const { t } = useTranslation();
  const [isLoading, setLoading] = useState<boolean>(false);
  const history = useHistory();
  const historyState = history.location.state as any;
  const selectedfundCode = useAppSelector((state) => state.fundCode.selectedfundCode);
  const dispatch = useDispatch<AppDispatch>();
  const [fileObj, setFileObj] = useState<{
    fileData: string;
  }>({
    fileData: ""
  });
  const generatePayload = () => ({
    excludeZero: historyState.excludeZeroOfCostCenter,
    ledgerDescription: historyState?.ledgerRecord?.ledger_des ?? "",
    ledgerCode: historyState?.ledgerRecord?.ledger_code ?? ""
  });

  useEffect(() => {
    createPdfPreviewFromBase64();
  }, []);

  const convertToCsv = async () => {
    setLoading(true);
    const res: any = await dispatch(getCostCentresCsvData({ payload: generatePayload() }));
    const csvData = res.payload.data;
    const blob = new Blob([csvData], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = res?.payload?.fileName ?? "file";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  const createPdfPreviewFromBase64 = async () => {
    try {
      const { payload } = await dispatch(
        getCostCentresPDFData({
          payload: generatePayload()
        })
      );
      const { data } = payload as any;
      const blob = new Blob([data], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      setFileObj({
        fileData: pdfUri
      });
    } catch (error) {
      // console.error("Error decoding base64 string:", error); TODO: Error Handling
    }
  };

  const convertToPdf = async () => {
    setLoading(true);
    const { payload } = await dispatch(getCostCentresPDFData({ payload: generatePayload() }));
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName || t("generalLedgerSetup.transactionBrowse.costCenterBrowseFile");
    link.click();
    setLoading(false);
  };

  const convertToXml = async () => {
    setLoading(true);
    const res: any = await dispatch(getCostCentresXMLData({ payload: generatePayload() }));
    const xmlData = res.payload.data;
    const blob = new Blob([xmlData], { type: "application/xml" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = res?.payload?.fileName ?? "file";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  return {
    convertToCsv,
    convertToPdf,
    convertToXml,
    fileObj,
    isLoading
  };
};

export default useCostCentrePreview;
