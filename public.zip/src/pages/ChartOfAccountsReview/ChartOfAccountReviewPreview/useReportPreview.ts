import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { getCurrentFinancialYear } from "@/types/UseStateType";
import { useHistory } from "react-router-dom";
import {
  acctReportPreviewCSV,
  acctReportPreviewPDF,
  acctReportPreviewXML
} from "../state/ChartOfAccountReportPreview.slice";

export const useReportPreview = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const dispatch = useDispatch<AppDispatch>();
  const historyState = history.location.state as any;
  const selectedfundCode = useAppSelector((state) => state.fundCode.selectedfundCode);

  const { budget, commitment, invoiced, actual, total, remaining } = useAppSelector(
    ({ chartOfAccountsReviewList }) => chartOfAccountsReviewList?.chartOfAccountsReviewList
  );
  const [pdfUri, setPdfUri] = useState<string>("");
  const [isLoading, setLoading] = useState<boolean>(false);

  const [fileObj, setFileObj] = useState<{
    fileData: string;
  }>({
    fileData: ""
  });

  interface MyResponseType {
    payload: string;
  }

  useEffect(() => {
    createPdfPreviewFromBase64();
  }, []);

  const createPdfPreviewFromBase64 = async () => {
    try {
      const { payload } = await dispatch(
        acctReportPreviewPDF({
          costId: historyState?.costCentreRecord?.cost_id,
          leddefId: historyState?.ledgerRecord?.leddef_id,
          fundId: selectedfundCode?.fund_id,
          costValue: historyState?.costCentreRecord?.cost_des,
          leddefValue: historyState?.ledgerRecord?.ledger_des,
          fundValue: selectedfundCode?.ledger_des,
          yearId: parseInt(getCurrentFinancialYear(), 10),
          showAllPreYrMovement: historyState?.isPreviousYearData,
          budget,
          commitment,
          invoiced,
          actual,
          total,
          remaining
        })
      );
      const { data } = payload as any;
      const blob = new Blob([data], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      setFileObj({
        fileData: pdfUri
      });
    } catch (error) {
      // console.error("Error decoding base64 string:", error);  //TODO: Error Handling
    }
  };

  const handlePdfClick = async () => {
    setLoading(true);
    const { payload } = await dispatch(
      acctReportPreviewPDF({
        costId: historyState?.costCentreRecord?.cost_id,
        leddefId: historyState?.ledgerRecord?.leddef_id,
        fundId: selectedfundCode?.fund_id,
        costValue: historyState?.costCentreRecord?.cost_des,
        leddefValue: historyState?.ledgerRecord?.ledger_des,
        fundValue: selectedfundCode?.ledger_des,
        yearId: parseInt(getCurrentFinancialYear(), 10),
        showAllPreYrMovement: historyState?.isPreviousYearData,
        budget,
        commitment,
        invoiced,
        actual,
        total,
        remaining
      })
    );
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName || "Chart of Accounts Review.pdf";
    link.click();
    setLoading(false);
  };

  const handleCsvClick = async () => {
    setLoading(true);
    const { payload } = await dispatch(
      acctReportPreviewCSV({
        costId: historyState?.costCentreRecord?.cost_id,
        leddefId: historyState?.ledgerRecord?.leddef_id,
        fundId: selectedfundCode?.fund_id,
        costValue: historyState?.costCentreRecord?.cost_des,
        leddefValue: historyState?.ledgerRecord?.ledger_des,
        fundValue: selectedfundCode?.ledger_des,
        yearId: parseInt(getCurrentFinancialYear(), 10),
        showAllPreYrMovement: historyState?.isPreviousYearData,
        budget,
        commitment,
        invoiced,
        actual,
        total,
        remaining
      })
    );
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName || "Chart of Accounts Review.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  const handleXmlClick = async () => {
    setLoading(true);
    const { payload } = await dispatch(
      acctReportPreviewXML({
        costId: historyState?.costCentreRecord?.cost_id,
        leddefId: historyState?.ledgerRecord?.leddef_id,
        fundId: selectedfundCode?.fund_id,
        costValue: historyState?.costCentreRecord?.cost_des,
        leddefValue: historyState?.ledgerRecord?.ledger_des,
        fundValue: selectedfundCode?.ledger_des,
        yearId: parseInt(getCurrentFinancialYear(), 10),
        showAllPreYrMovement: historyState?.isPreviousYearData,
        budget,
        commitment,
        invoiced,
        actual,
        total,
        remaining
      })
    );
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/xml" });
    // Create a download link for the Blob
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName || "Chart of Accounts Review.xml";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  return {
    handlePdfClick,
    handleCsvClick,
    handleXmlClick,
    pdfUri,
    fileObj,
    t,
    isLoading
  };
};

export default useReportPreview;
