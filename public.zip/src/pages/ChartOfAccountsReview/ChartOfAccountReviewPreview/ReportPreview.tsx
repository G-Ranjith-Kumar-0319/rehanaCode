import PreviewSection from "@/shared/components/Preview/PreviewSection";
import { Loader, LoaderType } from "@essnextgen/ui-kit";
import { useReportPreview } from "./useReportPreview";

const ReportPreview = () => {
  const { handlePdfClick, handleCsvClick, handleXmlClick, t, isLoading, fileObj } = useReportPreview();

  return (
    <>
      {isLoading ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Downloading file..."
          isLoaderModal
        />
      ) : null}
      <PreviewSection
        pageTitle={t("purchaseOrder.preview")}
        isBreadcrumbRequired
        className="charts-accounts-review wrapper__radius--0"
        pdfSrc={fileObj?.fileData}
        onPdfClick={handlePdfClick}
        onCsvClick={handleCsvClick}
        onXmlClick={handleXmlClick}
        isLoading={isLoading}
      />
    </>
  );
};

export default ReportPreview;
