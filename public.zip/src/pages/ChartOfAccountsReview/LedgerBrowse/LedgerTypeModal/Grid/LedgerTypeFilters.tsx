import { STATUS } from "@/types/UseStateType";
import {
  FormLabel,
  Grid,
  GridItem,
  RadioButton,
  RadioLabelPosition,
  TextInput,
  TextInputSize
} from "@essnextgen/ui-kit";
import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import useDebounce from "@/hooks/useDebounce";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import useNearestSearch from "@/hooks/useNearestSearch";
import columnDef from "./LedgerTypesColumnDef";
import { ledgerTypeActions } from "../../../state/LedgerTypes.slice";

const LedgerTypeFilters = ({ selectRow }: { selectRow: Dispatch<SetStateAction<RowType | undefined>> }) => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const dispatch = useDispatch<AppDispatch>();
  const { status, ledgerTypes, filters } = useAppSelector((state) => state.ledgerTypes);
  const debouncedValue = useDebounce(filters?.lookingFor!, 600);
  useNearestSearch({
    key: filters?.sequenceValue!,
    value: debouncedValue,
    rows: ledgerTypes,
    dataTestId: "ledgerTypesGrid",
    selectRow
  });

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(ledgerTypeActions.setFilters({ lookingFor: value.toUpperCase() }));
  };

  const handleSequenceChange = (value?: string) => {
    columnDef.map((col, index) => {
      if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });
    setColumn([...columnDef]);
    dispatch(ledgerTypeActions.setColumnDef(columns));
  };

  useEffect(() => {
    handleSequenceChange(filters?.sequenceValue);
  }, [filters?.sequenceValue]);

  return (
    <Grid
      className="custom-table"
      align="center"
    >
      <GridItem
        sm={12}
        md={4}
        xl={4}
      >
        <div className="essui-global-typography-default-h2">
          <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              autoFocus
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              id="looking-for"
              value={filters?.lookingFor}
              onChange={(e) => handleLookingForChange(e)}
              size={TextInputSize.Medium}
              readOnly={status === STATUS.LOADING}
            />
          </div>
        </div>
      </GridItem>

      <GridItem
        sm={12}
        md={4}
        xl={5}
      >
        <div className="essui-global-typography-default-h2">
          <FormLabel>{t("purchaseOrder.sequence")}</FormLabel>
          <div className="essui-textinput sequence">
            {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
              const sequenceId = `sequence=${index + 1}`;
              return (
                <RadioButton
                  label={column.sequenceName ? column.sequenceName : column.headerName}
                  name={column.field}
                  labelPosition={RadioLabelPosition.Right}
                  value={column.field}
                  onChange={() => {
                    dispatch(
                      ledgerTypeActions.setFilters({
                        lookingFor: "",
                        sequenceValue: String(column.field),
                        sequenceIndex: String(index)
                      })
                    );
                  }}
                  isSelected={filters?.sequenceValue === column.field}
                  key={sequenceId}
                />
              );
            })}
          </div>
        </div>
      </GridItem>
    </Grid>
  );
};

export default LedgerTypeFilters;
