import Layout from "@/components/Layout/Layout";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { useAppContext } from "@/routes/Routes";
import { useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { usNumberFormat } from "@/utils/getDataSource";
import { Grid, GridItem, FormLabel, Divider, Button, ButtonSize, ButtonColor } from "@essnextgen/ui-kit";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import { ledgersActions } from "../../state/Ledgers.slice";

const LedgerBrowseFooter = () => {
  const {
    ledgerBrowse: { ledgers, selectedLedger, status: ledgerStatus, filterState },
    ledgerTypes: { status: typesStatus },
    ledgerGroups: { status: groupsStatus }
  } = useAppSelector((state) => state);
  const dispatch = useDispatch();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { translate: locale } = useAppContext();

  const onSelectLedger = (selectedLedger: RowType | undefined) => {
    dispatch(ledgersActions.resetFilters());
    history.push(
      {
        pathname: "/general-ledger/chart-accounts-review"
      },
      { ...historyState, ledgerRecord: selectedLedger }
    );
  };

  const handlePreviewClick = () => {
    history.push(`${history.location.pathname}/preview`, { ...historyState });
  };

  return (
    <Layout
      isBreadcrumbRequired={false}
      className="charts-accounts-review"
    >
      <Grid
        container
        className="mt-12 justify__content--between row-gap-16 ml-60 mr-60"
      >
        <GridItem>
          <div>
            <FormLabel className="mb-5">{locale("ledgerBrowse.budget")}</FormLabel>
            <div>{usNumberFormat(ledgers?.budget)}</div>
          </div>
        </GridItem>
        <GridItem>
          <div>
            <FormLabel className="mb-5">{locale("ledgerBrowse.commitment")}</FormLabel>
            <div>{usNumberFormat(ledgers?.commitment)}</div>
          </div>
        </GridItem>
        <GridItem className="d-flex align-end">
          <div>
            <b>+</b>
          </div>
        </GridItem>
        <GridItem>
          <div>
            <FormLabel className="mb-5">{locale("ledgerBrowse.invoiced")}</FormLabel>
            <div>{usNumberFormat(ledgers?.invoiced)}</div>
          </div>
        </GridItem>
        <GridItem className="d-flex align-end">
          <div>
            <b>+</b>
          </div>
        </GridItem>
        <GridItem>
          <div>
            <FormLabel className="mb-5">{locale("ledgerBrowse.actual")}</FormLabel>
            <div>{usNumberFormat(ledgers?.actual)}</div>
          </div>
        </GridItem>
        <GridItem className="d-flex align-end">
          <div>
            <b>=</b>
          </div>
        </GridItem>
        <GridItem>
          <div>
            <FormLabel className="mb-5">{locale("ledgerBrowse.total")}</FormLabel>
            <div>{usNumberFormat(ledgers?.total)}</div>
          </div>
        </GridItem>
        <GridItem>
          <div>
            <FormLabel className="mb-5">{locale("ledgerBrowse.remaining")}</FormLabel>
            <div>{usNumberFormat(ledgers?.remaining)}</div>
          </div>
        </GridItem>
      </Grid>
      <Divider />
      <Grid className="mt-12">
        <GridItem
          sm={3}
          md={4}
          lg={6}
          xl={6}
        >
          <HelpButton
            identifier="testIdentifier"
            labelName="Help"
          />
        </GridItem>
        <GridItem
          sm={5}
          md={4}
          lg={6}
          xl={6}
        >
          <div className="d-flex justify-end">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              className="ml-4 mr-4"
              onClick={() => {
                dispatch(ledgersActions.resetFilters());
                history.push(
                  {
                    pathname: "/general-ledger/chart-accounts-review"
                  },
                  {
                    ...historyState,
                    excludeBalanceSheetAccounts: filterState.excludeBalanceSheetAccounts,
                    excludeNonZeroValues: filterState.excludeNonZeroValues
                  }
                );
              }}
            >
              {locale("common.cancel")}
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              className="ml-4 mr-4"
              onClick={handlePreviewClick}
            >
              {locale("generalLedgerSetup.preview")}
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
              className="ml-4 mr-4"
              onClick={() => onSelectLedger(selectedLedger)}
              disabled={
                !ledgers?.ledgerCodes?.length ||
                ledgerStatus !== STATUS.SUCCESS ||
                groupsStatus !== STATUS.SUCCESS ||
                typesStatus !== STATUS.SUCCESS
              }
            >
              {locale("generalLedgerSetup.select")}
            </Button>
          </div>
        </GridItem>
      </Grid>
    </Layout>
  );
};

export default LedgerBrowseFooter;
