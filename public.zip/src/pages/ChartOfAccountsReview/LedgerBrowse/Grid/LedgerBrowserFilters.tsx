import Input from "@/components/Input/Input";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  Dropdown,
  DropdownItem,
  FormLabel,
  Grid,
  GridItem,
  ISelectedItem,
  TextInputSize
} from "@essnextgen/ui-kit";
import { useAppContext } from "@/routes/Routes";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useState, FC, SyntheticEvent, useEffect, Dispatch, SetStateAction } from "react";
import useDebounce from "@/hooks/useDebounce";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import { useHistory } from "react-router-dom";
import { LedgersFiltersType, ledgersActions } from "../../state/Ledgers.slice";
import { ledgerGroupActions } from "../../state/LedgerGroups.slice";
import { ledgerTypeActions } from "../../state/LedgerTypes.slice";

type PropsType = {
  isOpen: (flag: boolean) => void;
  setIsDisabled: Dispatch<SetStateAction<boolean>>;
  isDisabled: boolean;
};

const LedgerBrowseFilters: FC<PropsType> = ({ isOpen, isDisabled, setIsDisabled }) => {
  const { translate: locale } = useAppContext();
  const dispatch = useDispatch();
  const [value, setValue] = useState<string>("");
  const { ledgerGroups, selectedGroup, status } = useAppSelector((state) => state.ledgerGroups);
  const { ledgers } = useAppSelector((state) => state.ledgerBrowse);
  const { ledgerTypes, selectedLedgerType } = useAppSelector((state) => state.ledgerTypes);
  const [ledgerTypeRow, setLedgerTypeRow] = useState<RowType | undefined>(selectedLedgerType);
  const { filterState } = useAppSelector((state) => state.ledgerBrowse);
  const { excludeNonZeroValues, excludeBalanceSheetAccounts, groupId } = filterState as LedgersFiltersType;
  const debouncedValue = useDebounce(value, 600);
  const [search, setSearch] = useState<string | undefined>();
  const history = useHistory();
  const historyState = history.location.state as any;

  useEffect(() => {
    setSearch(selectedLedgerType?.ledger_type);
    if (debouncedValue) {
      dispatch(
        ledgersActions.setFilters({
          ...filterState,
          lookingFor: debouncedValue.toUpperCase(),
          pageNumber: 1
        })
      );
    }
  }, [debouncedValue]);

  return (
    <Grid className="ledger-filters">
      <GridItem xl={2}>
        <Input
          onKeyDown={(event) => {
            // eslint-disable-next-line
            if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
              event.preventDefault();
            }
          }}
          labelText={locale("common.lookingFor")}
          value={value || filterState.lookingFor}
          onChange={(e) => {
            if (e.target.value !== "") {
              setValue(e.target.value.toUpperCase());
            } else {
              dispatch(
                ledgersActions.setFilters({
                  ...filterState,
                  lookingFor: "",
                  pageNumber: 1
                })
              );
            }
          }}
        />
      </GridItem>
      <GridItem xl={3}>
        <Input
          labelText={locale("ledgerBrowse.viewType")}
          inputWidth={90}
          searchable
          value={search}
          searchItems={ledgerTypes.map((l) => ({
            text: l.ledger_type,
            value: l.description
          }))}
          onNoSelection={() => {
            isOpen(true);
          }}
          onFocus={() => {
            setSearch(undefined);
          }}
          onPending={(selectedItem, index, flag) => {
            setLedgerTypeRow(index ? ledgerTypes.at(index) : undefined);
            if (flag === false) {
              setSearch("");
            }
            if (!selectedItem?.text && flag !== false && flag !== undefined) {
              dispatch(ledgerTypeActions.selectRow(undefined));
              dispatch(
                ledgersActions.setFilters({
                  ...filterState,
                  excludeBalanceSheetAccounts: false,
                  ledgerType: "",
                  lookingFor: "",
                  pageNumber: 1
                })
              );
            }
          }}
          onSelect={(selectedItem) => {
            if (selectedItem?.text) {
              setIsDisabled(true);
              dispatch(ledgerTypeActions.selectRow(ledgerTypes.find((t) => t.ledger_type === selectedItem?.text)));
              dispatch(
                ledgersActions.setFilters({
                  ...filterState,
                  ledgerType: selectedItem?.text,
                  lookingFor: "",
                  pageNumber: 1
                })
              );
            }
          }}
          button={
            <Input
              className="read-only"
              searchBtnClick={() => isOpen(true)}
              value={ledgerTypeRow?.description ?? ""}
              disabled
            />
          }
        />
      </GridItem>
      <GridItem>
        <FormLabel>{locale("ledgerBrowse.viewGroup")}</FormLabel>
        <Dropdown
          size={TextInputSize.Medium}
          searchable
          selectedItem={selectedGroup}
          isScrollbarVisible
          className="width-revert"
          onSelect={(e: SyntheticEvent, item: ISelectedItem) => {
            setIsDisabled(true);
            dispatch(ledgerGroupActions.setGroup(item));
            dispatch(
              ledgersActions.setFilters({
                ...filterState,
                lookingFor: "",
                excludeBalanceSheetAccounts: false,
                pageNumber: 1,
                groupId: Number(item.value)
              })
            );
          }}
          scrollbarHeight={Number(ledgers?.totalCount || 0) <= 3 ? 120 : undefined}
        >
          {(ledgerGroups || []).map((view: { [key: string]: string }, i: any) => {
            const id = `dropdown-group-${i}`;
            return (
              <DropdownItem
                key={id}
                id={id}
                text={view.group_des}
                value={view.group_id}
              >
                {view?.group_des}
              </DropdownItem>
            );
          })}
        </Dropdown>
      </GridItem>
      <GridItem
        xl={3}
        className="d-flex f-direction-col justify-center gap-8"
      >
        <CheckBox
          isSelected={excludeNonZeroValues === true}
          onChange={(e) => {
            dispatch(
              ledgersActions.setFilters({
                ...filterState,
                excludeNonZeroValues: !excludeNonZeroValues,
                pageNumber: 1
              })
            );
          }}
          label={locale("ledgerBrowse.ledgerCodeExclude")}
        />

        <CheckBox
          isSelected={
            excludeBalanceSheetAccounts === true &&
            !(isDisabled || historyState?.costCentreRecord?.cost_id !== undefined)
          }
          onChange={(e) => {
            dispatch(
              ledgersActions.setFilters({
                ...filterState,
                excludeBalanceSheetAccounts:
                  !excludeBalanceSheetAccounts &&
                  !(isDisabled || historyState?.costCentreRecord?.cost_id !== undefined),
                pageNumber: 1
              })
            );
          }}
          label={locale("ledgerBrowse.balanceSheetExclude")}
          disabled={isDisabled || historyState?.costCentreRecord?.cost_id !== undefined}
        />
      </GridItem>
      <GridItem className="m-auto">
        <Button
          color={ButtonColor.Secondary}
          size={ButtonSize.Small}
          onClick={() => {
            dispatch(ledgersActions.resetFilters());
            dispatch(ledgerTypeActions.selectRow(undefined));
            dispatch(ledgerGroupActions.setGroup({ text: "", value: "" }));
            setIsDisabled(false);
          }}
        >
          {locale("ledgerBrowse.reset")}
        </Button>
      </GridItem>
    </Grid>
  );
};

export default LedgerBrowseFilters;
