import { AppDispatch, useAppSelector } from "@/store/store";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import {
  getLedgerBrowseCSV,
  getLedgerBrowsePDF,
  getLedgerBrowseXML
} from "../../state/ChartOfAccountsReviewList.slice";

const useLedgerBrowsePreview = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const dispatch = useDispatch<AppDispatch>();

  const [isLoading, setLoading] = useState<boolean>(false);
  const [fileObj, setFileObj] = useState<{
    fileData: string;
  }>({
    fileData: ""
  });

  const historyState = history.location.state as any;
  const { selectedGroup } = useAppSelector((state) => state.ledgerGroups);
  const { selectedLedgerType } = useAppSelector((state) => state.ledgerTypes);

  const generatePayload = () => ({
    costId: Number(historyState?.costCentreRecord?.cost_id) || 0,
    costCentreDescription: historyState?.costCentreRecord?.cost_des || t("ledgerBrowse.allCostCentres"),
    type: selectedLedgerType?.ledger_type || "",
    typeDescription: selectedLedgerType?.description || t("ledgerBrowse.allLedgerTypes"),
    groupId: Number(selectedGroup?.value) || 0,
    groupDescription: selectedGroup?.text || t("ledgerBrowse.allLedgerGroups"),
    excludeNonZeroValues: historyState.excludeNonZeroValues,
    excludeBalanceSheetAccounts: historyState.excludeBalanceSheetAccounts,
    Holder: historyState?.costCentreRecord?.cost_hold
  });

  const createPdfPreviewFromBase64 = async () => {
    try {
      const { payload } = await dispatch(getLedgerBrowsePDF({ payload: generatePayload() }));
      const { data } = payload as any;
      const blob = new Blob([data], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      setFileObj({
        fileData: pdfUri
      });
    } catch (error) {
      setLoading(false);
      console.error("Error decoding base64 string:", error);
    }
  };

  useEffect(() => {
    createPdfPreviewFromBase64();
  }, []);

  const convertToPdf = async () => {
    setLoading(true);
    const { payload } = await dispatch(getLedgerBrowsePDF({ payload: generatePayload() }));
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName || `${t("ledgerBrowse.ledgerBrowseFile")}.pdf`; // Set the download attribute with file extension
    link.click();
    setLoading(false);
  };

  const convertToXml = async () => {
    setLoading(true);
    const res: any = await dispatch(getLedgerBrowseXML({ payload: generatePayload() }));
    const xmlData = res.payload.data;
    const blob = new Blob([xmlData], { type: "application/xml" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = res?.payload?.fileName ?? t("ledgerBrowse.ledgerBrowseFile");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  const convertToCsv = async () => {
    setLoading(true);
    const res: any = await dispatch(getLedgerBrowseCSV({ payload: generatePayload() }));
    const csvData = res.payload.data;
    const blob = new Blob([csvData], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = res?.payload?.fileName ?? t("ledgerBrowse.ledgerBrowseFile");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setLoading(false);
  };

  return {
    convertToCsv,
    convertToPdf,
    convertToXml,
    fileObj,
    isLoading
  };
};

export default useLedgerBrowsePreview;
