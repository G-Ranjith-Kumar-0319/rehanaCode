import { Button, ButtonColor, ButtonSize, Tooltip } from "@essnextgen/ui-kit";
import Layout from "@/components/Layout/Layout";
import "./Style.scss";
import { Csv } from "@carbon/icons-react/lib/generated/bucket-3";
import { Pdf, Xml } from "@carbon/icons-react";
import { useChartOfAccountPreviewPre } from "./useChartsOfAccountReviewPre";

const ChartsAccountsReviewPre = () => {
  const { convertToCsv, convertToPdf, convertToXml, fileObj, t } = useChartOfAccountPreviewPre();

  return (
    <>
      <Layout
        pageTitle="Preview"
        isBreadcrumbRequired
        className="charts-accounts-review wrapper__radius--0"
      >
        <div className="container">
          <div className="preview__pdf--view">
            <div className="preview__btn">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={() => convertToPdf()}
                aria-label="pdf"
                className="essui-button-icon-only--small"
              >
                <Tooltip content={t("common.pdf")}>
                  <span className="button-content">
                    <Pdf size="22" />
                  </span>
                </Tooltip>
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={() => {
                  convertToCsv();
                }}
                aria-label="csv"
                className="essui-button-icon-only--small"
              >
                <Tooltip
                  className="tooltip-custom"
                  content={t("common.csv")}
                >
                  <span className="button-content">
                    <Csv size="22" />
                  </span>
                </Tooltip>
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={() => convertToXml()}
                aria-label="xml"
                className="essui-button-icon-only--small"
              >
                <Tooltip content={t("common.xml")}>
                  <span className="button-content">
                    <Xml size="22" />
                  </span>
                </Tooltip>
              </Button>
            </div>
            <div className="main-pdf">
              <div className="border br-8 overflow-hidden centerval">
                <iframe
                  src={`${fileObj.filedata}#toolbar=0` || ""}
                  title="PDF Document"
                  style={{
                    width: "100%",
                    height: "500px", // Adjust the height as needed
                    border: "none",
                    transformOrigin: "top left"
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
};
export default ChartsAccountsReviewPre;
