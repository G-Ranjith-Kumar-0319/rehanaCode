import { cellRendererType } from "@/components/GridTable/GridTable";
import { Button, ButtonColor } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { getDate } from "@/utils/getDataSource";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useHistory, useParams } from "react-router-dom";
import { RootContext, useAppContext } from "@/routes/Routes";
import useTransactionSelectPeriod from "../useTransactionSelectPeriod";

const CustomCell = ({ field, row }: cellRendererType) => {
  const { selectedTransactionRow } = useTransactionSelectPeriod();

  const { fromDate, toDate } = useParams<{ fromDate: string; toDate: string }>();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const historyState = history.location.state as any;

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const getContent = () => {
    if (field === "actions") {
      return (
        <>
          <Button
            color={ButtonColor.Utility}
            className="segments-buttons"
            onClick={() => {
              history.push({
                pathname: `/general-ledger/chart-accounts-review/transaction-period/from/${fromDate}/to/${toDate}/transaction-details/${row?.user_id}`,
                state: {
                  ...historyState,
                  transactionBrowseRow: row,
                  selectedRowState: selectedTransactionRow
                }
              });
            }}
          >
            {t("common.view02")}
          </Button>
        </>
      );
    }
    if (field === "debit") {
      const formattedDebit =
        row?.debit !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.debit) : specialCharacters.zero;
      return <>{formattedDebit}</>;
    }
    if (field === "credit") {
      return <>{row?.credit !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.credit) : specialCharacters.zero}</>;
    }
    if (field === "journal_date") {
      return <>{getDate(row?.journal_date)}</>;
    }
    if (field === "narrative") {
      return <>{`${row?.narrative} ${row?.pct_narrative || ""}`}</>;
    }
    return null;
  };
  return getContent();
};

export default CustomCell;
