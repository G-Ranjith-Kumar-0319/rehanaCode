import { useEffect, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import Layout from "@/components/Layout/Layout";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  Divider,
  Grid,
  GridItem,
  Loader,
  LoaderType
} from "@essnextgen/ui-kit";
import { useHistory, useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import "./Style.scss";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { STATUS } from "@/types/UseStateType";
import CustomCell from "./Grid/CustomCell";
import transactionSelectPeriodDef from "./Grid/columnDef";
import useTransactionSelectPeriod from "./useTransactionSelectPeriod";
import { getFinancialPeriods, getTransactions, financialPeriodActions } from "../state/financialPeriod.slice";

const TransactionSelectPeriod = () => {
  const { t, selectedTransactionRow, selectedRowHandler, historyState, onCloseHandler, onSelectHandler } =
    useTransactionSelectPeriod();
  const { fromDate, toDate } = useParams<{ fromDate: string; toDate: string }>();
  const dispatch = useDispatch<AppDispatch>();
  const [isFromDescription, setIsFromDescription] = useState("");
  const [isToDescription, setIsToDescription] = useState("");
  const [responseData, setResponseData] = useState([]);
  const { transactionStatus } = useAppSelector((state) => state.financialPeriods);
  const isLoading = transactionStatus === STATUS.LOADING;
  const selectedfundCode = useAppSelector((state) => state.fundCode.selectedfundCode);
  const history = useHistory();
  const costId = historyState?.costCentreRecord?.cost_id || 0;
  const leddefId = historyState?.ledgerRecord?.leddef_id || 0;
  const fundId = selectedfundCode?.fund_id ? selectedfundCode?.fund_id : 0;

  useEffect(() => {
    dispatch(
      getFinancialPeriods({
        status: 0,
        callback: (data) => {
          const fromDescription = data.find((p: any) => String(p.period_no) === fromDate);
          setIsFromDescription(fromDescription?.description);

          const toDescription = data.find((p: any) => String(p.period_no) === toDate);
          setIsToDescription(toDescription?.description);
        }
      })
    );

    getTransactionsDetails();
  }, []);

  const getTransactionsDetails = async () => {
    const result: any = await dispatch(
      getTransactions({
        fromPeriodNo: fromDate,
        toPeriodNo: toDate,
        costId,
        leddefId,
        fundId
      })
    );
    setResponseData(result.payload.tranDetails);
  };

  const handlePreviewClick = () => {
    history.push(`${history.location.pathname}/preview`, { ...historyState });
  };

  useEffect(() => {
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      if (location.pathname === "/general-ledger/chart-accounts-review") {
        dispatch(financialPeriodActions.resetSelectedRow());
      }
    });
    return () => {
      unblock();
    };
  }, [history]);

  useEffect(() => {
    if (selectedTransactionRow?.journal_id === historyState?.selectedRowState?.journal_id) {
      const element = document.querySelector(".selected-row");
      element?.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    }
  }, [selectedTransactionRow]);

  return (
    <>
      <div className="loader-wrapper">
        {isLoading && (
          <Loader
            loaderType={LoaderType.Circular}
            loaderText="Please wait"
            isLoaderModal
          />
        )}
      </div>
      <Layout
        pageTitle={t("generalLedgerSetup.transactionBrowse.transactionBrowse")}
        isBreadcrumbRequired
        type="transparent"
        className="transaction-select-period"
      >
        <GridTableNew
          dataTestId="testGrid"
          id="testGrid"
          columnDef={transactionSelectPeriodDef}
          dataSource={responseData || []}
          isLoading={selectedTransactionRow === undefined && responseData.length === 0}
          customCell={CustomCell}
          selectedRow={selectedTransactionRow}
          selectedRowHandler={(row) => dispatch(financialPeriodActions.setSelectedRow(row))}
          isScrollable
          enableScrollIntoView
          useDeepSearch
        />
      </Layout>
      <Layout isBreadcrumbRequired={false}>
        <Grid className="mt-8">
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="essui-form-label">{t("generalLedgerSetup.periodFrom")}</div>
            <div className="mt-8">
              <span className="mr-4">{fromDate}</span>
              <span className="mr-4">{isFromDescription}</span>
              <strong className="mr-4">{t("generalLedgerSetup.to")}</strong>
              <span className="mr-4">{toDate}</span>
              {isToDescription}
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="essui-form-label">{t("generalLedgerSetup.cost")}</div>
            <div className="mt-8">{historyState?.costCentreRecord?.cost_des || "All Cost Centres"}</div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="essui-form-label">{t("generalLedgerSetup.ledger")}</div>
            <div className="mt-8">{historyState?.ledgerRecord?.ledger_des || "All Ledger Codes"}</div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="essui-form-label">{t("generalLedgerSetup.fund")}</div>
            <div className="mt-8">
              {selectedfundCode?.ledger_des ? selectedfundCode.ledger_des : t("purchaseOrder.allFunds")}
            </div>
          </GridItem>
        </Grid>
        <Divider />
        <Grid
          className="mt-16"
          justify="space-between"
        >
          <GridItem
            sm={8}
            lg={6}
            md={4}
          >
            <HelpButton
              identifier="help-button"
              labelName={t("common.help")}
            />
          </GridItem>
          <GridItem
            sm={8}
            lg={6}
            md={4}
          >
            <div className="d-flex justify-end gap-8">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={onCloseHandler}
              >
                {t("generalLedgerSetup.close")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={handlePreviewClick}
              >
                {t("generalLedgerSetup.preview")}
              </Button>
              <Button
                size={ButtonSize.Small}
                onClick={onSelectHandler}
              >
                {t("common.view02")}
              </Button>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};

export default TransactionSelectPeriod;
