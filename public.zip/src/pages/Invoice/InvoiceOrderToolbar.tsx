import React, { BaseSyntheticEvent, SyntheticEvent, useContext, useEffect, useState } from "react";
import {
  AddLarge,
  ArrowDown,
  ArrowUp,
  DataCheck,
  Printer,
  Reset,
  Save,
  Thumbnail_2 as ThumbNail2
} from "@carbon/icons-react";
import { ButtonSize, NotificationStatus } from "@essnextgen/ui-kit";
import { RouteComponentProps, withRouter, useHistory, useParams } from "react-router-dom";
import Toolbar, { ToolbarType } from "@/components/Toolbar/Toolbar";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { invoiceOrderType, sundryInvoiceType } from "@/utils/constants";
import {
  BOOLEAN_DATA,
  INVOICE_LINE_TYPE,
  INVOICE_STATUS,
  INVOICE_TYPE,
  RESPONSE_STATUS,
  STATUS,
  getCurrentFinancialYear,
  invoiceLineType,
  invoiceTypesName,
  specialCharacters
} from "@/types/UseStateType";
import SelectInvoiceTypeModal from "@/shared/components/SelectInvoiceTypeModal/SelectInvoiceTypeModal";
import { actions as supplierActions } from "@/pages/Invoice/State/InvoiceSupplierList.slice";
import { actions as ioLineActions } from "@/pages/Invoice/State/InvoiceNoteLineItem.slice";
import { actions as invoicePayAction } from "@/pages/Invoice/State/InvoicePayFrom.slice";
import { getInvoiceDetails, actions as ioDetailsActions } from "@/pages/Invoice/State/InvoiceNoteDetails";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { RootContext, useAppContext } from "@/routes/Routes";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import useHotKeys from "@/components/HotKeys/UseHotKeys";
import { invocieActiveStatus, invoiceDocument, actions as ioActions } from "./State/InvoiceNoteList.slice";
import useInvoiceLineItem from "./CreditNoteProcessing/InvoiceOrderView/useInvoiceLineItem";

const InvoiceOrderToolbar = ({
  isDirty,
  resolve,
  openModal,
  onSubmit,
  goToPrevRecord,
  goToNextRecord,
  setPromise,
  setIsViewDetail,
  resetForm,
  setIsChanged,
  isChanged = false,
  setIsRerender,
  isRerender,
  isHotKeyCalled
}: {
  isDirty?: boolean;
  isHotKeyCalled?: any;
  resolve?: any;
  openModal?: any;
  setPromise?: any;
  setIsViewDetail?: any;
  setIsChanged?: React.Dispatch<React.SetStateAction<boolean>>;
  setIsRerender?: React.Dispatch<React.SetStateAction<boolean>>;
  isChanged?: boolean;
  isRerender?: boolean;
  onSubmit?: () => Promise<boolean>;
  goToPrevRecord?: (e: SyntheticEvent) => void;
  goToNextRecord?: (e: SyntheticEvent) => void;
  resetForm?: any;
} & RouteComponentProps) => {
  const history = useHistory();
  const {
    location: { pathname }
  } = history;
  let historyState = history.location.state as any;
  const { getNewOldVatValues } = useInvoiceLineItem();
  const { redirectToInvoiceDetailsLink } = useAppContext();
  const { selectedRow, addInvoiceOrderStatus, filterState } = useAppSelector((state) => state.invoiceNote);
  const { invoiceDetails, invoiceAllOrder } = useAppSelector((state) => state.invoiceDetails);
  const { invoiceId, orderno, payeeId } = useParams<{
    orderno: string;
    invoiceId: any;
    clientId: any;
    payeeId: any;
  }>();
  const invoiceData = invoiceId ? invoiceDetails : selectedRow;
  const dispatch = useDispatch<AppDispatch>();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [isUndoModalOpen, setIsUndoModalOpen] = useState<boolean>(false);
  const [isInvoiceTypeModalOpen, setIsInvoiceTypeModalOpen] = useState(false);
  const { alert } = useAppSelector((state) => state.ui);
  const getSessionFilter = getSessionItem("filterState");
  const currentInvoiceType = sessionStorage.getItem("invoiceType");
  const { orderSelectedRow } = useAppSelector((state) => state.createOrderInvoice);
  const { invoiceNoteLineItem } = useAppSelector((state) => state.invoiceNoteLineItem);
  const handleInvoiceOrderType = (type: string) => {
    if (type !== "") {
      sessionStorage.setItem("invoiceType", type);
      dispatch(ioLineActions.setAddInvoiceType(type));
      dispatch(ioLineActions.resetInvoiceLineItem());
      dispatch(ioLineActions.resetSelectedRow());
      dispatch(ioDetailsActions.resetInvoiceDetails());
      dispatch(ioDetailsActions.setInvoiceNotes(""));
      dispatch(supplierActions.resetSelectedSupplier());
      dispatch(supplierActions.resetSelectedRow());
      dispatch(invoicePayAction.resetSelectedRow());
      dispatch(ioDetailsActions.resetOrderPrefixDetail());
      if (resetForm) resetForm(); // Reseting the invoice order form

      if (type === INVOICE_TYPE.NONORDERINV) {
        history.push("/invoice-credit-note/non-order/add");
      } else if (type === INVOICE_TYPE.SUNDRYINV) {
        history.push("/invoice-credit-note/sundry/add");
      } else if (type === INVOICE_TYPE.ORDERINV) {
        history.push("/invoice-credit-note/order/add");
      } else if (type === INVOICE_TYPE.CREDITNOTEINV) {
        history.push("/invoice-credit-note/credit-note/add");
      }
    }
  };
  const handlePrint = async () => {
    dispatch(ioActions.setIsPrintLoading(true));
    const res = await dispatch(invoiceDocument(invoiceData?.invoice_id));
    if (res?.meta?.requestStatus === RESPONSE_STATUS.FULFILLED) {
      const pdfData = res.payload as string;
      const byteCharacters = atob(pdfData);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i += 1) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank");
    }
    dispatch(ioActions.setIsPrintLoading(false));
  };

  const checkSaveChanges = (refreshOnRollback: boolean) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: "invalidData"
      })
    );
  };

  useEffect(
    () => () => {
      setToSession("invoiceIsFocus", false);
    },
    []
  );

  useEffect(() => {
    if (addInvoiceOrderStatus === STATUS.SUCCESS) {
      if (resolve) resolve(true);
    }
  }, [addInvoiceOrderStatus]);

  useEffect(() => {
    if (historyState?.invoiceLineList && setIsChanged) {
      const toggle = historyState?.invoiceLineList?.some((o: any) => o.is_changed === true || o.deleted === true);
      if (toggle) setIsChanged(toggle);
    }
  }, [historyState?.invoiceLineList]);

  let flag = false;
  // TODO: Breadcrumb keep your changes
  useEffect(() => {
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      if (
        // location.pathname === "/invoice-credit-note" &&
        location.pathname === "/invoice-credit-note" &&
        !alert?.enable &&
        !getSessionItem("invoiceIsFocus") &&
        (isDirty ||
          getSessionItem("isHotKey") ||
          isChanged ||
          historyState?.isDirty ||
          pathname === "/invoice-credit-note/non-order/add" ||
          pathname === "/invoice-credit-note/order/add" ||
          pathname === "/invoice-credit-note/credit-note/add")
      ) {
        dispatch(
          uiActions.confirmPopup({
            enable: true,
            message: t("alertMessage.keepChangesMsg"),
            title: t("common.simsFMSModule"),
            type: MODAL_TYPE.CONFIRMV2,
            yesCallback: async () => {
              let result;
              if (onSubmit) {
                result = await onSubmit();
                if (result === false) {
                  history.push("/invoice-credit-note");
                }
              }
            },
            noCallback: () => {
              flag = true;
              history.push("/invoice-credit-note");
            },
            isCancelBtnEnable: true
          })
        );

        if (!flag) {
          // dispatch(ioDetailsActions.resetInvoiceDetails());
          return false;
        }
      }
    });

    return () => {
      unblock();
    };
  }, [history, alert?.enable, isDirty, isChanged, historyState?.isDirty, getSessionItem("isHotKey")]);

  const isDisableInvoiceAll = () =>
    history.location.pathname === "/invoice-credit-note" || currentInvoiceType !== INVOICE_TYPE.ORDERINV;

  const butons: ToolbarType[] = [
    {
      title: t("common.focusMode"),
      element: <ThumbNail2 size={18} />,
      size: ButtonSize.Small,
      onClick: async () => {
        if (invoiceId) {
          dispatch(ioActions.resetFocus());
        } else {
          dispatch(ioActions.setFocus());
        }
        if (invoiceData) {
          dispatch(ioActions.setSelectedRow(invoiceData));
        }
        let result;
        let isError;
        if (
          (history.location.pathname !== "/invoice-credit-note" &&
            (isDirty || getSessionItem("isHotKey") || isChanged)) ||
          history.location.pathname === "/invoice-credit-note/non-order/add" ||
          history.location.pathname === "/invoice-credit-note/order/add" ||
          history.location.pathname === "/invoice-credit-note/credit-note/add"
        ) {
          setToSession("invoiceIsFocus", true);
          result = await setPromise(() => checkSaveChanges(false));
          if (onSubmit && result) {
            isError = await onSubmit();
            if (isError) {
              return;
            }
            if (isError === false) {
              await dispatch(
                getInvoiceDetails({
                  invoiceId,
                  callback: (data) => {
                    if (data?.status) {
                      const filters = filterState || getSessionFilter;
                      if (!data?.status || !filters?.status) {
                        history.push("/invoice-credit-note");
                        return;
                      }
                      if (filters?.status !== specialCharacters.BLANKVALUE && filters?.status !== data?.status) {
                        dispatch(ioDetailsActions.setRedirectAlertModal(true));
                      } else {
                        history.push("/invoice-credit-note");
                      }
                    }
                  }
                })
              );

              return;
            }
          }
          if (result === false) {
            history.push("/invoice-credit-note");
            return;
          }
          if (result === undefined) {
            return;
          }
        }
        if (window.location.href.includes("/add")) {
          history.push("/invoice-credit-note");
          return;
        }
        let invoiceTypeStr = "";

        // This will handle edit route for unauthorized and authorized
        const handleEditRoute = () => {
          const editable = [INVOICE_STATUS.UNAUTHORISED, INVOICE_STATUS?.AUTHORISED];
          if (editable.includes(selectedRow?.status)) {
            return "edit-";
          }
          return "";
        };
        //

        if (invoiceData?.invoice_type === invoiceOrderType.pi) {
          if (invoiceData?.order_id !== "" && invoiceData?.order_id !== null) {
            invoiceTypeStr = handleEditRoute() ? invoiceTypesName.EDIT_ORDER_INVOICE : invoiceTypesName?.ORDER_INVOICE;
          } else if (invoiceData?.sundry_invoice === sundryInvoiceType.t) {
            invoiceTypeStr = invoiceTypesName?.SUNDARY_INVOICE;
          } else {
            invoiceTypeStr = handleEditRoute()
              ? invoiceTypesName.EDIT_NON_ORDER_INVOICE
              : invoiceTypesName?.NON_ORDER_INVOICE;
          }
        } else if (invoiceData?.invoice_type === invoiceOrderType.pc) {
          invoiceTypeStr = handleEditRoute() ? invoiceTypesName.EDIT_CREDIT_NOTE : invoiceTypesName?.CREDIT_NOTE;
        }

        const invoiceDetailsLink = `invoice-credit-note/${invoiceTypeStr}${
          invoiceData?.order_id ? `/orderno/${invoiceData?.order_id}` : ""
        }/invoiceId/${invoiceData?.invoice_id ? invoiceData?.invoice_id : ""}`;

        if (window.location.href.includes(invoiceDetailsLink) || invoiceData === undefined) {
          history.push("/invoice-credit-note");
        } else {
          history.push(invoiceDetailsLink);
        }
      }
    },
    {
      title: t("common.previousRecord"),
      element: <ArrowUp size={18} />,
      size: ButtonSize.Small,
      onClick: async (e) => {
        let result;
        let isError;
        if (
          history.location.pathname !== "/invoice-credit-note" &&
          (isDirty || getSessionItem("isHotKey") || isChanged)
        ) {
          result = await setPromise(() => checkSaveChanges(false));
          if (onSubmit && result) {
            setToSession("invoiceIsNext", true);
            isError = await onSubmit();
            setToSession("invoiceIsNext", false);
            if (isError) {
              return;
            }
            if (isError === false && goToPrevRecord) {
              goToPrevRecord(e);
              return;
            }
          }
          if (result === undefined) {
            return;
          }
          if (result === false) {
            if (goToPrevRecord) goToPrevRecord(e);
            return;
          }
        }

        if (
          isError === undefined ||
          isError === false ||
          result === false ||
          (isError === undefined && result === undefined)
        ) {
          if (goToPrevRecord) goToPrevRecord(e);
        }
      }
    },
    {
      title: t("common.nextRecord"),
      element: <ArrowDown size={18} />,
      size: ButtonSize.Small,
      id: "btnNextRec",
      onClick: async (e) => {
        let result;
        let isError;
        if (
          history.location.pathname !== "/invoice-credit-note" &&
          (isDirty || getSessionItem("isHotKey") || isChanged)
        ) {
          result = await setPromise(() => checkSaveChanges(false));
          if (onSubmit && result) {
            setToSession("invoiceIsNext", true);
            isError = await onSubmit();
            setToSession("invoiceIsNext", false);
            if (isError) {
              return;
            }
            if (isError === false && goToNextRecord) {
              goToNextRecord(e);
              return;
            }
          }
          if (result === undefined) {
            return;
          }
          if (result === false) {
            if (goToNextRecord) goToNextRecord(e);
            return;
          }
        }
        if (
          isError === undefined ||
          isError === false ||
          result === false ||
          (isError === undefined && result === undefined)
        ) {
          if (goToNextRecord) goToNextRecord(e);
        }
      }
    },
    {
      title: t("common.addRecord"),
      element: <AddLarge size={18} />,
      onClick: async () => {
        let result;
        if (
          (history.location.pathname !== "/invoice-credit-note" &&
            (isDirty || getSessionItem("isHotKey") || isChanged)) ||
          history.location.pathname === "/invoice-credit-note/non-order/add" ||
          history.location.pathname === "/invoice-credit-note/order/add" ||
          history.location.pathname === "/invoice-credit-note/credit-note/add"
        ) {
          dispatch(
            uiActions.confirmPopup({
              title: t("alertMessage.title"),
              message: t("alertMessage.keepChangesMsg"),
              yesCallback: () => (onSubmit ? onSubmit() : null),
              noCallback: () => {
                setIsInvoiceTypeModalOpen(true);
                setIsViewDetail(false);
              },
              type: MODAL_TYPE.CONFIRMV2
            })
          );
        } else {
          setIsInvoiceTypeModalOpen(true);
        }
      },
      size: ButtonSize.Small
    },
    {
      title: t("common.saveRecordChanges"),
      element: <Save size={18} />,
      onClick: () => {
        dispatch(ioLineActions.setIsInvCancelInitialed(false));
        dispatch(ioLineActions.setIsInvAuthorizeInitialed(false));
        dispatch(ioLineActions.setIsInvSaveSuccess(false));
        if (onSubmit) onSubmit();
      },
      size: ButtonSize.Small
    },
    {
      title: t("common.undoRecordChanges"),
      element: <Reset size={18} />,
      size: ButtonSize.Small,
      onClick: () => {
        if (
          (history.location.pathname !== "/invoice-credit-note" &&
            (isDirty || getSessionItem("isHotKey") || isChanged)) ||
          history.location.pathname === "/invoice-credit-note/non-order/add" ||
          history.location.pathname === "/invoice-credit-note/order/add" ||
          history.location.pathname === "/invoice-credit-note/credit-note/add"
        ) {
          setIsUndoModalOpen(true);
        }
      }
    },
    {
      title: t("common.printRecord"),
      onClick: () => handlePrint(),
      element: <Printer size={18} />,
      size: ButtonSize.Small
    },
    {
      title: t("common.invoiceAll"),
      onClick: () => handleOnKeyPress(),
      element: <DataCheck size={18} />,
      size: ButtonSize.Small,
      disabled: isDisableInvoiceAll()
    }
  ];

  useHotKeys({
    keyName: "F7",
    handleOnKeyPress: () => {
      handleOnKeyPress();
    }
  });

  const handleOnKeyPress = () => {
    if (
      invoiceNoteLineItem.length > 0 &&
      currentInvoiceType === INVOICE_TYPE.ORDERINV &&
      ((orderno &&
        history.location.pathname.includes("/invoice-credit-note") &&
        (!history.location.pathname.includes("add/edit-line-item") ||
          !history.location.pathname.includes("add/edit-item"))) ||
        history.location.pathname === "/invoice-credit-note/order/add")
    ) {
      dispatch(
        invocieActiveStatus({
          yearId: getCurrentFinancialYear(),
          callback: (res: any) => {
            let filteredInvoiceOrderType;
            if (orderno) {
              filteredInvoiceOrderType = invoiceAllOrder?.filter((key: any) => key.id.toString() === orderno)[0]
                ?.order_type;
            } else {
              filteredInvoiceOrderType = historyState?.invoiceDetails?.order_type ?? orderSelectedRow?.order_type;
            }
            if (res === BOOLEAN_DATA.True && filteredInvoiceOrderType !== invoiceLineType.strFreeTxtOrdLine) {
              dispatch(
                uiActions.alertPopup({
                  enable: true,
                  type: MODAL_TYPE?.ALERT,
                  title: t("common.simsFMSModule"),
                  message: t("invoiceNote.invoiceActiveStatus"),
                  notificationType: NotificationStatus?.WARNING,
                  className: "primary-focus",
                  callback() {
                    manageLineItemData();
                  }
                })
              );
            } else {
              manageLineItemData();
            }
          }
        })
      );
    }
  };

  const calculateVat = (lineItemVal: any) => {
    const vatRate = lineItemVal.rate;
    let vat = 0;
    if (lineItemVal) {
      vat = +((lineItemVal?.base_free_text_remaining_amt / 100) * vatRate);
    }
    return vat;
  };

  const calculateLineCost = (lineItemVal: any) => {
    let lineCost = 0;
    if (lineItemVal) {
      lineCost = +(
        lineItemVal.inv_unit_cost *
        lineItemVal?.base_qty_out_with_del *
        ((100 - lineItemVal.discount) / 100)
      );
    }
    return lineCost;
  };

  const manageLineItemData = () => {
    if (historyState?.invoiceLineList.length > 0) {
      historyState?.invoiceLineList.map((line: any, index: any) => {
        if (line.line_type === invoiceLineType.strInvoiceLine) {
          if (line.type === invoiceLineType.strFreeTxtOrdLine) {
            if (line.line_cost === null || line.line_cost === "0.00" || line.line_cost === 0) {
              const updatedLines = {
                ...line,
                order_line_qty_inv: 1,
                old_line_cost: line.line_cost,
                line_cost: line.base_free_text_remaining_amt,
                free_text_remaining_amt: line.base_free_text_remaining_amt - line.line_cost,
                vat_amount: calculateVat(line),
                lineTypeVal: INVOICE_LINE_TYPE.DTFREETEXTINV
              };
              const clone = [...historyState.invoiceLineList];
              clone[index] = updatedLines;
              history.replace({
                ...history.location,
                state: {
                  ...(history.location.state as any),
                  invoiceLineList: clone
                }
              });
              historyState = history.location.state as any;
              getNewOldVatValues(updatedLines);
              return updatedLines;
            }
          } else {
            const updatedLines = {
              ...line,
              old_line_cost: line.line_cost,
              qty_inv: line.base_qty_out_with_del,
              line_cost: calculateLineCost(line),
              qty_out: line.base_qty_out - line.base_qty_out_with_del,
              lineTypeVal: INVOICE_LINE_TYPE.DTORDERINV
            };
            const clone = [...historyState.invoiceLineList];
            clone[index] = updatedLines;
            history.replace({
              ...history.location,
              state: {
                ...(history.location.state as any),
                invoiceLineList: clone
              }
            });
            historyState = history.location.state as any;
            getNewOldVatValues(updatedLines);
            return updatedLines;
          }
        }
        return line;
      });
      setToSession("isHotKey", true);
      isHotKeyCalled(true);
    }
  };

  return (
    <div>
      {isInvoiceTypeModalOpen && (
        <SelectInvoiceTypeModal
          isOpen={isInvoiceTypeModalOpen}
          setOpen={setIsInvoiceTypeModalOpen}
          selectedInvoiceType={(type) => {
            handleInvoiceOrderType(type);
          }}
        />
      )}
      <Toolbar buttons={butons} />
      <ConfirmModal
        className="undu-alert"
        isOpen={isUndoModalOpen}
        setOpen={setIsUndoModalOpen}
        title={t("alertMessage.title")}
        message={t("alertMessage.undoAlert.message")}
        confirm={() => {
          const { invoiceDetailsLink } = redirectToInvoiceDetailsLink(selectedRow!);
          if (setIsRerender) {
            setIsRerender(!isRerender);
          }
          history.push(invoiceDetailsLink);
        }}
      />
    </div>
  );
};

InvoiceOrderToolbar.defaultProps = {
  onSubmit: undefined,
  isDirty: undefined,
  resolve: undefined,
  openModal: undefined,
  setPromise: undefined,
  resetForm: undefined,
  goToPrevRecord: undefined,
  goToNextRecord: undefined,
  isHotKeyCalled: undefined,
  setIsViewDetail: undefined,
  setIsChanged: undefined,
  setIsRerender: undefined,
  isChanged: undefined,
  isRerender: undefined
};

export default withRouter(InvoiceOrderToolbar);
