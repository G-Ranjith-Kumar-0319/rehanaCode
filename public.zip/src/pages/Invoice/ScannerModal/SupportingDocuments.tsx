import Layout from "@/components/Layout/Layout";
import React, { ChangeEvent, Children, SetStateAction, useEffect, useLayoutEffect, useRef, useState } from "react";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import "./Style.scss";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  DateInput,
  Divider,
  Dropdown,
  DropdownItem,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  ISelectedItem,
  Loader,
  LoaderType,
  NotificationStatus,
  Pagination,
  RadioButton,
  RadioLabelPosition,
  TextInput,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import { ArrowLeft, ArrowRight, ReflectVertical, SkipBack, SkipForward, ZoomIn, ZoomOut } from "@carbon/icons-react";
import { useHistory, useParams } from "react-router-dom";
import { AppDispatch, useAppSelector } from "@/store/store";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import AlertModalSmall from "@/shared/components/AlertModal/AlertModalSmall";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { TransformComponent, TransformWrapper } from "react-zoom-pan-pinch";
import Modal from "@/components/Modal/Modal";
import { supportingDocumentCount } from "../State/InvoiceNoteList.slice";
import { deleteImage, getFiledataSupportingDoc, postSupportingDocs } from "./SupportingDocuments.slice";

const SupportingDocuments = () => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { invoiceId } = useParams<{ invoiceId: any }>();
  const [documentCount, setDocumentCount] = useState<any>();
  const [currentDocumentCount, setcurrentDocumentCount] = useState<any>();
  const [Fileinfo, setFileInfo] = useState<any>();
  const dispatch = useDispatch<AppDispatch>();
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const history = useHistory();
  const [flagSaveButton, setflagSaveButton] = useState(false);
  const [showAlert, setShowAlert] = useState<boolean>(false);
  const [fileResponseForSave, setfileResponseForSave] = useState<any>();
  const [flagAddFromFile, setFlagAddFromFile] = useState<boolean>(false);
  const [fitToImage, setFitToImage] = useState(false);
  const [actualSize, setActualSize] = useState(false);
  const [lastUpdateDate, setLastUpdateDate] = useState<string | null>(null);
  const [deleteAllImg, setDeleteAllImg] = useState<boolean>(false);
  const [isOpen, setIsOpen] = useState(false);
  const [isOpenScanner, setIsOpenScanner] = useState(false);
  const [isOpenfileextCheck, setIsOpenfileextCheck] = useState(false);
  const [isImageSaved, setisImageSaved] = useState(false);
  const [isDialogDeleted, setImageDeletedMsg] = useState(false);
  const [base64String, setBase64String] = useState<string>();
  const [dropDownSelectedValue, setDropDownSelectedValue] = useState<any>(1);
  const [isReplaceImage, setisReplaceImage] = useState<boolean>(false);
  const [swapImage, SetswapImage] = useState<boolean>(false);
  const [LastUpdateValueSwap, setLastUpdateValueSwap] = useState<any>();
  const [isAddwithoutSave, setisAddwithoutSave] = useState<boolean>(false);
  const [isexitCalled, setExitCalled] = useState<boolean>(false);
  const [isAddfromfile, setAddFromFile] = useState<boolean>(false);
  const [isSavedOneFile, setSavedOneFile] = useState<boolean>(false);
  const [isCopyImage, setCopyImage] = useState<boolean>(false);
  const [loading, setLoading] = useState(false);
  const [wholePageloading, setwholePageloading] = useState(false);
  const [deleteMsgFlag, setDeleteMsgFlag] = useState(false);
  const [invNumber, setInvNumber] = useState<any>("");
  const [replaceImageDateSwap, setreplaceImageDateSwap] = useState<any>();
  const { invoiceDetails } = useAppSelector((state) => state.invoiceDetails);
  const inputRef: React.Ref<HTMLInputElement> = useRef(null);
  const [findthePage, setFindthePage] = useState<any>();

  const imageRef = useRef<HTMLImageElement>(null);
  const [dimensions, setDimensions] = useState<{ width: number; height: number } | null>(null);
  const [isActualSizeImage, setisActualSizeImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [addedFilefromDevice, setaddedFilefromDevice] = useState<any>();

  useEffect(() => {
    if (invoiceDetails?.disp_inv_no !== undefined) {
      sessionStorage.setItem("invoiceNumber", invoiceDetails?.disp_inv_no);
      setInvNumber(invoiceDetails?.disp_inv_no);
    } else {
      setInvNumber(sessionStorage.getItem("invoiceNumber"));
    }
  }, [invoiceDetails]);

  const [fileObj, setFileObj] = useState<{
    filedata: string;
    fileType: string;
    fileLastUpdateTime: string;
    fileName: string;
  }>({
    filedata: "-",
    fileType: "-",
    fileLastUpdateTime: "-",
    fileName: "-"
  });

  const [fileObjReplace, setFileObjReplace] = useState<{
    filedata: string;
    fileType: string;
    fileLastUpdateTime: string;
    fileName: string;
  }>({
    filedata: "-",
    fileType: "-",
    fileLastUpdateTime: "-",
    fileName: "-"
  });

  const [fileObjconverttofile, setfileObjconverttofile] = useState<{ filedatafileType: any }>({
    filedatafileType: ""
  });

  const supportingDocumentAPI = async () => {
    const response = await dispatch(supportingDocumentCount(invoiceId));
    setDocumentCount(response.payload);
    setcurrentDocumentCount(`${response.payload}`);
  };

  useEffect(() => {
    supportingDocumentAPI();
  }, [invoiceId]);

  const FetchingImages = async (imagecounts: any) => {
    const response: any = await dispatch(getFiledataSupportingDoc({ invoiceID: invoiceId, imageNo: imagecounts }));
    const imageData = response.payload ? response.payload?.image_data : undefined;
    const fileTypes = ((response.payload && response.payload?.file_type) || "unknown").toLowerCase();
    const lastUpdate = response.payload ? response.payload?.last_update : undefined;
    const fileName = response.payload ? response.payload?.filename : undefined;

    setfileResponseForSave(response);
    setFileObj({
      filedata: imageData,
      fileType: fileTypes,
      fileLastUpdateTime: lastUpdate,
      fileName
    });
  };

  useEffect(() => {
    setwholePageloading(true);
    setTimeout(() => {
      setwholePageloading(false);
    }, 2000);

    const isSavedButtonAction = localStorage.getItem("isSavedButtonAction");

    const storedValue: string = localStorage.getItem("isReplaceButtonAction") as string;
    const parsedValue = JSON.parse(storedValue);

    const isReplaceButtonActionVar = localStorage.getItem("isReplaceButtonAction");
    const replaceImageCountVar = localStorage.getItem("replaceImageCount");

    setDropDownSelectedValue(documentCount);

    if (isSavedButtonAction) {
      if (isSavedButtonAction === "true") {
        setTimeout(() => {
          openImageSaved();
          FetchingImages(documentCount);
          setcurrentDocumentCount(documentCount);
          localStorage.removeItem("isSavedButtonAction");
        }, 2000);
      }
    }
    if (isReplaceButtonActionVar === "true") {
      setTimeout(() => {
        FetchingImages(replaceImageCountVar);
        setcurrentDocumentCount(replaceImageCountVar);
        localStorage.removeItem("isReplaceButtonAction");
        localStorage.removeItem("replaceImageCount");
      }, 2000);
    } else if (documentCount) {
      if (isSavedButtonAction === null || isReplaceButtonActionVar === null) {
        FetchingImages(1);
        setcurrentDocumentCount(1);
      }
    }

    const tabEnterFlag = localStorage.getItem("tabEnterFlag");
    const isTabEnterFlagTrue =
      tabEnterFlag !== null && tabEnterFlag !== undefined && tabEnterFlag !== "NaN" && tabEnterFlag === "true";
    if (isTabEnterFlagTrue) {
      FetchingImages(documentCount);
      setcurrentDocumentCount(documentCount);
      setTimeout(() => {
        localStorage.setItem("tabEnterFlag", "false");
      }, 1000);
    }
  }, [documentCount, invoiceId, lastUpdateDate]);

  // Fetching PDF from API
  useEffect(() => {
    const createPdfFromBase64 = () => {
      try {
        const byteCharacters = atob(fileObj.filedata);
        const byteNumbers = new Array(byteCharacters.length);
        let i = 0;
        while (i < byteCharacters.length) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
          i += 1; // Use compound assignment instead of increment operator
        }

        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: "application/pdf" });
        const pdfUri = URL.createObjectURL(blob);
        setFileObj({
          filedata: pdfUri,
          fileType: fileObj.fileType,
          fileLastUpdateTime: fileObj.fileLastUpdateTime,
          fileName: fileObj.fileName
        });
      } catch (error) {
        // TODO: Error Handling
        // console.error("Error decoding base64 string:", error);
        // Handle the error gracefully, e.g., set pdfUrl to null
      }
    };

    createPdfFromBase64();

    return () => {
      if (fileObj.filedata) {
        URL.revokeObjectURL(fileObj.filedata);
      }
    };
  }, [fileObj.filedata]);

  const saveOneNewImage = async (imageCount: any) => {
    setwholePageloading(true);
    let fileTypeTemp = fileObj.fileType;

    if (fileTypeTemp.startsWith("image/jpeg")) {
      fileTypeTemp = "jpeg";
    } else if (fileTypeTemp.startsWith("image/bmp")) {
      fileTypeTemp = "bmp";
    } else if (fileTypeTemp.startsWith("application/pdf")) {
      fileTypeTemp = "pdf";
    } else {
      fileTypeTemp = fileObj.fileType;
    }

    const currentDate: string = new Date().toISOString();

    const formdata = new FormData();
    formdata.append("Invoice_Id", invoiceId);
    formdata.append("Image_Number", imageCount);
    formdata.append("File_Type", fileTypeTemp);
    formdata.append("Last_Update", currentDate);

    // Check if Fileinfo is not null before appending
    if (Fileinfo) {
      formdata.append("FormFile", Fileinfo, Fileinfo.name);
    } else {
      // TODO: Error Handling
      // Handle the case where Fileinfo is null
      // console.error("Fileinfo is null");
    }

    const param: any = {
      Invoice_Id: invoiceId,
      Image_Number: imageCount,
      File_Type: fileTypeTemp,
      Last_Update: currentDate,
      FormFile: fileResponseForSave
    };

    dispatch(postSupportingDocs({ params: param, body: formdata }))
      .then((res: any) => {
        dispatch(getFiledataSupportingDoc({ invoiceID: invoiceId, imageNo: documentCount }));
        dispatch(supportingDocumentCount(invoiceId));
        setAddFromFile(false);
        localStorage.setItem("isSavedButtonAction", "true");
        window.location.reload();
      })
      .catch((error: any) => {
        setwholePageloading(false);
      });
  };

  const ReplaceOneNewImage = async () => {
    setwholePageloading(true);
    let fileTypeTemp = fileObj.fileType;
    const response: any = await dispatch(
      getFiledataSupportingDoc({ invoiceID: invoiceId, imageNo: dropDownSelectedValue })
    );

    // Perform additional actions based on the response
    if (response) {
      if (fileTypeTemp.startsWith("image/jpeg")) {
        fileTypeTemp = "jpeg";
      } else if (fileTypeTemp.startsWith("image/bmp")) {
        fileTypeTemp = "bmp";
      } else if (fileTypeTemp.startsWith("application/pdf")) {
        fileTypeTemp = "pdf";
      } else {
        fileTypeTemp = fileObj.fileType;
      }

      const formdata = new FormData();
      formdata.append("Invoice_Id", invoiceId);
      formdata.append("Image_Number", `${dropDownSelectedValue}`);
      formdata.append("File_Type", fileTypeTemp);
      formdata.append("Last_Update", response?.payload?.last_update);

      // Check if Fileinfo is not null before appending
      if (Fileinfo) {
        formdata.append("FormFile", Fileinfo, Fileinfo.name);
      } else {
        // TODO: Error Handling
        // Handle the case where Fileinfo is null
        // console.error("Fileinfo is null");
      }

      const param: any = {
        Invoice_Id: invoiceId,
        Image_Number: `${dropDownSelectedValue}`,
        File_Type: fileTypeTemp,
        Last_Update: response?.payload?.last_update,
        FormFile: base64String
      };

      dispatch(postSupportingDocs({ params: param, body: formdata }))
        .then((res: any) => {
          dispatch(getFiledataSupportingDoc({ invoiceID: invoiceId, imageNo: dropDownSelectedValue }));
          dispatch(supportingDocumentCount(invoiceId));

          // Convert objReplace to a string using JSON.stringify before storing it
          localStorage.setItem("isReplaceButtonAction", "true");
          localStorage.setItem("replaceImageCount", dropDownSelectedValue);

          window.location.reload();
          setwholePageloading(true);
        })
        .catch((error: any) => {
          setwholePageloading(true);
        });
    } else {
      // TODO: Error Handling
      // Handle error condition
      // console.error("Error fetching images:", response);
    }
  };

  const getPDFChangeButtonCalling = () => {
    setTimeout(() => {
      if (fileInputRef.current) {
        fileInputRef.current.click();
      }
    }, 500);
  };

  const getFileExtension = (fileName: string) => fileName.split(".").pop()?.toLowerCase() || "";

  const handleFileChangeButtonCalling = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];

    setaddedFilefromDevice(file);

    // conversion of file to base64
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        setBase64String(base64);
      };
      reader.readAsDataURL(file);
    }

    // conversion of file to base64

    const fileSizeInKb: number = file ? Math.floor(file.size / 1024) : 0;

    let fileTypeData: any = file?.type;

    if (fileTypeData.startsWith("image/jpeg")) {
      fileTypeData = "jpeg";
    } else if (fileTypeData.startsWith("image/jpg")) {
      fileTypeData = "jpg";
    } else if (fileTypeData.startsWith("image/bmp")) {
      fileTypeData = "bmp";
    } else if (fileTypeData.startsWith("application/pdf")) {
      fileTypeData = "pdf";
    }

    if (
      fileTypeData === "image/jpeg" ||
      fileTypeData === "application/pdf" ||
      fileTypeData === "image/bmp" ||
      fileTypeData === "image/jpg" ||
      fileTypeData === "pdf" ||
      fileTypeData === "bmp" ||
      fileTypeData === "jpeg" ||
      fileTypeData === "jpg"
    ) {
      if (fileSizeInKb <= 131072) {
        if (file) {
          setFileInfo(file);
          const localFileUrl = URL.createObjectURL(file);

          setPdfUrl(localFileUrl);

          setFileObj({
            filedata: localFileUrl,
            fileType: fileTypeData,
            fileLastUpdateTime: new Date(file.lastModified).toLocaleString(),
            fileName: file?.name
          });
          localStorage.setItem("SaveImageText", "false");
          setFlagAddFromFile(true);

          setreplaceImageDateSwap(new Date(file.lastModified).toLocaleString());

          // Button States
          setAddFromFile(true);
          // Button States
        }
      } else {
        openDialog();
      }
    } else {
      OpenfileextCheckDialog();
    }
  };

  const handleFileReplaceChange = () => {
    const file = addedFilefromDevice;

    // conversion of file to base64
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        setBase64String(base64);
      };
      reader.readAsDataURL(file);
    }

    // conversion of file to base64

    const fileSizeInKb: number = file ? Math.floor(file.size / 1024) : 0;

    let fileTypeData: any = file?.type;

    if (fileTypeData.startsWith("image/jpeg")) {
      fileTypeData = "jpeg";
    } else if (fileTypeData.startsWith("image/jpg")) {
      fileTypeData = "jpg";
    } else if (fileTypeData.startsWith("image/bmp")) {
      fileTypeData = "bmp";
    } else if (fileTypeData.startsWith("application/pdf")) {
      fileTypeData = "pdf";
    }

    if (
      fileTypeData === "image/jpeg" ||
      fileTypeData === "application/pdf" ||
      fileTypeData === "image/bmp" ||
      fileTypeData === "image/jpg" ||
      fileTypeData === "pdf" ||
      fileTypeData === "bmp" ||
      fileTypeData === "jpeg" ||
      fileTypeData === "jpg"
    ) {
      if (fileSizeInKb <= 131072) {
        if (file) {
          setFileInfo(file);
          const localFileUrl = URL.createObjectURL(file);

          setPdfUrl(localFileUrl);

          setFileObj({
            filedata: localFileUrl,
            fileType: fileTypeData,
            fileLastUpdateTime: new Date(file.lastModified).toLocaleString(),
            fileName: file?.name
          });
          localStorage.setItem("SaveImageText", "false");
          setFlagAddFromFile(true);

          setreplaceImageDateSwap(new Date(file.lastModified).toLocaleString());

          // Button States
          setAddFromFile(true);
          // Button States
        }
      } else {
        openDialog();
      }
    } else {
      OpenfileextCheckDialog();
    }
  };

  const dropdownItems = Array.from({ length: parseInt(documentCount, 10) }, (_, index) => ({
    id: String(index + 1),
    text: String(index + 1),
    value: String(index + 1)
  }));

  const [scale, setScale] = useState(1); // Initial scale
  const [rotation, setRotation] = useState(0); // Initial rotation

  const zoomRef = useRef<null | any>(null);

  const handleZoomIn = () => {
    if (zoomRef.current) {
      zoomRef.current.zoomIn();
    }
  };

  const MIN_SCALE = 0.5; // Define the minimum scale level
  const handleZoomOut = () => {
    setScale((prevScale) => {
      const newScale = Math.max(MIN_SCALE, prevScale - 0.1);
      if (zoomRef.current) {
        zoomRef.current.zoomOut(newScale);
      }
      return newScale;
    });
  };

  const handleFitToImage = () => {
    setScale(1);

    if (zoomRef.current) {
      zoomRef.current.resetTransform();
    }
  };

  const ActualSizeButton = () => {
    setScale(1);

    if (zoomRef.current) {
      zoomRef.current.setTransform(1.4, 1.4, 1.4);
    }
  };

  const handleRotate = () => {
    setRotation(rotation + 180);
  };

  const FirstImage = (currCount: any) => {
    FetchingImages(currCount);
    setcurrentDocumentCount(currCount);
    if (currCount === "" || currCount === "NaN") {
      setcurrentDocumentCount(1);
      FetchingImages(1);
    }
  };

  const LastImage = (currCount: any) => {
    FetchingImages(currCount);
    setcurrentDocumentCount(currCount);
    if (currCount === "" || currCount === "NaN") {
      setcurrentDocumentCount(1);
      FetchingImages(1);
    }
  };

  const NextImage = (currCount: any) => {
    const temp: any = parseInt(currCount, 10);
    let temp1: any = temp + 1;
    if (temp === documentCount) {
      temp1 = documentCount;
    }

    setcurrentDocumentCount(`${temp1}`);
    FetchingImages(temp1);
    if (currCount === "" || currCount === "NaN") {
      setcurrentDocumentCount(1);
      FetchingImages(1);
    }
  };

  const PrevImage = (currCount: any) => {
    const temp = parseInt(currCount, 10);
    let temp1 = temp - 1;

    if (temp === 1) {
      temp1 = 1;
    }

    setcurrentDocumentCount(`${temp1}`);
    FetchingImages(temp1);

    if (currCount === "" || currCount === "NaN") {
      setcurrentDocumentCount(1);
      FetchingImages(1);
    }
  };

  const ShowAlert = () => {
    setShowAlert(true);
  };
  const deleteAllImgs = () => {
    setDeleteAllImg(true);
  };

  const ReplaceImage = async () => {
    setisReplaceImage(true);
    SetswapImage(true);

    const response: any = await dispatch(
      getFiledataSupportingDoc({ invoiceID: invoiceId, imageNo: dropDownSelectedValue })
    );
    const imageData = response.payload ? response.payload?.image_data : undefined;
    const fileTypes = ((response.payload && response.payload?.file_type) || "unknown").toLowerCase();
    const lastUpdate = response.payload ? response.payload?.last_update : undefined;
    const fileName = response.payload ? response.payload?.filename : undefined;

    setLastUpdateValueSwap(lastUpdate);

    setFileObj({
      filedata: imageData,
      fileType: fileTypes,
      fileLastUpdateTime: lastUpdate,
      fileName
    });
  };

  const deleteImageMethod = (deleteAll: boolean) => {
    setLoading(true);
    setDeleteMsgFlag(deleteAll);

    const params = {
      invoiceId,
      imageNumber: currentDocumentCount,
      lastUpdate: fileObj.fileLastUpdateTime || "",
      deleteAll
    };

    dispatch(deleteImage(params))
      .then((res: any) => {
        dispatch(getFiledataSupportingDoc({ invoiceID: invoiceId, imageNo: documentCount }));
        dispatch(supportingDocumentCount(invoiceId));
        setLoading(false);
        setImageDeletedMsg(true);

        setTimeout(() => {
          window.location.reload();
          setImageDeletedMsg(false);
        }, 30000);
      })
      .catch((error: any) => {
        setLoading(false);
      });
  };

  const handleSaveAsFile = () => {
    setLoading(true);
    let fileTypeTemp = fileObj.fileType;

    if (fileTypeTemp.startsWith("image/jpeg")) {
      fileTypeTemp = "jpeg";
    } else if (fileTypeTemp.startsWith("image/bmp")) {
      fileTypeTemp = "bmp";
    } else if (fileTypeTemp.startsWith("application/pdf")) {
      fileTypeTemp = "pdf";
    } else {
      fileTypeTemp = fileObj.fileType;
    }

    if (fileObj.fileType !== "unknown" && fileTypeTemp !== "pdf") {
      fetch(fileObj.filedata)
        .then((response) => response.blob())
        .then((blob) => {
          // Create a link element
          const link = document.createElement("a");
          link.href = window.URL.createObjectURL(blob);
          link.download = `File.${fileTypeTemp}`; // Set the download attribute with file extension
          link.click();

          // Revoke the Blob URL to free up memory
          window.URL.revokeObjectURL(link.href);
          setLoading(false);
        })
        .catch((error) => {
          // TODO: Error Handling
          // console.error("Error downloading file:", error);
          setLoading(false);
        });
    }
  };

  const openDialog = () => {
    setIsOpen(true);
  };

  const closeDialog = () => {
    setIsOpen(false);
  };

  const OpenfileextCheckDialog = () => {
    setIsOpenfileextCheck(true);
  };

  const closefileextCheckDialog = () => {
    setIsOpenfileextCheck(false);
  };

  const openImageSaved = () => {
    setwholePageloading(false);
    setisImageSaved(true);
  };

  const closeisImageSavedCheckDialog = () => {
    setisImageSaved(false);
  };

  const closeDeleteDialog = () => {
    if (deleteMsgFlag === true) {
      setcurrentDocumentCount(0);
      setDocumentCount(0);
    }

    window.location.reload();
    setImageDeletedMsg(false);
  };

  const addBtnConfirmation = () => {
    setisAddwithoutSave(true);
  };

  let displayValue;
  if (!isAddfromfile) {
    const currentDate = new Date(); // Get current system date and time
    const datePart = `${currentDate.getDate()} ${currentDate.toLocaleString("default", {
      month: "short"
    })} ${currentDate.getFullYear()}`;
    const timePart = currentDate.toLocaleTimeString("en-US", { hour12: false }); // Use 24-hour format
    displayValue = `${datePart}  ${timePart}`;
  } else {
    displayValue = "-";
  }

  const formatDateTime = (dateString: string): string => {
    if (!dateString) {
      return "-";
    }

    const date = new Date(dateString);
    if (Number.isNaN(Number(date.getTime()))) {
      return "-";
    }

    // Format the date parts
    const day = date.getDate().toString().padStart(2, "0");
    const month = date.toLocaleString("default", { month: "short" });
    const year = date.getFullYear();

    // Format the time parts in 24-hour format
    const hours = date.getHours().toString().padStart(2, "0");
    const minutes = date.getMinutes().toString().padStart(2, "0");
    const seconds = date.getSeconds().toString().padStart(2, "0");

    return `${day} ${month} ${year} ${hours}:${minutes}:${seconds}`;
  };

  const CountChangeValue = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue: any = e.target.value;
    setFindthePage(e.target.value);

    if (newValue > documentCount) {
      setcurrentDocumentCount(documentCount);
      FetchingImages(documentCount);
      return;
    }

    if (newValue <= 0 && newValue !== "") {
      setcurrentDocumentCount(1);
      FetchingImages(1);
      return;
    }

    if (newValue === "") {
      // setcurrentDocumentCount(1);
      FetchingImages(currentDocumentCount);
      return;
    }

    setcurrentDocumentCount(newValue);
    FetchingImages(newValue);
  };

  useEffect(() => {
    inputRef?.current?.focus();
  }, []);

  const handleButtonClick = () => {
    if (isAddfromfile) {
      addBtnConfirmation();
    } else {
      getPDFChangeButtonCalling();
    }
  };
  const handleAddFromScanner = () => {
    setIsOpenScanner(true);
  };

  const gobackFunction = () => {
    history.push(removeSegments(window.location.pathname));
  };

  useEffect(() => {
    if (isOpenScanner) {
      setTimeout(() => {
        document.getElementById("scannerOkButton")?.focus();
      }, 100);
    } else {
      document.getElementById("scannerButton")?.focus();
    }
  }, [wholePageloading, isOpenScanner]);

  const identifier = "some-unique-identifier"; // Replace with actual identifier

  const removeSegments = (url: string): string => url.replace(/\/UI|\/suporting-documents|\/supporting-documents/g, "");

  return (
    <>
      <Layout
        pageTitle={`${t("invoiceScanDoc.invoiceTitleforinvoiceno")} ${invNumber}`}
        className="supporting__document"
      >
        {/* .................. */}

        {wholePageloading ? (
          <Loader
            loaderType={LoaderType.Circular}
            loaderText={t("common.loading")}
          />
        ) : (
          <>
            <Grid
              container
              className="marginT10"
            >
              <GridItem
                sm={12}
                md={12}
                lg={6}
                xl={6}
              >
                <div className="input-search">
                  <FormLabel>{t("invoiceScanDoc.originalFileName")}</FormLabel>
                  <div>
                    <TextInput
                      value={fileObj?.fileName || "-"}
                      disabled
                      className="not-in-use"
                    />
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={12}
                md={12}
                lg={2}
                xl={2}
              >
                <div className="input-search">
                  <FormLabel>{t("invoiceScanDoc.lastUpdate")}</FormLabel>
                  <div>
                    {swapImage ? (
                      <TextInput
                        value={formatDateTime(LastUpdateValueSwap)}
                        readOnly
                        className="not-in-use"
                      />
                    ) : (
                      <TextInput
                        value={isImageSaved || documentCount === 0 ? "-" : displayValue}
                        disabled={isImageSaved || documentCount === 0}
                        readOnly
                        className="not-in-use"
                      />
                    )}
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={12}
                md={12}
                lg={2}
                xl={2}
              >
                <div className="input-search">
                  <FormLabel>{t("invoiceScanDoc.imageType")}</FormLabel>
                  <div>
                    <TextInput
                      value={fileObj.fileType.toUpperCase() === "UNKNOWN" ? "-" : fileObj.fileType.toUpperCase()}
                      disabled
                      className="not-in-use"
                    />
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={12}
                md={12}
                lg={2}
                xl={2}
              >
                <div className="input-search">
                  <FormLabel>{t("invoiceScanDoc.imageLocation")}</FormLabel>
                  <div>
                    {swapImage ? (
                      <TextInput
                        value="Database"
                        className="not-in-use"
                        readOnly
                      />
                    ) : (
                      <TextInput
                        value={isImageSaved || documentCount === 0 || isAddfromfile ? "-" : "Database"}
                        disabled={isImageSaved || documentCount === 0 || isAddfromfile}
                        className="not-in-use"
                        readOnly
                      />
                    )}
                  </div>
                </div>
              </GridItem>
            </Grid>
            <Grid
              container
              className="marginT10"
            >
              <GridItem
                sm={12}
                md={12}
                lg={2}
                xl={2}
              >
                <Grid className="row-gap-16   margin-min">
                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <></>
                  </GridItem>
                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <Button
                      size={ButtonSize.Small}
                      className="w-100"
                      color={ButtonColor.Secondary}
                      onClick={handleAddFromScanner}
                      id="scannerButton"
                    >
                      {t("invoiceScanDoc.addFromScanner")}
                    </Button>
                  </GridItem>

                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <input
                      type="file"
                      id="fileInput"
                      accept=".pdf, .jpeg, .jpg, .bmp"
                      onChange={handleFileChangeButtonCalling}
                      ref={fileInputRef}
                      style={{ display: "none" }} // Hide the input element
                    />

                    <Button
                      size={ButtonSize.Small}
                      className="w-100"
                      color={ButtonColor.Secondary}
                      onClick={handleButtonClick}
                    >
                      {t("invoiceScanDoc.addFromFile")}
                    </Button>
                  </GridItem>
                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      disabled={isAddfromfile === false}
                      className="w-100"
                      onClick={async (e: React.SyntheticEvent<Element, Event>) => {
                        e.preventDefault();
                        try {
                          await saveOneNewImage(`${parseInt(documentCount, 10) + 1}`);
                          // Optionally, you can add additional logic here after the promise resolves
                        } catch (error) {
                          // TODO: Error Handling
                          // console.error("Error occurred:", error);
                          // Optionally, handle errors here
                        }
                      }}
                    >
                      {localStorage.getItem("SaveImageText") === "false"
                        ? t("invoiceScanDoc.saveNewoneImages")
                        : t("invoiceScanDoc.saveNewImages")}
                    </Button>
                  </GridItem>
                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      onClick={handleSaveAsFile}
                      className="w-100"
                      disabled={isAddfromfile === true || documentCount === 0 || fileObj.fileType === "pdf"}
                    >
                      {t("invoiceScanDoc.copyImageToFile")}
                    </Button>
                  </GridItem>
                </Grid>
              </GridItem>

              <GridItem
                sm={12}
                md={12}
                lg={8}
                xl={8}
              >
                <div className="border br-8 overflow-hidden centerval">
                  {loading ? (
                    <Loader
                      loaderType={LoaderType.Circular}
                      loaderText={t("common.loading")}
                    />
                  ) : (
                    <>
                      {isAddfromfile === false && documentCount === 0 ? (
                        <div className="middletxt"> {t("invoiceScanDoc.NoimageTxt")}</div>
                      ) : (
                        <>
                          {fileObj.fileType.toLowerCase() === "pdf" ||
                          fileObj.fileType.toLowerCase() === "application/pdf" ? (
                            <iframe
                              src={fileObj.filedata || ""}
                              title="PDF Document"
                              style={{
                                width: "100%",
                                height: "600px", // Adjust the height as needed
                                border: "none",
                                transformOrigin: "top left"
                              }}
                            />
                          ) : (
                            <div style={{ width: "100%", height: "100%", overflow: "auto" }}>
                              <TransformWrapper
                                initialScale={1}
                                initialPositionX={0}
                                initialPositionY={0}
                                ref={zoomRef}
                              >
                                {({ zoomIn, zoomOut, resetTransform }) => (
                                  <>
                                    <div
                                      style={{
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        overflow: "auto",
                                        width: "100%",
                                        height: "100%"
                                      }}
                                    >
                                      <TransformComponent>
                                        <div
                                          style={{
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center",
                                            overflow: "auto",
                                            width: "100%",
                                            height: "100%",
                                            transform: `scale(${scale})`,
                                            transition: "transform 0.2s"
                                          }}
                                        >
                                          <img
                                            src={fileObj.filedata || ""}
                                            ref={imageRef}
                                            alt=""
                                            style={{
                                              transform: `rotate(${rotation}deg)`,
                                              transition: "transform 0.3s ease",
                                              width: isActualSizeImage ? dimensions?.width || "auto" : "800px",
                                              height: isActualSizeImage ? dimensions?.height || "auto" : "auto",
                                              maxWidth: isActualSizeImage ? "none" : "90%",
                                              maxHeight: isActualSizeImage ? "none" : "90%"
                                            }}
                                          />
                                        </div>
                                      </TransformComponent>
                                    </div>
                                  </>
                                )}
                              </TransformWrapper>
                            </div>
                          )}
                        </>
                      )}
                    </>
                  )}
                </div>
              </GridItem>
              <GridItem
                sm={12}
                md={12}
                lg={2}
                xl={2}
              >
                <Grid className="row-gap-16">
                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      className="w-100"
                      disabled={documentCount === 0 || isAddfromfile === true}
                      onClick={ShowAlert}
                    >
                      {t("invoiceScanDoc.deleteImages")}
                    </Button>
                  </GridItem>
                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      className="w-100"
                      disabled={documentCount === 0 || isAddfromfile === true}
                      onClick={deleteAllImgs}
                    >
                      {t("invoiceScanDoc.deleteAll")}
                    </Button>
                  </GridItem>
                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      className="w-100"
                      onClick={ReplaceImage}
                      disabled={documentCount === 0 || isAddfromfile === false}
                    >
                      {t("invoiceScanDoc.replaceImages")}
                    </Button>
                  </GridItem>
                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <div className="drop-down">
                      <Dropdown
                        disabled={documentCount === 0 || isAddfromfile === false}
                        className="drop-down-width-set w-100"
                        placeholderText={documentCount}
                        onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => {
                          setDropDownSelectedValue(item.value);
                        }}
                      >
                        {/* Map over the dropdownItems array to generate DropdownItem components */}
                        {dropdownItems.map((item) => (
                          <DropdownItem
                            key={item.id}
                            id={item.id}
                            text={item.text}
                            value={item.value}
                          >
                            {item.text}
                          </DropdownItem>
                        ))}
                      </Dropdown>
                    </div>
                  </GridItem>
                </Grid>
                {showAlert && (
                  <ConfirmModal
                    isOpen={showAlert}
                    setOpen={setShowAlert}
                    className="cancel-popup"
                    title={t("invoiceScanDoc.deleteOneTile")}
                    message={t("invoiceScanDoc.deleteOneTitleMsg")}
                    confirm={() => {
                      setShowAlert(false);
                      deleteImageMethod(false);
                      setcurrentDocumentCount(currentDocumentCount - 1);
                      setDocumentCount(documentCount - 1);
                    }}
                  />
                )}

                <AlertModalSmall
                  isOpen={isOpen}
                  setOpen={closeDialog}
                  notificationType={NotificationStatus.WARNING}
                  message={t("invoiceScanDoc.fileexceedMsg")}
                  title={t("invoiceScanDoc.invoiceTitleSims")}
                />

                <AlertModalSmall
                  isOpen={isOpenfileextCheck}
                  setOpen={closefileextCheckDialog}
                  notificationType={NotificationStatus.WARNING}
                  message={t("invoiceScanDoc.fileTypeMsg")}
                  title={t("invoiceScanDoc.invoiceTitleSims")}
                />

                <AlertModalSmall
                  isOpen={isImageSaved}
                  setOpen={closeisImageSavedCheckDialog}
                  notificationType={NotificationStatus.SUCCESS}
                  message={t("invoiceScanDoc.msgImageSuccessSaved")}
                  title={t("invoiceScanDoc.invoiceTitleSims")}
                />

                {deleteMsgFlag ? (
                  <AlertModalSmall
                    isOpen={isDialogDeleted}
                    setOpen={closeDeleteDialog}
                    notificationType={NotificationStatus.SUCCESS}
                    message={`${documentCount} ${t("invoiceScanDoc.msgImagesAllSuccessdeleted")}`}
                    title={t("invoiceScanDoc.invoiceTitleSims")}
                  />
                ) : (
                  <AlertModalSmall
                    isOpen={isDialogDeleted}
                    setOpen={closeDeleteDialog}
                    notificationType={NotificationStatus.SUCCESS}
                    message={t("invoiceScanDoc.msgImageSuccessdeleted")}
                    title={t("invoiceScanDoc.invoiceTitleSims")}
                  />
                )}

                {deleteAllImg && (
                  <ConfirmModal
                    isOpen={deleteAllImg}
                    setOpen={setDeleteAllImg}
                    className="cancel-popup"
                    title={t("Delete All Images")}
                    message={
                      <div>
                        <p style={{ marginBottom: 3 }}>
                          There are {documentCount} images stored in the database for invoice {invNumber}.
                        </p>
                        <p style={{ marginTop: 0 }}>Are you sure you want to delete all these Images?</p>
                      </div>
                    }
                    confirm={() => {
                      setDeleteAllImg(false);
                      deleteImageMethod(true);
                    }}
                  />
                )}
                <ConfirmModal
                  isOpen={isAddwithoutSave}
                  setOpen={setisAddwithoutSave}
                  title={t("invoiceScanDoc.replaceImgMsgTitle")}
                  message={t("invoiceScanDoc.replaceImgMsg")}
                  confirm={getPDFChangeButtonCalling}
                />
                <ConfirmModal
                  isOpen={isAddwithoutSave}
                  setOpen={setisAddwithoutSave}
                  title={t("invoiceScanDoc.replaceImgMsgTitle")}
                  message={t("invoiceScanDoc.replaceImgMsg")}
                  confirm={getPDFChangeButtonCalling}
                />
                <ConfirmModal
                  isOpen={isexitCalled}
                  setOpen={setExitCalled}
                  title={t("invoiceNote.warning")}
                  message={t("invoiceNote.warningMsg")}
                  confirm={gobackFunction}
                />

                {isReplaceImage && (
                  <ConfirmModal
                    isOpen={isReplaceImage}
                    setOpen={setisReplaceImage}
                    title={t("invoiceScanDoc.msgReplaceImageTitle")}
                    message={t("invoiceScanDoc.msgReplaceImages")}
                    confirm={() => {
                      ReplaceOneNewImage();
                    }}
                    callback={(click) => {
                      if (!click?.confirm) {
                        SetswapImage(false);
                        handleFileReplaceChange();
                      }
                    }}
                  />
                )}
              </GridItem>
            </Grid>

            <Divider />

            <Grid container>
              <GridItem
                sm={12}
                md={12}
                lg={{
                  offset: 2,
                  span: 8
                }}
                xl={{
                  offset: 2,
                  span: 8
                }}
              >
                <Grid className="mr-t10">
                  <GridItem
                    sm={12}
                    md={12}
                    lg={12}
                    xl={12}
                    className="mb-8 d-flex space-center gap-16 flex-wrap"
                  >
                    <div className="display-flex gap-10 align-center">
                      <span> {t("invoiceScanDoc.imageTag")}</span>
                      <TextInput
                        value={currentDocumentCount}
                        disabled={documentCount === 0 || isAddfromfile === true}
                        inputWidth={40}
                        onKeyDown={(event) => {
                          // eslint-disable-next-line
                          if (
                            event.key !== "Tab" &&
                            typeof currentDocumentCount === "string" &&
                            /^[^a-zA-Z-]*$|^\d*[1-9]\d*$/.test(event.key) === false &&
                            event.key !== "Backspace" &&
                            event.key !== "-"
                          ) {
                            event.preventDefault();
                          }

                          if (event.key === "Tab" || event.key === "Enter") {
                            const newValue = findthePage;
                            if (newValue > documentCount) {
                              localStorage.setItem("tabEnterFlag", "true");
                              window.location.reload();
                            }
                          }
                        }}
                        onChange={(e) => CountChangeValue(e)}
                        inputRef={inputRef}
                        className="m-0 textinput-txt"
                      />

                      <span>of {documentCount}</span>
                    </div>

                    <div className="display-flex gap-10 set-btn-width">
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        onClick={handleZoomIn}
                        disabled={
                          fileObj.fileType === "-" ||
                          fileObj.fileType.toLowerCase() === "pdf" ||
                          fileObj.fileType === "application/pdf"
                        }
                      >
                        <ZoomIn size={20} />
                      </Button>
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        onClick={handleZoomOut}
                        disabled={
                          fileObj.fileType === "-" ||
                          fileObj.fileType.toLowerCase() === "pdf" ||
                          fileObj.fileType === "application/pdf"
                        }
                      >
                        <ZoomOut />
                      </Button>
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        onClick={handleRotate}
                        disabled={
                          fileObj.fileType === "-" ||
                          fileObj.fileType.toLowerCase() === "pdf" ||
                          fileObj.fileType === "application/pdf"
                        }
                      >
                        <ReflectVertical />
                      </Button>
                    </div>

                    <div className="display-flex gap-10 set-btn-width">
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        onClick={() => FirstImage(1)}
                        disabled={
                          documentCount <= 1 || parseInt(currentDocumentCount, 10) === 1 || isAddfromfile === true
                        }
                      >
                        <SkipBack />
                      </Button>
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        onClick={() => PrevImage(currentDocumentCount)}
                        disabled={
                          documentCount <= 1 || parseInt(currentDocumentCount, 10) === 1 || isAddfromfile === true
                        }
                      >
                        <ArrowLeft />
                      </Button>
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        onClick={() => NextImage(currentDocumentCount)}
                        disabled={
                          documentCount <= 1 ||
                          parseInt(documentCount, 10) === parseInt(currentDocumentCount, 10) ||
                          isAddfromfile === true
                        }
                      >
                        <ArrowRight />
                      </Button>
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        onClick={() => LastImage(documentCount)}
                        disabled={
                          documentCount <= 1 ||
                          parseInt(documentCount, 10) === parseInt(currentDocumentCount, 10) ||
                          isAddfromfile === true
                        }
                      >
                        <SkipForward />
                      </Button>
                    </div>

                    <div className="leftrightbtn gap-10">
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        className="w-100"
                        onClick={() => ActualSizeButton()}
                        disabled={
                          fileObj.fileType === "-" ||
                          fileObj.fileType.toLowerCase() === "pdf" ||
                          fileObj.fileType === "application/pdf"
                        }
                      >
                        {t("invoiceScanDoc.actualSizeBtn")}
                      </Button>
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        className="w-100"
                        onClick={handleFitToImage}
                        disabled={
                          fileObj.fileType === "-" ||
                          fileObj.fileType.toLowerCase() === "pdf" ||
                          fileObj.fileType === "application/pdf"
                        }
                      >
                        {t("invoiceScanDoc.fittoPageBtn")}
                      </Button>
                    </div>
                  </GridItem>
                </Grid>
              </GridItem>
            </Grid>
          </>
        )}

        <Grid
          container
          className="mt-12-imp"
        >
          <GridItem
            sm={12}
            md={4}
            lg={6}
            xl={6}
          >
            <div>
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </div>
          </GridItem>
          <GridItem
            sm={12}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="rightbtn">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
                onClick={() => {
                  if (isAddfromfile) {
                    setExitCalled(true);
                  } else {
                    history.goBack();
                  }
                }}
              >
                {t("invoiceScanDoc.OkBtn")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={() => history.push(removeSegments(window.location.pathname))}
              >
                {t("invoiceScanDoc.cancelBtn")}
              </Button>
            </div>
          </GridItem>
        </Grid>
        <Modal
          className="scanner-doc-modal"
          header={t("common.scanningGuidance")}
          isOpen={isOpenScanner}
          primaryBtnText={t("common.ok")}
          tertiaryBtnText={t("common.cancel")}
          fourthiaryBtnText={t("common.help")}
          secondaryBtnType={ButtonColor.Secondary}
          primaryBtnId="scannerOkButton"
          tertiaryBtnClick={() => {
            setIsOpenScanner(false);
          }}
          onClose={() => {
            setIsOpenScanner(false);
          }}
          primaryBtnClick={() => {
            setIsOpenScanner(false);
            handleButtonClick();
          }}
          fourthiaryBtnClick={() => {}}
        >
          <div
            data-testid="separator-top"
            className="essui-dialog__separator mb-16"
          />

          <div>{t("common.scannerText1")}</div>
          <div>{t("common.scannerText2")}</div>

          <div
            data-testid="separator-top"
            className="essui-dialog__separator mt-16"
          />
        </Modal>
      </Layout>
    </>
  );
};
export default SupportingDocuments;
