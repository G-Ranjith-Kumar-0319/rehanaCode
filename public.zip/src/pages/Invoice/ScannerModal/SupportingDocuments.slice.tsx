import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { client, apiRoot } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { TColumnDef } from "@/components/GridTable/GridTable";
import OrderBookColumnDef from "../Grid/columnDef";

export type TOrderBooks = {
  orderBook: { [key: string]: any }[];
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: string;
};

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type purchaseOrderState = {
  orderBooks: { [key: string]: any }[];
  error?: string;
  status?: STATUS;
  selectedBook?: { [key: string]: any };
  columnDef: TColumnDef;
  filters?: TFilters;
  supportingDocument: [];
};

const initialState: purchaseOrderState = {
  columnDef: OrderBookColumnDef,
  orderBooks: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined
  },
  supportingDocument: []
};

/** Thunks */
export const getOrderBooks = createAsyncThunk(
  "books/OrderBooks",
  async ({ status, callback }: { status: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/purchase-orders/order-books`, {
      params: { status }
    });

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const postSupportingDocs = createAsyncThunk("invoiceNote/lineItem", async ({ params, body }: any) => {
  const response = await client.post(
    `${apiRoot}/invoice/invoice-image-insert-update?Invoice_Id=${params.Invoice_Id}&Image_Number=${params.Image_Number}&File_Type=${params.File_Type}&Last_Update=${params.Last_Update}`,

    body
  );
  if (params.callback) {
    params.callback(response.data);
  }
  return response.data;
});

export const getSupportingDocumentCount = createAsyncThunk(
  "books/OrderBooks",
  async ({ status, callback }: { status: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/purchase-orders/order-books`, {
      params: { status }
    });

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getFiledataSupportingDoc = createAsyncThunk(
  "invoiceOrders/getFiledataSupportingDoc",
  async ({ invoiceID, imageNo }: { invoiceID: any; imageNo: any }) => {
    const response = await client.get(
      `${apiRoot}/invoice/invoice-image-get?invoiceId=${invoiceID}&imageNo=${imageNo}`,
      {}
    );

    return response.data;
  }
);

export const deleteImage = createAsyncThunk("orderBooks", async (params: { [key: string]: any }) => {
  const response = await client.delete(`${apiRoot}/invoice/invoice-image-delete`, { params });
  if (params.callback) {
    params.callback(response.data);
  }
  return response.data;
});

/**
 * # Purchase Order Details Slice
 * This slice of state is responsible for storing purchase order details state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** Purchase Orders Details */
    builder
      .addCase(getOrderBooks.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getOrderBooks.fulfilled, (state, action: PayloadAction<any>) => {
        state.orderBooks = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getOrderBooks.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
    builder
      .addCase(postSupportingDocs.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(postSupportingDocs.fulfilled, (state, action: PayloadAction<any>) => {
        state.supportingDocument = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(postSupportingDocs.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },

  initialState,
  name: "orderBooks",
  reducers: {
    selectRow: (state, action: PayloadAction<any>) => {
      state.selectedBook = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (OrderBookColumnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    },
    resetSelectedRow: (state) => {
      state.selectedBook = undefined;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
