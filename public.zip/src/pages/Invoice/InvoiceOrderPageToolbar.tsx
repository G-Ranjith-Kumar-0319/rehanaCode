import { DocumentTasks, LicenseDraft, Purchase, TaskRemove, Undo } from "@carbon/icons-react";

import { Button, ButtonColor, ButtonSize, Grid, GridItem, Notification, NotificationStatus } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { RouteComponentProps, useHistory, useLocation, useParams, withRouter } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import useQuery from "@/hooks/useQuery";
import { useCallback, useEffect, useState } from "react";
import {
  BOOLEAN_DATA,
  INVOICE_STATUS,
  INVOICE_TYPE,
  PAYMENT_METHOD,
  TRANSACTION,
  apiStatusCode,
  invoiceTypesName,
  sourceType
} from "@/types/UseStateType";
import { getOrderInvoiceDifference } from "@/shared/components/OrderAuditSummaryModal/state/OrderAuditSummary.slice";
import { invoiceOrderType, invoicecanceltype, isEmptyObject, sundryInvoiceType } from "@/utils/constants";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { formatCardExpiryDate } from "@/utils/getDataSource";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import InvoiceNotesCancalModal from "./CreditNoteProcessing/Modals/InvoiceNotesCancelModal";
import {
  actions as ioActions,
  authorisedStatus,
  getInvoiceOrdersFilter,
  invoiceThresholdCheck,
  preAuthorisedStatus
} from "./State/InvoiceNoteList.slice";
import { getInvoiceDetails, actions as idActions } from "./State/InvoiceNoteDetails";

import { getInvoiceNoteLineItem, actions as invoiceLineItemAction } from "./State/InvoiceNoteLineItem.slice";
import {
  actions,
  bankChargeCard,
  centralBank,
  chequePendingConfirmation,
  debitCardAvailable,
  invoiceGetDebitCard
} from "./State/InvoiceDirectPaymentProcessing.slice";

import { getChequeBankDetails, actions as chequeProccessingAction } from "./State/ManualChequeProcessing.slice";
import useRedirectByStatus from "./CreditNoteProcessing/InvoiceOrderView/useRedirectByStatus";

const InvoiceOrderPageToolbar = ({
  isDirty,
  onSubmit
}: {
  isDirty?: boolean;
  onSubmit?: () => void;
} & RouteComponentProps) => {
  const [isInvoiceNotesModalOpen, setIsInvoiceNotesModalOpen] = useState<boolean>(false);
  const dispatch = useDispatch();
  const { invoiceId } = useParams<{ orderno: string; invoiceId: any }>();
  const { invoiceDetails } = useAppSelector((state) => state.invoiceDetails);
  const { selectedRow, filterState } = useAppSelector((state: any) => state.invoiceNote);
  const [isAuthorizedBtnDisable, setAuthorizedBtnDisabled] = useState<boolean>(true);
  const [isManualChequeDisable, setManualChequeDisable] = useState<any>(true);
  const [isDirectPaymentBtnDisable, setDirectPaymentBtnDisable] = useState(true);
  const [isDirectPaymentReverseBtnDisable, setDirectPaymentReverseBtnDisable] = useState(true);
  const [isCancelBtnDisable, setCancelBtnDisable] = useState(false);
  const [invoiceType, setInvoiceType] = useState<string>("");
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { currentPage, invoices } = useAppSelector((state) => state?.invoiceNote.invoiceNoteList);
  const { isChargeCard, isCentralBank, isDebitCard } = useAppSelector((state) => state?.directPaymentProcess);
  const { addInvoiceType, isInvSaveSuccess, isInvCancelInitiated, isInvAuthorizeInitialed } = useAppSelector(
    (state) => state?.invoiceNoteLineItem
  );
  const [isError, setError] = useState(false);
  const [isPnpThresOpen, stePnpThresOpen] = useState(false);
  const [pnpThresPopupMessage, setThrespopupMessage] = useState("");
  const [isDiffPopup, setDiffPopup] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const location = useLocation();
  const isListingPage = location?.pathname === "/invoice-credit-note";
  const [isPendingChequeError, setPendingChequeError] = useState<boolean>(false);
  const [isPendingChequeMessage, setPendingChequeErrorMessage] = useState("");
  const [noActiveCardModal, setNoActiveCardModal] = useState(false);
  const [noActiveCardModalError, setNoActiveCardModalError] = useState("");
  const history = useHistory();
  const { checkInvoiceTypeAndRedirect, getSupplierPath } = useRedirectByStatus();
  const invoiceStatus = [
    INVOICE_STATUS.FULLY_AUTHORISED,
    INVOICE_STATUS.UNAUTHORISED,
    INVOICE_STATUS.ON_HOLD,
    INVOICE_STATUS.AUTHORISED
  ];

  // Get the invoice data accordingly
  const invoiceData = invoiceId ? invoiceDetails : selectedRow;

  const getInvoiceType = () => {
    if (invoiceData) {
      if (invoiceData?.invoice_type === invoiceOrderType.pi) {
        if (invoiceData?.order_id !== "" && invoiceData?.order_id !== null) {
          return INVOICE_TYPE.ORDERINV;
        }
        if (invoiceData?.sundry_invoice === sundryInvoiceType.t) {
          return INVOICE_TYPE.SUNDRYINV;
        }
        return INVOICE_TYPE.NONORDERINV;
      }
      if (invoiceData?.invoice_type === invoiceOrderType.pc) {
        return INVOICE_TYPE.CREDITNOTEINV;
      }
      return INVOICE_TYPE.INVOICEERROR;
    }
    return "";
  };

  const isAuthorizedDisabled = () => {
    if (invoiceData?.status === INVOICE_STATUS.UNAUTHORISED) {
      return false;
    }
    if (!invoiceId && !selectedRow) {
      return false;
    }
    return true;
  };

  const isCancelDisabled = () => {
    if (invoiceId && invoiceStatus.includes(invoiceDetails?.status)) {
      return false;
    }
    if (!invoiceId && invoiceStatus.includes(selectedRow?.status)) {
      return false;
    }
    if (!invoiceId && !selectedRow) {
      return false;
    }
    return true;
  };

  const isManualDisabled = () => {
    const invType =
      invoiceType === INVOICE_TYPE.ORDERINV ||
      invoiceType === INVOICE_TYPE.NONORDERINV ||
      invoiceType === INVOICE_TYPE.SUNDRYINV;

    const invStatus =
      invoiceData?.status === INVOICE_STATUS.FULLY_AUTHORISED || invoiceData?.status === INVOICE_STATUS.AUTHORISED;
    if (invStatus && invType && !isChargeCard && !isCentralBank) {
      return false;
    }
    return true;
  };

  const isValidChargeCardTransaction = useCallback(() => {
    const invType =
      invoiceType === INVOICE_TYPE.ORDERINV ||
      invoiceType === INVOICE_TYPE.NONORDERINV ||
      invoiceType === INVOICE_TYPE.SUNDRYINV ||
      invoiceType === INVOICE_TYPE.CREDITNOTEINV;

    const invStatus =
      invoiceData?.status === INVOICE_STATUS.FULLY_AUTHORISED || invoiceData?.status === INVOICE_STATUS.AUTHORISED;

    return invType && invStatus && isChargeCard;
  }, [invoiceType, invoiceData?.status, isChargeCard]);

  const isValidDebitCardTransaction = useCallback(() => {
    const invType =
      invoiceType === INVOICE_TYPE.ORDERINV ||
      invoiceType === INVOICE_TYPE.NONORDERINV ||
      invoiceType === INVOICE_TYPE.SUNDRYINV ||
      invoiceType === INVOICE_TYPE.CREDITNOTEINV;

    const invStatus =
      invoiceData?.status === INVOICE_STATUS.FULLY_AUTHORISED || invoiceData?.status === INVOICE_STATUS.AUTHORISED;

    return invType && invStatus && !isCentralBank && isDebitCard;
  }, [invoiceType, invoiceData?.status, isCentralBank, isDebitCard]);

  const isDirectPaymentProcessingDisable = useCallback(() => {
    if (invoiceData?.status === INVOICE_STATUS.PAID) {
      return true;
    }
    if (isValidChargeCardTransaction()) {
      return false;
    }
    if (isValidDebitCardTransaction()) {
      return false;
    }
    return true;
  }, [invoiceData?.status, isValidChargeCardTransaction, isValidDebitCardTransaction]);

  const isDirectPaymentReverseDisable = () => {
    const invPaymentMethod =
      invoiceData?.payment_type === PAYMENT_METHOD?.APChargeCard ||
      invoiceData?.payment_type === PAYMENT_METHOD?.APDebitCard;

    if (invoiceData?.status === INVOICE_STATUS.PAID) {
      if (invPaymentMethod) {
        return false;
      }
    }
    return true;
  };

  useEffect(() => {
    if (isInvSaveSuccess && isInvCancelInitiated) {
      setIsInvoiceNotesModalOpen(true);
    }
  }, [isInvSaveSuccess, isInvCancelInitiated]);

  useEffect(() => {
    if (isInvSaveSuccess && isInvAuthorizeInitialed && !isEmptyObject(invoiceData)) {
      authorizeClick();
    }
  }, [isInvSaveSuccess, isInvAuthorizeInitialed, invoiceData]);

  useEffect(() => {
    const invoiceTyoe: string = getInvoiceType();
    setInvoiceType(invoiceTyoe);
    const authorized = isAuthorizedDisabled();
    setAuthorizedBtnDisabled(authorized);
    const cancled = isCancelDisabled();
    setCancelBtnDisable(cancled);
    const directPayment = isDirectPaymentProcessingDisable();
    setDirectPaymentBtnDisable(directPayment);
    const manual = isManualDisabled();
    setManualChequeDisable(manual);
    const reversePayment = isDirectPaymentReverseDisable();
    setDirectPaymentReverseBtnDisable(reversePayment);
  }, [
    invoiceDetails,
    selectedRow,
    invoiceId,
    invoiceType,
    isDebitCard,
    setInvoiceType,
    isCentralBank,
    isChargeCard,
    addInvoiceType
  ]);

  // checking central bank and charge card
  useEffect(() => {
    if ((invoiceId || isListingPage) && invoiceData?.bank_id) {
      (async () => {
        const bankcharge: any = await isBankChargeCard(invoiceData?.bank_id);
        dispatch(actions.setBankChargeCard(bankcharge));
        const isCentral: any = await isCentralBankReq(invoiceData?.bank_id);
        dispatch(actions.setCentralBank(isCentral));
        const debitCard: any = await isDebitCardAvailable(invoiceData?.bank_id);
        dispatch(actions.setDebitCard(debitCard));
      })();
    }
  }, [ioActions, invoiceData, invoiceId]);

  //
  const checkPnpThreshold = async (id: any, invoiceNo: string) => {
    dispatch(
      invoiceThresholdCheck({
        invoiceID: id,
        callback: (data: any) => {
          if (data.pp_warning_threshold) {
            const ppAmount = data?.pp_amount === null ? 0 : data?.pp_amount;
            if (ppAmount > data?.pp_warning_threshold) {
              setThrespopupMessage(
                t("invoiceNote.pnpThreshold", {
                  invoiceNo,
                  ppAmount: parseFloat(ppAmount || 0).toFixed(2),
                  pp_warning_threshold: parseFloat(data?.pp_warning_threshold || 0).toFixed(2)
                })
              );
              stePnpThresOpen(true);
            } else {
              authorizeInvoiceHandle();
            }
          }
        }
      })
    );
    return true;
  };

  const fPreAuthInvoice = (id: any) => {
    const restrictedUser: boolean = false;
    let transactionString: string = "";
    if (restrictedUser) {
      dispatch(
        preAuthorisedStatus({
          invoiceID: id,
          callback: (data) => {
            if (data.status === apiStatusCode.OK) {
              if (data?.invoice_type === invoiceOrderType.pi) {
                transactionString = TRANSACTION?.INVOICE;
              } else if (data?.invoice_type === invoiceOrderType.pc) {
                transactionString = TRANSACTION?.CREDIT_NOTE;
              }
            }
          }
        })
      );
      return true;
    }
    return true;
  };

  const invoiceTypeInUrlFormat = () => {
    let invoiceTypeStr = "";
    if (invoiceData?.invoice_type === invoiceOrderType.pi) {
      if (invoiceData?.order_id !== "" && invoiceData?.order_id !== null) {
        invoiceTypeStr = invoiceTypesName?.ORDER_INVOICE;
      } else if (invoiceData?.sundry_invoice === sundryInvoiceType.t) {
        invoiceTypeStr = invoiceTypesName?.SUNDARY_INVOICE;
      } else {
        invoiceTypeStr = invoiceTypesName?.NON_ORDER_INVOICE;
      }
    } else if (invoiceData?.invoice_type === invoiceOrderType.pc) {
      invoiceTypeStr = invoiceTypesName?.CREDIT_NOTE;
    }
    return invoiceTypeStr;
  };

  const redirectOnFirstRecordOnViewPage = () => {
    if (Array.isArray(invoices) && invoices.length > 0) {
      let redirectRecord = null;
      const firstRecord = invoices.at(0) ?? null;
      const secondRecord = invoices.at(1) ?? null;
      if (invoiceId && invoiceId === String(invoices.at(0)?.invoice_id)) {
        redirectRecord = secondRecord;
      } else {
        redirectRecord = firstRecord;
      }
      dispatch(idActions.setRedirectAlertModal(true));
    }
  };

  function updatedInvoiceIdOnToolbarClick() {
    dispatch(ioActions.setFilters({ ...filterState, invoiceId: invoiceData.invoice_id }));
  }

  const checkInvOrderMatch = async (id: any) => {
    const res: any = await dispatch(getOrderInvoiceDifference({ invoiceId: id }));
    if (res?.payload.length === 0) {
      return false;
    }
    return true;
  };

  const authorizeInvoiceHandle = async () => {
    if (invoiceId) {
      dispatch(
        authorisedStatus({
          invoice_id: invoiceDetails?.invoice_id,
          amount: invoiceDetails?.total,
          bank_id: invoiceDetails?.bank_id,
          inv_last_update: invoiceDetails?.inv_last_update,
          ord_last_update: invoiceDetails?.ord_last_update,
          source: invoiceDetails?.source,
          callback: (data: any) => {
            if (data?.authorizedOrders[0] === invoiceDetails?.invoice_id) {
              if (filterState?.status) {
                redirectOnFirstRecordOnViewPage();
              } else {
                dispatch(
                  getInvoiceDetails({
                    invoiceId,
                    callback: (data) => {
                      checkInvoiceTypeAndRedirect(data);
                      dispatch(
                        getInvoiceNoteLineItem({
                          invoiceID: data.invoice_id,
                          OrderId: data.order_id,
                          callback: (res) => dispatch(invoiceLineItemAction.setSelectedRow(res[0]))
                        })
                      );
                    }
                  })
                );
              }
            } else {
              setError(true);
              setErrorMessage(data?.unauthorizedOrders[invoiceDetails?.invoice_id]);
            }
          }
        })
      );
    } else {
      dispatch(
        authorisedStatus({
          invoice_id: selectedRow?.invoice_id,
          amount: selectedRow?.total,
          bank_id: selectedRow?.bank_id,
          inv_last_update: selectedRow?.inv_last_update,
          ord_last_update: selectedRow?.ord_last_update,
          source: selectedRow?.source,
          callback: (data: any) => {
            try {
              if (data?.authorizedOrders[0] === selectedRow.invoice_id) {
                dispatch(
                  getInvoiceOrdersFilter({
                    sequence: filterState?.sequence,
                    status: filterState?.status,
                    order: filterState?.order,
                    pageNumber: String(currentPage),
                    pageSize: filterState?.pageSize,
                    type: filterState?.type,
                    lookingFor: "",
                    invoiceId: selectedRow?.invoice_id,
                    callback: (response: any) => {
                      if (response?.invoices && response?.invoices?.length > 0) {
                        const currentInvoice = response.invoices;
                        const selectedData = currentInvoice
                          .filter((item: any) => item.invoice_id === selectedRow?.invoice_id)
                          ?.at(0);
                        if (selectedData) {
                          dispatch(ioActions.setSelectedRow(selectedData));
                        } else if (currentInvoice && response?.invoices?.length > 0) {
                          dispatch(ioActions.setSelectedRow(response.invoices?.at(0)));
                        }
                      } else {
                        dispatch(ioActions.clearInvoices());
                      }
                    }
                  })
                );
              } else {
                setError(true);
                setErrorMessage(data?.unauthorizedOrders[selectedRow?.invoice_id]);
              }
            } catch (error) {
              console.error("Error occurred:", error);
            }
          }
        })
      );
    }
  };

  const authorizeClick = async () => {
    dispatch(invoiceLineItemAction.setIsInvAuthorizeInitialed(false));
    dispatch(invoiceLineItemAction.setIsInvSaveSuccess(false));
    let continueProcess: boolean = true;
    const invoiceType = invoiceId ? invoiceDetails?.invoice_type : selectedRow?.invoice_type;
    const orderId = invoiceId ? invoiceDetails?.order_id : selectedRow?.order_id;
    const source = invoiceId ? invoiceDetails?.source : selectedRow?.source;
    const invID = invoiceId ? invoiceDetails?.invoice_id : selectedRow?.invoice_id;
    const invoiceNo = invoiceId ? invoiceDetails?.inv_no : selectedRow?.inv_no;
    const eInvoice = source === sourceType?.XML;
    continueProcess = fPreAuthInvoice(invID);
    if (continueProcess) {
      if (invoiceType === invoiceOrderType.pi && orderId !== "" && orderId !== null) {
        const invOrdDiffNotify: any = eInvoice && checkInvOrderMatch(invID);
        if (invOrdDiffNotify) {
          setDiffPopup(true);
        } else {
          checkPnpThreshold(invID, invoiceNo);
        }
      } else {
        authorizeInvoiceHandle();
      }
    }
  };

  const isBankChargeCard = async (bankId: number) => {
    const res: any = await dispatch(bankChargeCard(bankId));
    if (res?.payload) {
      return true;
    }
    return false;
  };

  const isCentralBankReq = async (bankId: number) => {
    const res: any = await dispatch(centralBank(bankId));
    if (res?.payload === BOOLEAN_DATA?.True) {
      return true;
    }
    return false;
  };

  const isDebitCardAvailable = async (bankId: number) => {
    const res: any = await dispatch(debitCardAvailable(bankId));
    if (res?.payload) {
      return true;
    }
    return false;
  };

  const onChequekPending = async (invoiceId: any) => {
    const res: any = await dispatch(chequePendingConfirmation(invoiceId));
    const result = res?.payload === BOOLEAN_DATA?.True;
    if (result) {
      return true;
    }
    return false;
  };

  const fetchCardData = async () => {
    const data: any = await dispatch(invoiceGetDebitCard(invoiceData?.bank_id));
    if (data && data?.payload) {
      const updatedCardData = (data?.payload as any[]).map((item: any) => ({
        ...item,
        disp_expiry_date: formatCardExpiryDate(item?.disp_expiry_date)
      }));
      dispatch(actions.setDebitcardData(updatedCardData as any));
      dispatch(actions.setLoaded(true));
      return updatedCardData;
    }
    return data?.payload;
  };

  const manualCheckProcessingBtnClick = async () => {
    const modifyUrlForOrderInvoie = invoiceData?.order_id
      ? `${invoiceTypeInUrlFormat()}/orderno/${invoiceData?.order_id}/invoiceId/${invoiceData?.invoice_id}`
      : `${invoiceTypeInUrlFormat()}/invoiceId/${invoiceData?.invoice_id}`;

    const redirectUrl = invoiceId
      ? `${getSupplierPath()}/invoice-credit-note/${modifyUrlForOrderInvoie}/manual-cheque-processing`
      : `${getSupplierPath()}/invoice-credit-note/manual-cheque-processing?invoiceId=${
          invoiceData?.invoice_id ? invoiceData?.invoice_id : ""
        }`;
    dispatch(chequeProccessingAction.setChequePaymentLoading(true));
    const isChequePending = await onChequekPending(invoiceData?.invoice_id);
    if (isChequePending) {
      const sInvCred: string =
        invoiceData?.invoice_type === invoiceOrderType?.pc ? invoicecanceltype?.credit : invoicecanceltype?.invoice;
      setPendingChequeError(true);
      setPendingChequeErrorMessage(sInvCred);
    } else {
      const chequeList: any = await dispatch(getChequeBankDetails({ bankId: invoiceData?.bank_id, isActive: true }));
      const recordCount = chequeList?.payload?.length > 0;
      if (recordCount) {
        history.push(redirectUrl);
        updatedInvoiceIdOnToolbarClick();
      } else {
        dispatch(
          uiActions.alertPopup({
            enable: true,
            type: MODAL_TYPE?.ALERT,
            message: t("invoiceNote.noChequeAvailableErrorMessage"),
            title: t("invoiceNote.invoiceModalCancel"),
            notificationType: NotificationStatus?.WARNING
          })
        );
      }
    }
    dispatch(chequeProccessingAction.setChequePaymentLoading(false));
  };

  const directPaymentBtnClick = async () => {
    try {
      const modifyUrlForOrderInvoice = invoiceData?.order_id
        ? `${invoiceTypeInUrlFormat()}/orderno/${invoiceData?.order_id}/invoiceId/${invoiceData?.invoice_id}`
        : `${invoiceTypeInUrlFormat()}/invoiceId/${invoiceData?.invoice_id}`;

      const redirectUrl = invoiceId
        ? `${getSupplierPath()}/invoice-credit-note/${modifyUrlForOrderInvoice}/direct-payment-processing`
        : `${getSupplierPath()}/invoice-credit-note/direct-payment-processing`;

      dispatch(actions.setDirectPaymentLoading(true));

      // Check if there's a pending cheque
      const isChequePending = await onChequekPending(invoiceData?.invoice_id);
      if (isChequePending) {
        const sInvCred: string =
          invoiceData?.invoice_type === invoiceOrderType?.pc ? invoicecanceltype?.credit : invoicecanceltype?.invoice;
        setPendingChequeError(true);
        setPendingChequeErrorMessage(sInvCred);
      } else {
        // Fetch card data for payment
        const cardList: any = await fetchCardData();
        const recordCount = cardList && cardList?.length > 0;
        if (recordCount) {
          // Set the selected card if only one card is available
          if (cardList.length === 1) {
            dispatch(actions.setSelectedRow(cardList[0]));
          }
          // Proceed with payment
          const cardModalTitle = isChargeCard ? t("invoiceNote.chargeCardPayment") : t("invoiceNote.debitCardPayment");
          dispatch(actions.setCardModaltitle(cardModalTitle));
          dispatch(actions.setStoreCurrPage(currentPage));
          history.push(redirectUrl);
          updatedInvoiceIdOnToolbarClick();
        } else {
          const modalErrorMsg = isChargeCard
            ? t("invoiceNote.directPaymentErrorMessage")
            : t("invoiceNote.directPaymentErrorMessage2");

          dispatch(
            uiActions.alertPopup({
              enable: true,
              type: MODAL_TYPE?.ALERT,
              message: modalErrorMsg,
              title: t("common.information"),
              notificationType: NotificationStatus?.HIGHLIGHT
            })
          );
        }
      }
    } catch (error) {
      console.log(error);
    } finally {
      dispatch(actions.setDirectPaymentLoading(false));
    }
  };

  const directPaymentReversalBtnClick = () => {
    const modifyUrlForOrderInvoie = invoiceData?.order_id
      ? `${invoiceTypeInUrlFormat()}/orderno/${invoiceData?.order_id}/invoiceId/${invoiceData?.invoice_id}`
      : `${invoiceTypeInUrlFormat()}/invoiceId/${invoiceData?.invoice_id}`;

    const redirectUrl = invoiceId
      ? `${getSupplierPath()}/invoice-credit-note/${modifyUrlForOrderInvoie}/direct-payment-reversal`
      : `${getSupplierPath()}/invoice-credit-note/direct-payment-reversal`;
    history.push(redirectUrl);
    updatedInvoiceIdOnToolbarClick();
    dispatch(actions.setStoreCurrPage(currentPage));
  };
  return (
    <>
      <Grid
        justify="flex-end"
        className="tools"
      >
        <GridItem>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={t("invoiceNote.cancelInvCrNote")}
            onClick={async () => {
              if (onSubmit && (!invoiceId || isDirty)) {
                dispatch(invoiceLineItemAction.setIsInvCancelInitialed(true));
                await onSubmit();
              } else {
                setIsInvoiceNotesModalOpen(true);
              }
            }}
            disabled={isCancelBtnDisable}
          >
            <TaskRemove size={22} />
          </Button>
        </GridItem>
        <GridItem>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={t("invoiceNote.authoriseInvCrNote")}
            onClick={async () => {
              if (onSubmit && (!invoiceId || isDirty)) {
                dispatch(invoiceLineItemAction.setIsInvSaveSuccess(false));
                dispatch(invoiceLineItemAction.setIsInvAuthorizeInitialed(true));
                await onSubmit();
              } else {
                authorizeClick();
              }
            }}
            disabled={isAuthorizedBtnDisable}
          >
            <DocumentTasks size={22} />
          </Button>
        </GridItem>
        <GridItem>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={t("invoiceNote.manualCheckProcessing")}
            onClick={manualCheckProcessingBtnClick}
            disabled={isManualChequeDisable}
          >
            <LicenseDraft size={22} />
          </Button>
        </GridItem>
        <GridItem>
          <Button
            // ref={directPaymentBtnRef}
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={t("invoiceNote.directpaymentProcessing")}
            disabled={isDirectPaymentBtnDisable}
            onClick={directPaymentBtnClick}
          >
            <Purchase size={22} />
          </Button>
        </GridItem>
        <GridItem>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            title={t("invoiceNote.directpaymentReversal")}
            disabled={isDirectPaymentReverseBtnDisable}
            onClick={directPaymentReversalBtnClick}
          >
            <Undo size={22} />
          </Button>
        </GridItem>
      </Grid>
      <InvoiceNotesCancalModal
        isOpen={isInvoiceNotesModalOpen}
        setOpen={setIsInvoiceNotesModalOpen}
        redirectOnFirstRecordOnViewPage={redirectOnFirstRecordOnViewPage}
      />

      {/* Threshold popup */}
      <ConfirmModal
        isOpen={isPnpThresOpen}
        setOpen={stePnpThresOpen}
        title={t("invoiceNote.invoiceModalCancel")}
        message={pnpThresPopupMessage}
        className="cancel-popup"
        confirm={() => {
          stePnpThresOpen(false);
          authorizeInvoiceHandle();
        }}
      />

      {/* Invoice Order Difference Popup */}
      <ConfirmModal
        isOpen={isDiffPopup}
        setOpen={setDiffPopup}
        title={t("invoiceNote.invoiceModalCancel")}
        message={t("invoiceNote.authOrderdiff", {
          inv_no: invoiceData?.inv_no
        })}
        className="cancel-popup"
        confirm={() => {
          const invID = invoiceId ? invoiceDetails?.invoice_id : selectedRow?.invoice_id;
          const invoiceNo = invoiceId ? invoiceDetails?.inv_no : selectedRow?.inv_no;
          setDiffPopup(false);
          checkPnpThreshold(invID, invoiceNo);
        }}
      />

      {/* pendingCheque error  modal */}
      <Modalv2
        header={t("invoiceNote.invoiceModalCancel")}
        isOpen={isPendingChequeError}
        className="cancel-popup"
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setPendingChequeError(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
      >
        <Notification
          actionElement={1}
          dataTestId="warning-id"
          escapeExits
          id="warning-id"
          hideCloseButton
          status={NotificationStatus.WARNING}
          title={t("invoiceNote.pendingChequeError", {
            sInvCred: isPendingChequeMessage
          })}
          className="mb-18 confirm-modal-text"
        />
      </Modalv2>

      {/* Not active card modal */}
      <Modalv2
        header={t("invoiceNote.invoiceModalCancel")}
        isOpen={noActiveCardModal}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setNoActiveCardModal(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
        className="cancel-popup"
      >
        <Notification
          actionElement={1}
          dataTestId="warning-id"
          escapeExits
          id="warning-id"
          hideCloseButton
          status={NotificationStatus?.HIGHLIGHT}
          title={noActiveCardModalError || ""}
          className="mb-18 confirm-modal-text"
        />
      </Modalv2>

      {/*  */}
      {/*  */}
      <Modalv2
        header={t("invoiceNote.invoiceModalCancel")}
        isOpen={isError}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setError(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
        className="cancel-popup"
      >
        <Notification
          actionElement={1}
          dataTestId="warning-id"
          escapeExits
          id="warning-id"
          hideCloseButton
          status={NotificationStatus.WARNING}
          title={errorMessage}
          className="mb-18 confirm-modal-text"
        />
      </Modalv2>
    </>
  );
};

InvoiceOrderPageToolbar.defaultProps = {
  onSubmit: undefined,
  isDirty: undefined
};

export default withRouter(InvoiceOrderPageToolbar);
