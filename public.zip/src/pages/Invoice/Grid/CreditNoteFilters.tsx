import {
  Button,
  ButtonColor,
  ButtonSize,
  Dropdown,
  DropdownItem,
  FormLabel,
  Grid,
  GridItem,
  ISelectedItem,
  Icon,
  IconSize,
  RadioButton,
  RadioLabelPosition,
  TextInput,
  TextInputSize
} from "@essnextgen/ui-kit";
import React, { forwardRef, useEffect, useLayoutEffect, useState } from "react";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import useDebounce from "@/hooks/useDebounce";
import DatePicker from "react-datepicker";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { STATUS } from "@/types/UseStateType";
import columnDef from "./columnDef";
import "./CreditNoteFilterStyle.scss";
import { TgetInvoiceNoteOrder, getInvoiceOrdersFilter, actions as ioactions } from "../State/InvoiceNoteList.slice";
import { getInvoiceNoteStatus, actions } from "../State/InvoiceNoteStatus.slice";
import { getInvoiceNoteType, actions as actionsType } from "../State/InvoiceNoteType.slice";

// import { getInvoiceOrdersFilter, getInvoicesByTagFilters, actions as ioActions } from "../State/InvoiceNoteList.slice";

const CreditNoteFilters = ({ lookingFor, setLookingFor }: any) => {
  const { setInvoiceNoteType } = actionsType;
  // const [lookingFor, setLookingFor] = useState<string | undefined>(undefined);
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const { selectedRow } = useAppSelector((state) => state.invoiceNote);
  const dispatch = useDispatch<AppDispatch>();
  // const debouncedValue = useDebounce(lookingFor, 500);

  const lookingForChangehandler = (value: string) => {
    setLookingFor(value);
  };

  const {
    allInvoice,
    filterState,
    status,
    invoiceNoteList,
    columnDef: prevColumnDef
  } = useAppSelector((state) => state.invoiceNote);
  const { sequenceValue, order: selectedSort } = filterState as TgetInvoiceNoteOrder;

  const handleSequenceChange = (value: React.SetStateAction<string>, sequenceIndex: number) => {
    if (columns[0].checkboxSelection === true) {
      let columnSet = [];
      switch (value) {
        case "inv_no":
          columnSet = new Set([columns[0], columns[1], columns[2], columns[3], ...prevColumnDef]) as any;
          dispatch(ioactions.setColumnDef(columnSet));
          break;

        case "inv_date":
          columnSet = new Set([columns[0], columns[2], columns[1], columns[3], ...prevColumnDef]) as any;
          dispatch(ioactions.setColumnDef(columnSet));
          break;

        case "trans_no":
          columnSet = new Set([columns[0], columns[3], columns[1], columns[2], ...prevColumnDef]) as any;
          dispatch(ioactions.setColumnDef(columnSet));
          break;

        case "source":
          columnSet = new Set([columns[0], columns[9], columns[1], columns[2], ...prevColumnDef]) as any;
          dispatch(ioactions.setColumnDef(columnSet));
          break;

        case "client_name":
          columnSet = new Set([columns[0], columns[8], columns[1], columns[2], ...prevColumnDef]) as any;
          dispatch(ioactions.setColumnDef(columnSet));
          break;

        case "total":
          columnSet = new Set([columns[0], columns[4], columns[1], columns[2], ...prevColumnDef]) as any;
          dispatch(ioactions.setColumnDef(columnSet));
          break;

        default:
          columnSet = new Set([columns[0], columns[1], columns[2], columns[3], ...prevColumnDef]) as any;
          dispatch(ioactions.setColumnDef(columnSet));
          break;
      }
    }
    lookingForChangehandler("");
    setColumn([...columnDef]);
    dispatch(ioactions.resetFocus());
    dispatch(
      ioactions.setFilters({
        invoiceId: selectedRow?.invoice_id,
        lookingFor: "",
        sequence: String(sequenceIndex),
        sequenceValue: String(value),
        defaultSequence: false
      })
    );
  };

  const {
    status: invoiceOrderResponseStatus,
    invoiceNoteStatus: invoiceStatus,
    selectedStatus
  } = useAppSelector((state) => state.invoiceStatus);

  const {
    status: invoiceTypeResponse,
    invoiceNoteType: invoiceType,
    selectedType
  } = useAppSelector((state) => state.invoiceNoteType);

  const lookingForCallback = (value: string) => {
    dispatch(ioactions.setFilters({ lookingFor, defaultSequence: filterState?.defaultSequence }));
  };

  const CustomButton = forwardRef(({ value, onClick }: any, ref: any) => (
    <Button
      color={ButtonColor.Secondary}
      onClick={onClick}
      className="input-search-button essui-button-icon-only--small"
      size={ButtonSize.Small}
      disabled={sequenceValue !== "inv_date"}
      ref={ref}
    >
      <Icon
        size={IconSize.Medium}
        name="calendar"
      />
    </Button>
  ));
  return (
    <>
      <Grid
        className="custom-table"
        align="center"
        justify="space-between"
      >
        <GridItem xl={3}>
          <div className="essui-global-typography-default-h2">
            <div className="looking-for">
              <LookingFor
                initialValue={lookingFor}
                callback={lookingForCallback}
                changeHandler={lookingForChangehandler}
                hasDatePicker
                disableDatePicker={filterState?.sequenceValue !== "inv_date"}
                isInputReadOnly={status === STATUS.LOADING}
                className="essui-global-typography-default-h2 looking-for-container"
              />
            </div>
          </div>
        </GridItem>
        <GridItem xl={7}>
          <Grid justify="flex-end">
            <GridItem xl={5}>
              <FormLabel forId="status">{t("invoiceNote.status")}</FormLabel>
              <Dropdown
                size={TextInputSize.Medium}
                searchable
                isScrollbarVisible
                selectedItem={selectedStatus}
                onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => {
                  dispatch(actions.setInvoiceNoteStatus(item));
                  dispatch(
                    ioactions.setFilters({
                      status: item.value,
                      defaultSequence: filterState?.defaultSequence,
                      pageNumber: "1",
                      lookingFor: ""
                    })
                  );
                  dispatch(ioactions.resetFocus());
                  lookingForChangehandler("");
                }}
              >
                {(invoiceStatus || []).map((status: { [key: string]: string }, i: any) => {
                  const id = `dropdown-${i}`;
                  return (
                    <DropdownItem
                      key={id}
                      id={id}
                      text={status.description}
                      value={status.code}
                    >
                      {status.description}
                    </DropdownItem>
                  );
                })}
              </Dropdown>
            </GridItem>
            <GridItem xl={5}>
              <FormLabel forId="view">{t("invoiceNote.type")}</FormLabel>
              <div className="filter">
                <Dropdown
                  size={TextInputSize.Medium}
                  searchable
                  isScrollbarVisible
                  selectedItem={selectedType}
                  onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => {
                    dispatch(setInvoiceNoteType(item));
                    dispatch(
                      ioactions.setFilters({
                        type: item.text,
                        defaultSequence: filterState?.defaultSequence,
                        pageNumber: "1",
                        lookingFor: ""
                      })
                    );
                    dispatch(ioactions.resetFocus());
                    lookingForChangehandler("");
                  }}
                >
                  {(invoiceType || []).map((view: { [key: string]: string }, i: any) => {
                    const id = `dropdown-${i}`;
                    return (
                      <DropdownItem
                        key={id}
                        id={id}
                        text={view.description}
                        value={view.code}
                      >
                        {view.description}
                      </DropdownItem>
                    );
                  })}
                </Dropdown>
              </div>
            </GridItem>
          </Grid>
        </GridItem>
      </Grid>
      <Grid
        align="flex-end"
        className="custom-table"
        justify="space-between"
      >
        <GridItem xl={9}>
          <FormLabel>{t("invoiceNote.sequence")}</FormLabel>
          <div className="essui-textinput sequence">
            {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
              const sequenceId = `sequence=${index + 1}`;
              const sequence = column.sequenceIndex
                ? columnDef.find((s) => s.sequenceIndex === index && s.sequence && s.sequenceIndex)
                : column;
              return (
                <RadioButton
                  label={sequence?.sequenceName ? sequence?.sequenceName : sequence?.headerName}
                  labelPosition={RadioLabelPosition.Right}
                  value={sequence?.field}
                  onChange={() => handleSequenceChange(sequence?.field!, index)}
                  isSelected={sequenceValue === sequence?.field}
                  key={sequenceId}
                />
              );
            })}
          </div>
        </GridItem>
        <GridItem xl={3}>
          <div className="essui-textinput sequence">
            <RadioButton
              className="sorting"
              label="Ascending"
              labelPosition={RadioLabelPosition.Right}
              value="0"
              onChange={() => {
                dispatch(
                  ioactions.setFilters({
                    invoiceId: selectedRow?.invoice_id,
                    order: "0",
                    defaultSequence: false,
                    lookingFor: ""
                  })
                );
                dispatch(ioactions.resetFocus());
                lookingForChangehandler("");
              }}
              isSelected={selectedSort === "0"}
            />
            <RadioButton
              className="sorting"
              label="Descending"
              labelPosition={RadioLabelPosition.Right}
              value="1"
              onChange={() => {
                dispatch(
                  ioactions.setFilters({
                    invoiceId: selectedRow?.invoice_id,
                    order: "1",
                    defaultSequence: false,
                    lookingFor: ""
                  })
                );
                dispatch(ioactions.resetFocus());
                lookingForChangehandler("");
              }}
              isSelected={selectedSort === "1"}
            />
          </div>
        </GridItem>
      </Grid>
    </>
  );
};

export default CreditNoteFilters;
