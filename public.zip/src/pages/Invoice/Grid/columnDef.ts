import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

export const InvoiceOrdersDef: TColumnDef = [
  {
    field: "checkbox",
    checkboxSelection: true
  },
  {
    headerName: "Invoice/Credit Note No.",
    field: "disp_inv_no",
    sequence: true,
    sequenceIndex: 0
  },
  {
    headerName: "Invoice Date",
    field: "inv_date",
    sequenceName: "Date",
    cellRenderer: "GridCellLink",
    sequence: true,
    sequenceIndex: 1
  },
  {
    headerName: "Trans ID",
    field: "trans_no",
    sequence: true,
    sequenceIndex: 2
  },
  {
    headerName: "Amount",
    field: "total",
    sequence: true,
    sequenceIndex: 5,
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Status",
    field: "description"
  },
  {
    headerName: "Order Number",
    field: "ordernum"
  },
  {
    headerName: "Cross Year",
    field: "transfer_code"
  },
  {
    headerName: "Supplier",
    field: "client_name",
    sequence: true,
    sequenceIndex: 4,
    enableTooltip: true
  },
  {
    headerName: "SRC",
    field: "source",
    sequenceName: "Source",
    sequence: true,
    sequenceIndex: 3
  },
  {
    headerName: "Var.",
    field: "actionLink",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "",
    field: "detailLink",
    cellRenderer: "GridCellLink"
  }
];

export default InvoiceOrdersDef;
