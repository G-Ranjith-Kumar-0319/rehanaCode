import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { type } from "@testing-library/user-event/dist/type";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "../../../config";

type InvoiceNoteStateType = {
  cardSelectedRow?: any;
  debitCardData?: any;
  status?: string;
  isLoaded?: boolean;
  isChargeCard?: any;
  isCentralBank?: any;
  isDebitCard?: any;
  cardModaltitle?: string;
  isDirectPaymentLoading?: boolean;
  invoicePaymentDetail: string | any;
  storeCurrPage: string;
};

const initialState: InvoiceNoteStateType = {
  cardSelectedRow: undefined,
  debitCardData: [],
  status: "",
  isLoaded: false,
  isChargeCard: null,
  isCentralBank: null,
  isDebitCard: null,
  cardModaltitle: "",
  isDirectPaymentLoading: false,
  invoicePaymentDetail: [],
  storeCurrPage: ""
};

export const invoiceGetDebitCard = createAsyncThunk("invoiceOrders/getDebitCard", async (bankId: any) => {
  const response = await client.get(`${apiRoot}/invoice/invoice-get-debitcards?bankId=${bankId}`);

  return response.data;
});

export const invoiceDirectPaymentProccesing = createAsyncThunk(
  "invoiceOrders/directPayment",
  async ({ bankId, invoiceId, period, debitCardId, paymentBy, narrative }: any) => {
    const response = await client.post(`${apiRoot}/invoice/invoice-direct-payment-processing`, {
      bank_id: bankId,
      invoice_id: invoiceId,
      period,
      narrative,
      debit_card_id: debitCardId,
      payment_by: paymentBy
    });
    return response?.data;
  }
);

export const chequePendingConfirmation = createAsyncThunk("invoiceOrders/getDebitCard", async (invoiceId: any) => {
  const response = await client.get(`${apiRoot}/Cheques/cheque-pending-confirmation?invoiceId=${invoiceId}`);
  return response.data;
});

export const bankChargeCard = createAsyncThunk("invoiceOrders/bankChargeCard", async (bankId: any) => {
  const response = await client.get(`${apiRoot}/invoice/invoice-is-bank-charge-card?bankId=${bankId}`);
  return response.data;
});

export const debitCardAvailable = createAsyncThunk("invoiceOrders/debitCardAvailable", async (bankId: any) => {
  const response = await client.get(`${apiRoot}/invoice/invoice-debit-card-available?bankId=${bankId}`);
  return response.data;
});

export const centralBank = createAsyncThunk("invoiceOrders/centralBank", async (bankId: any) => {
  const response = await client.get(`${apiRoot}/invoice/invoice-is-central-bank?bankId=${bankId}`);
  return response.data;
});

export const invoiceDebitRun = createAsyncThunk(
  "invoiceOrders/invoiceDebitRunNew",
  /* eslint-disable camelcase */
  async ({
    invoiceID,
    isChargeCard,
    callback
  }: {
    invoiceID: string;
    isChargeCard: boolean;
    callback?: (data: { [key: string]: any }) => void;
  }) => {
    const res = await client.get(
      `${apiRoot}/invoice/invoice-debit-run?invoiceId=${invoiceID}&isChargeCard=${isChargeCard}`
    );

    if (res.data && callback) {
      callback(res.data);
    }
    return res.data;
  }
);

export const directCancelPayment = createAsyncThunk(
  "invoiceOrders/directCancelPayment",
  /* eslint-disable camelcase */
  async ({
    invoice_id,
    reason,
    callback
  }: {
    invoice_id: string;
    reason: string;
    callback?: (data: { [key: string]: any }) => void;
  }) => {
    const res = await client.post(`${apiRoot}/invoice/invoice-direct-cancel-payment`, {
      invoice_id,
      reason
    });

    if (res.data && callback) {
      callback(res.data);
    }
    return res.data;
  }
);
/**
 * # Invoice Direct Payment processing Slice
 * This slice of state is responsible for managing direct payment processing state
 */
const slice = createSlice({
  initialState,
  name: "directPaymentProcess",
  extraReducers: (builder) => {
    builder.addCase(invoiceGetDebitCard.fulfilled, (state, action) => {
      state.debitCardData = action.payload;
      state.status = STATUS.SUCCESS;
    });
    builder.addCase(invoiceDebitRun.fulfilled, (state, action) => {
      state.invoicePaymentDetail = action.payload;
      state.status = STATUS.SUCCESS;
    });
  },
  reducers: {
    setSelectedRow: (state, action) => {
      state.cardSelectedRow = action.payload;
    },
    setDebitcardData: (state, action) => {
      state.debitCardData = action.payload;
    },
    setLoaded: (state, action) => {
      state.isLoaded = action.payload;
    },
    setBankChargeCard: (state, action) => {
      state.isChargeCard = action.payload;
    },
    setCentralBank: (state, action) => {
      state.isCentralBank = action.payload;
    },
    setDebitCard: (state, action) => {
      state.isDebitCard = action.payload;
    },
    setCardModaltitle: (state, action) => {
      state.cardModaltitle = action.payload;
    },
    setDirectPaymentLoading: (state, action) => {
      state.isDirectPaymentLoading = action.payload;
    },
    setStoreCurrPage: (state, action) => {
      state.storeCurrPage = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
