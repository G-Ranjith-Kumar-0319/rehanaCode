import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import {
  INVOICE_STATUS,
  INVOICE_TYPE,
  STATUS,
  TAGTYPES,
  apiStatusCode,
  getCurrentFinancialYear
} from "@/types/UseStateType";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { RootState } from "@/store/store";
import { type } from "@testing-library/user-event/dist/type";
import {
  convertDateWithLeadingZero,
  dateConvert,
  findDifferencesByProperty,
  getDateTime,
  removeDuplicates
} from "@/utils/getDataSource";
import { apiRoot, client } from "../../../config";
import columnDef from "../Grid/columnDef";

export type InvoiceNoteListType = { [key: string]: any }[];

export type InvoiceNoteType = {
  invoices: InvoiceNoteListType;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: string;
  checkedRows: { [key: string]: any }[];
};

type InvoiceNoteStateType = {
  allInvoice: { [key: string]: any }[];
  selectedRow?: { [key: string]: any };
  invoiceNoteList: InvoiceNoteType;
  error: string | undefined;
  checkedRows: { [key: string]: any }[];
  unCheckedRows: { [key: string]: any }[];
  status?: STATUS;
  pageStatus?: STATUS;
  columnDef: TColumnDef;
  viewStatus?: STATUS;
  cancelStatus?: STATUS;
  order?: Number;
  filterState?: TgetInvoiceNoteOrder;
  isFocus?: boolean;
  isInvoiceTypeModalOpen: boolean;
  currentInvoiceType: string;
  defaultSequence?: boolean;
  checkedInvoices?: Number[];
  isPrintLoading: boolean;
  deleteLine: { [key: string]: any }[];
  addInvoiceOrderStatus?: STATUS;
  lineParts: { [key: string]: any }[];
  isHotKey?: boolean;
};
export type TgetInvoiceNoteOrder = {
  pageNumber?: string;
  pageSize?: string;
  type?: string;
  status?: string | any;
  order?: string;
  sequence?: string;
  sequenceValue?: string;
  lookingFor?: string | undefined;
  isFocus?: boolean;
  invoiceId?: null | number;
  defaultSequence?: boolean;
};
const initialState: InvoiceNoteStateType = {
  allInvoice: [],
  filterState: {
    pageNumber: "1",
    pageSize: "10",
    status: null,
    order: "1",
    sequence: "0",
    sequenceValue: columnDef.filter((col) => !!col.sequence)[0].field,
    lookingFor: "",
    defaultSequence: true
  },
  checkedRows: [],
  unCheckedRows: [],
  deleteLine: [],
  lineParts: [],
  checkedInvoices: [],
  invoiceNoteList: {
    invoices: [] || null,
    currentPage: 1,
    totalCount: "",
    pageSize: 10,
    totalPages: 0,
    checkedRows: []
  },
  columnDef,
  error: "",
  isFocus: false,
  isInvoiceTypeModalOpen: false,
  currentInvoiceType: "",
  isPrintLoading: false,
  isHotKey: false
};

let orderInvoice;

type Page = { pageNumber?: number; pageSize?: number };

/** Thunks */
export const getInvoiceNotes = createAsyncThunk(
  "invoice/list",
  async ({ sequence, order, type, status }: TgetInvoiceNoteOrder) => {
    switch (type) {
      case "All":
        type = "";
        orderInvoice = "";
        break;
      case "All Invoices":
        type = "PI";
        orderInvoice = "";
        break;
      case "All Order Invoices":
        type = "PI";
        orderInvoice = "T";
        break;
      case "All Credit Notes":
        type = "PC";
        orderInvoice = "";
        break;
      case "All Non-Order Invoices":
        type = "PI";
        orderInvoice = "F";
        break;
      case "All Sundry Invoices":
        type = "PS";
        orderInvoice = "F";
        break;
      default:
        type = "";
        orderInvoice = "";
        break;
    }
    const response = await client.get(`${apiRoot}/invoice/sequence`, {
      params: { sequence, order, type, status, orderInvoice }
    });
    return response.data;
  }
);

export const getInvoiceOrdersFilter = createAsyncThunk(
  "invoiceOrders/list",
  async (
    {
      pageSize,
      pageNumber,
      status,
      type,
      sequence,
      order,
      defaultSequence,
      lookingFor,
      invoiceId,
      callback
    }: TgetInvoiceNoteOrder & { callback?: (data: any) => void },
    thunkAPI
  ) => {
    switch (type) {
      case "All":
        type = "";
        orderInvoice = "";
        break;
      case "All Invoices":
        type = "PI";
        orderInvoice = "";
        break;
      case "All Order Invoices":
        type = "PI";
        orderInvoice = "T";
        break;
      case "All Credit Notes":
        type = "PC";
        orderInvoice = "";
        break;
      case "All Non-Order Invoices":
        type = "PI";
        orderInvoice = "F";
        break;
      case "All Sundry Invoices":
        type = "PS";
        orderInvoice = "F";
        break;
      default:
        type = "";
        orderInvoice = "";
        break;
    }
    try {
      const response = await client.post(`${apiRoot}/invoice/filter-by-all`, {
        pageSize,
        pageNumber,
        status,
        type,
        sequence,
        order,
        orderInvoice,
        defaultSequence,
        lookingFor,
        invoiceId
      });
      if (callback) callback(response.data);
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getInvoiceNotesPages = createAsyncThunk("invoice/list", async ({ pageNumber, pageSize }: Page) => {
  const response = await client.get(`${apiRoot}/invoice?PageNumber=${pageNumber}&PageSize=${pageSize}`);
  return response.data;
});

type TGetChequeBankDetails = {
  bankId: number;
  isActive: boolean;
};
export const getChequeBankDetails = createAsyncThunk(
  "invoice/getChequeBankDetails",
  async ({ bankId, isActive }: TGetChequeBankDetails) => {
    const response = await client.get(`${apiRoot}/Cheques/cheque-available`, {
      params: { bankId, isActive }
    });
    return response.data;
  }
);

export const invoiceGetPayByDate = createAsyncThunk(
  "invoiceOrders/getPayByDate",
  async ({ date, callback }: any & { callback?: (data: any) => void }) => {
    const formatDate = convertDateWithLeadingZero(date);
    const response = await client.get(`${apiRoot}/common/Get-Period`, {
      params: { date: formatDate }
    });
    if (callback) callback(response.data);
    return response.data;
  }
);

export const invocieActiveStatus = createAsyncThunk(
  "invoiceOrders/invocieActiveStatus",
  async ({ yearId, callback }: any & { callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/invoice/invoice-active-status`, {
      params: { yearId }
    });
    if (callback) callback(response.data);
    return response.data;
  }
);

export const cancelInvoiceOrder = createAsyncThunk(
  "invoiceOrders/cancel",
  /* eslint-disable camelcase */
  async ({
    invoice_id,
    inv_last_update,
    ord_last_update,
    reconcile_edit_invoice_id = 0,
    callback
  }: any & { callback?: (data: any) => void }) => {
    try {
      const res = await client.post(`${apiRoot}/invoice/invoice-cancel`, {
        invoice_id,
        inv_last_update,
        ord_last_update,
        reconcile_edit_invoice_id
      });
      if (callback) {
        callback(res.data);
      }
      return res.data;
    } catch (err: any) {
      if (err && err.response) {
        if (
          err?.response?.status === apiStatusCode.SQLEXCEPTION &&
          err?.response?.data &&
          err?.response?.data?.message
        ) {
          if (callback) {
            callback(err?.response?.data);
          }
        }
      }
      return err.response.data;
    }
  }
);

export const getInvoicesByTagFilters = createAsyncThunk(
  "invoiceOrders/listByTagFilters",
  async (params: { [key: string]: any }) => {
    const response = await client.post(`${apiRoot}/invoice/filter-by-tags`, { ...params });

    if (params.callback) {
      params.callback(response.data);
    }
    return response.data;
  }
);

type addInvoiceType = {
  data: { [key: string]: any };
} & Partial<{ callback: (id: string) => void }>;

const invoiceReqData = (data: any, thunkAPI: any) => {
  const {
    invoiceNoteLineItem: {
      invoiceNoteLineItem,
      invoiceLineItemVat,
      filteredInvoiceLineItem,
      filteredInvoiceLineItemVat,
      fitleredinvoiceLineItemPost
    },
    invoiceDetails: { allowDuplicate },
    invoiceNote: { deleteLine, lineParts }
  } = thunkAPI.getState() as RootState;
  const invDate = data?.inv_date ? convertDateWithLeadingZero(data?.inv_date) : null;
  const payByDate = data?.pay_by ? convertDateWithLeadingZero(data?.pay_by) : null;
  const currentInvoiceType = sessionStorage.getItem("invoiceType");
  const index = [
    INVOICE_STATUS.PAID,
    INVOICE_STATUS.RECONCILED,
    INVOICE_STATUS.CANCELLED,
    INVOICE_STATUS.ON_HOLD,
    INVOICE_STATUS.PASSED_FOR_PAYMENT,
    INVOICE_STATUS.FULLY_AUTHORISED
  ].indexOf(data?.status);

  // Send invoiceType index accordingly
  const invTypeIndex = currentInvoiceType === INVOICE_TYPE.NONORDERINV ? 1 : 0;
  switch (currentInvoiceType) {
    case INVOICE_TYPE.NONORDERINV:
    case INVOICE_TYPE.ORDERINV:
      return {
        invoiceType: invTypeIndex,
        header: {
          bank_id: data?.bank_id,
          client_id: data?.client_id,
          inv_date: invDate,
          inv_no: data?.invoice_id ? data?.inv_no : data?.disp_inv_no, // to handle duplicate invoice
          inv_no_suffix: data?.inv_no_suffix,
          long_inv_no: data?.invoice_id ? data?.long_disp_inv_no : data?.long_inv_no,
          long_inv_no_suffix: data?.long_inv_no_suffix,
          invoice_id: data?.invoice_id ? data?.invoice_id : null,
          invoice_type: "PI",
          matched_invoice_id: null,
          narrative: data?.narrative === "-" ? "" : data?.narrative,
          on_hold: data?.on_hold === "" ? "F" : data?.on_hold,
          order_id: data?.order_id === "" ? null : data?.order_id,
          pay_by: payByDate,
          period: data?.period,
          newinvoice: data?.invoice_id ? "F" : "T",
          change_from_order: "F",
          inv_last_update: data?.inv_last_update,
          sundry_invoice: "F",
          ord_last_update: data?.ord_last_update,
          inv_notes: data?.inv_notes === "-" ? "" : data?.inv_notes,
          disp_inv_no: data?.disp_inv_no
        },
        invoiceLine:
          index === -1
            ? filteredInvoiceLineItem?.map((o: any) => ({
                order_line_id: o?.order_line_id,
                discount: o.discount ?? 0.0,
                cost_id: o.cost_id,
                ledger_id: o.ledger_id,
                vat_id: o.vat_id,
                part_no: o.part_no,
                adding: o?.invoice_line_id ? "F" : "T",
                invoice_id: data?.invoice_id ? data?.invoice_id : null,
                line_cost: Number(o.line_cost) ?? 0.0,
                line_type: o?.line_type,
                narrative: o?.narrative ?? "",
                qty_inv: o?.qty_inv ?? 0,
                order_line_qty_inv: o?.order_line_qty_inv ?? 0,
                invoice_line_id: o?.invoice_line_id ? o?.invoice_line_id : null,
                services: o.services === "T" ? "T" : "F",
                reconcile_edit_invoice_id: 0,
                inv_last_update: data?.inv_last_update,
                ord_last_update: data?.ord_last_update,
                inv_item_desc: o?.at_calc_item_des ?? "",
                inv_Line_Ref: null,
                leddef_id: o.leddef_id,
                fund_id: o.fund_id,
                cost_code: o.cost_code,
                ledger_code: o.ledger_code,
                fund_code: o.fund_code,
                cost_des: o.cost_des,
                ledger_des: o.ledger_des,
                fund_des: o.fund_des,
                inv_line_number: o?.inv_line_number ?? 1
              }))
            : null,
        vatLine:
          index === -1
            ? filteredInvoiceLineItemVat?.map((v: any) => ({
                invoice_id: data?.invoice_id ? data?.invoice_id : null,
                invoice_line_id: v?.invoice_line_id ? v?.invoice_line_id : null,
                ledger_id: v.ledger_id,
                line_cost: v.line_cost,
                last_update: data?.inv_last_update
              }))
            : null,
        deleteLine: Array.isArray(deleteLine) && deleteLine.length > 0 ? deleteLine : null,
        transaction_type: data?.invoice_id ? "B" : "A",
        reconcile_edit_invoice_id: 0,
        allowduplicate: allowDuplicate,
        sundrySupplier: null,
        parts: Array.isArray(lineParts) && lineParts.length > 0 ? lineParts : null
      };
    case INVOICE_TYPE.CREDITNOTEINV:
      return {
        invoiceType: 2,
        header: {
          bank_id: data?.bank_id,
          client_id: data?.client_id,
          inv_date: invDate,
          inv_no: data?.invoice_id ? data?.inv_no : data?.disp_inv_no, // to handle duplicate invoice
          inv_no_suffix: data?.inv_no_suffix,
          long_inv_no: data?.invoice_id ? data?.long_disp_inv_no : data?.long_inv_no,
          long_inv_no_suffix: data?.long_inv_no_suffix,
          invoice_id: data?.invoice_id ? data?.invoice_id : null,
          invoice_type: "PC",
          matched_invoice_id: data.matched_inv_no ? data.matched_inv_id : null,
          matched_inv_no: data.matched_inv_no,
          narrative: data?.narrative === "-" ? "" : data?.narrative,
          on_hold: data?.on_hold,
          order_id: null,
          pay_by: payByDate,
          period: data?.period,
          newinvoice: data?.invoice_id ? "F" : "T",
          change_from_order: "F",
          inv_last_update: data?.invoice_id ? data.inv_last_update : null,
          sundry_invoice: "F",
          ord_last_update: null,
          inv_notes: data?.inv_notes === "-" ? "" : data?.inv_notes,
          disp_inv_no: data?.disp_inv_no
        },
        invoiceLine:
          index === -1
            ? filteredInvoiceLineItem?.map((o: any) => ({
                order_line_id: null,
                discount: o.discount,
                cost_id: o.cost_id,
                ledger_id: o.ledger_id,
                vat_id: o.vat_id,
                part_no: null,
                adding: o.invoice_line_id ? "F" : "T",
                invoice_id: data?.invoice_id ? data.invoice_id : null,
                line_cost: o.line_cost,
                line_type: "E",
                narrative: o?.narrative ?? "",
                qty_inv: 0,
                order_line_qty_inv: null,
                invoice_line_id: o?.invoice_line_id ? o?.invoice_line_id : null,
                services: o.services === "T" ? "T" : "F",
                reconcile_edit_invoice_id: 0,
                inv_last_update: data?.invoice_id ? data?.inv_last_update : null,
                ord_last_update: "",
                inv_item_desc: "",
                inv_Line_Ref: null,
                leddef_id: o.ledger_id,
                fund_id: o.fund_id,
                cost_code: o.cost_code,
                ledger_code: o.ledger_code,
                fund_code: o.fund_code,
                cost_des: o.cost_des,
                ledger_des: o.ledger_des,
                fund_des: o.fund_des,
                inv_line_number: o?.inv_line_number ?? 1
              }))
            : null,
        vatLine:
          index === -1
            ? filteredInvoiceLineItemVat?.map((v: any) => ({
                invoice_id: data?.invoice_id ? data?.invoice_id : null,
                invoice_line_id: v?.invoice_line_id ? v?.invoice_line_id : null,
                ledger_id: v.ledger_id,
                line_cost: v.line_cost,
                last_update: data?.invoice_id ? data?.inv_last_update : null
              }))
            : null,
        deleteLine: Array.isArray(deleteLine) && deleteLine.length > 0 ? deleteLine : null,
        transaction_type: data?.invoice_id ? "B" : "A",
        reconcile_edit_invoice_id: 0,
        allowduplicate: allowDuplicate,
        sundrySupplier: null,
        parts: Array.isArray(lineParts) && lineParts.length > 0 ? lineParts : null
      };
    default:
      return null;
  }
};

export const addInvoice = createAsyncThunk(
  "invoices/addnon-order",
  async ({ data, callback }: addInvoiceType, thunkAPI) => {
    const body = invoiceReqData(data, thunkAPI);
    const response = await client.post(`${apiRoot}/invoice/invoice-save`, body);

    if (response.data && callback) {
      callback(response.data as string);
    }
    return response.data;
  }
);

export const invoiceGetDebitCard = createAsyncThunk("invoiceOrders/getDebitCard", async (bankId: any) => {
  const response = await client.get(`${apiRoot}/invoice/invoice-get-debitcards?bankId=${bankId}`);
  return response.data;
});

export const invoiceFinancialYear = createAsyncThunk(
  "invoiceOrders/getFinancialYear",
  async ({ callback }: { callback?: (data: { [key: string]: any }) => void }) => {
    const response = await client.get(`${apiRoot}/common/financial-year?yearId=${getCurrentFinancialYear()}`);

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const invoiceDocument = createAsyncThunk("invoiceOrders/getDocument", async (invoiceId: any) => {
  const response = await client.get(`${apiRoot}/document/invoice-document?invoiceId=${invoiceId}`);
  return response.data;
});

export const supportingDocumentCount = createAsyncThunk(
  "invoiceOrders/supportingDocumentCount",
  async (invoiceID: any) => {
    const response = await client.get(`${apiRoot}/invoice/invoice-image-doc-count?invoiceId=${invoiceID}`);
    return response.data;
  }
);

export const getInputStreamFile = createAsyncThunk("invoiceOrders/getInputStreamFile", async () => {
  const response = await client.get(`${apiRoot}/invoice/invoice-File-Stream`);
  return response.data;
});

export const authorisedStatus = createAsyncThunk(
  "invoiceOrders/authorise",
  async ({
    amount,
    bank_id,
    inv_last_update,
    invoice_id,
    ord_last_update,
    source,
    callback // remove the type annotation
  }: any) => {
    const res = await client.post(`${apiRoot}/invoice/invoice-authorise`, [
      {
        invoice_id,
        amount,
        bank_id,
        inv_last_update,
        ord_last_update: ord_last_update ?? null,
        reconcile_edit_invoice_id: invoice_id,
        transaction_type: "",
        source,
        supplier_DUNs: "",
        establishment_DUNs: "",
        document_id: 0
      }
    ]);

    if (callback) {
      callback(res.data); // Invoke the callback with the response data
    }

    return res.data;
  }
);

export const authorizedTagged = createAsyncThunk(
  "invoiceOrders/authorise-tagged",
  async ({ invoice_id, callback, invoiceType, continueInvDiff, continuePPThreshold }: any) => {
    const res = await client.post(`${apiRoot}/invoice/invoice-authorise-tagged`, {
      invoice_id,
      invoiceType,
      continueInvDiff,
      continuePPThreshold
    });

    if (callback) {
      callback(res.data); // Invoke the callback with the response data
    }

    return res.data;
  }
);
export const getFilteredInvoice = createAsyncThunk(
  "invoiceOrders/listAll",
  async ({
    pageSize,
    pageNumber,
    status,
    type,
    sequence,
    order,
    defaultSequence,
    lookingFor,
    callback
  }: TgetInvoiceNoteOrder & { callback?: (data: any) => void }) => {
    switch (type) {
      case "All":
        type = "";
        orderInvoice = "";
        break;
      case "All Invoices":
        type = "PI";
        orderInvoice = "";
        break;
      case "All Order Invoices":
        type = "PI";
        orderInvoice = "T";
        break;
      case "All Credit Notes":
        type = "PC";
        orderInvoice = "";
        break;
      case "All Non-Order Invoices":
        type = "PI";
        orderInvoice = "F";
        break;
      case "All Sundry Invoices":
        type = "PS";
        orderInvoice = "F";
        break;
      default:
        type = "";
        orderInvoice = "";
        break;
    }

    const response = await client.post(`${apiRoot}/invoice/filter-by-all`, {
      pageSize,
      pageNumber,
      status,
      type,
      sequence,
      order,
      orderInvoice,
      defaultSequence,
      lookingFor
    });
    if (callback) callback(response.data);
    return response.data;
  }
);

export const preAuthorisedStatus = createAsyncThunk(
  "invoiceOrders/pre-authorise",
  /* eslint-disable camelcase */
  async ({ invoiceID, callback }: { invoiceID: string; callback?: (data: { [key: string]: any }) => void }) => {
    const res = await client.get(`${apiRoot}/invoice/invoice-pre-authorise?invoiceId=${invoiceID}`);
    if (res.data && callback) {
      callback(res.data);
    }
    return res.data;
  }
);

export const invoiceThresholdCheck = createAsyncThunk(
  "invoiceOrders/invoice-threshold-check",
  /* eslint-disable camelcase */
  async ({ invoiceID, callback }: any & { callback?: (data: any) => void }) => {
    const res = await client.get(`${apiRoot}/invoice/invoice-threshold-check?invoiceId=${invoiceID}`);
    if (res.data && callback) {
      callback(res.data);
    }
    return res.data;
  }
);

/**
 * # Invoice Orders Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  initialState,
  name: "invoiceNote",
  extraReducers: (builder) => {
    /** Invoice Orders List */
    builder
      .addCase(getInvoiceOrdersFilter.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getInvoiceOrdersFilter.fulfilled, (state, action: PayloadAction<any>) => {
        state.invoiceNoteList = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoiceOrdersFilter.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getInvoiceNotes.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getInvoiceNotes.fulfilled, (state, action: PayloadAction<any>) => {
        state.allInvoice = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoiceNotes.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(cancelInvoiceOrder.pending, (state) => {
        state.cancelStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(cancelInvoiceOrder.fulfilled, (state, action: PayloadAction<any>) => {
        state.cancelStatus = STATUS.SUCCESS;
      })
      .addCase(cancelInvoiceOrder.rejected, (state, action: PayloadAction<any>) => {
        state.cancelStatus = STATUS.FAILED;
      });
    builder
      .addCase(addInvoice.pending, (state) => {
        state.addInvoiceOrderStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(addInvoice.fulfilled, (state, action: PayloadAction<any>) => {
        state.addInvoiceOrderStatus = STATUS.SUCCESS;
        // state.addPurchaseOrderStatus = undefined;
      })
      .addCase(addInvoice.rejected, (state) => {
        state.addInvoiceOrderStatus = STATUS.FAILED;
      });
  },
  reducers: {
    sortOrderNumber: (state, action: PayloadAction<{ type: string }>) => {
      state.invoiceNoteList.invoices = state.invoiceNoteList.invoices.sort((a, b) =>
        action.payload.type === "ASC" && a.order_no < b.order_no ? 1 : -1
      );
    },
    sortOrderDate: (state, action: PayloadAction<{ type: string }>) => {
      state.invoiceNoteList.invoices = state.invoiceNoteList.invoices.sort((a, b) =>
        action.payload.type === "ASC" && a.inv_date < b.inv_date ? 1 : -1
      );
    },
    sortSource: (state, action: PayloadAction<{ type: string }>) => {
      state.invoiceNoteList.invoices = state.invoiceNoteList.invoices.sort((a, b) =>
        action.payload.type === "ASC" && a.source < b.source ? 1 : -1
      );
    },
    handleCheckbox: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const checkedRowIds = action.payload.row.map((invoice: any) => invoice.invoice_id);

      const mergedCheckedInvoices = current(state.checkedInvoices)?.concat(checkedRowIds);
      const uniqueCheckedInvoices = Array.from(new Set(mergedCheckedInvoices));
      const unCheckedRows = findDifferencesByProperty(
        current(state.checkedRows),
        [...action.payload.row],
        "invoice_id"
      );
      const unCheckedRowIds = unCheckedRows.map((invoice: any) => invoice.invoice_id);

      const finalCheckedInvoices = uniqueCheckedInvoices?.filter((invoice) => !unCheckedRowIds.includes(invoice));
      state.checkedInvoices = finalCheckedInvoices;
      state.checkedRows = [...action.payload.row];
    },
    handleUncheckedRow: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const diff = findDifferencesByProperty(current(state.checkedRows), [...action.payload.row], "invoice_id");
      state.unCheckedRows = [...current(state.unCheckedRows), ...diff];
    },
    unCheckedAll: (state) => {
      state.checkedRows = [];
    },
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    },
    resetSelectedRow: (state) => {
      state.selectedRow = undefined;
    },
    setFocus: (state) => {
      state.isFocus = true;
    },
    resetFocus: (state) => {
      state.isFocus = false;
    },
    setInvoiceTypeModal: (state, action: PayloadAction<boolean>) => {
      state.isInvoiceTypeModalOpen = action.payload;
    },
    setDeleteLine: (state, action: PayloadAction<any>) => {
      state.deleteLine = [...action.payload];
    },
    setLineParts: (state, action: PayloadAction<any>) => {
      state.lineParts = [...action.payload];
    },
    resetLineParts: (state) => {
      state.lineParts = [];
    },
    checkFiltered: (state) => {
      if (state?.invoiceNoteList) {
        const { invoices } = state.invoiceNoteList;
        if (invoices) {
          const checkedRows = invoices.filter((row) => current(state.checkedInvoices)?.includes(row.invoice_id));
          state.checkedRows = checkedRows;
        }
      }
    },
    unCheckAll: (state) => {
      state.checkedRows = [];
    },
    clearUncheckedRows: (state) => {
      state.unCheckedRows = [];
    },
    checkAll: (state) => {
      const invoiceList = current(state.invoiceNoteList?.invoices).filter(
        (invoice) => invoice.status === INVOICE_STATUS.UNAUTHORISED
      );
      state.checkedRows = [...invoiceList];
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TgetInvoiceNoteOrder>) => {
      state.filterState = {
        ...state.filterState,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filterState = {
        ...initialState.filterState,
        sequenceValue: columnDef.filter((col) => !!col.sequence)[0].field
      };
      state.columnDef = [...columnDef];
    },
    setCheckedInvoices: (state, action: PayloadAction<any>) => {
      state.checkedInvoices = [...action.payload];
      const checkedRows = current(state.invoiceNoteList?.invoices).filter((row) =>
        state.checkedInvoices?.includes(row.invoice_id)
      );
      state.checkedRows = checkedRows;
    },
    clearCheckedInvoices: (state) => {
      state.checkedInvoices = [];
    },
    clearInvoices: (state) => {
      state.invoiceNoteList.invoices = [];
    },
    setIsPrintLoading: (state, action) => {
      state.isPrintLoading = action.payload;
    },
    setIsHotKey: (state, action) => {
      state.isHotKey = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
