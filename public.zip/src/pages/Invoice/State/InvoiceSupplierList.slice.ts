import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";

type InvoiceDetailsType = {
  supplier?: { [key: string]: any };
  supplierListBrowse?: { [key: string]: any }[];
  selectedSupplier?: { [key: string]: any };
  error: string | undefined;
  status?: STATUS;
  getSupplyAllStatus?: STATUS;
  showDetail?: boolean;
};

type TgetAllSundrySupplier = {
  clientId?: string;
};

type TgetSupplierBrowse = {
  clientId?: string;
  credType?: string;
};

const initialState: InvoiceDetailsType = {
  error: ""
};

/** Thunks */
export const getInvoiceSupplierAll = createAsyncThunk(
  "supplierAll/listAll",
  async ({ clientId }: TgetAllSundrySupplier) => {
    const response = await client.get(`${apiRoot}/invoice/invoice-supplier-details`, {
      params: { clientId }
    });
    return response.data;
  }
);

export const getSundrySuppliersAll = createAsyncThunk(
  "suppliersSundry/lsitAll",
  async ({ clientId }: TgetAllSundrySupplier) => {
    const response = await client.get(`${apiRoot}/invoice/invoice-sundry-suppliers`, {
      params: { clientId }
    });
    return response.data;
  }
);

export const getSupplierBrowse = createAsyncThunk(
  "invoice/supplierBrowse",
  async ({ clientId, credType }: TgetSupplierBrowse) => {
    const response = await client.get(`${apiRoot}/invoice/invoice-sundry-suppliers-browse`, {
      params: { clientId, credType }
    });
    return response.data;
  }
);

export const getBankBySupplierId = createAsyncThunk("invoice/getBankByInvoice", async ({ invoiceId }: any) => {
  const response = await client.get(`${apiRoot}/invoice/get-bank`, {
    params: { invoiceId }
  });
  return response.data;
});
/**
 * # Invoice Orders Details Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  initialState,
  name: "invoiceNoteDetails",
  extraReducers: (builder) => {
    builder
      .addCase(getInvoiceSupplierAll.pending, (state) => {
        state.getSupplyAllStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getInvoiceSupplierAll.fulfilled, (state, action: PayloadAction<any>) => {
        state.supplier = action.payload;
        state.getSupplyAllStatus = STATUS.SUCCESS;
      })
      .addCase(getInvoiceSupplierAll.rejected, (state) => {
        state.getSupplyAllStatus = STATUS.FAILED;
      });
    builder
      .addCase(getSundrySuppliersAll.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getSundrySuppliersAll.fulfilled, (state, action: PayloadAction<any>) => {
        state.supplier = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getSundrySuppliersAll.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
    builder
      .addCase(getSupplierBrowse.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getSupplierBrowse.fulfilled, (state, action: PayloadAction<any>) => {
        state.supplierListBrowse = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getSupplierBrowse.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  reducers: {
    resetSelectedSupplier: (state) => {
      state.supplierListBrowse = [];
    },
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      if (action.payload !== undefined) {
        state.selectedSupplier = action.payload;
      }
    },
    setSelectedRowUndefined: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedSupplier = undefined;
    },
    setShowButton: (state, action: PayloadAction<any>) => {
      state.showDetail = action.payload;
    },
    resetSelectedRow: (state) => {
      state.selectedSupplier = undefined;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
