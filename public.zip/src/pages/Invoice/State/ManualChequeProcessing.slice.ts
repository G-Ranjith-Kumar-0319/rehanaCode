import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";

type ChequesAvailableType = {
  chequeDetails?: { [key: string]: any }[];
  error: string | undefined;
  status?: STATUS;
  chequePeriods?: { [key: string]: any }[];
  defaultPeriod?: number;
  manualChequeLoading: boolean;
  chequeSelectedRow?: { [key: string]: any };
  chequeRightSelectedRow?: { [key: string]: any };
  isChequePaymentLoading?: boolean;
};

const initialState: ChequesAvailableType = {
  error: "",
  manualChequeLoading: false
};

/** Thunks */
type TPostChequeNumberValidate = {
  bankId: number;
  chequeNumber: number;
};
export const postChequeNumberValidate = createAsyncThunk(
  "invoice/getChequeNoValidate",
  async ({ bankId, chequeNumber }: TPostChequeNumberValidate) => {
    const response = await client.get(`${apiRoot}/Cheques/cheque-no-validate`, {
      params: { bankId, chequeNumber }
    });
    return response.data;
  }
);

export const postChequePaymentProccesing = createAsyncThunk(
  "invoice/postChequePayment",
  async ({ bankId, bookId, invoiceId, period, chequeNumber, narrative }: any) => {
    const response = await client.post(`${apiRoot}/Cheques/cheque-manual-run`, {
      bank_id: bankId,
      book_id: bookId,
      invoice_id: invoiceId,
      period,
      cheque_number: chequeNumber,
      narrative
    });
    return response?.data;
  }
);

type TgetChequeBankDetails = {
  bankId: number;
  isActive: boolean;
};
export const getChequeBankDetails = createAsyncThunk(
  "invoice/getChequeBankDetails",
  async ({ bankId, isActive }: TgetChequeBankDetails) => {
    const response = await client.get(`${apiRoot}/Cheques/cheque-available`, {
      params: { bankId, isActive }
    });
    return response.data;
  }
);

type TgetDefaultPeriod = {
  date: string;
};
export const getDefaultPeriod = createAsyncThunk("invoice/getDefaultPeriod", async ({ date }: TgetDefaultPeriod) => {
  const response = await client.get(`${apiRoot}/Cheques/get-default-period`, {
    params: { date }
  });
  return response.data;
});

/**
 * # Invoice Orders Details Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  initialState,
  name: "chequeAvailable",
  extraReducers: (builder) => {
    builder
      .addCase(getChequeBankDetails.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeBankDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequeDetails = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getChequeBankDetails.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getDefaultPeriod.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getDefaultPeriod.fulfilled, (state, action: PayloadAction<any>) => {
        state.defaultPeriod = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getDefaultPeriod.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {
    setChequeSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.chequeSelectedRow = action.payload;
    },
    setChequeRightSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.chequeRightSelectedRow = action.payload;
    },
    setChequePaymentLoading: (state, action) => {
      state.isChequePaymentLoading = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
