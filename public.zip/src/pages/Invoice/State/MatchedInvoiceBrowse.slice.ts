import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import matchedInvoiceColumnDef from "@/shared/components/MatchedInvoiceBrowseModal/Grid/columnDef";
import { apiRoot, client } from "../../../config";
import { STATUS } from "../../../types/UseStateType";

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type matchedInvoiceState = {
  matchedInvoiceDetails: { [key: string]: any }[];
  selectedValue?: { [key: string]: any };
  columnDef: TColumnDef;
  error?: string;
  status?: STATUS;
  filters?: TFilters;
};

const initialState: matchedInvoiceState = {
  columnDef: matchedInvoiceColumnDef,
  matchedInvoiceDetails: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined
  }
};

/** Thunks */
export const getInvoiceNumberDetails = createAsyncThunk(
  "invoice/invoiceNumberDetails",
  async ({
    clientId,
    sequence,
    callback
  }: {
    clientId: string;
    sequence: any;
    callback?: (data: { [key: string]: any }) => void;
  }) => {
    const response = await client.get(`${apiRoot}/invoice/invoice-matched?sequence=${sequence}&clientid=${clientId}`);

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

const slice = createSlice({
  extraReducers: (builder) => {
    /** Matched Invoice Browse Slice */
    builder
      .addCase(getInvoiceNumberDetails.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getInvoiceNumberDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.matchedInvoiceDetails = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoiceNumberDetails.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = STATUS.FAILED;
      });
  },
  initialState,
  name: "matchedInvoice",
  reducers: {
    selectMatchedInvoice: (state, action: PayloadAction<any>) => {
      state.selectedValue = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (matchedInvoiceColumnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    },
    resetSelectedRow: (state) => {
      state.selectedValue = undefined;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
