import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";

type InvoiceDetailsType = {
  allPeriods?: { [key: string]: any };
  error: string | undefined;
  status?: STATUS;
};

const initialState: InvoiceDetailsType = {
  error: ""
};

/** Thunks */
export const getPeriods = createAsyncThunk("invoice/periods", async () => {
  const response = await client.get(`${apiRoot}/common/all-periods`);
  return response.data;
});

/**
 * # Invoice Periods Details Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  initialState,
  name: "periods",
  extraReducers: (builder) => {
    builder
      .addCase(getPeriods.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getPeriods.fulfilled, (state, action: PayloadAction<any>) => {
        state.allPeriods = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getPeriods.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {}
});

export const { actions: PeriodsActions, reducer } = slice;
export default reducer;
