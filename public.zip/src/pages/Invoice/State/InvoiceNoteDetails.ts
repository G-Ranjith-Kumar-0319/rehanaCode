import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";

type InvoiceDetailsType = {
  invoiceDetails?: { [key: string]: any };
  error: string | undefined;
  status?: STATUS;
  getInoiveNumStatus?: STATUS;
  getOrderPrefixSttaus?: STATUS;
  orderPrefixDetail?: { [key: string]: any };
  invoiceAllOrder?: { [key: string]: any }[];
  invoiceAllNumbers?: { [key: string]: any }[];
  allowDuplicate?: number;
  totalLineItemVal?: any;
  invoiceNotes?: string;
  redirectAlertModal?: boolean;
};

const initialState: InvoiceDetailsType = {
  error: "",
  allowDuplicate: 0,
  redirectAlertModal: false
};

/** Thunks */
export const getInvoiceDetails = createAsyncThunk(
  "invoice/details",
  async ({ invoiceId, callback }: { invoiceId: string; callback?: (data: { [key: string]: any }) => void }) => {
    const response = await client.get(`${apiRoot}/invoice/invoice-header?invoiceID=${invoiceId}`);

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const getInvoiceNumberDetails = createAsyncThunk(
  "invoice/invoiceNumberDetails",
  async ({ clientId, callback }: { clientId: string; callback?: (data: { [key: string]: any }) => void }) => {
    const response = await client.get(`${apiRoot}/invoice/invoice-matched?clientid=${clientId}`);

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getInvoiceOrderPrefix = createAsyncThunk(
  "invoice/getInoiceOrderPrefix",
  async ({ orderId, callback }: { orderId: string; callback?: (data: { [key: string]: any }) => void }) => {
    const response = await client.get(`${apiRoot}/invoice/order-prefix?orderId=${orderId}`);

    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getInvoiceAllOrder = createAsyncThunk("invoice/allOrder", async () => {
  const response = await client.get(`${apiRoot}/invoice/all-orders`);
  return response.data;
});

/**
 * # Invoice Orders Details Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  initialState,
  name: "invoiceNoteDetails",
  extraReducers: (builder) => {
    builder
      .addCase(getInvoiceDetails.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getInvoiceDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.invoiceDetails = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoiceDetails.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getInvoiceAllOrder.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getInvoiceAllOrder.fulfilled, (state, action: PayloadAction<any>) => {
        state.invoiceAllOrder = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoiceAllOrder.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getInvoiceNumberDetails.pending, (state) => {
        state.getInoiveNumStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getInvoiceNumberDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.invoiceAllNumbers = action.payload;
        state.getInoiveNumStatus = STATUS.SUCCESS;
      })
      .addCase(getInvoiceNumberDetails.rejected, (state) => {
        state.getInoiveNumStatus = STATUS.FAILED;
      });
    builder
      .addCase(getInvoiceOrderPrefix.pending, (state) => {
        state.getOrderPrefixSttaus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getInvoiceOrderPrefix.fulfilled, (state, action: PayloadAction<any>) => {
        state.orderPrefixDetail = action.payload;
        state.getOrderPrefixSttaus = STATUS.SUCCESS;
      })
      .addCase(getInvoiceOrderPrefix.rejected, (state) => {
        state.getOrderPrefixSttaus = STATUS.FAILED;
      });
  },
  reducers: {
    resetInvoiceDetails: (state) => {
      state.invoiceDetails = [];
    },
    setAllowDuplicateVal: (state, action: PayloadAction<any>) => {
      state.allowDuplicate = action.payload;
    },
    addLineItemTotal: (state, action: any) => {
      state.totalLineItemVal = action.payload;
    },
    setRedirectAlertModal: (state, action) => {
      state.redirectAlertModal = action.payload;
    },
    setInvoiceNotes: (state, action) => {
      state.invoiceNotes = action.payload;
    },
    resetOrderPrefixDetail: (state) => {
      state.orderPrefixDetail = [];
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
