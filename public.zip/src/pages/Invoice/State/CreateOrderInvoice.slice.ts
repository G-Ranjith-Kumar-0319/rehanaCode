import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { type } from "@testing-library/user-event/dist/type";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "../../../config";

type CreateOrderInvoiceStateType = {
  isOrderModal: boolean;
  orderSelectedRow: any;
};

const initialState: CreateOrderInvoiceStateType = {
  isOrderModal: false,
  orderSelectedRow: null
};

/** Thunks */
export const getInvoicePrintAndBank = createAsyncThunk("createOrderInvoice/invoice-prints", async (orderId?: any) => {
  const response = await client.get(`${apiRoot}/invoice/invoice-prints?orderId=${orderId}`);
  return response.data;
});

export const orderlastUpdateVal = createAsyncThunk("createOrderInvoice/order-lastupdate", async (orderId?: any) => {
  const response = await client.get(`${apiRoot}/invoice/order-lastupdate?orderId=${orderId}`);
  return response.data;
});
/**
 * # Invoice Direct Payment processing Slice
 * This slice of state is responsible for managing direct payment processing state
 */
const slice = createSlice({
  initialState,
  name: "creatOrderInvoice",
  extraReducers: (builder) => {},
  reducers: {
    setOrderModal: (state, action) => {
      state.isOrderModal = action.payload;
    },
    setOrderSelectedRow: (state, action) => {
      state.orderSelectedRow = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
