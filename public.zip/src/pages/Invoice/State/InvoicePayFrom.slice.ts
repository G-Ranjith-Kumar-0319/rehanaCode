import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import payFromInvoiceColumnDef from "@/shared/components/InvoicePayFromModal/Grid/columnDef";
import { apiRoot, client } from "../../../config";
import { STATUS } from "../../../types/UseStateType";

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type purchaseOrderState = {
  paymentDetails: { [key: string]: any }[];
  selectedValue?: { [key: string]: any };
  columnDef: TColumnDef;
  error?: string;
  status?: STATUS;
  filters?: TFilters;
};

const initialState: purchaseOrderState = {
  columnDef: payFromInvoiceColumnDef,
  paymentDetails: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: payFromInvoiceColumnDef.filter((col) => col.sequence === true)[0].field
  }
};

/** Thunks */

export const getInvoiceOrderPaymentFrom = createAsyncThunk("invoice/bank-lookup", async (sequence?: any) => {
  const response = await client.get(`${apiRoot}/invoice/bank-lookup?sequence=${sequence || 0}`);
  return response.data;
});

/**
 * # Purchase Order Details Slice
 * This slice of state is responsible for storing purchase order details state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** Purchase Orders Details */
    builder
      .addCase(getInvoiceOrderPaymentFrom.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getInvoiceOrderPaymentFrom.fulfilled, (state, action: PayloadAction<any>) => {
        state.paymentDetails = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoiceOrderPaymentFrom.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  initialState,
  name: "invoicePaymentFrom",
  reducers: {
    selectPaymentMethod: (state, action: PayloadAction<any>) => {
      state.selectedValue = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (payFromInvoiceColumnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    },
    resetSelectedRow: (state) => {
      state.selectedValue = undefined;
    },
    resetPaymentDetails: (state) => {
      state.paymentDetails = [];
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
