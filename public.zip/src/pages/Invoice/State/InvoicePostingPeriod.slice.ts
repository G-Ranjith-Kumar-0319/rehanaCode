import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import postingPeriodColumnDef from "@/shared/components/PostingPeriod/Grid/columnDef";
import { apiRoot, client } from "../../../config";
import { STATUS } from "../../../types/UseStateType";

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type postingPeriodState = {
  postingPeriodDetails: { [key: string]: any }[];
  selectedValuePostingPeriod?: { [key: string]: any };
  columnDef: TColumnDef;
  error?: string;
  status?: STATUS;
  filters?: TFilters;
};

const initialState: postingPeriodState = {
  columnDef: postingPeriodColumnDef,
  postingPeriodDetails: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined
  }
};

/** Thunks */
export const getInvoicePostingPeriod = createAsyncThunk("invoiceNote/paymentFromDetails", async (sequence?: any) => {
  const response = await client.get(`${apiRoot}/common/open-period?sequence=${sequence || 0}`);
  return response.data;
});

const slice = createSlice({
  extraReducers: (builder) => {
    /** Invoice Posting period Slice */
    builder
      .addCase(getInvoicePostingPeriod.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getInvoicePostingPeriod.fulfilled, (state, action: PayloadAction<any>) => {
        const filtetedPositingPeriod = [...action.payload].map((period) => {
          const newPeriod = { ...period };
          newPeriod.code = newPeriod.code.toString();
          return newPeriod;
        });
        state.postingPeriodDetails = filtetedPositingPeriod;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoicePostingPeriod.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload?.error.message;
      });
  },
  initialState,
  name: "invoicePostingPeriod",
  reducers: {
    selectPostingPeriod: (state, action: PayloadAction<any>) => {
      state.selectedValuePostingPeriod = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (postingPeriodColumnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    },
    resetSelectedRow: (state) => {
      state.selectedValuePostingPeriod = undefined;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
