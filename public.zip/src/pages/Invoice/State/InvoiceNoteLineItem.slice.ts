import { ISelectedItem } from "@essnextgen/ui-kit";
import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { STATUS, invoiceLineTypes } from "@/types/UseStateType";
import { apiRoot, client } from "../../../config";

type invoiceNoteState = {
  invoiceNoteLineItem: { [key: string]: any }[];
  invoiceLineItemVat: { [key: string]: any }[];
  filteredInvoiceLineItemVat: { [key: string]: any }[];
  arrangedInvoiceLineItem: { [key: string]: any }[];
  filteredInvoiceLineItem: { [key: string]: any }[];
  fitleredinvoiceLineItemPost: { [key: string]: any }[];
  selectedRow?: { [key: string]: any };
  invoiceLedgerType?: { [key: string]: any };
  selectedRowCustomCell?: { [key: string]: any };
  selectedRowCustomCellRow?: { [key: string]: any };
  error: string | undefined;
  status: string;
  selectedStatus: ISelectedItem;
  selectedRowIndex: number;
  vatRate: number;
  updatedRow: { [key: string]: any } | null;
  vatDeletedList: any[];
  addInvoiceType: any;
  isInvSaveSuccess: boolean;
  isInvCancelInitiated: boolean;
  isInvAuthorizeInitialed: boolean;
  isFreeText: number;
};

const initialState: invoiceNoteState = {
  invoiceNoteLineItem: [],
  invoiceLineItemVat: [],
  filteredInvoiceLineItemVat: [],
  filteredInvoiceLineItem: [],
  fitleredinvoiceLineItemPost: [],
  arrangedInvoiceLineItem: [],
  selectedStatus: {
    text: "",
    value: ""
  },
  error: "",
  status: "",
  selectedRowIndex: -1,
  vatRate: 0,
  updatedRow: null,
  vatDeletedList: [],
  addInvoiceType: "",
  isInvSaveSuccess: false,
  isInvCancelInitiated: false,
  isInvAuthorizeInitialed: false,
  isFreeText: 0
};

export const getInvoiceNoteLineItem = createAsyncThunk(
  "invoiceNote/lineItem",
  async (
    { invoiceID, OrderId, callback }: { invoiceID: string | null; OrderId: string; callback?: (data: any) => void },
    thunkAPI
  ) => {
    try {
      const response = await client.get(`${apiRoot}/invoice/invoice-lines`, {
        params: {
          invoiceID,
          OrderId
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getInvoiceLedgerType = createAsyncThunk(
  "invoiceNote/lineItemInvoice",
  async ({ leddefId, callback }: { leddefId: string | null; callback?: (data: any) => void }, thunkAPI) => {
    try {
      const response = await client.get(`${apiRoot}/invoice/invoice-ledger-Type`, {
        params: {
          leddefId
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);
//
export const getVatLedger = createAsyncThunk(
  "invoiceNote/invoice-vat-ledger",
  async ({ vatId, callback }: { vatId: number | null; callback?: (data: any) => void }, thunkAPI) => {
    try {
      const response = await client.get(`${apiRoot}/invoice/invoice-vat-ledger`, {
        params: {
          vatId
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const invoicePartsCheck = createAsyncThunk(
  "invoiceNote/invoice-parts-check",
  async (
    {
      clientId,
      partNo,
      cost,
      callback
    }: {
      clientId: number;
      partNo: string;
      cost: number;
      callback?: (data: any) => void;
    },
    thunkAPI
  ) => {
    try {
      const response = await client.get(`${apiRoot}/invoice/invoice-parts-check`, {
        params: { clientId, partNo, cost }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getVatRate = createAsyncThunk(
  "invoiceNote/get-vat",
  async ({ vatId, callback }: { vatId: string | null; callback?: (data: any) => void }, thunkAPI) => {
    try {
      const response = await client.get(`${apiRoot}/common/Get-Vat`, {
        params: {
          vatId
        }
      });

      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

/**
 * # Invoice Note Status Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** Purchase Orders List */
    builder
      .addCase(getInvoiceNoteLineItem.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getInvoiceNoteLineItem.fulfilled, (state, action: PayloadAction<any>) => {
        function arrangeTableList() {
          if (Array.isArray(action.payload) && action.payload.length > 0) {
            const e = action.payload?.filter(
              (t: any) => t?.line_type !== invoiceLineTypes?.LINETYPEP && t?.line_type !== invoiceLineTypes?.LINETYPEV
            );
            const p = action.payload?.filter((t: any) => t?.line_type === invoiceLineTypes?.LINETYPEP);
            const v = action.payload?.filter((t: any) => t?.line_type === invoiceLineTypes?.LINETYPEV);
            return [...e, ...p, ...v];
          }
          return [];
        }
        state.invoiceNoteLineItem = arrangeTableList();
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoiceNoteLineItem.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action?.payload?.error?.message;
      });
    builder
      .addCase(getInvoiceLedgerType.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getInvoiceLedgerType.fulfilled, (state, action: PayloadAction<any>) => {
        state.invoiceLedgerType = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoiceLedgerType.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  initialState,
  name: "invoiceNoteLineItem",
  reducers: {
    setSelectedRow: (state, action: PayloadAction<any>) => {
      state.selectedRow = action.payload;
    },
    resetInvoiceLineItem: (state) => {
      state.invoiceNoteLineItem = [];
    },
    resetInvoiceVatLineItem: (state) => {
      state.invoiceLineItemVat = [];
    },
    resetSelectedRow: (state) => {
      state.selectedRow = undefined;
    },
    addInvoiceLineItem: (state, action: PayloadAction<any>) => {
      const { length } = current(state.invoiceNoteLineItem);
      state.invoiceNoteLineItem.push({
        ...action.payload,
        unique_id: length + 1
      });
    },
    deleteInvoiceLineItem: (state, action: PayloadAction<any>) => {
      state.invoiceNoteLineItem = current(state.invoiceNoteLineItem).filter((invoice) => invoice !== action.payload);
      state.invoiceLineItemVat = current(state.invoiceLineItemVat).filter(
        (invoice) => invoice.ledef_id !== action.payload.ledger_code
      );
    },
    addInvoiceLineItemVat: (state, action: PayloadAction<any>) => {
      state.invoiceLineItemVat = [...action.payload];
    },
    setInvoiceLineItemVat: (state, action: PayloadAction<any>) => {
      const filtetedItemVat = [...action.payload].filter((lineItem) => lineItem?.line_type === "V");
      state.invoiceLineItemVat = filtetedItemVat;
    },
    setInvoiceLineItemSegregate: (state, action: PayloadAction<any>) => {
      state.filteredInvoiceLineItemVat = [...action.payload].filter(
        (lineItem) => lineItem?.line_type === invoiceLineTypes.LINETYPEV
      );
      state.filteredInvoiceLineItem = [...action.payload].filter(
        (lineItem) => lineItem?.line_type !== invoiceLineTypes.LINETYPEV
      );
    },
    setArrageLineItem: (state, action: PayloadAction<any>) => {
      state.arrangedInvoiceLineItem = action.payload;
    },
    setinvoiceLineStatus: (state, action: PayloadAction<any>) => {
      state.status = action.payload;
    },
    setSelecteRowIndex: (state, action: PayloadAction<any>) => {
      state.selectedRowIndex = action.payload;
    },
    setVateRate: (state, action: PayloadAction<any>) => {
      state.vatRate = action.payload;
    },
    setUpdatedRow: (state, action: PayloadAction<any>) => {
      state.updatedRow = action.payload;
    },
    updateInvoiceLineItem: (state, action: PayloadAction<any>) => {
      state.invoiceNoteLineItem = action.payload;
    },
    addToDeleteVatList: (state, action: PayloadAction<any>) => {
      state.vatDeletedList = [action.payload];
    },
    setAddInvoiceType: (state, action: PayloadAction<any>) => {
      state.addInvoiceType = action.payload;
    },
    setIsInvSaveSuccess: (state, action: PayloadAction<any>) => {
      state.isInvSaveSuccess = action.payload;
    },
    setIsInvCancelInitialed: (state, action: PayloadAction<any>) => {
      state.isInvCancelInitiated = action.payload;
    },
    setIsInvAuthorizeInitialed: (state, action: PayloadAction<any>) => {
      state.isInvAuthorizeInitialed = action.payload;
    },
    setFreeText: (state, action) => {
      state.isFreeText = action.payload;
    },
    setSelectedRowCustomCell: (state, action: PayloadAction<any>) => {
      state.selectedRowCustomCell = action.payload;
    },
    resetRowCustomCell: (state, action: PayloadAction<any>) => {
      state.selectedRowCustomCell = undefined;
    },
    setSelectedRowCustomCellRow: (state, action: PayloadAction<any>) => {
      state.selectedRowCustomCellRow = action.payload;
    },
    resetSelectedRowCustomCellRow: (state, action: PayloadAction<any>) => {
      state.selectedRowCustomCellRow = undefined;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
