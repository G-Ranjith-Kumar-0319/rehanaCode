import { ISelectedItem } from "@essnextgen/ui-kit";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { apiRoot, client } from "../../../config";

type invoiceNoteState = {
  invoiceNoteStatus: { [key: string]: any }[];
  error: string | undefined;
  status: string;
  selectedStatus: ISelectedItem;
};

const initialState: invoiceNoteState = {
  invoiceNoteStatus: [],
  selectedStatus: {
    text: "",
    value: ""
  },
  error: "",
  status: ""
};

/** Thunks */
export const getInvoiceNoteStatus = createAsyncThunk("invoiceNote/Status", async () => {
  const response = await client.get(`${apiRoot}/invoice/status`);
  return response.data;
});

/**
 * # Invoice Note Status Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** Purchase Orders List */
    builder
      .addCase(getInvoiceNoteStatus.pending, (state) => {
        state.status = "loading";
        state.error = undefined;
      })
      .addCase(getInvoiceNoteStatus.fulfilled, (state, action: PayloadAction<any>) => {
        if (!state.selectedStatus.text) {
          state.selectedStatus = {
            text: action.payload[0]?.description,
            value: action.payload[0]?.code
          };
        }
        state.invoiceNoteStatus = action.payload;
        state.status = "success";
      })
      .addCase(getInvoiceNoteStatus.rejected, (state) => {
        state.status = "failed";
      });
  },
  initialState,
  name: "invoiceNoteStatus",
  reducers: {
    setInvoiceNoteStatus: (state, action: PayloadAction<any>) => {
      state.selectedStatus = action.payload;
    },
    resetFilters: (state) => {
      state.selectedStatus = {
        ...initialState.selectedStatus
      };
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
