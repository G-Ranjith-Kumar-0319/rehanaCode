import { ISelectedItem } from "@essnextgen/ui-kit";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { apiRoot, client } from "../../../config";

type invoiceNoteState = {
  invoiceNoteType: { [key: string]: any }[];
  error: string | undefined;
  status: string;
  selectedType: ISelectedItem;
};

const initialState: invoiceNoteState = {
  invoiceNoteType: [],
  selectedType: {
    text: "",
    value: ""
  },
  error: "",
  status: ""
};

/** Thunks */
export const getInvoiceNoteType = createAsyncThunk("invoiceNote/Type", async () => {
  const response = await client.get(`${apiRoot}/invoice/type-Lookup`);
  return response.data;
});

/**
 * # Invoice Note Status Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** Purchase Orders List */
    builder
      .addCase(getInvoiceNoteType.pending, (state) => {
        state.status = "loading";
        state.error = undefined;
      })
      .addCase(getInvoiceNoteType.fulfilled, (state, action: PayloadAction<any>) => {
        if (!state.selectedType.text) {
          state.selectedType = {
            text: action.payload[0]?.description,
            value: action.payload[0]?.code
          };
        }
        state.invoiceNoteType = action.payload;
        state.status = "success";
      })
      .addCase(getInvoiceNoteType.rejected, (state) => {
        state.status = "failed";
      });
  },
  initialState,
  name: "invoiceNoteType",
  reducers: {
    setInvoiceNoteType: (state, action: PayloadAction<any>) => {
      state.selectedType = action.payload;
    },
    resetFilters: (state) => {
      state.selectedType = {
        ...initialState.selectedType
      };
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
