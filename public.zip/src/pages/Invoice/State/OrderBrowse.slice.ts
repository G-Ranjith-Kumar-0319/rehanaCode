import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import orderBrowsecolumnDef from "@/pages/Invoice/CreditNoteProcessing/CreateOrderInvoice/columnDef";
import { apiRoot, client } from "@/config";
import { isArrayLength } from "@/pages/GeneralLedgerSetup/ProfileModels/utils";
import { STATUS } from "../../../types/UseStateType";

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
  orderIdFromSupplier?: any;
};

const initialState: any = {
  columnDef: orderBrowsecolumnDef,
  orderIdFromSupplier: undefined,
  orderBrowseDetail: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined
  }
};

/** Thunks */
export const getInvoiceOrderBrowse = createAsyncThunk("invoiceNote/orderBrowse", async (clientID?: any) => {
  const response = await client.get(`${apiRoot}/invoice/uninvoiced-lookup?clientID=${clientID}`);
  return response.data;
});
const slice = createSlice({
  extraReducers: (builder) => {
    /** Invoice Order Browse period Slice */
    builder
      .addCase(getInvoiceOrderBrowse.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getInvoiceOrderBrowse.fulfilled, (state, action: PayloadAction<any>) => {
        const filterOrderBrowse = [...action.payload].map((orders) => {
          const newOrders = { ...orders };
          newOrders.code = newOrders.code.toString();
          return newOrders;
        });
        state.orderBrowseDetail = filterOrderBrowse;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getInvoiceOrderBrowse.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  initialState,
  name: "orderBrowse",
  reducers: {
    selectOrderBrowse: (state, action: PayloadAction<any>) => {
      state.selectedValue = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (state?.columnDef || [])?.filter((col: any) => !!col.sequence)?.at(0)?.field
      };
    },
    resetSelectedRow: (state) => {
      state.selectedValue = undefined;
    },
    filterOrderById: (state, action: PayloadAction<Number | null>) => {
      state.orderIdFromSupplier = action.payload;
    },
    setOrderBrowserDetail: (state, action) => {
      const payloadArray = Array.isArray(action.payload) ? action.payload : [action.payload];
      const clone = [...payloadArray];
      state.orderBrowseDetail = clone;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
