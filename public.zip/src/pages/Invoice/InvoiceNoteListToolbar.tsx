import { Catalog } from "@carbon/icons-react";
import PageToolbar, { PageToolbarType } from "@/components/Toolbar/PageToolbar";
import { AppDispatch, useAppSelector } from "@/store/store";
import { invoiceStatus } from "@/utils/constants";
import { useDispatch } from "react-redux";
import { useState } from "react";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { cancelInvoiceOrder } from "./State/InvoiceNoteList.slice";

const InvoiceNoteListToolbar = ({ handleNotesClick }: { handleNotesClick?: () => void }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { selectedRow } = useAppSelector((state) => state.invoiceNote);
  const [isconfirmModalOpen, setIsconfirmModalOpen] = useState<boolean>(false);
  const dispatch = useDispatch<AppDispatch>();
  const butons: PageToolbarType[] = [
    {
      title: "Cancel Invoice / Credit Note",
      element: <Catalog size={22} />,
      onClick: () => {
        setIsconfirmModalOpen(true);
      },
      disableCheck: !(
        selectedRow?.status === invoiceStatus.unauthorised ||
        selectedRow?.status === invoiceStatus.fullyAuth ||
        selectedRow?.status === invoiceStatus.onHold
      )
    }
  ];

  return (
    <>
      <PageToolbar buttons={butons} />
      <ConfirmModal
        isOpen={isconfirmModalOpen}
        setOpen={setIsconfirmModalOpen}
        title={t("common.confirmTitile")}
        message={t("confirmMsg.invoiceCancelTitle")}
        confirm={() => {
          dispatch(cancelInvoiceOrder({ row: selectedRow }));
          setIsconfirmModalOpen(false);
        }}
      />
    </>
  );
};

InvoiceNoteListToolbar.defaultProps = {
  handleNotesClick: undefined
};

export default InvoiceNoteListToolbar;
