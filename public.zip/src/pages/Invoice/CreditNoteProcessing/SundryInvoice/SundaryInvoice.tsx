import React, { useEffect, useRef, useState } from "react";
import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  IPaginationProps,
  ITableProps,
  TextInputSize,
  TextInput,
  TextInputIconPosition,
  Textarea,
  DateInput,
  CheckBox,
  Divider,
  Icon
} from "@essnextgen/ui-kit";
// import "./Style.scss";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import Layout from "@/components/Layout/Layout";
import GridTable, { cellRendererType } from "@/components/GridTable/GridTable";
import { CreateInvoiceOrdersDef } from "@/utils/constants";
import { STATUS } from "@/types/UseStateType";
import InvoiceOrderTools from "../../InvoiceOrderToolbar";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];

const SundryInvoice = (args: ITableProps) => {
  const dispatch = useDispatch<AppDispatch>();
  const containerRef: React.MutableRefObject<HTMLDivElement | null> = useRef<HTMLDivElement>(null);
  const { status, viewStatus, pageStatus } = useAppSelector((state) => state.purchaseOrder);
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();

  const {
    status: purchaseOrderResponseStatus,
    purchaseOrderStatus: purchaseOrderViews,
    selectedView
  } = useAppSelector((state) => state.purchaseViews);

  const { purchaseOrders, pageSize, currentPage, totalPages } = useAppSelector(
    ({ purchaseOrder }) => purchaseOrder?.purchaseOrdersList
  );

  // To switch between languages i18n.changeLanguage() function requires language param.
  useEffect(() => {
    i18n.changeLanguage("en");
  }, []);

  const arr = [{}];

  return (
    <Layout
      pageTitle="Sundry Invoice"
      className="sundry-order sundry-order__page"
      rightContent={<InvoiceOrderTools />}
    >
      <Grid
        container
        className="mt-10"
      >
        <GridItem xl={4}>
          <FormLabel forId="name">{t("invoiceNote.status")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconName="search"
            iconPosition={TextInputIconPosition.Right}
          />
          <Textarea
            id="textarea"
            maxLength={100}
          />
          <FormLabel forId="name">{t("invoiceNote.type")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconName="view"
            iconPosition={TextInputIconPosition.Right}
          />
        </GridItem>

        <GridItem xl={4}>
          <FormLabel forId="name">{t("invoiceNote.fullInvoiceNo")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconName="search"
            iconPosition={TextInputIconPosition.Right}
          />

          <FormLabel forId="name">{t("invoiceNote.invoiceno")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconName="view"
            iconPosition={TextInputIconPosition.Right}
          />

          <FormLabel forId="name">{t("invoiceNote.invoiceTotal")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconPosition={TextInputIconPosition.Right}
          />

          <FormLabel forId="name">{t("invoiceNote.payFrom")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconName="search"
            iconPosition={TextInputIconPosition.Right}
          />
          <CheckBox
            dataTestId="test-id"
            id="element-id"
            label="On Hold"
            value="2"
          />
        </GridItem>
        <GridItem xl={4}>
          <FormLabel>{t("invoiceNote.invoiceDate")}</FormLabel>
          <DateInput
            dataTestId="test-id"
            id="element-id"
          />

          <FormLabel forId="name">{t("invoiceNote.source")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconPosition={TextInputIconPosition.Right}
          />

          <FormLabel>{t("invoiceNote.paidByDate")}</FormLabel>
          <DateInput
            dataTestId="test-id"
            id="element-id"
          />

          <FormLabel forId="name">{t("invoiceNote.postingPeriod")}</FormLabel>
          <div />
          <TextInput
            id="name-1"
            iconName="search"
            size={TextInputSize.Small}
            iconPosition={TextInputIconPosition.Right}
          />

          <FormLabel forId="name">{t("invoiceNote.invoiceNote")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconName="edit--alt"
            iconPosition={TextInputIconPosition.Right}
          />
        </GridItem>
      </Grid>
      <br />
      <Grid>
        <GridItem xl={12}>
          <GridTable
            dataSource={arr}
            isLoading={pageStatus === STATUS.LOADING || status === STATUS.LOADING || viewStatus === STATUS.LOADING}
            columnDef={CreateInvoiceOrdersDef}
            isLookingForFilter={[]}
          />
        </GridItem>
      </Grid>
      <br />
      <Grid>
        <GridItem xl={6}>
          <FormLabel forId="name">{t("invoiceNote.ledgerCode")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconPosition={TextInputIconPosition.Right}
          />
          <FormLabel forId="name">{t("invoiceNote.transID")}</FormLabel>
          <br />
          <FormLabel forId="name">{t("invoiceNote.totalVAT")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconPosition={TextInputIconPosition.Right}
            placeholderText="0.00"
          />
        </GridItem>

        <GridItem xl={3}>
          <FormLabel forId="name">{t("invoiceNote.costCenter")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconPosition={TextInputIconPosition.Right}
          />
          <br />
          <FormLabel forId="name">{t("invoiceNote.invoiceTotalIncludingVAT")}</FormLabel>
          <TextInput
            id="name-1"
            size={TextInputSize.Small}
            iconPosition={TextInputIconPosition.Right}
            placeholderText="0.00"
          />
        </GridItem>

        <GridItem xl={3}>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Secondary}
            disabled
          >
            {t("invoiceNote.supportingDocuments")}
          </Button>
        </GridItem>
      </Grid>
    </Layout>
  );
};

export default SundryInvoice;
