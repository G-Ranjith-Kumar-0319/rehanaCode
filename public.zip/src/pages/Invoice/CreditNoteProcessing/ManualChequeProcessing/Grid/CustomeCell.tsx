import { cellRendererType } from "@/components/GridTable/GridTable";

const CustomCell = ({ field, row }: cellRendererType) => {
  const getContent = () => {
    switch (field) {
      case "unused":
        return parseInt(row?.last_no, 10) - parseInt(row?.next_no, 10) + 1;
      default:
        return "";
    }
  };
  return getContent();
};

export default CustomCell;
