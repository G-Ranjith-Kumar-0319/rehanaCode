import { TColumnDef } from "@/components/GridTable/GridTable";

const chequeBooksColumnDef: TColumnDef = [
  {
    headerName: "Start",
    field: "first_no",
    align: "left"
  },
  {
    headerName: "End",
    field: "last_no",
    align: "left"
  },
  {
    headerName: "Unused",
    field: "unused",
    align: "left",
    cellRenderer: "GridCellLink"
  }
];

export default chequeBooksColumnDef;
