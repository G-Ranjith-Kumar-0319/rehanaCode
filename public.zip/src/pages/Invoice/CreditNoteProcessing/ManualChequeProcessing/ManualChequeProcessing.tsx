import {
  ButtonColor,
  FormLabel,
  Button,
  ButtonSize,
  Grid,
  GridItem,
  IconColor,
  IconSize,
  Divider,
  TextInput,
  Icon,
  LoaderType,
  Loader,
  ValidationTextLevel,
  Notification,
  NotificationStatus
} from "@essnextgen/ui-kit";

import { useEffect, useLayoutEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import useQuery from "@/hooks/useQuery";
import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import "./Style.scss";
import { useHistory, useParams } from "react-router-dom";
import PostingPeriodModal from "@/shared/components/PostingPeriod/PostingPeriodModal";
import { useForm } from "react-hook-form";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { BOOLEAN_DATA, INVOICE_ROW, RESPONSE_STATUS } from "@/types/UseStateType";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import chequeBooksColumnDef from "./Grid/columnDef";
import CustomCell from "./Grid/CustomeCell";
import { getInvoiceDetails } from "../../State/InvoiceNoteDetails";
import { actions as postingPeriodActions, getInvoicePostingPeriod } from "../../State/InvoicePostingPeriod.slice";
import {
  getDefaultPeriod,
  postChequePaymentProccesing,
  actions as ioActions,
  postChequeNumberValidate
} from "../../State/ManualChequeProcessing.slice";
import { AppDispatch, useAppSelector } from "../../../../store/store";
import { getInvoiceOrdersFilter, actions as notListAction } from "../../State/InvoiceNoteList.slice";

type TChequeFormData = {
  period?: string;
  month?: string;
  nextChequeNo: string;
  chequeNarrative?: string;
};

export const getCurrentDate = (): string => {
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = `0${currentDate.getMonth() + 1}`.slice(-2);
  const day = `0${currentDate.getDate()}`.slice(-2);
  return `${day}/${month}/${year}`;
};

const ManualChequeProcessingModal = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const playmode = "essui-textinput essui-textinput--medium b-0 pl-0 m-0 playback";
  const searchParams = useQuery();
  const history = useHistory();
  const {
    location: { pathname }
  } = history;
  const dispatch = useDispatch<AppDispatch>();
  let { invoiceId } = useParams<{ invoiceId: any }>();
  if (!invoiceId) {
    invoiceId = searchParams.get("invoiceId");
  }
  const [isPostLoading, setIsPostLoading] = useState<boolean>(false);
  const [isPostingPeriodModalOpen, setPostingPeriodModalOpen] = useState<boolean>(false);
  const { postingPeriodDetails } = useAppSelector((state) => state.invoicePostingPeriod);
  const { chequeDetails, defaultPeriod, chequeSelectedRow, chequeRightSelectedRow } = useAppSelector(
    (state) => state.chequeDetails
  );
  const { storeCurrPage } = useAppSelector((state: any) => state.directPaymentProcess);
  const { invoiceDetails } = useAppSelector((state) => state.invoiceDetails);
  const { selectedRow, filterState, currentPage } = useAppSelector((state: any) => state.invoiceNote);
  const invoiceData = invoiceId ? invoiceDetails : selectedRow;
  const [rightSelectedCheques, setRightSelectedCheques] = useState<any>([]);
  const [leftSelectedCheques, setLeftSelectedCheques] = useState<any>([]);
  const [isChequeValidateOpen, setIsChequeValidateOpen] = useState<boolean>(false);
  const [isNarrativeFieldErr, setIsNarrativeFieldError] = useState<boolean>(false);
  const [isNextCheckNoFieldErr, setIsNextCheckNoFieldErr] = useState<boolean>(false);
  const [isOpenAlert, setIsOpenAlert] = useState<boolean>(false);
  const [isLoaded, setLoaded] = useState(false);
  const [isChanged, setIsChanged] = useState(false);
  const [isCancel, setIsCancel] = useState(false);
  const [message, setMessage] = useState<string>("");
  const [periodMonth, setPeriodMonth] = useState<boolean>(false);
  const { alert } = useAppSelector((state) => state.ui);
  const {
    register,
    handleSubmit,
    reset,
    getValues,
    setValue,
    trigger,
    watch,
    formState: { errors, isDirty }
  } = useForm<TChequeFormData>({ shouldFocusError: false });

  type TBankDetails = {
    bankAccName: string;
    bankAccNo: number;
    sortCode: string;
  };
  const [bankData, setBankData] = useState<TBankDetails>();

  useLayoutEffect(() => {
    if (invoiceId) {
      dispatch(getInvoiceDetails({ invoiceId }));
    }
    dispatch(getDefaultPeriod({ date: getCurrentDate() }));
  }, []);

  useEffect(() => {
    if (chequeDetails?.length) {
      setLeftSelectedCheques(chequeDetails);
      dispatch(ioActions.setChequeSelectedRow(chequeDetails[0]));
      const bankData: TBankDetails = {
        bankAccName: chequeDetails[0].ledger_des,
        bankAccNo: chequeDetails[0].bank_account,
        sortCode: chequeDetails[0].bank_sort_code
      };
      setBankData(bankData);
    }
  }, [chequeDetails]);

  useEffect(() => {
    if (postingPeriodDetails?.length && defaultPeriod) {
      const defaultPeriodObj: any = postingPeriodDetails.filter(
        (period) => period.code === defaultPeriod.toString()
      )[0];
      if (!isLoaded) {
        setValue("period", defaultPeriodObj?.code);
        setValue("month", String(defaultPeriodObj?.description));
        setLoaded(true);
      }
      setValue("nextChequeNo", "000000");
      setPeriodMonth(true);
    }
  }, [postingPeriodDetails, defaultPeriod]);

  const shiftCheckRight = () => {
    setIsChanged(true);
    dispatch(ioActions.setChequeRightSelectedRow(chequeSelectedRow));
    const leftChequeArr = leftSelectedCheques.filter((cheque: any) => cheque?.book_id !== chequeSelectedRow?.book_id);
    const rightChequeArr = [];
    rightChequeArr.push(chequeSelectedRow);
    setLeftSelectedCheques(leftChequeArr);
    setRightSelectedCheques(rightChequeArr);
    setValue("nextChequeNo", chequeSelectedRow?.next_no);
  };

  const shirtChequeLeft = () => {
    setIsChanged(true);
    const leftChequeArr = leftSelectedCheques.length ? leftSelectedCheques : [];
    leftChequeArr.push(chequeRightSelectedRow);
    setLeftSelectedCheques(leftChequeArr);
    setRightSelectedCheques("");
    setValue("nextChequeNo", "000000");
  };

  const validateCheckForm = () => {
    setIsNarrativeFieldError(false);
    setIsNextCheckNoFieldErr(false);
    let error = false;
    if (!getValues("chequeNarrative")) {
      setIsNarrativeFieldError(true);
      error = true;
    }

    if (
      !getValues("nextChequeNo") ||
      parseInt(getValues("nextChequeNo"), 10) < parseInt(chequeRightSelectedRow?.first_no, 10) ||
      parseInt(getValues("nextChequeNo"), 10) > parseInt(chequeRightSelectedRow?.last_no, 10)
    ) {
      setIsNextCheckNoFieldErr(true);
      error = true;
    }
    return error;
  };

  const refreshPageAndGetUpdatedList = () => {
    dispatch(notListAction.setFilters({ ...filterState, invoiceId: selectedRow?.invoice_id, lookingFor: "" }));
  };

  const postChequePaymentSave = async () => {
    if (validateCheckForm()) {
      setMessage(t("common.invalidData"));
      setIsOpenAlert(true);
    } else {
      setIsPostLoading(true);
      const chequeNoValidateObj = {
        bankId: invoiceData?.bank_id,
        chequeNumber: parseInt(getValues("nextChequeNo"), 10)
      };
      const chequeNoValidateRes = await dispatch(postChequeNumberValidate(chequeNoValidateObj));

      if (chequeNoValidateRes.payload === BOOLEAN_DATA.True) {
        setIsPostLoading(false);
        setIsChequeValidateOpen(true);
      } else {
        processPost();
      }
    }
  };

  const processPost = async () => {
    const postObj = {
      bankId: invoiceData?.bank_id,
      bookId: chequeRightSelectedRow?.book_id,
      invoiceId: invoiceData?.invoice_id,
      period: getValues("period"),
      chequeNumber: parseInt(getValues("nextChequeNo"), 10),
      narrative: getValues("chequeNarrative")
    };

    const res = await dispatch(postChequePaymentProccesing(postObj));
    if (res?.meta?.requestStatus === RESPONSE_STATUS.FULFILLED) {
      refreshPageAndGetUpdatedList();
      history.goBack();
    } else if (res?.meta?.requestStatus === RESPONSE_STATUS.REJECTED) {
      setMessage(t("manualChequeProcessing.alreadyUsedError"));
      setIsOpenAlert(true);
    }
    setIsChanged(false);
    setIsPostLoading(false);
  };

  let flag = false;
  useEffect(() => {
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      if (
        (location.pathname === `/invoice-credit-note/manual-cheque-processing?invoiceId=${invoiceId}` ||
          location.pathname === `/invoice-credit-note`) &&
        !alert?.enable &&
        (isDirty || isChanged)
      ) {
        dispatch(
          uiActions.confirmPopup({
            enable: true,
            message: t("alertMessage.keepChangesMsg"),
            title: t("common.simsFMSModule"),
            type: MODAL_TYPE.CONFIRMV2,
            yesCallback: async () => {
              let result;
              if (postChequePaymentSave) {
                postChequePaymentSave();
              }
            },
            noCallback: () => {
              flag = true;
              if (invoiceId && isCancel) {
                history.push(`/invoice-credit-note/manual-cheque-processing?invoiceId=${invoiceId}`);
              } else {
                history.push("/invoice-credit-note");
              }
            },
            isCancelBtnEnable: true
          })
        );

        if (!flag) {
          return false;
        }
      }
    });

    return () => {
      unblock();
    };
  }, [alert?.enable, isDirty, isChanged, rightSelectedCheques, isCancel]);

  return (
    <>
      {isPostLoading ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText={t("common.loading")}
        />
      ) : (
        <Layout
          pageTitle="Manual Cheque Processing"
          className="manual-cheque-processing"
          rightContent=""
          toolbar=""
          isBreadcrumbRequired
        >
          <Grid>
            <GridItem
              sm={12}
              md={3}
              xl={3}
            >
              <FormLabel>{t("manualChequeProcessing.selectBankAccount")}</FormLabel>
              <div className={playmode}>{bankData?.bankAccName}</div>
            </GridItem>
            <GridItem
              sm={12}
              md={2}
              xl={2}
            >
              <FormLabel>{t("manualChequeProcessing.accountNo")}</FormLabel>
              <div className={playmode}>{bankData?.bankAccNo}</div>
            </GridItem>
            <GridItem
              sm={12}
              md={2}
              xl={2}
            >
              <FormLabel>{t("manualChequeProcessing.sortCode")}</FormLabel>
              <div className={playmode}>{bankData?.sortCode}</div>
            </GridItem>
          </Grid>
          <Divider />
          <Grid className="mt-16">
            <GridItem>
              <FormLabel>
                <div className="essui-global-typography-default-h4">{t("manualChequeProcessing.selectChequeBook")}</div>
              </FormLabel>
            </GridItem>
          </Grid>
          <Grid className="mt-16">
            <GridItem lg={4}>
              <GridTableNew
                filters={
                  <div className="essui-global-typography-default-subtitle">
                    {t("manualChequeProcessing.availableChequeBook")}
                  </div>
                }
                dataSource={leftSelectedCheques || []}
                columnDef={chequeBooksColumnDef}
                selectedRow={chequeSelectedRow}
                selectedRowHandler={(row) => {
                  dispatch(ioActions.setChequeSelectedRow(row));
                }}
                isLoading={false}
                customCell={CustomCell}
                isScrollable
                enableScrollIntoView
              />
            </GridItem>
            <GridItem
              lg={1}
              className="select-cheque-btn"
            >
              <Button
                className="base-class table-btn"
                color={ButtonColor.Secondary}
                iconName="arrow--right"
                size={ButtonSize.Small}
                onClick={() => {
                  shiftCheckRight();
                }}
                disabled={rightSelectedCheques?.length}
              />
              <Button
                className="base-class table-btn"
                color={ButtonColor.Secondary}
                iconName="arrow--left"
                size={ButtonSize.Small}
                onClick={() => {
                  shirtChequeLeft();
                }}
                disabled={rightSelectedCheques?.length === 0}
              />
            </GridItem>
            <GridItem
              lg={5}
              className="checkBookUsed"
            >
              <GridTableNew
                filters={
                  <div className="essui-global-typography-default-subtitle">
                    {t("manualChequeProcessing.chequeToBeUsed")}
                  </div>
                }
                dataSource={rightSelectedCheques || []}
                columnDef={chequeBooksColumnDef}
                selectedRow={chequeRightSelectedRow}
                selectedRowHandler={(row) => {
                  dispatch(ioActions.setChequeRightSelectedRow(row));
                }}
                isLoading={false}
                customCell={CustomCell}
              />
              <FormLabel className="next-check-book-lbl">{t("manualChequeProcessing.nextChequeNo")}</FormLabel>
              <TextInput
                id="nextChequeNo"
                className={`w-100 ${isNextCheckNoFieldErr ? "essui-textinput--error" : ""}`}
                value={watch("nextChequeNo")}
                maxLength={6}
                onChange={(e) => {
                  setValue("nextChequeNo", e.target.value, { shouldDirty: true });
                  setIsNextCheckNoFieldErr(false);
                  register("nextChequeNo").onChange(e);
                }}
                validationTextLevel={errors.nextChequeNo ? ValidationTextLevel.Error : undefined}
              />
            </GridItem>
          </Grid>
          <Divider />
          <Grid className="mt-16">
            <GridItem
              sm={12}
              md={2}
              xl={2}
            >
              <Grid>
                <GridItem
                  lg={12}
                  className="manual-cheque-period-field"
                >
                  <Input
                    id="chequePeriod"
                    searchable
                    labelText={t("manualChequeProcessing.paymentPeriod")}
                    inputWidth={50}
                    searchItems={(postingPeriodDetails || []).map((p) => ({
                      text: p?.code,
                      value: p?.id
                    }))}
                    onSelect={(selectedItem) => {
                      const payfrom = postingPeriodDetails.filter((s) => s.id === selectedItem?.value)[0];
                      if (selectedItem?.text) {
                        setValue("period", String(selectedItem.text), { shouldDirty: true });
                        setValue("month", payfrom.description);
                      } else {
                        setValue("period", "");
                        setValue("month", "");
                      }
                      dispatch(postingPeriodActions.selectPostingPeriod(payfrom));
                    }}
                    onNoSelection={() => {
                      setPostingPeriodModalOpen(true);
                    }}
                    onChange={(e) => {
                      setValue("period", e.target.value, { shouldDirty: true });
                      register("period").onChange(e);
                    }}
                    value={getValues("period")?.toString()}
                    inputRef={(e) => register("period").ref(e)}
                    name={register("period", { required: true }).name}
                    validationTextLevel={errors.period ? ValidationTextLevel.Error : undefined}
                    button={
                      <>
                        <TextInput
                          id="desc"
                          className="width55"
                          inputWidth={60}
                          value={getValues("month")}
                          name={register("month", { required: true }).name}
                          onChange={(e) => {
                            register("month").onChange(e);
                          }}
                          disabled
                        />

                        <Button
                          color={ButtonColor.Secondary}
                          onClick={() => {
                            setPostingPeriodModalOpen(true);
                          }}
                          className={
                            !invoiceId ? "essui-button-icon-only--small disabled" : "essui-button-icon-only--small"
                          }
                          disabled={!invoiceId}
                          size={ButtonSize.Small}
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="search"
                          />
                        </Button>
                      </>
                    }
                  />
                </GridItem>
              </Grid>
            </GridItem>
            <GridItem
              sm={12}
              md={10}
              xl={10}
            >
              <FormLabel>{t("manualChequeProcessing.chequeNarrative")}</FormLabel>
              <TextInput
                id="chequeNarrative"
                className={`w-100 ${isNarrativeFieldErr ? "essui-textinput--error" : ""}`}
                value={getValues("chequeNarrative")}
                maxLength={60}
                onChange={(e) => {
                  setValue("chequeNarrative", e.target.value, { shouldDirty: true });
                  setIsNarrativeFieldError(false);
                  register("chequeNarrative").onChange(e);
                }}
                validationTextLevel={errors.chequeNarrative ? ValidationTextLevel.Error : undefined}
              />
            </GridItem>
          </Grid>
          <Grid className="mt-16">
            <GridItem lg={10}>
              {/* <Button
                size={ButtonSize.Small}
                color={ButtonColor.Tertiary}
                className="selection-processing"
              >
                {t("common.help")}
              </Button> */}
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </GridItem>
            <GridItem
              lg={2}
              className="cheque-post-btn"
            >
              <Grid>
                <GridItem>
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    className="selection-processing"
                    onClick={() => {
                      setIsCancel(true);
                      history.goBack();
                    }}
                  >
                    {t("common.cancel")}
                  </Button>
                </GridItem>
                <GridItem>
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Primary}
                    className="selection-processing"
                    onClick={postChequePaymentSave}
                    disabled={rightSelectedCheques?.length === 0}
                  >
                    {t("manualChequeProcessing.post")}
                  </Button>
                </GridItem>
              </Grid>
            </GridItem>
            <Grid />
          </Grid>
        </Layout>
      )}
      <PostingPeriodModal
        isOpen={isPostingPeriodModalOpen}
        setOpen={setPostingPeriodModalOpen}
        selectedRow={(row) => {
          setValue("period", String(row.code));
          setValue("month", row?.description);
          dispatch(postingPeriodActions.selectPostingPeriod(row));
        }}
      />
      <ConfirmModal
        isOpen={isChequeValidateOpen}
        setOpen={setIsChequeValidateOpen}
        className="cancel-popup"
        title={t("invoiceNote.invoiceModalCancel")}
        message={t("manualChequeProcessing.chequeValidateError")}
        confirm={() => {
          setIsChequeValidateOpen(false);
          processPost();
        }}
      />
      <Modalv2
        isOpen={isOpenAlert}
        header={t("common.simsFMSModule")}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setIsOpenAlert(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
      >
        <>
          <Notification
            actionElement={1}
            dataTestId="delete-new-warning-id"
            escapeExits
            id="delete-new-warning-id"
            className="confirm-modal-text"
            hideCloseButton
            status={NotificationStatus.WARNING}
            title={message}
          />
        </>
      </Modalv2>
    </>
  );
};

export default ManualChequeProcessingModal;
