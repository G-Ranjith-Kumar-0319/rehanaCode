import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import useQuery from "@/hooks/useQuery";
import { useParams } from "react-router-dom";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import Modal from "../../../../components/Modal/Modal";
import { STATUS } from "../../../../types/UseStateType";
import GridTable from "../../../../components/GridTable/GridTable";
import { orderAuditSummaryColumnDef } from "../../../../utils/constants";
import { AppDispatch, useAppSelector } from "../../../../store/store";
import { getOrderAuditSummary } from "../../../../shared/components/OrderAuditSummaryModal/state/OrderAuditSummary.slice";

type TOrderBookModalProp = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  selectBook?: (book: { [key: string]: any } | undefined) => void | undefined;
};

const InvoiceAuditSummaryModal = ({ setOpen, isOpen, selectBook }: TOrderBookModalProp) => {
  const dispatch = useDispatch<AppDispatch>();
  const [selectedRow, setSelectedRow] = useState<{ [key: string]: any } | undefined>();
  const closeHandler = () => setOpen(false);
  const { invoiceId } = useParams<{ orderno: string; invoiceId: any }>();

  const rowClick = (row: { [key: string]: any }) => {
    setSelectedRow(row);
  };
  const { status, auditSummary } = useAppSelector((state) => state.orderAuditSummary);

  useEffect(() => {
    if (isOpen) dispatch(getOrderAuditSummary({ invoiceId: invoiceId || undefined }));
  }, [isOpen]);

  return (
    <Modal
      header="Invoice Audit Summary"
      isOpen={isOpen}
      primaryBtnText="OK"
      primaryBtnClick={closeHandler}
      onClose={() => {
        setOpen(false);
      }}
    >
      <GridTableNew
        dataSource={auditSummary || []}
        isLoading={status === STATUS.LOADING}
        columnDef={orderAuditSummaryColumnDef}
      />
    </Modal>
  );
};

InvoiceAuditSummaryModal.defaultProps = {
  selectBook: undefined
};

export default InvoiceAuditSummaryModal;
