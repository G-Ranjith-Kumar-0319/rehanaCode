import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import useQuery from "@/hooks/useQuery";
import GridTableNew, { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import Input from "@/components/Input/Input";
import { FormLabel, Grid, GridItem } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { columnCssForDiffColumn } from "@/utils/getDataSource";
import { useParams } from "react-router-dom";
import { STATUS, specialCharacters } from "../../../../types/UseStateType";
import { orderInvoiceDifference, orderInvoiceHeaderColunmDef } from "../../../../utils/constants";
import { AppDispatch, useAppSelector } from "../../../../store/store";
import { getOrderInvoiceDifference } from "../../../../shared/components/OrderAuditSummaryModal/state/OrderAuditSummary.slice";
import "./Style.scss";
import Modal from "../../../../components/Modal/Modal";

type TOrderBookModalProp = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  watch?: (value: string) => void;
};

const InvoiceDifferenceModal = ({ setOpen, isOpen, watch }: TOrderBookModalProp) => {
  const dispatch = useDispatch<AppDispatch>();
  const closeHandler = () => setOpen(false);
  const searchParams = useQuery();
  // const invoiceId = searchParams.get("invoiceId");
  const { invoiceId } = useParams<{ orderno: string; invoiceId: any }>();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { invoiceDetails } = useAppSelector((state) => state.invoiceDetails);
  const isToolTipAllowed = true;
  const { status, invoiceOrderDifferenceList } = useAppSelector((state) => state.orderAuditSummary);
  const [defaultActiveCell, setDefaultActiveCell] = useState<boolean>(true);

  useEffect(() => {
    if (invoiceId && isOpen) dispatch(getOrderInvoiceDifference({ invoiceId: invoiceId || undefined }));
  }, [isOpen]);

  const CustomCell = ({ field, row }: cellRendererType) => {
    const numberFormatter = new Intl.NumberFormat("en-US", {
      style: "decimal",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    const getContent = () => {
      if (row) {
        switch (field) {
          case "inv_line_number":
            return (
              <>
                <div>{row?.inv_line_number ? row?.inv_line_number : specialCharacters.HYPHEN}&nbsp;</div>
              </>
            );
          case "ord_line_number":
            return (
              <>
                <div>{row?.ord_line_number ? row?.ord_line_number : specialCharacters.HYPHEN}&nbsp;</div>
              </>
            );
          case "inv_part_number":
            return (
              <>
                <div>{row?.inv_part_number ? row?.inv_part_number : specialCharacters.HYPHEN}&nbsp;</div>
              </>
            );
          case "ord_part_number":
            return (
              <>
                <div>{row?.ord_part_number ? row?.ord_part_number : specialCharacters.HYPHEN}&nbsp;</div>
              </>
            );
          case "inv_item_description":
            return (
              <>
                <span>{row?.inv_item_description ? row?.inv_item_description : specialCharacters.HYPHEN}&nbsp;</span>
              </>
            );
          case "ord_item_description":
            return (
              <>
                <span>{row?.ord_item_description ? row?.ord_item_description : specialCharacters.HYPHEN}&nbsp;</span>
              </>
            );
          case "inv_cost_per_unit":
            return (
              <>
                <div>
                  {row?.inv_cost_per_unit ? numberFormatter.format(row?.inv_cost_per_unit) : specialCharacters.HYPHEN}
                  &nbsp;
                </div>
              </>
            );
          case "ord_cost_per_unit":
            return (
              <>
                <div>
                  {row?.ord_cost_per_unit ? numberFormatter.format(row?.ord_cost_per_unit) : specialCharacters.HYPHEN}
                  &nbsp;
                </div>
              </>
            );
          case "inv_discount":
            return (
              <>
                <div>
                  {row?.inv_discount !== specialCharacters.BLANKVALUE
                    ? numberFormatter.format(row?.inv_discount)
                    : specialCharacters.HYPHEN}
                  &nbsp;
                </div>
              </>
            );
          case "ord_discount":
            return (
              <>
                <div>
                  {row?.ord_discount !== specialCharacters.BLANKVALUE
                    ? numberFormatter.format(row?.ord_discount)
                    : specialCharacters.HYPHEN}
                  &nbsp;
                </div>
              </>
            );
          default:
            return <div />;
        }
      }
      return null;
    };
    return getContent();
  };

  useEffect(() => {
    setDefaultActiveCell(isOpen);
  }, [isOpen]);

  const activeClassHandler = () => {
    setDefaultActiveCell(false);
  };

  return (
    <div className="invoice-difference">
      <Modal
        header={t("invoiceNote.invoiceDiffTitle")}
        isOpen={isOpen}
        primaryBtnText="OK"
        primaryBtnClick={closeHandler}
        onClose={() => {
          setOpen(false);
        }}
        fourthiaryBtnClick={() => {}}
        className="invoice-width"
      >
        <div className="grid-table">
          <GridTableNew
            filters={
              <div>
                <Grid justify="space-between">
                  <GridItem xl={3}>
                    <FormLabel>{t("viewInvoiceCreditNote.invoiceNumber")}</FormLabel>
                    <div className="mt-8">{invoiceDetails?.disp_inv_no || (watch && watch("disp_inv_no"))}</div>
                  </GridItem>
                  <GridItem xl={3}>
                    <FormLabel>{t("viewInvoiceCreditNote.orderNumber")}</FormLabel>
                    <div className="mt-8">{invoiceDetails?.ordernum || (watch && watch("ordernum"))}</div>
                  </GridItem>
                </Grid>
              </div>
            }
            customCell={CustomCell}
            dataSource={invoiceOrderDifferenceList || []}
            isLoading={status === STATUS.LOADING}
            columnDef={orderInvoiceDifference}
            columnDefHeader={orderInvoiceHeaderColunmDef}
            toolTipAllow={isToolTipAllowed}
            selectedRow={{}}
            isRowSelectionEnabled={false}
            headerClickHandler={activeClassHandler}
          />
        </div>
      </Modal>
    </div>
  );
};

InvoiceDifferenceModal.defaultProps = {
  watch: undefined
};

export default InvoiceDifferenceModal;
