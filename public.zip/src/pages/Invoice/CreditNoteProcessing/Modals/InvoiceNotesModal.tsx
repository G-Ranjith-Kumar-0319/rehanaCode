import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { ButtonColor, FormLabel, Textarea } from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { INVOICE_STATUS, INVOICE_TYPE, STATUS } from "@/types/UseStateType";
import { invoiceOrderType } from "@/utils/constants";
import { useParams } from "react-router-dom";
import Modal from "../../../../components/Modal/Modal";
import { AppDispatch, useAppSelector } from "../../../../store/store";
import { actions as ioActions } from "../../State/InvoiceNoteDetails";
import "./Style.scss";

type TOrderBookModalProp = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
};

const InvoiceNotesModal = ({ setOpen, isOpen }: TOrderBookModalProp) => {
  const dispatch = useDispatch<AppDispatch>();
  const closeHandler = () => setOpen(false);
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { status, invoiceDetails } = useAppSelector((state) => state.invoiceDetails);
  const [isDisabled, setIsDisabled] = useState<boolean>(false);
  const [explanationText, setExplanationText] = useState<String>("");
  const currentInvoiceType = sessionStorage.getItem("invoiceType");
  const { orderno, invoiceId } = useParams<{ orderno: string; invoiceId: any }>();
  useEffect(() => {
    if (status === STATUS.SUCCESS) {
      if (
        invoiceDetails?.invoice_type === invoiceOrderType.pc &&
        (invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED || invoiceDetails?.status === INVOICE_STATUS.AUTHORISED)
      ) {
        setIsDisabled(false);
      } else if (
        invoiceDetails?.status === INVOICE_STATUS.AUTHORISED ||
        invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED
      ) {
        setIsDisabled(false);
      } else {
        setIsDisabled(true);
      }
    }
    if (invoiceDetails?.length === 0) {
      setIsDisabled(false);
    }
  }, [invoiceDetails]);
  useEffect(() => {
    const timer = setTimeout(() => {
      document.getElementById("invoiceNotesModal")?.focus();
    }, 100);
    return () => clearTimeout(timer);
  });
  return (
    <Modal
      header={
        invoiceDetails?.invoice_type === invoiceOrderType.pc ||
        (!invoiceId && currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV)
          ? t("invoiceNote.invoiceModalCreditNotes")
          : t("invoiceNote.invoiceModalNotes")
      }
      isOpen={isOpen}
      primaryBtnText={t("common.ok")}
      tertiaryBtnText={t("common.cancel")}
      fourthiaryBtnText={t("common.help")}
      secondaryBtnType={ButtonColor.Secondary}
      primaryBtnStatus={isDisabled}
      tertiaryBtnClick={closeHandler}
      primaryBtnClick={() => {
        dispatch(ioActions.setInvoiceNotes(explanationText));
        closeHandler();
      }}
      fourthiaryBtnClick={() => {}}
    >
      <div className="invoice-modal">
        <div className="text-area-label-color">
          <FormLabel
            forId="textarea"
            className="label-color"
          >
            {t("invoiceNote.explanationText")}
          </FormLabel>
        </div>

        <Textarea
          value={!invoiceDetails?.inv_notes && isDisabled ? "-" : invoiceDetails?.inv_notes}
          disabled={isDisabled}
          onChange={(e) => setExplanationText(e.target.value)}
          id="invoiceNotesModal"
        />
      </div>
      <div />
    </Modal>
  );
};

export default InvoiceNotesModal;
