import { useEffect, useLayoutEffect, useState } from "react";
import { useDispatch } from "react-redux";
import {
  ButtonColor,
  FormLabel,
  NotificationStatus,
  Notification,
  Textarea,
  Button,
  ButtonSize
} from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { INVOICE_ROW, INVOICE_STATUS, STATUS, apiStatusCode } from "@/types/UseStateType";
import useQuery from "@/hooks/useQuery";
import { invoiceOrderType, invoicecanceltype } from "@/utils/constants";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { useParams } from "react-router-dom";
import Modal from "../../../../components/Modal/Modal";
import { AppDispatch, useAppSelector } from "../../../../store/store";
import { getInvoiceNoteLineItem, actions as invoiceLineItemAction } from "../../State/InvoiceNoteLineItem.slice";
import { actions as ioActions, cancelInvoiceOrder, getInvoiceOrdersFilter } from "../../State/InvoiceNoteList.slice";

import "./Style.scss";
import { getInvoiceDetails } from "../../State/InvoiceNoteDetails";
import useRedirectByStatus from "../InvoiceOrderView/useRedirectByStatus";

type TOrderBookModalProp = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  selectBook?: (book: { [key: string]: any } | undefined) => void | undefined;
  redirectOnFirstRecordOnViewPage?: any;
};

const InvoiceNotesCancelModal = ({
  setOpen,
  isOpen,
  selectBook,
  redirectOnFirstRecordOnViewPage
}: TOrderBookModalProp) => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [isInvoiceNotesErrorModalOpen, setIsInvoiceNotesErrorModalOpen] = useState<boolean>(false);
  const [cancelInvoiceErrorMessage, setCancelInvoiceErrorMessage] = useState<string>("");
  const searchParams = useQuery();
  const { invoiceId } = useParams<{ orderno: string; invoiceId: any }>();
  // ALL USE STATE CODE
  const [isDisabled, setIsDisabled] = useState<boolean>(true);
  const { currentPage } = useAppSelector((state) => state?.invoiceNote.invoiceNoteList);

  // ALL USEAPPSELECTOR CODE
  const { auditSummary } = useAppSelector((state) => state.orderAuditSummary);
  const { status, invoiceDetails } = useAppSelector((state) => state.invoiceDetails);
  const { selectedRow, filterState } = useAppSelector((state) => state.invoiceNote);
  const dispatch = useDispatch<AppDispatch>();
  const closeHandler = () => setOpen(false);
  const { checkInvoiceTypeAndRedirect } = useRedirectByStatus();

  let invoiceType = null;

  if (selectedRow?.invoice_type === invoiceOrderType.pc) {
    invoiceType = invoicecanceltype.credit;
  } else if (selectedRow?.invoice_type === invoiceOrderType.pi) {
    invoiceType = invoicecanceltype.invoice;
  }

  const title =
    invoiceType !== null
      ? `Are you sure you want to cancel this ${invoiceType}?`
      : "Are you sure you want to cancel this invoice?";

  useEffect(() => {
    if (status === STATUS.SUCCESS) {
      if (
        invoiceDetails?.status === INVOICE_STATUS.FULLY_AUTHORISED ||
        invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED ||
        invoiceDetails?.status === INVOICE_STATUS.ON_HOLD
      ) {
        setIsDisabled(false);
      } else {
        setIsDisabled(true);
      }
    }
  }, [invoiceDetails]);

  const updateSelectedRecord = async () => {
    if (invoiceId) {
      dispatch(
        cancelInvoiceOrder({
          invoice_id: invoiceDetails?.invoice_id,
          inv_last_update: invoiceDetails?.inv_last_update,
          ord_last_update: invoiceDetails?.ord_last_update,
          callback: (data: any) => {
            if (data.status === apiStatusCode.SQLEXCEPTION) {
              setIsInvoiceNotesErrorModalOpen(true);
              setCancelInvoiceErrorMessage(data.message);
            } else if (filterState?.status) {
              redirectOnFirstRecordOnViewPage();
              return;
            } else {
              dispatch(
                getInvoiceDetails({
                  invoiceId,
                  callback: (data) => {
                    checkInvoiceTypeAndRedirect(data);
                    dispatch(
                      getInvoiceNoteLineItem({
                        invoiceID: data.invoice_id,
                        OrderId: data.order_id,
                        callback: (res) => dispatch(invoiceLineItemAction.setSelectedRow(res[0]))
                      })
                    );
                  }
                })
              );
            }
            setOpen(false);
          }
        })
      );
    } else {
      dispatch(
        cancelInvoiceOrder({
          invoice_id: selectedRow?.invoice_id,
          inv_last_update: selectedRow?.inv_last_update,
          ord_last_update: selectedRow?.ord_last_update,
          callback: (data: any) => {
            if (data.status === apiStatusCode.SQLEXCEPTION) {
              setIsInvoiceNotesErrorModalOpen(true);
              setCancelInvoiceErrorMessage(data.message);
            } else {
              dispatch(
                getInvoiceOrdersFilter({
                  sequence: filterState?.sequence,
                  status: filterState?.status,
                  order: filterState?.order,
                  pageNumber: String(currentPage),
                  pageSize: filterState?.pageSize,
                  type: filterState?.type,
                  lookingFor: "",
                  invoiceId: selectedRow?.invoice_id,
                  callback: (response: any) => {
                    if (response?.invoices && response?.invoices?.length > 0) {
                      const currentInvoice = response.invoices;
                      const selectedData = currentInvoice
                        .filter((item: any) => item.invoice_id === selectedRow?.invoice_id)
                        ?.at(0);
                      if (selectedData) {
                        dispatch(ioActions.setSelectedRow(selectedData));
                      } else if (currentInvoice && response?.invoices?.length > 0) {
                        dispatch(ioActions.setSelectedRow(response.invoices?.at(0)));
                      }
                    } else {
                      dispatch(ioActions.clearInvoices());
                    }
                  }
                })
              ).then(() => {
                setOpen(false);
              });
            }
            setOpen(false);
          }
        })
      );
    }
  };

  const closeInvoiceNotesErrorModalOpen = () => {
    setIsInvoiceNotesErrorModalOpen(false);
  };

  const errorPrimaryButton = (
    <Button
      size={ButtonSize.Small}
      onClick={closeInvoiceNotesErrorModalOpen}
    >
      {t("common.ok")}
    </Button>
  );

  return (
    <>
      <ConfirmModal
        isOpen={isOpen}
        setOpen={setOpen}
        className="cancel-popup"
        title={t("invoiceNote.invoiceModalCancel")}
        message={title}
        confirm={() => {
          updateSelectedRecord();
          setOpen(false);
        }}
        callback={(click) => {
          dispatch(invoiceLineItemAction.setIsInvCancelInitialed(false));
          dispatch(invoiceLineItemAction.setIsInvSaveSuccess(false));
        }}
      />

      <Modalv2
        header={t("invoiceNote.invoiceModalCancel")}
        isOpen={isInvoiceNotesErrorModalOpen}
        primaryButton={errorPrimaryButton}
        className="cancel-popup"
      >
        <Notification
          actionElement={1}
          dataTestId="warning-id"
          escapeExits
          id="warning-id"
          hideCloseButton
          status={NotificationStatus.WARNING}
          title={cancelInvoiceErrorMessage}
          className="mb-18 confirm-modal-text"
        />
      </Modalv2>
    </>
  );
};

InvoiceNotesCancelModal.defaultProps = {
  selectBook: undefined,
  redirectOnFirstRecordOnViewPage: undefined
};

export default InvoiceNotesCancelModal;
