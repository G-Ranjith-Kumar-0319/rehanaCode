import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Notification,
  NotificationStatus,
  Orientation,
  Textarea,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { INVOICE_STATUS, STATUS } from "@/types/UseStateType";
import { invoiceOrderType, deepEqual } from "@/utils/constants";
import { useHistory } from "react-router-dom";
import { useForm } from "react-hook-form";
import "./Style.scss";
import NumberInput from "@/components/NumberInput/NumberInput";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import { getVatLedgerinfo } from "@/shared/components/VatCodesModal/state/VatCodes.slice";
import { setToSession, usNumberFormat } from "@/utils/getDataSource";
import { AppDispatch, useAppSelector } from "../../../../store/store";
import Modal from "../../../../components/Modal/Modal";
import { actions as invoiceLineItemAction } from "../../State/InvoiceNoteLineItem.slice";

type TVatLineDetailsModalModalProp = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
};
type TVatLineDetailFormData = {
  vatAmount: string;
};
const VatLineDetailsModal = ({ setOpen, isOpen }: TVatLineDetailsModalModalProp) => {
  const dispatch = useDispatch<AppDispatch>();
  const closeHandler = () => setOpen(false);
  const [keepChangesModal, setKeepChangesModal] = useState<boolean>(false);
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { status, invoiceDetails } = useAppSelector((state) => state.invoiceDetails);
  const { vatInfo } = useAppSelector((state: any) => state.vatCodes);
  const [isDisabled, setIsDisabled] = useState<boolean>(false);
  const { selectedRow } = useAppSelector((state) => state.invoiceNoteLineItem);
  const [isOpenAlert, setIsOpenAlert] = useState<boolean>(false);
  const history = useHistory();
  const historyState = history.location.state as any;
  const {
    register,
    handleSubmit,
    reset,
    getValues,
    setValue,
    trigger,
    watch,
    formState: { errors, isDirty }
  } = useForm<TVatLineDetailFormData>({
    mode: "all",
    shouldFocusError: false,
    defaultValues: {
      vatAmount: "0.00"
    }
  });

  useEffect(() => {
    reset({
      vatAmount: Number(selectedRow?.line_cost).toFixed(2)
    });

    if (selectedRow?.ledger_id) {
      setValue("vatAmount", Number(selectedRow?.line_cost).toFixed(2));
      dispatch(getVatLedgerinfo({ vatLedgerId: selectedRow?.ledger_id }));
    }
  }, [selectedRow]);

  useEffect(() => {
    if (status === STATUS.SUCCESS) {
      if (
        invoiceDetails?.invoice_type === invoiceOrderType.pc &&
        (invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED || invoiceDetails?.status === INVOICE_STATUS.AUTHORISED)
      ) {
        setIsDisabled(false);
      } else if (
        invoiceDetails?.status === INVOICE_STATUS.AUTHORISED ||
        invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED
      ) {
        setIsDisabled(false);
      } else {
        setIsDisabled(true);
      }
    }
    if (invoiceDetails?.length === 0) {
      setIsDisabled(false);
    }
  }, [invoiceDetails]);

  const onSubmit = handleSubmit(
    async (data) => {
      const selectedIndex = historyState?.invoiceLineList?.findIndex((t: any) => deepEqual(t, selectedRow));
      const tempInvoiceLineList = [...historyState?.invoiceLineList];
      tempInvoiceLineList[selectedIndex] = {
        ...tempInvoiceLineList[selectedIndex],
        line_cost: data?.vatAmount,
        is_changed: true
      };
      // dispatch(invoiceLineItemAction.setSelectedRow(tempInvoiceLineList[selectedIndex]));
      history.replace({ ...history.location, state: { ...historyState, invoiceLineList: tempInvoiceLineList } });
      closeHandler();
    },
    (error) => {
      setIsOpenAlert(true);
    }
  );

  useEffect(() => {
    if (isDirty) {
      setToSession("modalClose", true);
    }
  }, [isDirty]);

  return (
    <Modal
      header={t("vatLineDetails.header")}
      isOpen={isOpen}
      primaryBtnText={t("common.save")}
      tertiaryBtnText={t("common.cancel")}
      fourthiaryBtnText={t("common.help")}
      secondaryBtnType={ButtonColor.Secondary}
      primaryBtnStatus={isDisabled}
      tertiaryBtnClick={() => {
        if (isDirty) {
          setKeepChangesModal(true);
        } else {
          reset();
          closeHandler();
        }
      }}
      onClose={() => {
        setOpen(false);
      }}
      primaryBtnClick={() => {
        onSubmit();
      }}
      fourthiaryBtnClick={() => {}}
      className="vat-line-detail-modal"
    >
      <Grid container>
        <GridItem lg={12}>
          <Grid>
            <GridItem lg={6}>
              <FormLabel>{t("vatLineDetails.vatAmount")}</FormLabel>
              <NumberInput
                defaultValue={watch("vatAmount")}
                decimals={2}
                maxLength={12}
                name={
                  register("vatAmount", {
                    required: true,
                    validate: (value) => value !== "0.00"
                  }).name
                }
                onChange={(e) => {
                  const newValue = e.target.value === "0" ? "0.00" : e.target.value;
                  setValue("vatAmount", newValue, { shouldDirty: true });
                  register("vatAmount").onChange(e);
                }}
                inputRef={(e) => register("vatAmount").ref(e)}
                validationTextLevel={errors.vatAmount ? ValidationTextLevel.Error : undefined}
              />
            </GridItem>
          </Grid>
          <Divider orientation={Orientation.HORIZONTAL} />

          <Grid className="mt-12">
            <GridItem lg={12}>
              <FormLabel>{t("vatLineDetails.vatDesc")}</FormLabel>
              <div className="essui-textinput--medium border-0 playback">{selectedRow?.ledger_des}</div>
            </GridItem>
          </Grid>

          <Grid className="mt-8">
            <GridItem lg={6}>
              <FormLabel>{t("vatLineDetails.vatCode")}</FormLabel>
              <div className="essui-textinput--medium border-0 playback">{vatInfo[0]?.vat_code}</div>
            </GridItem>
            <GridItem lg={6}>
              <FormLabel>{t("vatLineDetails.vatRate")}</FormLabel>
              <div className="essui-textinput--medium border-0 playback">{usNumberFormat(vatInfo[0]?.rate)}</div>
            </GridItem>
          </Grid>
        </GridItem>
      </Grid>
      <Modalv2
        isOpen={isOpenAlert}
        header={t("common.simsFMSModule")}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setIsOpenAlert(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
        className="confirm-modal-text"
      >
        <>
          <Notification
            actionElement={1}
            className="confirm-modal-text"
            dataTestId="delete-new-warning-id"
            escapeExits
            id="delete-new-warning-id"
            hideCloseButton
            status={NotificationStatus.WARNING}
            title={t("common.invalidData")}
          />
        </>
      </Modalv2>
      <Modal
        className="keep-changes-modal"
        primaryBtnText={t("common.yes")}
        secondaryBtnText={t("common.no")}
        tertiaryBtnText={t("common.cancel")}
        primaryBtnType={ButtonColor.Primary}
        secondaryBtnType={ButtonColor.Secondary}
        primaryBtnClick={(e) => {
          setKeepChangesModal(false);
          onSubmit();
        }}
        secondaryBtnClick={() => {
          reset();
          closeHandler();
          setKeepChangesModal(false);
        }}
        tertiaryBtnClick={() => setKeepChangesModal(false)}
        isOpen={keepChangesModal}
        header={t("common.simsFMSModule")}
      >
        <>
          <Notification
            actionElement={1}
            dataTestId="delete-new-warning-id"
            escapeExits
            id="delete-new-warning-id"
            hideCloseButton
            status={NotificationStatus.WARNING}
            title={t("supplier.payeeBrowser.keepChanges")}
          />
        </>
      </Modal>
    </Modal>
  );
};

export default VatLineDetailsModal;
