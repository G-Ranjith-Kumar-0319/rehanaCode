import { TColumnDef } from "@/components/GridTable/GridTable";

const orderBrowsecolumnDef: TColumnDef = [
  {
    headerName: "Order Number",
    field: "code",
    sequence: true
  },
  {
    headerName: "Supplier",
    field: "description",
    sequence: true
  }
];
export default orderBrowsecolumnDef;
