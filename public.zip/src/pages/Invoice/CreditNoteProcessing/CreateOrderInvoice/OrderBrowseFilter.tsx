import useDebounce from "@/hooks/useDebounce";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import findNearest from "@/utils/nearestSearch";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  FormLabel,
  Grid,
  GridItem,
  RadioButton,
  RadioLabelPosition,
  TextInput,
  TextInputSize
} from "@essnextgen/ui-kit";
import React, { Dispatch, useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { actions as obActions } from "@/pages/Invoice/State/OrderBrowse.slice";
import columnDef from "./columnDef";

const OrderBrowseFilter = ({ setSelectRow }: { setSelectRow: Dispatch<any> }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const dispatch = useDispatch<AppDispatch>();
  const { orderBrowseDetail, filters } = useAppSelector((state) => state.orderBrowse);
  const { selectedSupplier } = useAppSelector((state) => state.selectedSupplier);
  const debouncedValue = useDebounce(filters?.lookingFor!, 300);
  const inputRef: React.Ref<HTMLInputElement> = useRef(null);

  useEffect(() => {
    if (debouncedValue !== "" && orderBrowseDetail && orderBrowseDetail?.length) {
      let found;
      found = [...orderBrowseDetail]
        .filter((element) =>
          debouncedValue
            ? element[filters?.sequenceValue!].toString()?.toUpperCase()?.startsWith(debouncedValue!)
            : false
        )
        .at(0);

      if (found && found !== undefined) setSelectRow(found);

      if (found === undefined) {
        found = findNearest(
          [...orderBrowseDetail],
          [{ fieldName: filters?.sequenceValue!, searchValue: debouncedValue.charAt(0) }],
          true
        );
        setSelectRow(found);
      }
      const element = document.getElementById(`rowIndex-invoiceOrderBrowseModal-${orderBrowseDetail.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [debouncedValue]);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(obActions.setFilters({ lookingFor: value.toUpperCase() }));
  };

  const handleSequenceChange = (value?: string) => {
    columnDef?.map((col, index) => {
      if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });
    setColumn([...columnDef]);
    dispatch(obActions.setColumnDef(columns));
  };

  useEffect(() => {
    handleSequenceChange(filters?.sequenceValue);
  }, [filters?.sequenceValue]);

  // remove supplier column if supplier is truthy
  useEffect(() => {
    if (selectedSupplier) {
      const clone = [...columns];
      clone.splice(1, 1);
      setColumn(clone);
      dispatch(obActions.setColumnDef(clone));
    }
  }, [selectedSupplier]);
  return (
    <>
      <Grid
        className="custom-table"
        align="center"
      >
        <GridItem
          sm={4}
          md={4}
          xl={4}
        >
          <div className="essui-global-typography-default-h2 ml-4">
            <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
            <div className="looking-for">
              <TextInput
                onKeyDown={(event) => {
                  // eslint-disable-next-line
                  if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                    event.preventDefault();
                  }
                }}
                inputRef={inputRef}
                id="looking-for"
                value={filters?.lookingFor}
                onChange={(e) => handleLookingForChange(e)}
                size={TextInputSize.Medium}
              />
            </div>
          </div>
        </GridItem>

        <GridItem
          sm={5}
          md={5}
          xl={5}
        >
          {!selectedSupplier && (
            <div className="essui-global-typography-default-h2">
              <FormLabel>{t("purchaseOrder.sequence")}</FormLabel>
              <div className="essui-textinput sequence">
                {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                  const sequenceId = `sequence=${index + 1}`;
                  return (
                    <RadioButton
                      label={column.sequenceName ? column.sequenceName : column.headerName}
                      name={column.sequenceName ? column.sequenceName : column.headerName}
                      labelPosition={RadioLabelPosition.Right}
                      value={column.field}
                      onChange={() => {
                        dispatch(
                          obActions.setFilters({
                            sequenceValue: String(column.field),
                            sequenceIndex: String(index),
                            lookingFor: ""
                          })
                        );
                      }}
                      isSelected={filters?.sequenceValue === column.field}
                      key={sequenceId}
                    />
                  );
                })}
              </div>
            </div>
          )}
        </GridItem>
      </Grid>
    </>
  );
};

export default OrderBrowseFilter;
