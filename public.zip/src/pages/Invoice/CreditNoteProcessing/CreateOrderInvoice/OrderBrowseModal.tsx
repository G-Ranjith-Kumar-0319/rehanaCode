import GridTableNew from "@/components/GridTableNew/GridTableNew";
import Modal from "@/components/Modal/Modal";
import { useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { ButtonColor } from "@essnextgen/ui-kit";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { INVOICE_TYPE } from "@/types/UseStateType";
import { getInvoiceOrderBrowse, actions as obActions } from "../../State/OrderBrowse.slice";
import { actions as coActions, getInvoicePrintAndBank } from "../../State/CreateOrderInvoice.slice";
import orderBrowsecolumnDef from "./columnDef";
import OrderBrowseFilter from "./OrderBrowseFilter";

const OrderBrowseModal = ({
  submitOrderNumber,
  setOrderBrowseModal,
  orderBrowseModal,
  setSelectedFromOrder,
  setFinalLineItem,
  setPrintAlert,
  isViewPageLoading
}: any) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    orderBrowseDetail = [],
    filters,
    columnDef,
    orderIdFromSupplier
  } = useAppSelector((state) => state.orderBrowse);
  const [selectedRow, setSelectRow] = useState<any>(orderBrowseDetail?.at(0));
  const { selectedSupplier } = useAppSelector((state) => state.selectedSupplier);
  const dispatch = useDispatch();
  const currentInvoiceType = sessionStorage.getItem("invoiceType");

  useEffect(() => {
    const { field } = orderBrowsecolumnDef.filter((col) => !!col.sequence)[0];
    dispatch(obActions.setFilters({ sequenceValue: field }));
  }, []);

  useEffect(() => {
    if (currentInvoiceType === INVOICE_TYPE?.ORDERINV && !orderIdFromSupplier) {
      dispatch(getInvoiceOrderBrowse(selectedSupplier?.client_id || null));
    }
  }, [filters?.sequenceIndex, orderBrowseModal, selectedSupplier, orderIdFromSupplier]);

  const lookingForChangeHandler = (value: string) => {
    dispatch(obActions.setFilters({ lookingFor: value }));
  };
  const closeModal = () => {
    setOrderBrowseModal(false);
    lookingForChangeHandler("");
  };

  const onLookupChange = async () => {
    setSelectedFromOrder(true);
    closeModal();
    dispatch(coActions.setOrderSelectedRow(selectedRow));
    submitOrderNumber(selectedRow);

    if (Array.isArray(orderBrowseDetail) && orderBrowseDetail.length > 1) {
      const res: any = await dispatch(getInvoicePrintAndBank(selectedRow?.id));
      if (res?.payload?.no_prints === 0) {
        setPrintAlert(true);
      }
    }
  };

  useEffect(() => {
    if (!orderBrowseModal) {
      setSelectRow(null);
    }
  }, [orderBrowseModal]);

  return (
    <>
      <Modal
        header={t("Order Browse")}
        isOpen={orderBrowseModal}
        tertiaryBtnClick={() => {
          closeModal();
        }}
        secondaryBtnText={t("common.select")}
        secondaryBtnType={ButtonColor.Primary}
        secondaryBtnClick={() => {
          lookingForChangeHandler("");
          onLookupChange();
        }}
        fourthiaryBtnClick={() => {}}
      >
        <GridTableNew
          filters={<OrderBrowseFilter setSelectRow={setSelectRow} />}
          dataSource={orderBrowseDetail}
          selectedRow={selectedRow}
          isLoading={false}
          columnDef={columnDef}
          dataTestId="invoiceOrderBrowseModal"
          selectedRowHandler={(row) => {
            setSelectRow(row);
          }}
          isScrollable
          enableScrollIntoView
          onEnterKeyPress={() => {
            closeModal();
            dispatch(coActions.setOrderSelectedRow(selectedRow));
          }}
        />
      </Modal>
    </>
  );
};

export default OrderBrowseModal;
