import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useState } from "react";
import OrderBrowseModal from "./OrderBrowseModal";

const CreateOrderInvoice = () => <></>;

export default CreateOrderInvoice;
