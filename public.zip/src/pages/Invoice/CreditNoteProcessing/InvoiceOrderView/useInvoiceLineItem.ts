import { getVatLedgerinfo } from "@/shared/components/VatCodesModal/state/VatCodes.slice";
import { AppDispatch, useAppSelector } from "@/store/store";
import { INVOICE_LINE_TYPE, invoiceLineType, invoiceLineTypes } from "@/types/UseStateType";
import { useDispatch } from "react-redux";
import { useHistory, useLocation, useParams } from "react-router-dom";

const useInvoiceLineItem = () => {
  let combineArray: any = [];
  const { invoiceId } = useParams<{ orderno: string; invoiceId: any }>();
  const history = useHistory<any>();
  const { invoiceLineList = [], vatDeletedList: previousDeletedList } = history?.location?.state || {};
  const vatDeletedList: Number[] = previousDeletedList || [];
  const { invoiceNoteLineItem } = useAppSelector((state) => state.invoiceNoteLineItem);
  const dispatch = useDispatch<AppDispatch>();

  const isVatUsed = (oldVatId: number) =>
    combineArray?.some((t: any) => t?.vat_id && Number(t?.vat_id === oldVatId) && t?.line_cost !== 0);

  const updateOldVatValues = (newVatId: any, oldVatId: any, oldVatAmt: any, newLineCost: any, oldVatInfo: any) => {
    let newVatRate;
    let newVatAmt = 0;
    let newVatLineCost = 0;
    const oldVatData: any = oldVatInfo?.at(0) ?? {};
    if (oldVatId !== 0) {
      if (newVatId !== 0 && newLineCost !== 0) {
        newVatRate = oldVatData?.rate;
        newVatAmt = Number(newLineCost / 100) * newVatRate;
      }
      if (oldVatData) {
        const ledgerId = oldVatData?.vat_ledger_id;

        const updateOldVatRow = () => {
          const foundItemAndIndex = combineArray
            ?.map((item: any, index: number) => {
              if (item?.ledger_id === ledgerId && item?.line_type === invoiceLineTypes?.LINETYPEV) {
                return { ...item, index };
              }
              return undefined;
            })
            .filter((t: any) => t)
            ?.at(0);
          if (foundItemAndIndex) {
            if (oldVatId === newVatId) {
              newVatLineCost = Number(foundItemAndIndex?.line_cost - oldVatAmt + newVatAmt);
            } else {
              newVatLineCost = Number(foundItemAndIndex?.line_cost - oldVatAmt);
            }
            if (newVatLineCost <= 0) {
              newVatLineCost = newVatAmt;
            }
            const temp: any = combineArray;
            if (isVatUsed(oldVatId)) {
              temp[foundItemAndIndex?.index] = { ...temp[foundItemAndIndex?.index], line_cost: newVatLineCost };
            } else {
              if (foundItemAndIndex?.invoice_line_id) vatDeletedList.push(foundItemAndIndex?.invoice_line_id);
              temp?.splice(foundItemAndIndex?.index, 1);
            }
            const tempHistory = history?.location?.state;
            const filterHistory = tempHistory?.invoiceLineList.filter(
              (val: any) => val.line_type !== invoiceLineType.strVatLine
            );
            const filteredTemp = temp?.filter((val: any) => val.line_type === invoiceLineType.strVatLine);
            combineArray = [...filterHistory, ...filteredTemp];
            history.replace({
              ...history.location,
              state: {
                ...(history.location.state as any),
                invoiceLineList: combineArray
              }
            });
          }
        };
        updateOldVatRow();
      }
    }
  };

  const updaNewVatValues = (newVatId: any, oldVatId: any, newLineCost: any, oldVatInfo: any) => {
    let newVatAmt = 0;
    let newVatRate = 0;
    let newVatLineCost = 0;
    let newlineVatAmt = 0;
    const vatData: any = oldVatInfo?.at(0);
    if (newVatId !== 0) {
      if (newLineCost !== 0) {
        newVatRate = vatData?.rate;
        newVatAmt = Number(newLineCost / 100) * newVatRate;
      }
      if (vatData) {
        const ledgerId = vatData?.vat_ledger_id;
        const updateNewVatRow = async () => {
          const tempHistory = history?.location?.state;
          const foundItemAndIndex = combineArray
            ?.map((item: any, index: number) => {
              if (item?.ledger_id === ledgerId && item?.line_type === invoiceLineTypes?.LINETYPEV) {
                return { ...item, index };
              }
              return undefined;
            })
            .filter((t: any) => t)
            ?.at(0);

          if (foundItemAndIndex) {
            if (oldVatId !== newVatId) {
              newVatLineCost = Number(foundItemAndIndex?.line_cost + newVatAmt);
              const temp = [...combineArray];
              temp[foundItemAndIndex?.index] = { ...temp[foundItemAndIndex?.index], line_cost: newVatLineCost };
              combineArray = temp;
              history.replace({
                ...history.location,
                state: {
                  ...(history.location.state as any),
                  invoiceLineList: combineArray
                }
              });
            }
          } else {
            // Insert new vat line
            newlineVatAmt = Number(newLineCost / 100) * vatData.rate;
            if (newlineVatAmt !== 0) {
              const insertNewItem: any = {
                invoice_id: invoiceId || null,
                line_cost: newlineVatAmt,
                line_type: invoiceLineTypes?.LINETYPEV,
                type: invoiceLineTypes?.LINETYPEV,
                ledger_id: vatData?.vat_ledger_id,
                at_calc_item_des: vatData?.ledger_des,
                rate: newVatRate,
                ledger_code: vatData?.ledger_code,
                ledger_des: vatData?.ledger_des,
                at_Full_ledger: `(${vatData?.ledger_code})  ${vatData?.ledger_des}`
              };

              const filterHistory = tempHistory?.invoiceLineList.filter(
                (val: any) => val.line_type === invoiceLineType.strInvoiceLine
              );
              filterHistory.push(insertNewItem);
              if (filterHistory.length > 0) {
                combineArray = [...filterHistory];
              }
              history.replace({
                ...history.location,
                state: {
                  ...(history.location.state as any),
                  invoiceLineList: combineArray
                }
              });
            }
          }
        };
        updateNewVatRow();
      }
    }
  };

  const getNewOldVatValues = async (data: any) => {
    let oldVatId = 0;
    let oldVatAmt = 0;
    let newVatId = 0;
    let newLineCost = 0;
    combineArray = [...history.location.state.invoiceLineList];
    const ledgerVatData: any = await dispatch(getVatLedgerinfo({ vatId: data?.vat_id }));
    const oldVatInfo = ledgerVatData.payload;
    if (ledgerVatData?.payload?.length > 0) {
      if (data.lineTypeVal === INVOICE_LINE_TYPE?.DTVAT) {
        oldVatId = 0;
        oldVatAmt = 0;
      } else {
        const vatRate = oldVatInfo && oldVatInfo?.at(0)?.rate;
        oldVatId = data?.vat_id;
        oldVatAmt = Number(data?.old_line_cost / 100) * vatRate;
      }
      if (data.lineTypeVal !== INVOICE_LINE_TYPE.DTVAT) {
        newVatId = data?.vat_id;
        newLineCost = data?.line_cost;
      }
      if (data.lineTypeVal !== INVOICE_LINE_TYPE?.DTVAT) {
        updateOldVatValues(newVatId, oldVatId, oldVatAmt, newLineCost, oldVatInfo);
        updaNewVatValues(newVatId, oldVatId, newLineCost, oldVatInfo);
      }
    }
  };

  return {
    getNewOldVatValues
  };
};

export default useInvoiceLineItem;
