import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  CheckBox,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  Loader,
  LoaderType,
  Notification,
  NotificationStatus,
  Orientation,
  TextInput,
  Textarea,
  Tooltip,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import "./Style.scss";
import { useHistory, useLocation, useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { AppDispatch, useAppSelector } from "@/store/store";
import UseStateType, {
  BOOLEAN_DATA,
  INVOICE_LINE_TYPE,
  INVOICE_TYPE,
  KEYBOARD_STRING,
  METHOD,
  MODULE_TYPE,
  STATUS,
  invoiceLineType,
  invoiceLineTypes,
  invoiceTypesName,
  specialCharacters
} from "@/types/UseStateType";
import { useDispatch, useSelector } from "react-redux";
import {
  actions as costActions,
  getAdjustmentAmt,
  getCostCentersBalanceAdg,
  getCostCentersBudget
} from "@/shared/components/CostCenterModal/state/costCenters.slice";
import { actions as ledgerActions } from "@/shared/components/LedgerCodesModal/state/LedgerCodes.slice";
import { actions as fundActions } from "@/shared/components/FundCodesModal/state/FundCodes.slice";
import {
  getLedgerIdDetails,
  getLedgerIdDetailsForServiceCheck,
  getVatLedgerinfo,
  actions as vatActions
} from "@/shared/components/VatCodesModal/state/VatCodes.slice";
import { useCallback, useContext, useEffect, useLayoutEffect, useRef, useState } from "react";
import { calculateVatLineAmount, getSessionItem, setToSession, usNumberFormat } from "@/utils/getDataSource";
import {
  actions,
  getInvoiceLedgerType,
  getVatLedger,
  getVatRate,
  invoicePartsCheck,
  actions as ioLineActions
} from "@/pages/Invoice/State/InvoiceNoteLineItem.slice";
import { actions as ioNoteListActions } from "@/pages/Invoice/State/InvoiceNoteList.slice";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import NumberInput from "@/components/NumberInput/NumberInput";
import InvoiceCostCentersModal from "@/shared/components/CostCenterModal/InvoiceCostCenterModal";
import InvoiceLedgerCodesModal from "@/shared/components/LedgerCodesModal/InvoiceLedgerCodesModal";
import InvoiceFundCodesModal from "@/shared/components/FundCodesModal/InvoicefundCodesModal";
import InvoiceVatCodesModal from "@/shared/components/VatCodesModal/InvoiceVatCodesModal";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { RootContext, useAppContext } from "@/routes/Routes";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import useDebounce from "@/hooks/useDebounce";
import { METHODS } from "http";
import { isArrayLength } from "@/pages/GeneralLedgerSetup/ProfileModels/utils";

/* eslint-disable camelcase */
type FormData = {
  adding: string;
  invoice_id: number;
  ledger_id: string;
  cost_id: string;
  line_cost: string;
  vat_id: string;
  line_type: string;
  narrative: string;
  qty_inv: string;
  order_line_qty_inv: 0;
  discount: string;
  order_line_id: string;
  invoice_line_id: string;
  services: string;
  reconcile_edit_invoice_id: string;
  inv_last_update: string;
  ord_last_update: string;
  part_no: string;
  inv_item_desc: string;
  inv_Line_Ref: string;
  leddef_id: string;
  fund_id: string;
  cost_code: string;
  ledger_code: string;
  fund_code: string;
  cost_des: string;
  combination: string;
  ledger_des: string;
  fund_des: string;
  vat_code: string;
  vat_des: string;
  inv_line_number: string;
  item_des: string;
  inv_unit_cost: number | string;
};

const InvoiceLineItem = () => {
  const location = useLocation();
  const { invoiceId, method, lineTypeVal, orderno }: any = location.state || {};
  const removedItem = invoiceId ? "/add/add-item" : "/line-item";
  let removedItemEdit = invoiceId ? "/add/edit-item" : "/edit-line-item";
  if (invoiceId && lineTypeVal === INVOICE_LINE_TYPE.DTPOSTANDPACKING && method === METHOD.ADD) {
    removedItemEdit = "/add/add-post-packing";
  } else if (!invoiceId && lineTypeVal === INVOICE_LINE_TYPE.DTPOSTANDPACKING && method === METHOD.ADD) {
    removedItemEdit = "/post-packing";
  } else if (!invoiceId && lineTypeVal === INVOICE_LINE_TYPE.DTPOSTANDPACKING && method === METHOD.EDIT) {
    removedItemEdit = "/edit-post-packing";
  } else if (invoiceId && lineTypeVal === INVOICE_LINE_TYPE.DTPOSTANDPACKING && method === METHOD.EDIT) {
    removedItemEdit = "/add/edit-post-packing";
  }
  const currLocation = location?.pathname.replace(removedItem, "");
  const currLocationEdit = location?.pathname.replace(removedItemEdit, "");
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { costCenters, selectedCostCentre, budgetCombination, budgetCostCentre, adjustmentAmt } = useAppSelector(
    (state) => state.costCenters
  );
  const { isFreeText } = useAppSelector((state) => state.invoiceNoteLineItem);

  const { status: ledgerCodeStatus, ledgerCodes, selectedLedgerCode } = useAppSelector((state) => state.ledgerCodes);
  const history = useHistory<any>();
  const {
    invoiceLineList = [],
    selectedIndex,
    invoiceDetails,
    vatDeletedList: previousDeletedList
  } = history?.location?.state || {};
  const currentInvoiceType = sessionStorage.getItem("invoiceType");
  const { status: fundCodeStatus, fundCodes, selectedfundCode } = useAppSelector((state) => state.fundCodes);
  const {
    vatCodes = [],
    selectedVatCode,
    vatInfo,
    ledgerDetails,
    defaultVatStatus,
    defaultVatCode
  } = useAppSelector((state: any) => state.vatCodes);
  const dispatch = useDispatch<AppDispatch>();
  const [isOpenCostCenterModal, setIsOpenCostCenterModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isOpenLedgerCodesModal, setIsOpenLedgerCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isOpenFundCodesModal, setIsOpenFundCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [isOpenVatCodesModal, setIsOpenVatCodesModal]: UseStateType<boolean> = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const [isOpenAlert, setIsOpenAlert] = useState<boolean>(false);
  const [outStandingAmt, setOutStandingAmt] = useState<any>("0.00");
  const [quantiyOutStanding, setQuantityOutStanding] = useState("0");
  const { selectedValue } = useAppSelector((state) => state.invoicePaymentFrom);
  let combineArray: any = [];
  const vatDeletedList: Number[] = previousDeletedList || [];
  const { setPromise } = useAppContext();
  const { selectedRow } = useAppSelector((state) => state.invoiceNoteLineItem);
  const { lineParts } = useAppSelector((state) => state.invoiceNote);
  const [oldVatInfo, setOldVatInfo] = useState<any>([]);
  const lineListLength = invoiceLineList?.filter((t: any) => t?.line_type === invoiceLineType?.strInvoiceLine).length;
  const [pageLineCount, setPageLineCount] = useState<number>(selectedIndex + 1 || lineListLength + 1);
  const [isServiceChecked, setServiceChecked] = useState<any>(false);
  const [suggestedLedgerRow, setSuggestedLedgerRow] = useState<any>(null);
  const [serviceBoxToggle, setServiceBoxToggle] = useState(false);
  const [isNextLineClicked, setNextLineClicked] = useState<boolean>(false);
  const [suggestedCostRow, setSuggestedCostRow] = useState<any>(null);
  // Selected row accordingly
  const selectedRowData = selectedRow || invoiceLineList[selectedIndex];
  let ttInvLedgerCost: any;
  let ttInvLedgerFund: any;
  let ttLedgerLedger: any;
  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    watch,
    reset,
    formState: { errors, isDirty, dirtyFields },
    getValues
  } = useForm<FormData>({
    defaultValues: {
      adding: "T",
      line_cost: "0.00",
      line_type: "",
      item_des: "",
      cost_des: "",
      ledger_des: "",
      fund_des: "",
      vat_des: "",
      invoice_id: 0,
      narrative: "",
      qty_inv: "0",
      order_line_qty_inv: 0,
      discount: "0.00",
      order_line_id: "",
      invoice_line_id: "",
      services: "",
      reconcile_edit_invoice_id: "",
      inv_last_update: "",
      ord_last_update: "",
      part_no: "",
      inv_item_desc: "",
      inv_Line_Ref: "",
      leddef_id: "",
      cost_code: "",
      ledger_code: "",
      fund_code: "",
      inv_line_number: "",
      inv_unit_cost: "0.00"
    }
  });
  // Clear form on unmount
  useEffect(
    () => () => {
      dispatch(costActions.selectRow(undefined));
      dispatch(ledgerActions.selectRowLedgerCode(undefined));
      dispatch(vatActions.selectVatCodeForInvoice(undefined));
      dispatch(fundActions.selectRow(undefined));
      dispatch(costActions.reset());
      dispatch(costActions.resetCostCombination());
      dispatch(ledgerActions.reset());
      reset();
      setValue("cost_code", "");
      setValue("ledger_code", "");
      setValue("fund_code", "");
      setValue("vat_code", "");
      setValue("item_des", "");
      setValue("vat_des", "");
    },
    []
  );
  const disableFieldOnQTYChange = () => {
    if (lineTypeVal === INVOICE_LINE_TYPE?.DTORDERINV) {
      if (+watch("qty_inv") <= 0 || !isQuantityValid()) {
        return true;
      }
    }
    return false;
  };
  const firstLoad = useRef(true);
  const disableCostLedgerFund = () => {
    if (firstLoad.current) {
      return false;
    }
    if (lineTypeVal === INVOICE_LINE_TYPE?.DTORDERINV) {
      if (+watch("qty_inv") <= 0 || !isQuantityValid()) {
        return true;
      }
    }
    return false;
  };

  const watchedQtyInvoiced = watch("qty_inv");
  useEffect(() => {
    const quantity: any =
      selectedRowData?.base_qty_out - Number(watchedQtyInvoiced) > 0
        ? selectedRowData?.base_qty_out - Number(watchedQtyInvoiced)
        : 0;
    setQuantityOutStanding(quantity);
    calculate();
  }, [watchedQtyInvoiced, selectedRowData, quantiyOutStanding]);

  const calculationOutStantingAmt = () => {
    const basRemainAmt = Number(selectedRowData?.base_free_text_remaining_amt);
    const lineCost = Number(watch("line_cost"));
    if (lineCost <= basRemainAmt) setOutStandingAmt(basRemainAmt - lineCost);
    else setOutStandingAmt(0.0);
  };

  useEffect(() => {
    calculationOutStantingAmt();
  }, [+watch("line_cost"), selectedRowData]);

  const calculate = () => {
    const qtyInvoiced = Number(watchedQtyInvoiced);

    const unitCost = Number(watch("inv_unit_cost"));
    const discount = Number(watch("discount")) / 100;

    const lineCost = qtyInvoiced * unitCost;
    const discountedAmt = lineCost * discount;
    const finalLineCost = lineCost - discountedAmt;
    // typeof finalLineCost === "number" ? finalLineCost?.toFixed(2) : finalLineCost;
    setValue("line_cost", finalLineCost?.toFixed(2));
  };

  const calculateUnitCost = () => {
    const discount = Number(watch("discount")) / 100;
    const unitCost = Number(watch("line_cost")) / (1 - discount);
    setValue("inv_unit_cost", unitCost.toFixed(2));
  };

  // Manage nextline state on is dirty state for cancel btn
  useEffect(() => {
    if (isDirty) {
      setNextLineClicked(false);
    }
  }, [isDirty]);
  const closeHandler = async (type?: string) => {
    if (type === "cancel") {
      let result;
      if (!isNextLineClicked) {
        if (method === METHOD.ADD || isDirty) {
          result = await setPromise(() => checkSaveChanges());
          if (result === undefined) {
            return;
          }
          if (result) {
            onSubmit();
            return;
          }
        }
      }
      if (lineTypeVal === INVOICE_LINE_TYPE?.DTPOSTANDPACKING) {
        history.push(currLocationEdit, {
          ...(history.location.state as any)
        });
      } else {
        history.push(method === METHOD.ADD ? `${currLocation}` : `${currLocationEdit}`, {
          ...(history.location.state as any)
        });
      }
    } else {
      history.replace({ ...history.location, state: updateAndGetHisory() });
      const currentValues = getValues();
      reset(currentValues, {
        keepDirty: false // Reset dirty state
      });
      setValue("line_cost", "");
      setValue("item_des", "");
      setValue("narrative", "");
    }
  };

  const checkSaveChanges = () => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: "invalidData"
      })
    );
  };

  useEffect(() => {
    if (selectedCostCentre !== undefined) {
      setValue("cost_code", selectedCostCentre?.code);
      setValue("cost_des", selectedCostCentre?.description);
      trigger("cost_code");
      trigger("cost_des");
      dispatch(getCostCentersBudget({ costId: selectedCostCentre?.id, balanceAdjustment: 0 }));
      // resetLedgerAndFundData();
    }
  }, [selectedCostCentre]);

  const getOldVatInfo = async () => {
    const data: any = await dispatch(getVatLedgerinfo({ vatId: selectedRowData?.vat_id }));
    if (data?.payload) {
      setOldVatInfo(data?.payload);
    }
  };
  useEffect(() => {
    if (method === METHOD?.EDIT) {
      getOldVatInfo();
    }
  }, []);

  const isBSLedgerType = (sLedgerType: string) => {
    if (
      sLedgerType === invoiceLineTypes.LINETYPEAO ||
      sLedgerType === invoiceLineTypes.LINETYPELS ||
      sLedgerType === invoiceLineTypes.LINETYPECP ||
      sLedgerType === invoiceLineTypes.LINETYPEPY
    ) {
      return true;
    }
    return false;
  };
  const fbCentralBank = (data: any) => {
    if (data && data.centrally_processed === BOOLEAN_DATA?.True) {
      return true;
    }
    return false;
  };

  const getLedType = (l_str_LedDef: string, l_str_LedType: string, bServices: boolean, LedFund: any) => {
    let sLedDefId: any = 0;
    switch (LedFund) {
      case ttInvLedgerCost:
        sLedDefId = "";
        break;
      case ttInvLedgerFund:
        sLedDefId = selectedLedgerCode?.id;
        break;
      case ttLedgerLedger:
        if (l_str_LedDef === "") {
          sLedDefId = selectedLedgerCode?.id;
        } else {
          sLedDefId = l_str_LedDef;
        }
        break;
      default:
    }
    dispatch(
      getInvoiceLedgerType({
        leddefId: sLedDefId,
        callback: (res: any) => {
          l_str_LedType = res?.ledger_type;
          bServices = res?.services;
          if (
            isBSLedgerType(l_str_LedType) &&
            fbCentralBank(selectedValue) &&
            lineTypeVal !== INVOICE_LINE_TYPE.DTORDERINV
          ) {
            setMessage(t("invoiceNote.paidInvoiceError"));
            setIsOpenAlert(true);
            return false;
          }
          if (isBSLedgerType(l_str_LedType) && lineTypeVal === INVOICE_LINE_TYPE.DTORDERINV) {
            setMessage(t("invoiceNote.orderBaseInvoiceError"));
            setIsOpenAlert(true);
            return false;
          }
          if (isBSLedgerType(l_str_LedType) && lineTypeVal === INVOICE_LINE_TYPE.DTFREETEXTINV) {
            setMessage(t("invoiceNote.freeTextInvoiceError"));
            setIsOpenAlert(true);
            return false;
          }
          if (isBSLedgerType(l_str_LedType) && lineTypeVal === INVOICE_LINE_TYPE.DTFREETEXTINV) {
            setMessage(t("invoiceNote.orderBaseInvoiceError"));
            setIsOpenAlert(true);
            return false;
          }
          return true;
        }
      })
    );

    return true;
  };

  const checkBSCentralBank = () => {
    const bServices: boolean = true;
    const l_str_LedType: string = "";
    const valid = getLedType("", l_str_LedType, bServices, ttInvLedgerFund);
    if (valid) {
      return true;
    }
    return false;
  };

  const createPartData = () => {
    const selectedIndex = lineParts.findIndex((part) => part?.part_no === selectedRowData?.part_no);
    if (selectedIndex !== -1) {
      const tempLineParts = [...lineParts];
      tempLineParts[selectedIndex] = { ...tempLineParts[selectedIndex], cost: watch("inv_unit_cost") };
      dispatch(ioNoteListActions.setLineParts(tempLineParts));
    } else {
      dispatch(
        ioNoteListActions.setLineParts([
          ...lineParts,
          { clientId: invoiceDetails?.client_id, partNo: selectedRowData.part_no, cost: watch("inv_unit_cost") }
        ])
      );
    }
  };

  const onModalSubmit = (number: number) => {
    dispatch(ioLineActions.setFreeText(number));
    onSubmit();
  };

  const validateUnitCostChange = () => {
    // This conditions should be commented once it is clear
    const isNetAmountNotZero = +watch("line_cost") !== 0;
    if (
      lineTypeVal === INVOICE_LINE_TYPE?.DTFREETEXTINV &&
      selectedRowData?.order_line_qty_inv !== 1 &&
      isNetAmountNotZero
    ) {
      dispatch(
        uiActions.confirmPopup({
          title: t("alertMessage.title"),
          message: t("creatOrderInvoice.freeTextAlertMessage"),
          yesCallback: () => {
            onModalSubmit(1);
          },
          noCallback: () => {
            onModalSubmit(0);
          },
          type: MODAL_TYPE.CONFIRMV2,
          isCancelBtnEnable: false
        })
      );
    } else if (
      selectedRowData?.part_no &&
      lineTypeVal === INVOICE_LINE_TYPE.DTORDERINV &&
      watch("inv_unit_cost") !== selectedRowData?.inv_unit_cost
    ) {
      dispatch(
        invoicePartsCheck({
          clientId: invoiceDetails?.client_id,
          partNo: selectedRowData.part_no,
          cost: Number(watch("inv_unit_cost")),
          callback(data) {
            if (data === BOOLEAN_DATA.True) {
              dispatch(
                uiActions.confirmPopup({
                  title: t("alertMessage.title"),
                  message: t("creatOrderInvoice.unitCostChangeMsg"),
                  yesCallback: () => {
                    createPartData();
                    onSubmit();
                  },
                  noCallback: () => {
                    onSubmit();
                  },
                  type: MODAL_TYPE.CONFIRMV2,
                  isCancelBtnEnable: false
                })
              );
            } else {
              onSubmit();
            }
          }
        })
      );
    } else {
      onSubmit();
    }
  };

  const validateLine = (data: any) => {
    let valid: boolean = false;
    if (data) {
      valid = checkBSCentralBank();
      if (valid) {
        if (lineTypeVal === INVOICE_LINE_TYPE.DTORDERINV) {
          // write validation for order line
        }
        return valid;
      }
      return valid;
    }
    return valid;
  };

  const isVatUsed = (oldVatId: number) =>
    combineArray?.some((t: any) => t?.vat_id && Number(t?.vat_id === oldVatId) && t?.line_cost > 0);

  const updaNewVatValues = (newVatId: any, oldVatId: any, newLineCost: any) => {
    let newVatAmt = 0;
    let newVatRate = 0;
    let newVatLineCost = 0;
    let newlineVatAmt = 0;
    const vatData: any = vatInfo?.at(0);
    if (newVatId !== 0) {
      if (newLineCost !== 0) {
        newVatRate = vatData?.rate;
        newVatAmt = Number(newLineCost / 100) * newVatRate;
      }
      if (vatData) {
        const ledgerId = vatData?.vat_ledger_id;
        const updateNewVatRow = async () => {
          const foundItemAndIndex = combineArray
            ?.map((item: any, index: number) => {
              if (item?.ledger_id === ledgerId && item?.line_type === invoiceLineTypes?.LINETYPEV) {
                return { ...item, index };
              }
              return undefined;
            })
            .filter((t: any) => t)
            ?.at(0);

          if (foundItemAndIndex) {
            if (oldVatId !== newVatId) {
              newVatLineCost = Number(foundItemAndIndex?.line_cost + newVatAmt);
              const temp = [...combineArray];
              temp[foundItemAndIndex?.index] = { ...temp[foundItemAndIndex?.index], line_cost: newVatLineCost };
              combineArray = temp;
            }
          } else {
            // Insert new vat line
            newlineVatAmt = Number(newLineCost / 100) * vatData.rate;
            if (newlineVatAmt !== 0) {
              const insertNewItem: any = {
                invoice_id: invoiceId || null,
                line_cost: newlineVatAmt,
                line_type: invoiceLineTypes?.LINETYPEV,
                type: invoiceLineTypes?.LINETYPEV,
                ledger_id: vatData?.vat_ledger_id,
                at_calc_item_des: vatData?.ledger_des,
                rate: newVatRate,
                ledger_code: vatData?.ledger_code,
                ledger_des: vatData?.ledger_des,
                at_Full_ledger: `(${vatData?.ledger_code})  ${vatData?.ledger_des}`
              };
              combineArray.push(insertNewItem);
            }
          }
        };
        updateNewVatRow();
      }
    }
  };
  const updateOldVatValues = (newVatId: any, oldVatId: any, oldVatAmt: any, newLineCost: any) => {
    let newVatRate;
    let newVatAmt = 0;
    let newVatLineCost = 0;
    const oldVatData: any = oldVatInfo?.at(0) ?? {};
    if (oldVatId !== 0) {
      if (newVatId !== 0 && newLineCost !== 0) {
        newVatRate = oldVatData?.rate;
        newVatAmt = Number(newLineCost / 100) * newVatRate;
      }
      if (oldVatData) {
        const ledgerId = oldVatData?.vat_ledger_id;

        const updateOldVatRow = () => {
          const foundItemAndIndex = combineArray
            ?.map((item: any, index: number) => {
              if (item?.ledger_id === ledgerId && item?.line_type === invoiceLineTypes?.LINETYPEV) {
                return { ...item, index };
              }
              return undefined;
            })
            .filter((t: any) => t)
            ?.at(0);
          if (foundItemAndIndex) {
            if (oldVatId === newVatId) {
              newVatLineCost = Number(foundItemAndIndex?.line_cost - oldVatAmt + newVatAmt);
            } else {
              newVatLineCost = Number(foundItemAndIndex?.line_cost - oldVatAmt);
            }
            if (newVatLineCost <= 0) {
              newVatLineCost = newVatAmt;
            }
            const temp: any = combineArray;
            if (isVatUsed(oldVatId)) {
              temp[foundItemAndIndex?.index] = { ...temp[foundItemAndIndex?.index], line_cost: newVatLineCost };
            } else {
              if (foundItemAndIndex?.invoice_line_id) vatDeletedList.push(foundItemAndIndex?.invoice_line_id);
              temp?.splice(foundItemAndIndex?.index, 1);
            }
            combineArray = temp;
          }
        };
        updateOldVatRow();
      }
    }
  };

  function findLastIndexOfType(data: any, targetType: string) {
    // Filter the list to get all elements of the target type
    const filteredData = data?.filter((item: any) => item.line_type === targetType && !item?.inv_line_number);
    // Find the last element of the filtered list
    if (isArrayLength(filteredData)) {
      const lastElement = filteredData[filteredData.length - 1];
      // Return the index of the last element in the original list
      return data?.lastIndexOf(lastElement);
    }
    return -1;
  }

  // Main Submit function
  const getNewOldVatValues = (data: any) => {
    let oldVatId = 0;
    let oldVatAmt = 0;
    let newVatId = 0;
    let newLineCost = 0;

    if (method === METHOD?.ADD || lineTypeVal === INVOICE_LINE_TYPE?.DTVAT) {
      oldVatId = 0;
      oldVatAmt = 0;
    } else {
      const vatRate = oldVatInfo && oldVatInfo?.at(0)?.rate;
      oldVatId = selectedRowData?.vat_id;
      oldVatAmt = Number(selectedRowData?.line_cost / 100) * vatRate;
    }
    if (lineTypeVal !== INVOICE_LINE_TYPE.DTVAT && method !== METHOD?.DELETE) {
      newVatId = data?.vat_id;
      newLineCost = data?.line_cost;
    }
    if (lineTypeVal !== INVOICE_LINE_TYPE?.DTVAT) {
      updateOldVatValues(newVatId, oldVatId, oldVatAmt, newLineCost);
      updaNewVatValues(newVatId, oldVatId, newLineCost);
    }
  };
  const isQuantityValid = () => {
    if (lineTypeVal === INVOICE_LINE_TYPE?.DTORDERINV) {
      return selectedRowData?.base_qty_out - Number(watch("qty_inv")) >= 0;
    }
    return true;
  };
  const handleSubmitData = (formData: any) => {
    if (true) {
      const fullCostCentreVal = `(${formData?.cost_code}) ${formData?.cost_des?.substring(0, 43)}`;
      const fullLedgerValue = `(${formData?.ledger_code}) ${formData?.ledger_des?.substring(0, 43)}`;
      const vatCode = vatInfo?.at(0)?.vat_code;
      const vatRate = vatInfo?.at(0)?.rate;
      const lineCost: any = watch("line_cost");
      const vatAmount = +((lineCost / 100) * vatRate);
      let data: any = {
        ...formData,
        cost_id: selectedCostCentre?.id,
        at_full_cost_centre: fullCostCentreVal,
        leddef_id: selectedLedgerCode?.id,
        ledger_id: ledgerDetails?.ledgerId,
        at_full_ledger: fullLedgerValue,
        fund_id: selectedfundCode?.id,
        vat_id: selectedVatCode?.vat_id,
        inv_unit_cost: null,
        qty_inv: null,
        vat_code: vatCode,
        rate: vatRate,
        vat_amount: vatAmount,
        discount: formData?.discount ?? "0.00",
        inv_line_number: selectedRowData?.inv_line_number,
        invoice_line_id: selectedRowData?.invoice_line_id,
        order_line_id: selectedRowData?.order_line_id,
        base_qty_out_with_del: selectedRowData?.base_qty_out_with_del,
        adding: method === METHOD?.ADD ? "T" : "F",
        is_changed: true,
        services: isServiceChecked ? BOOLEAN_DATA?.True : BOOLEAN_DATA?.False
      };

      switch (lineTypeVal) {
        case INVOICE_LINE_TYPE.DTORDERINV:
          data = {
            ...data,
            line_cost: formData?.line_cost,
            vat_id: selectedVatCode?.vat_id,
            discount: formData?.discount,
            inv_unit_cost: formData?.inv_unit_cost ?? 0.0,
            narrative: "",
            qty_out: quantiyOutStanding,
            qty_inv: formData?.qty_inv,
            // type: "",
            line_type: selectedRowData?.line_type,
            order_line_qty_inv: selectedRowData?.order_line_qty_inv,
            part_no: selectedRowData?.part_no,
            at_calc_item_des: selectedRowData?.at_calc_item_des,
            base_qty_out: selectedRowData?.base_qty_out,
            base_free_text_remaining_amt: selectedRowData?.base_free_text_remaining_amt
          };

          break;
        case INVOICE_LINE_TYPE.DTFREETEXTINV:
          data = {
            ...data,
            inv_unit_cost: 0.0,
            line_cost: formData?.line_cost,
            line_type: invoiceLineTypes?.INVOICELINE,
            narrative: "",
            type: selectedRowData?.type,
            discount: formData?.discount,
            vat_amount: Number((selectedRowData?.base_free_text_remaining_amt / 100) * selectedVatCode?.rate),
            order_line_qty_inv: isFreeText,
            free_text_remaining_amt:
              Number(selectedRowData?.base_free_text_remaining_amt) - Number(formData?.line_cost),
            at_calc_item_des: selectedRowData?.at_calc_item_des,
            base_free_text_remaining_amt: selectedRowData?.base_free_text_remaining_amt
          };
          break;
        case INVOICE_LINE_TYPE.DTPOSTANDPACKING:
          data = {
            ...data,
            narrative: "",
            ltem_desc: formData?.item_des,
            at_calc_item_des: "Post & Packing",
            discount: "0.00",
            line_type: invoiceLineTypes?.LINETYPEP
          };

          break;
        case INVOICE_LINE_TYPE.DTNONORDERINV:
          data = {
            ...data,
            narrative: formData.item_des,
            ltem_desc: formData?.item_des,
            at_calc_item_des: "",
            discount: formData?.discount ?? "0.00",
            line_type: invoiceLineTypes?.INVOICELINE
          };
          break;
        default:
          break;
      }
      const clone: any = [...invoiceLineList];
      if (method === METHOD?.EDIT) {
        clone[selectedIndex] = data;
        combineArray = clone;
      } else if (method === METHOD?.ADD) {
        if (invoiceLineList.length > 0) {
          combineArray = clone;
        }
        if (invoiceId) {
          let filtered;
          let lastPPIndex;
          if (lineTypeVal === INVOICE_LINE_TYPE?.DTPOSTANDPACKING) {
            lastPPIndex = findLastIndexOfType(invoiceLineList, invoiceLineTypes?.LINETYPEP);
            if (lastPPIndex !== -1) {
              // Found the index, now push the item after that index
              combineArray.splice(lastPPIndex + 1, 0, data);
            } else {
              combineArray.unshift(data);
            }
          } else {
            filtered = invoiceLineList?.filter(
              (t: any) =>
                t?.line_type !== invoiceLineTypes?.LINETYPEP &&
                t?.line_type !== invoiceLineTypes?.LINETYPEV &&
                !t?.inv_line_number
            );
            if (isArrayLength(filtered)) {
              // Found the index, now push the item after that index
              combineArray.splice(filtered.length, 0, data);
            } else {
              combineArray.unshift(data);
            }
          }
        } else {
          combineArray.push(data);
        }
      }

      // Highlight newly added row on detail page
      dispatch(ioLineActions.setSelectedRow(data));
      //
      getNewOldVatValues(data);
    }
  };

  function arrangeTableList() {
    if (Array.isArray(combineArray) && combineArray.length > 0) {
      const e = combineArray?.filter(
        (t: any) => t?.line_type !== invoiceLineTypes?.LINETYPEP && t?.line_type !== invoiceLineTypes?.LINETYPEV
      );
      const p = combineArray?.filter((t: any) => t?.line_type === invoiceLineTypes?.LINETYPEP);
      const v = combineArray?.filter((t: any) => t?.line_type === invoiceLineTypes?.LINETYPEV);
      return [...e, ...p, ...v];
    }
    return [];
  }

  const updateAndGetHisory = () => ({
    ...(history.location.state as any),
    invoiceId,
    method,
    vatDeletedList: [...vatDeletedList],
    invoiceLineList: [...arrangeTableList()]
  });

  const onSubmit = handleSubmit(
    async (formData) => {
      const isSaveAfterNextLineClick = method === METHOD?.ADD && !isDirty && isNextLineClicked;
      if (!isSaveAfterNextLineClick) {
        handleSubmitData(formData);
        if (lineTypeVal === INVOICE_LINE_TYPE?.DTPOSTANDPACKING) {
          history.push(currLocationEdit, { ...updateAndGetHisory() });
        } else {
          history.push(method === METHOD?.ADD ? `${currLocation}` : `${currLocationEdit}`, { ...updateAndGetHisory() });
        }
      } else {
        history.push(currLocation, { ...(history.location.state as any) });
      }
    },
    (error) => {
      setMessage(t("common.invalidData"));
      setIsOpenAlert(true);
    }
  );
  const onSubmitNext = handleSubmit(
    async (formData) => {
      if (isDirty) {
        handleSubmitData(formData);
        closeHandler("nextLine");
        setPageLineCount((count) => count + 1);
        setNextLineClicked(true);
      }
    },
    (error) => {
      setMessage(t("common.invalidData"));
      setIsOpenAlert(true);
    }
  );

  // Populate Fund and Vat code by selecting Ledger code in orderline
  useEffect(() => {
    if (selectedLedgerCode) {
      setValue("ledger_code", selectedLedgerCode?.code);
      setValue("ledger_des", selectedLedgerCode?.description);
      if (
        fundCodeStatus === STATUS.SUCCESS &&
        Object.keys(fundCodes).length !== 0 &&
        ledgerCodeStatus === STATUS.SUCCESS &&
        fundCodes &&
        fundCodes[0].vat_id !== null
      ) {
        setValue("fund_code", selectedfundCode?.code);
        setValue("fund_des", selectedfundCode?.description);
        trigger("fund_code");
        trigger("fund_des");

        setValue("vat_code", selectedVatCode?.vat_code);
        setValue("vat_des", selectedVatCode?.vat_des);
        // trigger("vat_code");
        // trigger("vat_des");
      }
      if (fundCodes[0]?.combination_balance !== null && fundCodes[0]?.combination_balance !== 0) {
        setValue("combination", usNumberFormat(fundCodes[0]?.combination_balance));
      }
      trigger("combination");
    }
  }, [fundCodeStatus, ledgerCodeStatus]);

  useEffect(() => {
    if (selectedfundCode) {
      setValue("fund_code", selectedfundCode?.code);
      setValue("fund_des", selectedfundCode?.description);
      trigger("fund_code");
      trigger("fund_des");
      dispatch(getLedgerIdDetails({ leddefId: selectedLedgerCode?.id, fundId: selectedfundCode?.id }));
    }
  }, [selectedfundCode]);

  const isFirstTimeLoading = useRef(true);
  // This is only for managing service checkbox on change
  const leddefId = suggestedLedgerRow?.id || selectedLedgerCode?.id;
  const debounceLedgerCode = useDebounce(watch("ledger_code"), 300);
  const handleCheckboxHideShow = useCallback(() => {
    if (debounceLedgerCode) {
      if (leddefId) {
        dispatch(
          getLedgerIdDetailsForServiceCheck({
            leddefId,
            callback(data) {
              const flag = method === METHOD?.EDIT && isFirstTimeLoading.current;
              if (!flag) {
                setServiceChecked(data?.services === BOOLEAN_DATA?.True);
                isFirstTimeLoading.current = false;
              }
              setServiceBoxToggle(
                [
                  invoiceLineTypes.LINETYPEEX,
                  invoiceLineTypes?.LINETYPEAO,
                  invoiceLineTypes?.LINETYPELS,
                  invoiceLineTypes?.LINETYPECP,
                  invoiceLineTypes?.LINETYPEPY
                ]?.includes(data?.ledger_type)
              );
            }
          })
        );
      } else {
        setServiceBoxToggle(false);
      }
    } else {
      setServiceBoxToggle(false);
    }
  }, [leddefId, debounceLedgerCode, isFirstTimeLoading]);

  useEffect(() => {
    handleCheckboxHideShow();
  }, [handleCheckboxHideShow]);

  const handleCostCenterPendingState = useCallback(async () => {
    await dispatch(
      getCostCentersBudget({
        costId: suggestedCostRow?.id,
        balanceAdjustment: 0,
        async callback() {
          await dispatch(
            getCostCentersBalanceAdg({
              costId: suggestedCostRow?.id,
              leddefId: selectedLedgerCode?.id,
              fundId: selectedfundCode?.id,
              adjustment: adjustmentAmt || 0
            })
          );
        }
      })
    );
  }, [selectedCostCentre, suggestedCostRow]);

  useEffect(() => {
    if (!selectedCostCentre) {
      handleCostCenterPendingState();
    }
  }, [handleCostCenterPendingState]);

  // flag to check if vat is there should not orverwrite on edit mode
  const isPrefilledVatRef = useRef(false);
  const manageDefaultVatCode = useCallback(() => {
    // Skip the effect on the first render if in edit mode
    if (!isPrefilledVatRef.current && (method === METHOD.EDIT || (method === METHOD?.ADD && watch("vat_code")))) {
      return;
    }
    const isDefaultVat =
      selectedLedgerCode &&
      defaultVatCode &&
      defaultVatCode > 0 &&
      defaultVatStatus === STATUS.SUCCESS &&
      vatCodes &&
      vatCodes.length > 0;
    if (isDefaultVat) {
      const vatData = vatCodes.find((s: any) => s.vat_id === defaultVatCode);
      setValue("vat_code", vatData?.vat_code);
      setValue("vat_des", vatData?.vat_des);
      dispatch(vatActions.selectVatCodeForInvoice(vatData));
    }
    if (!selectedLedgerCode) {
      dispatch(fundActions.selectRow(undefined));
      setValue("fund_code", "");
      setValue("fund_des", "");
      setValue("vat_code", "");
      setValue("vat_des", "");
      dispatch(vatActions.selectVatCodeForInvoice(undefined));
    }
  }, [selectedLedgerCode, defaultVatStatus, method]);

  useEffect(() => {
    manageDefaultVatCode();
  }, [manageDefaultVatCode]);

  useEffect(() => {
    if (selectedVatCode) {
      setValue("vat_code", selectedVatCode?.vat_code);
      setValue("vat_des", selectedVatCode?.vat_des);
      dispatch(getVatLedgerinfo({ vatId: selectedVatCode.vat_id }));
    }
  }, [selectedVatCode]);

  useEffect(() => {
    if (!watch("cost_code")) {
      dispatch(costActions.selectRow(undefined));
      dispatch(costActions.resetCostCombination());
    }
  }, [watch("cost_code")]);

  useEffect(() => {
    if (selectedCostCentre && selectedLedgerCode && selectedfundCode) {
      dispatch(
        getAdjustmentAmt({
          costId: selectedCostCentre?.id,
          leddefId: selectedLedgerCode?.id,
          fundId: selectedfundCode?.id,
          orderId: "",
          callback(data) {
            dispatch(
              getCostCentersBalanceAdg({
                costId: selectedCostCentre?.id,
                leddefId: selectedLedgerCode?.id,
                fundId: selectedfundCode?.id,
                adjustment: adjustmentAmt || 0
              })
            );
          }
        })
      );
    }
  }, [selectedCostCentre, selectedLedgerCode, selectedfundCode]);

  const costCenterClick = () => {
    setIsOpenCostCenterModal(true);
  };
  const ledgerCodeClick = () => {
    setIsOpenLedgerCodesModal(true);
  };
  const fundCodeClick = () => {
    setIsOpenFundCodesModal(true);
  };
  const vatCodeClick = () => {
    setIsOpenVatCodesModal(true);
  };

  const handlePageTitile = () => {
    if (lineTypeVal === INVOICE_LINE_TYPE.POSTNPAKING) {
      return t("postNpacking.postPackingTitle");
    }
    if (lineTypeVal === INVOICE_LINE_TYPE.FREETEXT) {
      return t("creatOrderInvoice.freeTextOrderLineTitle");
    }
    // Line list length  will be used while adding new line item :)
    return t("invoiceNote.addNonOrder", { selectedIndex: pageLineCount });
  };

  // Don't call this function on first time while edit mode
  const isFirstTimeLedger = useRef(false);
  const handleSelectLedgerManage = useCallback(() => {
    if (!isFirstTimeLedger.current && method === METHOD.EDIT) {
      isFirstTimeLedger.current = true;
      return;
    }
    const notRequire = costCenters?.some((p: any) => selectedCostCentre?.id === p?.id);
    if (!notRequire && Array.isArray(costCenters) && costCenters.length === 1) {
      const row = costCenters?.at(0);
      dispatch(costActions.selectRow(row));
      setValue("cost_code", row?.code);
      setValue("cost_des", row?.description);
    } else if (!notRequire && Array.isArray(costCenters) && costCenters.length > 1) {
      dispatch(costActions.selectRow(undefined));
      setValue("cost_code", "");
      setValue("cost_des", "");
    }
  }, [selectedLedgerCode, selectedCostCentre, costCenters]);

  const [ledgerOnSelectInvoked, setLedgerOnSelectInvoked] = useState<string>("");
  useEffect(() => {
    if (costCenters && !isOpenLedgerCodesModal && ledgerOnSelectInvoked === "invokedBYLedgerOnSelect") {
      handleSelectLedgerManage();
    }
  }, [ledgerOnSelectInvoked, costCenters]);

  useEffect(() => {
    const whichFocus =
      lineTypeVal === INVOICE_LINE_TYPE.POSTNPAKING ||
      lineTypeVal === INVOICE_LINE_TYPE?.DTORDERINV ||
      lineTypeVal === INVOICE_LINE_TYPE?.DTFREETEXTINV;
    if (whichFocus) {
      document.querySelectorAll("input")[0]?.focus();
    } else {
      document.getElementById("itemDesc")?.focus();
    }
    if (!watch("item_des") && !whichFocus) {
      document.getElementById("itemDesc")?.focus();
    }
  }, [watch("item_des")]);

  // Don't call this function on first time while edit mode
  const isFirstTimeCostCenter = useRef(false);
  const handleSelectCostCenterManage = useCallback(() => {
    if (!isFirstTimeCostCenter.current && method === METHOD.EDIT) {
      isFirstTimeCostCenter.current = true;
      return;
    }
    const notRequire = ledgerCodes?.some((p: any) => selectedLedgerCode?.id === p?.id);
    if (!notRequire && selectedCostCentre && Array.isArray(ledgerCodes) && ledgerCodes.length === 1) {
      const row = ledgerCodes?.at(0);
      dispatch(ledgerActions.selectRowLedgerCode(row));
      setValue("ledger_code", row?.code);
      setValue("ledger_des", row?.description);
      trigger("ledger_code");
      trigger("ledger_des");
    } else if (!notRequire && Array.isArray(ledgerCodes) && ledgerCodes.length > 1) {
      dispatch(ledgerActions.selectRowLedgerCode(undefined));
      setValue("ledger_code", "");
      setValue("ledger_des", "");
      dispatch(fundActions.selectRow(undefined));
      setValue("fund_code", "");
      setValue("fund_des", "");
      dispatch(costActions.resetBudgetCombination());
    }
  }, [ledgerCodes, selectedLedgerCode, selectedCostCentre]);

  useEffect(() => {
    handleSelectCostCenterManage();
  }, [handleSelectCostCenterManage]);

  // For prefill form
  const prefillVatCode = (id: number) => {
    const found = vatCodes.find((s: any) => Number(s.vat_id === id));
    if (found && !selectedVatCode) dispatch(vatActions.selectVatCodeForInvoice(found));
  };
  const prefillCostCenter = (id: number) => {
    const found = costCenters.find((s: any) => Number(s.id === id));
    if (found && !selectedCostCentre) dispatch(costActions.selectRow(found));
  };

  const prefillLedgerCode = (id: number) => {
    const found = ledgerCodes.find((s: any) => Number(s.id === id));
    if (found && !selectedLedgerCode) dispatch(ledgerActions.selectRowLedgerCode(found));
  };

  const prefillFundCode = (row: any) => {
    dispatch(fundActions.selectRow(row));
  };

  const hasPrefilled = useRef(false);
  const prefillLineItemData = useCallback(
    (hasPrefilled: any) => {
      if (
        !hasPrefilled.current &&
        selectedRowData &&
        method === METHOD?.EDIT &&
        Array.isArray(vatCodes) &&
        vatCodes.length > 0 &&
        Array.isArray(ledgerCodes) &&
        ledgerCodes.length > 0 &&
        Array.isArray(costCenters) &&
        costCenters.length > 0
      ) {
        if (currentInvoiceType === INVOICE_TYPE.ORDERINV) {
          setValue("item_des", selectedRowData?.item_des);
        } else {
          setValue("item_des", selectedRowData?.narrative);
        }

        setValue("discount", usNumberFormat(selectedRowData?.discount));
        setValue(
          "services",
          selectedRowData?.services === BOOLEAN_DATA?.True ? BOOLEAN_DATA?.True : BOOLEAN_DATA?.False
        );
        // check checkbox while edit mode
        setServiceChecked(selectedRowData?.services === BOOLEAN_DATA?.True);
        //
        setValue("line_cost", Number(selectedRowData?.line_cost).toFixed(2));
        setOutStandingAmt(selectedRowData?.free_text_remaining_amt);
        prefillCostCenter(selectedRowData?.cost_id);
        prefillLedgerCode(selectedRowData?.leddef_id);
        prefillVatCode(selectedRowData?.vat_id);
        const creatFundRow = {
          id: selectedRowData?.fund_id,
          code: selectedRowData?.fund_code,
          description: selectedRowData?.fund_des
        };
        prefillFundCode(creatFundRow);

        // order line type dtOrdrInv only
        if (lineTypeVal === INVOICE_LINE_TYPE?.DTORDERINV) {
          setQuantityOutStanding(selectedRowData?.qty_out);
          setValue("inv_unit_cost", Number(selectedRowData?.inv_unit_cost)?.toFixed(2));
          setValue("discount", usNumberFormat(selectedRowData?.discount));
          setValue("qty_inv", selectedRowData?.qty_inv);
        } else if (lineTypeVal === INVOICE_LINE_TYPE?.DTFREETEXTINV) {
          setValue("discount", usNumberFormat(selectedRowData?.discount));
        }
        hasPrefilled.current = true;
      }
    },
    [selectedRowData, method, lineTypeVal, hasPrefilled, vatCodes, ledgerCodes, costCenters]
  );
  useEffect(() => {
    if (method === METHOD?.EDIT) {
      prefillLineItemData(hasPrefilled);
    }
  }, [method, prefillLineItemData]);

  const getQtyInv = () => {
    const invoivceQunatity = watch("qty_inv");
    if (invoivceQunatity !== null && invoivceQunatity !== undefined) {
      return String(Math.abs(parseFloat(invoivceQunatity)));
    }
    return String(0);
  };

  const getLineAmount = () => {
    const lineCost = watch("line_cost");
    if (lineCost !== null && lineCost !== undefined) {
      return String(Math.abs(parseFloat(lineCost)));
    }
    return String(0.0);
  };

  return (
    <>
      <Layout
        pageTitle={handlePageTitile()}
        className="invoice-line-item"
        isBreadcrumbRequired
      >
        <Grid>
          <GridItem
            lg={8}
            xl={8}
          >
            {lineTypeVal !== INVOICE_LINE_TYPE.POSTNPAKING && (
              <Grid className="w-100">
                <GridItem className="w-100">
                  <FormLabel forId="itemDesc">{t("invoiceNote.itemDesc")}</FormLabel>
                  <Textarea
                    id="itemDesc"
                    {...register("item_des", { required: false })}
                    useAutoWidth={false}
                    cols={undefined}
                    rows={undefined}
                    maxLength={60}
                    value={getValues("item_des")}
                    onChange={(e) => {
                      setValue("item_des", e.currentTarget.value, { shouldDirty: true });
                      trigger("item_des");
                    }}
                    disabled={
                      lineTypeVal === INVOICE_LINE_TYPE?.DTORDERINV || lineTypeVal === INVOICE_LINE_TYPE?.DTFREETEXTINV
                    }
                  />
                </GridItem>
              </Grid>
            )}
            <Grid>
              <GridItem xl={5}>
                <Input
                  id="costCenter"
                  labelText={t("invoiceNote.lineCostCentre")}
                  searchable
                  searchItems={costCenters.map((b) => ({ text: b.code, value: b.code }))}
                  className="width160"
                  inputRef={(e) => register("cost_code").ref(e)}
                  name={register("cost_code", { required: true }).name}
                  value={watch("cost_code")}
                  onChange={(e) => {
                    setValue("cost_code", e.target.value, { shouldDirty: true });
                    setValue("cost_des", e.target.value ? getValues("cost_des") : specialCharacters.BLANKVALUE);
                  }}
                  onBlur={(e) => {
                    register("cost_code").onBlur(e);
                    trigger("cost_code");
                  }}
                  onSelect={(selectedItem) => {
                    const costCenter = costCenters.filter((s) => s.code === selectedItem?.value).at(0);
                    setValue(
                      "cost_des",
                      costCenters.length === 1 || (selectedItem?.text && getValues("cost_code") !== "")
                        ? costCenter?.description
                        : specialCharacters.BLANKVALUE
                    );
                    setValue("cost_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
                    dispatch(costActions.selectRow(costCenter));
                  }}
                  onPending={(selectedItem) => {
                    const row = costCenters.filter((s) => s.code === selectedItem?.value).at(0);
                    if (row) {
                      setValue("cost_des", row?.description);
                      setSuggestedCostRow(row);
                    } else {
                      setSuggestedCostRow(null);
                    }
                  }}
                  disabled={!isQuantityValid() || disableCostLedgerFund()}
                  onNoSelection={() => setIsOpenCostCenterModal(true)}
                  validationTextLevel={errors.cost_code ? ValidationTextLevel.Error : undefined}
                  button={
                    <>
                      <Tooltip content={watch("cost_des")}>
                        <div className="essui-textinput essui-textinput--medium read-only invoice-line-tooltip-class">
                          {watch("cost_des")}
                        </div>
                      </Tooltip>
                      <Button
                        color={ButtonColor.Secondary}
                        size={ButtonSize.Small}
                        onClick={costCenterClick}
                        disabled={!isQuantityValid() || disableCostLedgerFund()}
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                />
              </GridItem>
              <GridItem xl={5}>
                <Input
                  id="ledgerCode"
                  labelText={t("invoiceNote.lineLedgerCode")}
                  searchable
                  onSelect={(selectedItem) => {
                    const ledgerCodeValue = ledgerCodes.find((s) => s.code === selectedItem?.value);
                    setValue(
                      "ledger_des",
                      ledgerCodes.length === 1 || (selectedItem?.text && getValues("ledger_code") !== "")
                        ? ledgerCodeValue?.description
                        : specialCharacters.BLANKVALUE
                    );
                    setValue("ledger_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
                    dispatch(ledgerActions.selectRowLedgerCode(ledgerCodeValue));
                    isFirstTimeLedger.current = true;
                    setLedgerOnSelectInvoked("invokedBYLedgerOnSelect");
                  }}
                  onNoSelection={() => setIsOpenLedgerCodesModal(true)}
                  value={watch("ledger_code")}
                  disabled={!isQuantityValid() || disableCostLedgerFund()}
                  searchItems={ledgerCodes.map((b) => ({ text: b.code, value: b.code }))}
                  inputRef={(e) => register("ledger_code").ref(e)}
                  name={register("ledger_code", { required: true }).name}
                  onBlur={(e) => {
                    register("ledger_code").onBlur(e);
                    trigger("ledger_code");
                  }}
                  onChange={(e) => {
                    register("ledger_code").onChange(e);
                    isFirstTimeLoading.current = false;
                    if (!e.target.value) {
                      setValue("ledger_code", specialCharacters.BLANKVALUE);
                      setValue("ledger_des", specialCharacters.BLANKVALUE);
                    }
                  }}
                  validationTextLevel={errors.ledger_code ? ValidationTextLevel.Error : undefined}
                  onPending={(selectedItem) => {
                    const row = ledgerCodes.filter((s) => s.code === selectedItem?.value).at(0);
                    setSuggestedLedgerRow(row);
                    if (row) {
                      setValue("ledger_des", row?.description);
                    } else {
                      setValue("fund_code", "");
                      setValue("fund_des", "");
                      dispatch(costActions.resetBudgetCombination());
                      dispatch(ledgerActions.selectRowLedgerCode(undefined));
                    }
                  }}
                  button={
                    <>
                      <Tooltip content={watch("ledger_des")}>
                        <div className="essui-textinput essui-textinput--medium read-only invoice-line-tooltip-class">
                          {watch("ledger_des")}
                        </div>
                      </Tooltip>
                      <Button
                        color={ButtonColor.Secondary}
                        size={ButtonSize.Small}
                        onClick={ledgerCodeClick}
                        disabled={!isQuantityValid() || disableCostLedgerFund()}
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                />
              </GridItem>
            </Grid>
            <Grid>
              <GridItem xl={5}>
                <Input
                  id="fundCode"
                  labelText={t("invoiceNote.lineFundCode")}
                  searchable
                  onSelect={(selectedItem) => {
                    const fundCodeValue = fundCodes.filter((s) => s.code === selectedItem?.value).at(0);
                    setValue(
                      "fund_des",
                      fundCodes.length === 1 || (selectedItem?.text && getValues("fund_code") !== "")
                        ? fundCodeValue?.description
                        : specialCharacters.BLANKVALUE
                    );
                    setValue("fund_code", selectedItem?.text ? selectedItem.text! : specialCharacters.BLANKVALUE);
                    dispatch(fundActions.selectRow(fundCodeValue));
                  }}
                  onNoSelection={() => setIsOpenFundCodesModal(true)}
                  value={watch("fund_code")}
                  searchItems={fundCodes.map((b) => ({ text: b.code, value: b.code }))}
                  inputRef={(e) => register("fund_code").ref(e)}
                  name={register("fund_code", { required: !!(watch("cost_code") && watch("ledger_code")) }).name}
                  onBlur={(e) => {
                    register("fund_code").onBlur(e);
                    if (watch("cost_code") && watch("ledger_code")) {
                      trigger("fund_code");
                    }
                  }}
                  validationTextLevel={errors.fund_code ? ValidationTextLevel.Error : undefined}
                  disabled={!watch("ledger_code") || !isQuantityValid() || disableCostLedgerFund()}
                  onChange={(e) => {
                    register("fund_code").onChange(e);
                    if (!e.target.value) {
                      setValue("fund_code", specialCharacters.BLANKVALUE);
                      setValue("fund_des", specialCharacters.BLANKVALUE);
                      dispatch(costActions.resetBudgetCombination());
                    }
                  }}
                  onPending={(selectedItem) => {
                    const row = fundCodes.filter((s) => s.code === selectedItem?.value).at(0);
                    setValue("fund_des", row?.description);
                    if (row === undefined) {
                      dispatch(fundActions.selectRow(undefined));
                    }
                  }}
                  button={
                    <>
                      <Tooltip content={watch("fund_des")}>
                        <div className="essui-textinput essui-textinput--medium read-only invoice-line-tooltip-class">
                          {watch("fund_des")}
                        </div>
                      </Tooltip>
                      <Button
                        color={ButtonColor.Secondary}
                        size={ButtonSize.Small}
                        onClick={fundCodeClick}
                        className={` btnclass essui-button-icon-only--small ${
                          !watch("ledger_code") || !isQuantityValid() ? "disabled" : null
                        }`}
                        disabled={!watch("ledger_code") || !isQuantityValid() || disableCostLedgerFund()}
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                />
              </GridItem>
              <GridItem
                xl={4}
                md={3}
              >
                {serviceBoxToggle ? (
                  <div className="mr-t32">
                    <CheckBox
                      isSelected={isServiceChecked}
                      id="lineItemService"
                      label={t("invoiceNote.lineServices")}
                      onChange={(e: any) => {
                        const { checked } = e.target;
                        setServiceChecked(checked);
                        setValue("services", checked ? BOOLEAN_DATA.True : BOOLEAN_DATA.False);
                        register("services").onChange(e);
                      }}
                    />
                  </div>
                ) : null}
              </GridItem>
            </Grid>
          </GridItem>
          <Divider orientation={Orientation.VERTICAL} />
          <GridItem
            lg={3}
            xl={3}
          >
            <h2 className="essui-global-typography-default-h4 m-0">Budget Remaining</h2>
            <Grid className="mt-24">
              <GridItem xl={12}>
                <FormLabel forId="costC">{t("invoiceNote.lineCostCentre")}</FormLabel>
              </GridItem>
              <GridItem
                xl={12}
                className="mt-8"
              >
                {budgetCostCentre?.cost_centre_balance === 0
                  ? "0.00"
                  : usNumberFormat(budgetCostCentre?.cost_centre_balance)}
              </GridItem>
            </Grid>
            <Grid className="mt-16">
              <GridItem xl={12}>
                <FormLabel forId="combination">{t("purchaseOrder.combination")}</FormLabel>
              </GridItem>
              <GridItem
                xl={12}
                className="mt-8"
              >
                {budgetCombination === 0 ? "0.00" : usNumberFormat(budgetCombination!)}
              </GridItem>
            </Grid>
          </GridItem>
        </Grid>
        <Divider orientation={Orientation.HORIZONTAL} />

        {lineTypeVal === INVOICE_LINE_TYPE.ORDERINV && (
          <Grid className="mt-16">
            <GridItem
              lg={2}
              xl={2}
            >
              <div className="table-controls">
                <div className="controls">
                  <FormLabel> {t("creatOrderInvoice.quantityOutStanding")}</FormLabel>
                  <div className="mt-16">{Number(quantiyOutStanding)}</div>
                </div>
              </div>
            </GridItem>
            <GridItem
              lg={2}
              xl={2}
            >
              <FormLabel forId="quantityInvoiced">{t("creatOrderInvoice.quantityInvoiced")}</FormLabel>
              <NumberInput
                autoFocus
                id="quantityInvoiced"
                defaultValue={getQtyInv()}
                decimals={0}
                maxLength={6}
                name={
                  register("qty_inv", {
                    required: true,
                    validate: (value) => isQuantityValid()
                  }).name
                }
                onChange={(e) => {
                  const { value } = e.target;
                  setValue("qty_inv", value, { shouldDirty: true });
                  register("qty_inv").onChange(e);
                  trigger("qty_inv");
                  firstLoad.current = false;
                }}
                onBlur={() => {
                  trigger("qty_inv");
                }}
                inputRef={(e) => register("qty_inv").ref(e)}
                validationTextLevel={errors.qty_inv ? ValidationTextLevel.Error : undefined}
              />
            </GridItem>
            <GridItem
              lg={2}
              xl={2}
            >
              <FormLabel forId="unitcost">{t("creatOrderInvoice.unitcost")}</FormLabel>
              <NumberInput
                id="unitCost"
                value={watch("inv_unit_cost") as any}
                defaultValue={(watch("inv_unit_cost") as string) || "0.00"}
                decimals={2}
                maxLength={12}
                name={register("inv_unit_cost").name}
                onBlur={calculate}
                onChange={(e) => {
                  const newValue = e.target.value === KEYBOARD_STRING.Zero ? "0.00" : e.target.value;
                  setValue("inv_unit_cost", newValue, { shouldDirty: true });
                  register("inv_unit_cost").onChange(e);
                }}
                inputRef={(e) => register("inv_unit_cost").ref(e)}
                disabled={disableFieldOnQTYChange()}
              />
            </GridItem>
            <GridItem
              lg={2}
              xl={2}
            >
              <FormLabel forId="discount">{t("creatOrderInvoice.discount")}</FormLabel>
              <NumberInput
                id="discount"
                value={watch("discount")}
                defaultValue={watch("discount") || "0.00"}
                decimals={2}
                maxLength={2}
                name={register("discount").name}
                onBlur={calculate}
                onChange={(e) => {
                  const newValue = e.target.value === KEYBOARD_STRING.Zero ? "0.00" : e.target.value;
                  setValue("discount", newValue);
                  register("discount").onChange(e);
                }}
                inputRef={(e) => register("discount").ref(e)}
                disabled={disableFieldOnQTYChange()}
              />
            </GridItem>
          </Grid>
        )}

        <Grid className="mt-16">
          <GridItem
            xl={8}
            lg={8}
          >
            <Grid>
              <GridItem lg={5}>
                <Input
                  id="vatCode"
                  labelText={t("invoiceNote.lineVatCode")}
                  searchable
                  onSelect={(selectedItem) => {
                    const vatcodesValue = vatCodes.find((s: any) => s.vat_code === selectedItem?.value);
                    setValue(
                      "vat_code",
                      selectedItem?.text ? String(selectedItem.text!) : specialCharacters.BLANKVALUE
                    );
                    dispatch(vatActions.selectVatCodeForInvoice(vatcodesValue));
                  }}
                  onNoSelection={() => setIsOpenVatCodesModal(true)}
                  value={watch("vat_code")}
                  searchItems={vatCodes?.map((b: any) => ({ text: b.vat_code, value: b.vat_code }))}
                  inputRef={(e) => register("vat_code").ref(e)}
                  onBlur={(e) => {
                    register("vat_code").onBlur(e);
                    trigger("vat_code");
                  }}
                  name={register("vat_code", { required: true }).name}
                  validationTextLevel={errors.vat_code ? ValidationTextLevel.Error : undefined}
                  onChange={(e) => {
                    register("vat_code").onChange(e);
                    if (!e.target.value) {
                      setValue("vat_code", specialCharacters.BLANKVALUE);
                      setValue("vat_des", specialCharacters.HYPHEN);
                    }
                  }}
                  onPending={(selected) => {
                    const found = vatCodes?.find((p: any) => p?.vat_code === selected?.value);
                    setValue("vat_des", found?.vat_des);
                    dispatch(vatActions.selectVatCodeForInvoice(found));
                  }}
                  button={
                    <>
                      <Tooltip content={watch("vat_des")}>
                        <div className="essui-textinput essui-textinput--medium read-only invoice-line-tooltip-class">
                          {watch("vat_des")}
                        </div>
                      </Tooltip>
                      <Button
                        color={ButtonColor.Secondary}
                        size={ButtonSize.Small}
                        onClick={vatCodeClick}
                        disabled={disableFieldOnQTYChange()}
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                  disabled={disableFieldOnQTYChange()}
                />
              </GridItem>
              <GridItem xl={3}>
                <FormLabel forId="netAmount">{t("invoiceNote.lineNetAmount")}</FormLabel>
                <NumberInput
                  id="netAmount"
                  defaultValue={getLineAmount()} // getLineAmount()
                  decimals={2}
                  maxLength={12}
                  name={register("line_cost").name}
                  onBlur={calculateUnitCost}
                  onChange={(e) => {
                    const newValue = e.target.value === KEYBOARD_STRING.Zero ? "0.00" : e.target.value;
                    setValue("line_cost", newValue, { shouldDirty: true });
                    register("line_cost").onChange(e);
                  }}
                  inputRef={(e) => register("line_cost").ref(e)}
                  disabled={disableFieldOnQTYChange()}
                />
              </GridItem>

              {lineTypeVal === INVOICE_LINE_TYPE.FREETEXT && (
                <GridItem
                  lg={3}
                  xl={3}
                >
                  <FormLabel forId="discount">{t("creatOrderInvoice.discount")}</FormLabel>
                  <NumberInput
                    id="discount"
                    value={watch("discount")}
                    defaultValue={watch("discount") || "0.00"}
                    decimals={2}
                    maxLength={2}
                    name={register("discount").name}
                    onChange={(e) => {
                      const newValue = e.target.value === KEYBOARD_STRING.Zero ? "0.00" : e.target.value;
                      setValue("discount", newValue, { shouldDirty: true });
                      register("discount").onChange(e);
                      calculate();
                    }}
                    inputRef={(e) => register("discount").ref(e)}
                  />
                </GridItem>
              )}
            </Grid>
          </GridItem>
          <GridItem
            xl={3}
            lg={3}
          >
            <div />
          </GridItem>
        </Grid>

        {lineTypeVal === INVOICE_LINE_TYPE.FREETEXT && (
          <>
            <Divider orientation={Orientation.HORIZONTAL} />
            <Grid className="mt-16">
              <GridItem
                lg={2}
                xl={2}
              >
                <div className="table-controls">
                  <div className="controls">
                    <FormLabel> {t("creatOrderInvoice.outstandingAmount")}</FormLabel>
                    <div className="mt-16">{parseFloat(outStandingAmt).toFixed(2)}</div>
                  </div>
                </div>
              </GridItem>
            </Grid>
          </>
        )}

        <Grid className="mt-8">
          <GridItem
            lg={2}
            xl={2}
          >
            <Grid>
              {/* <Button
                size={ButtonSize.Small}
                onClick={() => {}}
                color={ButtonColor.Tertiary}
                iconPosition={ButtonIconPosition.Left}
              >
                {t("common.help")}
              </Button> */}
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </Grid>
          </GridItem>
          <GridItem
            lg={10}
            xl={10}
          >
            <Grid className="dialog-right-button m-0">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                iconPosition={ButtonIconPosition.Left}
                onClick={() => closeHandler("cancel")}
              >
                {t("common.cancel")}
              </Button>
              {(currentInvoiceType === INVOICE_TYPE.NONORDERINV || currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV) &&
                method === METHOD.ADD && (
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    iconPosition={ButtonIconPosition.Left}
                    onClick={async () => {
                      await onSubmitNext();
                    }}
                  >
                    {t("common.nextLine")}
                  </Button>
                )}

              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
                iconPosition={ButtonIconPosition.Left}
                onClick={() => {
                  validateUnitCostChange();
                }}
              >
                {t("common.save")}
              </Button>
            </Grid>
          </GridItem>
        </Grid>
      </Layout>
      <InvoiceCostCentersModal
        setValue={setValue}
        trigger={trigger}
        isOpen={isOpenCostCenterModal}
        setOpen={setIsOpenCostCenterModal}
        handleSelectCostCenterManage={handleSelectCostCenterManage}
        module={MODULE_TYPE.INVOICE}
        headerName={t("invoiceNote.costCenters")}
      />
      <InvoiceLedgerCodesModal
        isFirstTimeLoading={isFirstTimeLoading}
        isFirstTimeLedger={isFirstTimeLedger}
        handleSelectLedgerManage={handleSelectLedgerManage}
        setValue={setValue}
        trigger={trigger}
        isOpen={isOpenLedgerCodesModal}
        setOpen={setIsOpenLedgerCodesModal}
        headerName={t("invoiceNote.ledgerCodeBrowse")}
        module={MODULE_TYPE.INVOICE}
      />
      <InvoiceFundCodesModal
        setValue={setValue}
        trigger={trigger}
        isOpen={isOpenFundCodesModal}
        setOpen={setIsOpenFundCodesModal}
        headerName={t("invoiceNote.fundCodeBrowse")}
        module={MODULE_TYPE.INVOICE}
      />
      <InvoiceVatCodesModal
        setValue={setValue}
        trigger={trigger}
        isOpen={isOpenVatCodesModal}
        setOpen={setIsOpenVatCodesModal}
        headerName={t("invoiceNote.vatCodeBrowse")}
        module={MODULE_TYPE.INVOICE}
      />
      <Modalv2
        isOpen={isOpenAlert}
        header={t("common.simsFMSModule")}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setIsOpenAlert(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
      >
        <>
          <Notification
            actionElement={1}
            dataTestId="delete-new-warning-id"
            escapeExits
            id="delete-new-warning-id"
            hideCloseButton
            className="confirm-modal-text"
            status={NotificationStatus.WARNING}
            title={message}
          />
        </>
      </Modalv2>
    </>
  );
};

export default InvoiceLineItem;
