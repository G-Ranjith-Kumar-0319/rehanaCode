import { useAppSelector } from "@/store/store";
import { INVOICE_STATUS, invoiceTypesName } from "@/types/UseStateType";
import { invoiceOrderType, sundryInvoiceType } from "@/utils/constants";
import { useHistory } from "react-router-dom";

const useRedirectByStatus = () => {
  const history = useHistory();
  const { selectedSupplier } = useAppSelector((state) => state.selectedSupplier);
  const editable = [INVOICE_STATUS.UNAUTHORISED, INVOICE_STATUS?.AUTHORISED];

  const isNavigateFromSupplier = () => history?.location?.pathname.includes("supplier");
  const isEditInvoicePageFromSupplier = () => history?.location?.pathname.includes("editInv");
  const isViewInvoicePageFromSupplier = () => history?.location?.pathname.includes("viewInv");

  const getSupplierPath = () => {
    if (isNavigateFromSupplier()) {
      if (isViewInvoicePageFromSupplier()) {
        return `/accounts-payable/supplier/edit/${selectedSupplier?.client_id ? selectedSupplier?.client_id : "0"}/${
          selectedSupplier?.alt_client ? selectedSupplier?.alt_client : "0"
        }/viewInv`;
      }
      return `/accounts-payable/supplier/edit/${selectedSupplier?.client_id ? selectedSupplier?.client_id : "0"}/${
        selectedSupplier?.alt_client ? selectedSupplier?.alt_client : "0"
      }`;
    }
    return "";
  };

  // This will handle edit route for unauthorized and authorized
  const handleEditRoute = (data?: any) => {
    const supplierPath = getSupplierPath();
    if (!supplierPath && editable.includes(data?.status)) {
      return "edit-";
    }
    if (supplierPath && !editable.includes(data?.status)) {
      // this is for supplier route
      return "/viewInv";
    }
    return "";
  };
  //

  const invTypeAfterSave = (invoiceDetails: any) => {
    let invoiceTypeStr = "";
    if (invoiceDetails?.invoice_type === invoiceOrderType.pi) {
      if (invoiceDetails?.order_id !== "" && invoiceDetails?.order_id !== null) {
        invoiceTypeStr =
          handleEditRoute(invoiceDetails) === "edit-"
            ? invoiceTypesName.EDIT_ORDER_INVOICE
            : invoiceTypesName?.ORDER_INVOICE;
      } else if (invoiceDetails?.sundry_invoice === sundryInvoiceType.t) {
        invoiceTypeStr = invoiceTypesName?.SUNDARY_INVOICE;
      } else {
        invoiceTypeStr =
          handleEditRoute(invoiceDetails) === "edit-"
            ? invoiceTypesName.EDIT_NON_ORDER_INVOICE
            : invoiceTypesName?.NON_ORDER_INVOICE;
      }
    } else if (invoiceDetails?.invoice_type === invoiceOrderType.pc) {
      invoiceTypeStr =
        handleEditRoute(invoiceDetails) === "edit-" ? invoiceTypesName.EDIT_CREDIT_NOTE : invoiceTypesName?.CREDIT_NOTE;
    }
    return invoiceTypeStr;
  };

  const checkInvoiceTypeAndRedirect = (data: any) => {
    const supplierPath = getSupplierPath();
    let prepareSupplierUrl = "";
    if (supplierPath) {
      prepareSupplierUrl =
        supplierPath.includes("viewInv") && handleEditRoute(data)?.includes("viewInv")
          ? supplierPath
          : `${supplierPath}${handleEditRoute(data)}`;
    }
    const invoiceViewLink =
      data?.order_id || data?.order_no
        ? `${prepareSupplierUrl}/invoice-credit-note/${invTypeAfterSave(data)}/orderno/${data?.order_id}/invoiceId/${
            data?.invoiceId || data?.invoice_id
          }`
        : `${prepareSupplierUrl}/invoice-credit-note/${invTypeAfterSave(data)}/invoiceId/${
            data?.invoiceId || data?.invoice_id
          }`;
    history.push(invoiceViewLink);
  };

  return {
    checkInvoiceTypeAndRedirect,
    getSupplierPath
  };
};

export default useRedirectByStatus;
