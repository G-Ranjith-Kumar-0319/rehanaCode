import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  IPaginationProps,
  ISelectedItem,
  Icon,
  IconColor,
  IconSize,
  Loader,
  LoaderType,
  Notification,
  NotificationStatus,
  Orientation,
  Segmented,
  SegmentedButton,
  Tag,
  TagColor,
  TagSize,
  TextInput,
  Tooltip,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import "./Style.scss";
import { AddLarge, WatsonHealth3DSoftware } from "@carbon/icons-react";
import {
  ReactNode,
  SyntheticEvent,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useRef,
  useState
} from "react";
import SuppliersModal from "@/shared/components/SuppliersModal/SuppliersModal";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useForm } from "react-hook-form";
import {
  BOOLEAN_DATA,
  COMMON_MSG,
  CONVERT_ORDER,
  DELIV_STATUS,
  INVOICE_DETAILS,
  INVOICE_MSG_TYPE,
  INVOICE_STATUS,
  INVOICE_TYPE,
  METHOD,
  NUMBER_LENGTH,
  STATUS,
  invoiceLineTypes,
  invoiceTypesName,
  specialCharacters,
  viewPageStatus,
  INVOICE_LINE_TYPE,
  RESPONSE_STATUS,
  KEYBOARD_STRING,
  invoiceTypes,
  getCurrentFinancialYear,
  invoiceLineType
} from "@/types/UseStateType";
import { getPurchaseOrderStatus } from "@/pages/PurchaseOrder/state/PurchaseOrderStatus.slice";
import { useHistory, useLocation, useParams } from "react-router-dom";
import { dateSeparator, invoiceOrderType, sundryInvoiceType, maxSupplierAddresses, deepEqual } from "@/utils/constants";
import { cellRendererType } from "@/components/GridTable/GridTable";
import {
  addDaysToDate,
  convertDateWithLeadingZero,
  dateConvertInDDslashMMslashYYYY,
  deleteSessionItem,
  formatToTwoDigits,
  getAddress,
  getInvoiceDetailsUrl,
  getInvoiceTypeValue,
  getSessionItem,
  setToSession,
  splitDateFromTtoNormal,
  stringToDate,
  usNumberFormat
} from "@/utils/getDataSource";
import InputDate from "@/shared/components/InputDate/InputDate";
import InvoiceLineItemModal from "@/shared/components/InvoiceLineItemModal/InvoiceLineItemModal";
import InvoiceFromModal from "@/shared/components/InvoicePayFromModal/InvoicePayFromModal";
import PostingPeriodModal from "@/shared/components/PostingPeriod/PostingPeriodModal";
import {
  actions as InvoiceSupplierAction,
  getBankBySupplierId,
  getInvoiceSupplierAll,
  getSundrySuppliersAll,
  getSupplierBrowse
} from "@/pages/Invoice/State/InvoiceSupplierList.slice";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import NumberInput from "@/components/NumberInput/NumberInput";
import MatchedInvoiceBrowseModal from "@/shared/components/MatchedInvoiceBrowseModal/MatchedInvoiceBrowseModal";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import GridRowActions, { OptionsType } from "@/components/GridRowActions/GridRowActions";
import { actions, getVatLedgerinfo } from "@/shared/components/VatCodesModal/state/VatCodes.slice";
import { getFinancialYear } from "@/store/state/financialYear.slice";
import { RootContext, useAppContext } from "@/routes/Routes";
import {
  actions as ioNoteListActions,
  addInvoice,
  invoiceGetPayByDate,
  getInputStreamFile,
  getInvoiceOrdersFilter,
  supportingDocumentCount,
  actions as ioActions,
  actions as invNoteListAction,
  invoiceFinancialYear
} from "@/pages/Invoice/State/InvoiceNoteList.slice";
import useBrowserReload from "@/hooks/useBrowserReload";
import useDebounce from "@/hooks/useDebounce";
import { isArrayLength } from "@/pages/GeneralLedgerSetup/ProfileModels/utils";
import InvoiceOrderTools from "../../InvoiceOrderToolbar";
import { getInvoiceNoteLineItem, actions as invoiceLineItemAction } from "../../State/InvoiceNoteLineItem.slice";
import {
  getInvoiceDetails,
  getInvoiceAllOrder,
  actions as invActions,
  getInvoiceNumberDetails,
  getInvoiceOrderPrefix
} from "../../State/InvoiceNoteDetails";
import orderLineItemsOrderInvoiceColumnDef, { nonOrderLineItemsOrderInvoiceColumnDef } from "./Grid/columnDef";
import { getPeriods } from "../../State/Periods";
import InvoiceOrderPageToolbar from "../../InvoiceOrderPageToolbar";
import InvoiceAuditSummaryModal from "../Modals/InvoiceAuditSummary";
import InvoiceNotesModal from "../Modals/InvoiceNotesModal";
import InvoiceDifferenceModal from "../Modals/InvoiceDifferenceModal";
import { actions as postingPeriodActions } from "../../State/InvoicePostingPeriod.slice";
import { actions as payFromActions } from "../../State/InvoicePayFrom.slice";
import { actions as matchedInvoice } from "../../State/MatchedInvoiceBrowse.slice";

import OrderBrowseModal from "../CreateOrderInvoice/OrderBrowseModal";
import { actions as coActions, getInvoicePrintAndBank, orderlastUpdateVal } from "../../State/CreateOrderInvoice.slice";
import { actions as orderBrowseActions } from "../../State/OrderBrowse.slice";

import VatLineDetailsModal from "../Modals/VatLineDetailsModal";
import CustomCell from "./Grid/CustomCell";
import useRedirectByStatus from "./useRedirectByStatus";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];
/* eslint-disable camelcase */
type InvoiceFormData = {
  invoice_id?: string;
  order_id?: string;
  ord_last_update?: string;
  supplier?: string;
  supplier_address?: string;
  description?: string;
  trans_no?: string;
  transfer_text?: string;
  on_hold?: string;
  inv_no?: string;
  inv_no_suffix?: string;
  long_inv_no?: string;
  long_inv_no_suffix?: string;
  disp_inv_no?: string;
  narrative?: string;
  ordernum?: string;
  total?: string;
  inv_date?: string;
  source?: string;
  pay_by?: string;
  bank_description?: string;
  inv_notes?: string;
  long_disp_inv_no?: string;
  period?: string;
  matched_inv_no?: string;
  matched_inv_id?: string;
  month?: string;
  bank_id?: string;
  client_id?: string;
  total_amt_vat?: any;
  inv_last_update?: string;
  deleteLineItemIds?: any;
  status?: string;
};
type clickHandlerType = (e: SyntheticEvent, selectedItem: ISelectedItem) => void;
type TButton = {
  visible: boolean;
  enable: boolean;
};

type TButtons = {
  piLineAdd?: TButton; // Add TButton
  piLineEdit?: TButton; // Edit TButton
  piLineDelete?: TButton; // Delete TButton
  piLinePostAndPacking?: TButton; // PostAndPacking TButton
  piLineView?: TButton; // View TButton
  eiBrOrders?: TButton; // Supplier TButton
  eiBrPayFrom?: TButton;
  eiBrPayTo?: TButton;
};

type FieldsType = InvoiceFormData & TButtons;

const InvoiceOrderView = () => {
  const { selectedRow: listrow, filterState: listFilter } = useAppSelector((state) => state.invoiceNote);
  const { resolve, setPromise } = useAppContext();
  const [isAuditModalOpen, setIsAuditModalOpen] = useState<boolean>(false);
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [isInvoiceDifferences, setIsInvoiceDifferences] = useState<boolean>(false);
  const [isInvoiceNotesModalOpen, setIsInvoiceNotesModalOpen] = useState<boolean>(false);
  const [isSuppliersModal, setIsSuppliersModal] = useState<boolean>(false);
  const [isVatLineDetailModalOpen, setIsVatLineDetailModalOpen] = useState<boolean>(false);
  const [isViewDetail, setIsViewDetail] = useState<boolean>(false);
  const [isDisabled, setIsDisabled] = useState<boolean>(false);
  const { invoiceNoteList, isFocus } = useAppSelector((state) => state?.invoiceNote);
  const dispatch = useDispatch<AppDispatch>();
  const { isChequePaymentLoading } = useAppSelector((state) => state.chequeDetails);
  const { orderno, invoiceId } = useParams<{ orderno: string; invoiceId: any }>();
  const { orderSelectedRow } = useAppSelector((state) => state.createOrderInvoice);
  const [fields, setFields] = useState<FieldsType>();
  const [isViewInvoiceLineItem, setIsViewInvoiceLineItem] = useState<boolean>(false);
  const history = useHistory();
  const location = useLocation();
  const { orderBrowseDetail = [], orderIdFromSupplier } = useAppSelector((state) => state.orderBrowse);
  const [isPrintAlert, setPrintAlert] = useState(false);
  const { invoiceNoteLineItem, invoiceLineItemVat, selectedRow, selectedRowCustomCell, selectedRowCustomCellRow } =
    useAppSelector((state) => state.invoiceNoteLineItem);
  const { alert } = useAppSelector((state) => state.ui);
  const [isRerender, setIsRerender] = useState<boolean>(false);
  const [isHotKey, setIsHotKeyCalled] = useState<boolean>(false);
  const [financialYearInfo, setFinancialYearInfo] = useState<any>(null);
  const [saveDuplicateMsg, setSaveDuplicateMsg] = useState<string>("");
  const [isDuplicateInvoice, setDuplicateInvoice] = useState<boolean>(false);
  const [isFullInvoiceNoDuplicate, setIsFullInvoiceNoDuplicate] = useState<boolean>(false);
  const isReload = useBrowserReload();

  const {
    status: supplierStatus,
    supplierListBrowse,
    selectedSupplier,
    supplier
  } = useAppSelector((state) => state.selectedSupplier);
  const { suppliersList } = useAppSelector((state) => state.suppliers);
  let currentInvoiceType = sessionStorage.getItem("invoiceType");
  const [supportingDocument, setSupportingDocument] = useState<any>();
  const [FileStreamObj, setInputFileStreamObj] = useState<{ store_documents_in_database: any; use_file_server: any }>({
    store_documents_in_database: "",
    use_file_server: ""
  });
  const isOrderModeAdd = !orderno && currentInvoiceType === INVOICE_TYPE.ORDERINV;
  const { filterState, isPrintLoading } = useAppSelector((state) => state.invoiceNote);
  const [isPayFromModalOpen, setIsPayFromModalOpen] = useState<boolean>(false);
  const [isMatchedInvoiceModal, setIsMatchedInvoiceModal] = useState<boolean>(false);
  const [isPostingPeriodModalOpen, setPostingPeriodModalOpen] = useState<boolean>(false);
  const [bankName, setBankName] = useState("");
  const { paymentDetails, status: payFromStatus, selectedValue } = useAppSelector((state) => state.invoicePaymentFrom);
  const {
    matchedInvoiceDetails,
    selectedValue: selectedInvNumber,
    status: invNumberStatus
  } = useAppSelector((state) => state.getInvoiceNumberDetails);
  const [orderBrowseModal, setOrderBrowseModal] = useState<Boolean>(false);
  const {
    postingPeriodDetails,
    selectedValuePostingPeriod,
    status: postingPeriodStatus
  } = useAppSelector((state) => state.invoicePostingPeriod);
  const { isDirectPaymentLoading } = useAppSelector((state) => state.directPaymentProcess);
  const [isCentralProcessed, setCentralProcessed] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const [isOpenAlert, setIsOpenAlert] = useState<boolean>(false);
  const [lineType, setLineType] = useState<string>("");
  const { method, lineTypeVal, invoiceLineList }: any = location?.state || {};

  const historyState = history.location.state as any;
  const {
    status: invoiceDetailStatus,
    invoiceDetails,
    invoiceAllOrder,
    totalLineItemVal,
    invoiceNotes,
    redirectAlertModal,
    orderPrefixDetail
  } = useAppSelector((state) => state.invoiceDetails);
  const { status: poViewStatus } = useAppSelector((state) => state.purchaseViews);
  const { status: periodStatus, allPeriods } = useAppSelector((state) => state.periods);
  const invoiceData = invoiceId ? invoiceDetails : selectedRow;
  const [isRedirectLoading, setRedirectLoading] = useState(false);
  const [isundoInvoiceDetail, setIsundoInvoiceDetail] = useState<boolean>(false);
  const [submittedData, setSubmittedData] = useState<any>(null);
  const [isChanged, setIsChanged] = useState<any>(false);
  const [suggestedSupplier, setSuggestedSupplier] = useState<any>(null);
  const [suggestedAddress, setSuggestedAdress] = useState<any>(null);
  const [selectedFromOrder, setSelectedFromOrder] = useState(false);
  // get session filter
  const getSessionFilter = getSessionItem("filterState");
  const invoiceIsNext = getSessionItem("invoiceIsNext");
  const { checkInvoiceTypeAndRedirect } = useRedirectByStatus();
  const isLoading =
    isDirectPaymentLoading ||
    isChequePaymentLoading ||
    isPrintLoading ||
    periodStatus === STATUS.LOADING ||
    supplierStatus === STATUS.LOADING ||
    poViewStatus === STATUS.LOADING ||
    invoiceDetailStatus === STATUS.LOADING ||
    // status === STATUS.LOADING ||
    isRedirectLoading;

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const resetForm = () => {
    reset();
    reset({
      supplier: "",
      long_inv_no: "",
      disp_inv_no: "",
      inv_date: "",
      ordernum: "",
      total: "0.00",
      pay_by: "",
      bank_description: "",
      period: "",
      month: "",
      on_hold: "F",
      inv_notes: "",
      narrative: "",
      source: "",
      matched_inv_no: ""
    });
  };
  const isCentralProccess = () => {
    if (invoiceDetails?.centrally_processed === INVOICE_DETAILS.CENTRALLY_PROCESSED) {
      setCentralProcessed(true);
    } else if (selectedValue?.centrally_processed === INVOICE_DETAILS.CENTRALLY_PROCESSED) {
      setCentralProcessed(true);
    } else {
      setCentralProcessed(false);
    }
  };
  useEffect(() => {
    isCentralProccess();
  }, [selectedValue, isCentralProcessed, invoiceDetails]);

  useEffect(() => {
    document.querySelectorAll("input")[0]?.focus();
    if (!invoiceId) {
      dispatch(
        invoiceFinancialYear({
          callback: (data) => {
            setFinancialYearInfo(data);
          }
        })
      );
    }
  }, []);

  useEffect(() => {
    if (filterState) setToSession("filterState", filterState);
    if (!getSessionItem("validateFinancial")) {
      setToSession("validateFinancial", true);
    }
    return () => {
      deleteSessionItem("validateFinancial");
    };
  }, [filterState]);

  useEffect(
    () => () => {
      // This function will be called when the component unmounts or navigates away
      if (history.location.pathname === "/invoice-credit-note") {
        deleteSessionItem("invoiceType");
      }
    },
    []
  );

  useEffect(() => {
    dispatch(ioActions.setFilters({ ...filterState, invoiceId, lookingFor: "" }));
  }, [invoiceId]);

  const getInvoiceType = () => {
    if (invoiceDetails?.invoice_type === invoiceOrderType.pi) {
      if (invoiceDetails?.order_id !== "" && invoiceDetails?.order_id !== null) {
        sessionStorage.setItem("invoiceType", INVOICE_TYPE.ORDERINV);
      } else if (invoiceDetails?.sundry_invoice === sundryInvoiceType.t) {
        sessionStorage.setItem("invoiceType", INVOICE_TYPE.SUNDRYINV);
      } else {
        sessionStorage.setItem("invoiceType", INVOICE_TYPE.NONORDERINV);
      }
    } else if (invoiceDetails?.invoice_type === invoiceOrderType.pc) {
      sessionStorage.setItem("invoiceType", INVOICE_TYPE?.CREDITNOTEINV);
    } else {
      sessionStorage.setItem("invoiceType", INVOICE_TYPE.INVOICEERROR);
    }
    currentInvoiceType = sessionStorage.getItem("invoiceType");
  };

  useEffect(() => {
    if (historyState === undefined || historyState?.invoiceLineList === undefined) {
      if (Array.isArray(invoiceNoteLineItem) && invoiceNoteLineItem?.length > 0) {
        const historyState = {
          ...(history.location.state as any),
          invoiceId,
          method,
          lineTypeVal,
          // invoiceDetails : getValues(),
          vatDeletedList: [],
          invoiceList: invoiceNoteList,
          invoiceLineList: [...invoiceNoteLineItem]
        };
        history.replace({ ...history.location, state: historyState });
      }
    }
  }, [historyState, invoiceNoteLineItem]);

  const {
    register,
    handleSubmit,
    reset,
    getValues,
    setValue,
    trigger,
    watch,
    getFieldState,
    formState: { errors, isDirty }
  } = useForm<InvoiceFormData>({
    mode: "all",
    shouldFocusError: false,
    defaultValues: {
      total: "0.00",
      inv_date: "",
      pay_by: "",
      on_hold: "F",
      total_amt_vat: 0.0
    }
  });

  const enableEdit = (field: keyof FieldsType) => {
    setFields((prev) => ({ ...prev, [field]: "true" }));
  };
  const disableEdit = (field: keyof FieldsType) => {
    setFields((prev) => ({ ...prev, [field]: "false" }));
  };
  const buttonVisible = (field: keyof TButtons) => {
    setFields((prev) => {
      const newPrev = prev !== undefined ? prev[field] : null;
      return {
        ...prev,
        [field]: {
          ...newPrev,
          visible: true
        }
      };
    });
  };
  const buttonNotVisible = (field: keyof TButtons) => {
    setFields((prev) => {
      const newPrev = prev !== undefined ? prev[field] : null;
      return {
        ...prev,
        [field]: {
          ...newPrev,
          visible: false
        }
      };
    });
  };
  const buttonEnable = (field: keyof TButtons) => {
    setFields((prev) => {
      const newPrev = prev !== undefined ? prev[field] : null;
      return {
        ...prev,
        [field]: {
          ...newPrev,
          enable: true
        }
      };
    });
  };
  const buttonDisable = (field: keyof TButtons) => {
    setFields((prev) => {
      const newPrev = prev !== undefined ? prev[field] : null;
      return {
        ...prev,
        [field]: {
          ...newPrev,
          enable: false
        }
      };
    });
  };

  const enableLine = () => {
    //   {view the add/edit/delete buttons}
    buttonVisible("piLineAdd"); // piLineAdd.Visible := true;
    buttonVisible("piLineEdit"); // piLineEdit.Visible := true;
    buttonVisible("piLineDelete"); // piLineDelete.Visible := true;

    if (currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV) {
      buttonNotVisible("piLinePostAndPacking"); // piLinePostAndPacking.Visible := false
    } else {
      buttonVisible("piLinePostAndPacking"); // piLinePostAndPacking.Visible := true;
    }

    // {disable view button}
    buttonNotVisible("piLineView"); // piLineView.Visible := false
  };

  const setLinesReadOnly = () => {
    // {Hide the add/edit/delete buttons}
    buttonNotVisible("piLineAdd");
    buttonNotVisible("piLineEdit");
    buttonNotVisible("piLineDelete");
    buttonNotVisible("piLinePostAndPacking");

    // {Enable the view button}
    buttonEnable("piLinePostAndPacking");
    buttonVisible("piLinePostAndPacking");
  };

  useLayoutEffect(() => {
    if (!isLoading && invoiceDetails?.status) {
      getInvoiceType();
      if (
        invoiceDetails?.status === INVOICE_STATUS.AUTHORISED ||
        invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED
      ) {
        if (
          currentInvoiceType === INVOICE_TYPE.ORDERINV ||
          currentInvoiceType === INVOICE_TYPE.NONORDERINV ||
          currentInvoiceType === INVOICE_TYPE.SUNDRYINV
        ) {
          enableEdit("narrative"); // EnableEdit(eiInvoiceNarrative);
          enableEdit("ordernum"); // EnableEdit(eiInvoiceNum);
          enableEdit("long_inv_no"); // EnableEdit(eiFullInvNo);
          enableEdit("inv_date"); // EnableEdit(eiInvoiceDate);
          enableEdit("total"); // EnableEdit(eiInvoiceTotal);
          enableEdit("pay_by"); // EnableEdit(eiPayBy);
          enableEdit("inv_notes"); // EnableEdit(eiInvNotes);
          enableEdit("eiBrPayFrom"); // EnableLookTrip(eibrPayFrom);
          // enableEdit("matched_inv_no");
        } else {
          // disableEdit("matched_inv_no");
          // as per the delphi code  ==>  EnableCreditControls; procedure need to be called.
          enableEdit("narrative");
          enableEdit("inv_notes");
          enableEdit("long_inv_no");
          enableEdit("disp_inv_no");
          enableEdit("total");
          enableEdit("inv_date");
          enableEdit("eiBrPayFrom");
          enableEdit("matched_inv_no");
          enableEdit("period");
          enableEdit("bank_description");
        }

        enableLine();

        if (
          currentInvoiceType === INVOICE_TYPE.ORDERINV ||
          currentInvoiceType === INVOICE_TYPE.NONORDERINV ||
          currentInvoiceType === INVOICE_TYPE.SUNDRYINV
        ) {
          enableEdit("inv_notes"); // EnableEdit(eiInvNotes);
          disableEdit("disp_inv_no"); // DisableEdit(eiInvoiceNum);
          disableEdit("long_inv_no"); // DisableEdit(eiFullInvNo);
          disableEdit("inv_date"); // DisableEdit(eiInvoiceDate);
          disableEdit("eiBrOrders"); // DisableLookTrip(eiBrOrders);
          disableEdit("ordernum");
          disableEdit("period");
          disableEdit("supplier");
          if (getValues("source") === "XML" && invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED) {
            buttonEnable("eiBrPayFrom"); // EnableLookTrip(eiBrPayFrom)
          } else {
            buttonDisable("eiBrPayFrom"); // DisableLookTrip(eiBrPayFrom);
          }

          if (getValues("source") === "XML") {
            disableEdit("total"); // DisableEdit(eiInvoiceTotal);
            setValue("total", usNumberFormat(invoiceDetails?.total));
            disableEdit("narrative"); // DisableEdit(eiInvoiceNarrative);
          } else {
            enableEdit("total"); // EnableEdit(eiInvoiceTotal);
            enableEdit("narrative"); // EnableEdit(eiInvoiceNarrative);
          }
        } else {
          disableEdit("long_inv_no");
          disableEdit("disp_inv_no");
          disableEdit("inv_date");
          enableEdit("inv_notes");

          if (getValues("source") === "XML" && invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED) {
            enableEdit("bank_description"); // EnableLookTrip(eiBrPayTo)
            enableEdit("period");
          } else {
            disableEdit("bank_description"); // DisableLookTrip(eiBrPayTo)
            disableEdit("period");
          }

          if (getValues("source") === "XML" && invoiceId) {
            disableEdit("total");
            disableEdit("narrative");
            disableEdit("matched_inv_no");
            // DisableEdit(eiInvoiceNarrative);
            // DisableLookTrip(eibrCrInvoices);
          } else {
            enableEdit("total");
            enableEdit("narrative");
            enableEdit("matched_inv_no");
          }
        }
      } else {
        if (
          currentInvoiceType === INVOICE_TYPE.ORDERINV ||
          currentInvoiceType === INVOICE_TYPE.NONORDERINV ||
          currentInvoiceType === INVOICE_TYPE.SUNDRYINV
        ) {
          disableEdit("eiBrOrders"); // DisableLookTrip(eiBrOrders);
          disableEdit("ordernum"); // DisableLookTrip(eiBrOrders);
          buttonDisable("eiBrPayFrom"); // DisableLookTrip(eibrPayFrom);
          disableEdit("bank_description"); // DisableLookTrip(eibrPayFrom);
        } else {
          // SetCreditReadOnly
          disableEdit("matched_inv_no");
        }
        disableEdit("narrative"); // DisableEdit(eiInvoiceNarrative);
        disableEdit("disp_inv_no"); // DisableEdit(eiInvoiceNum);
        disableEdit("long_inv_no"); // DisableEdit(eiFullInvNo);
        disableEdit("inv_date"); // DisableEdit(eiInvoiceDate);
        disableEdit("total"); // DisableEdit(eiInvoiceTotal);
        setValue("total", usNumberFormat(invoiceDetails?.total));
        disableEdit("pay_by"); // DisableEdit(eiPayBy);
        disableEdit("inv_notes"); // DisableEdit(eiInvNotes);
        disableEdit("supplier"); // EditableSupplierMode := False;
        disableEdit("period");
        disableEdit("bank_description");
        // SetLinesReadOnly
        setLinesReadOnly();
      }
    }
  }, [isLoading, invoiceDetails, orderno, currentInvoiceType]);

  const isInvoiceStatusChange = (newStatus: any) => {
    const filters = filterState || getSessionFilter;
    if (!newStatus || !filters?.status) return false;
    if (filters?.status !== specialCharacters.BLANKVALUE && filters?.status !== newStatus) {
      return true;
    }
    return false;
  };

  useEffect(() => {
    if (method === METHOD?.EDIT && currentInvoiceType === INVOICE_TYPE?.ORDERINV) {
      setIsViewDetail(true);
      if (selectedSupplier) {
        dispatch(getInvoiceSupplierAll({ clientId: selectedSupplier?.client_id }));
      }
    }
  }, [method, selectedSupplier]);

  const invoiceFocusField = () => {
    if (invoiceDetails) {
      switch (invoiceDetails?.status) {
        case INVOICE_STATUS.PAID:
        case INVOICE_STATUS.FULLY_AUTHORISED:
        case INVOICE_STATUS.RECONCILED:
        case INVOICE_STATUS.PASSED_FOR_PAYMENT:
        case INVOICE_STATUS.CANCELLED:
        case INVOICE_STATUS.ON_HOLD:
        case INVOICE_STATUS.PART_AUTHORISED:
          document.getElementById("rowIndex-invoiceOrderLine-0")?.focus();
          break;
        default:
          break;
      }
    }
    if (!method) {
      window.scroll(0, 0);
    }
  };

  useEffect(() => {
    const handleAsyncOperations = async () => {
      if (selectedRowCustomCell && selectedRowCustomCellRow) {
        dispatch(invoiceLineItemAction.resetRowCustomCell(true));
        dispatch(invoiceLineItemAction.resetSelectedRowCustomCellRow(true));
        setIsChanged(true);
        if (selectedRowCustomCell.value === "clear") {
          if (historyState?.invoiceLineList?.length > 0) {
            const selectedIndex = historyState?.invoiceLineList?.findIndex((t: any) => deepEqual(t, selectedRow));
            historyState?.invoiceLineList.splice(selectedIndex, 1);

            const oldVatInfo: any = await dispatch(getVatLedgerinfo({ vatId: selectedRowCustomCellRow?.vat_id }));

            const vatRate = oldVatInfo?.payload && oldVatInfo?.payload?.at(0)?.rate;
            const oldVatAmt = Number(selectedRowCustomCellRow?.line_cost / 100) * vatRate;
            updateOldVatValues(selectedRowCustomCellRow?.vat_id, oldVatAmt, oldVatInfo?.payload?.at(0)?.vat_ledger_id);
            const temp = historyState?.vatDeletedList || [];
            if (selectedRow?.invoice_line_id) {
              temp.push(selectedRow?.invoice_line_id);
            }
            const updateHistory = {
              ...(history.location.state as any),
              vatDeletedList: [...temp]
            };
            history.replace({ ...history.location, state: updateHistory });
          }
        } else if (selectedRowCustomCell.value === "edit") {
          if (selectedRowCustomCellRow?.line_type === invoiceLineTypes.LINETYPEV) {
            setIsVatLineDetailModalOpen(true);
            const updateHistory = {
              ...(history.location.state as any),
              invoiceDetails: getValues()
            };
            history.replace({ ...history.location, state: updateHistory });
          } else {
            const selectedIndex = historyState?.invoiceLineList?.findIndex((t: any) => deepEqual(t, selectedRow));
            const result = await trigger();
            if (result) {
              if (lineType) {
                handleLineItemDetails(METHOD.EDIT, lineType, selectedIndex);
              }
            } else {
              setMessage(t("common.invalidData"));
              setIsOpenAlert(true);
            }
          }
        }
      }
    };

    handleAsyncOperations();
  }, [selectedRowCustomCell, selectedRowCustomCellRow]);

  useEffect(() => {
    if (invoiceId) {
      setIsDisabled(true);
      setIsViewDetail(true);
      dispatch(getPeriods());
      dispatch(getPurchaseOrderStatus());
      if (invoiceId) {
        dispatch(
          getInvoiceDetails({
            invoiceId,
            callback: (data) => {
              /** This condition modified for calling the all order api only for order invoices */
              if (data?.order_id) {
                dispatch(getInvoiceAllOrder());
              }
              // checkInvoiceTypeAndRedirect(data);
              dispatch(invActions.addLineItemTotal(data?.total));

              if (isInvoiceStatusChange(data?.status)) {
                dispatch(invActions.setRedirectAlertModal(true));
              }

              dispatch(
                getInvoiceNoteLineItem({
                  invoiceID: data.invoice_id,
                  OrderId: data.order_id,
                  callback: (res) => {
                    // dispatch(invoiceLineItemAction.setSelectedRow(res?.at(0)))
                  }
                })
              );
              dispatch(
                getSupplierBrowse({
                  clientId: data?.client_id,
                  credType: data?.sundry_invoice === sundryInvoiceType.t ? sundryInvoiceType.f : sundryInvoiceType.t
                })
              );
            }
          })
        );
      }
    }
  }, [invoiceId, isRerender, isundoInvoiceDetail]);

  useEffect(() => {
    if (invoiceDetailStatus === STATUS.SUCCESS && invoiceId && invoiceDetails !== undefined) {
      dispatch(ioActions.setSelectedRow(invoiceDetails));
      reset({
        invoice_id: invoiceDetails?.invoice_id,
        order_id: invoiceDetails?.order_id ? invoiceDetails?.order_id : null,
        ord_last_update: invoiceDetails?.ord_last_update ? invoiceDetails?.ord_last_update : null,
        bank_id: invoiceDetails?.bank_id,
        client_id: invoiceDetails?.client_id,
        inv_last_update: invoiceDetails?.inv_last_update,
        supplier: invoiceDetails?.client_name,
        inv_no: invoiceDetails?.inv_no,
        inv_no_suffix: invoiceDetails?.inv_no_suffix,
        long_inv_no:
          invoiceDetails?.long_disp_inv_no?.trim() !== undefined && invoiceDetails?.long_disp_inv_no?.trim() !== ""
            ? invoiceDetails?.long_disp_inv_no
            : specialCharacters.HYPHEN,
        long_disp_inv_no: invoiceDetails?.long_inv_no,
        long_inv_no_suffix: invoiceDetails?.long_inv_no_suffix,
        disp_inv_no: invoiceDetails?.disp_inv_no,
        inv_date: new Date(invoiceDetails?.inv_date).toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "short",
          year: "numeric"
        }),
        ordernum: invoiceDetails?.ordernum,
        total: invoiceDetails?.total?.toFixed(2),
        pay_by: dateConvertInDDslashMMslashYYYY(invoiceDetails?.pay_by, fields?.pay_by),
        bank_description: invoiceDetails?.bank_description,
        period: invoiceDetails?.period,
        on_hold: invoiceDetails?.on_hold,
        inv_notes: getInvNotes(),
        narrative: getNarrative(),
        source: invoiceDetails?.source,
        matched_inv_no: invoiceDetails?.matched_inv_no,
        matched_inv_id: invoiceDetails?.matched_invoice_id,
        month: allPeriods?.filter((p: any) => p.code === invoiceDetails?.period)[0]?.description,
        status: invoiceDetails?.status
      });
    }
  }, [
    invoiceDetailStatus,
    fields?.pay_by,
    fields,
    isChequePaymentLoading,
    isDirectPaymentLoading,
    invoiceDetails,
    invoiceDetails?.pay_by,
    isPrintLoading
  ]);

  useEffect(() => {
    setValue("inv_notes", invoiceNotes, { shouldDirty: true });
  }, [invoiceNotes]);

  useEffect(() => {
    if (selectedValue !== undefined && payFromStatus === STATUS.SUCCESS) {
      const payfrom = paymentDetails.filter((s) => s.id === selectedValue?.id)[0];
      dispatch(payFromActions.selectPaymentMethod(payfrom));
      setValue("bank_description", payfrom?.code);
      setValue("bank_id", payfrom?.id);
    }
  }, [selectedValue]);

  useEffect(() => {
    if (selectedValuePostingPeriod !== undefined && postingPeriodStatus === STATUS.SUCCESS) {
      const postingPrd = postingPeriodDetails.filter((s) => s.id === selectedValuePostingPeriod?.id)[0];
      dispatch(postingPeriodActions.selectPostingPeriod(postingPrd));
      setValue("period", postingPrd?.code);
      setValue("month", postingPrd?.description);
    }
  }, [selectedValuePostingPeriod]);

  useEffect(() => {
    if (selectedInvNumber !== undefined && invNumberStatus === STATUS.SUCCESS) {
      const invNumberCredit = matchedInvoiceDetails.filter((s) => s.id === selectedInvNumber?.id)[0];
      setValue("matched_inv_no", invNumberCredit?.code);
      dispatch(matchedInvoice.selectMatchedInvoice(invNumberCredit));
    }
  }, [selectedInvNumber]);

  const isNavigateFromSupplier = () => history?.location?.pathname.includes("supplier");
  const isEditInvoicePageFromSupplier = () => history?.location?.pathname.includes("editInv");
  const isViewInvoicePageFromSupplier = () => history?.location?.pathname.includes("viewInv");
  const isViewPaymentPageFromSupplier = () => history?.location?.pathname.includes("view-payments");
  const isViewPaymentFromChequeProcessing = () => history?.location?.pathname.includes("cheque-processing-detail");
  const getSupplierPath = () => {
    if (isNavigateFromSupplier()) {
      if (isViewInvoicePageFromSupplier()) {
        return `/accounts-payable/supplier/edit/${selectedSupplier?.client_id ? selectedSupplier?.client_id : "0"}/${
          selectedSupplier?.alt_client ? selectedSupplier?.alt_client : "0"
        }/viewInv`;
      }
      return `/accounts-payable/supplier/edit/${selectedSupplier?.client_id ? selectedSupplier?.client_id : "0"}/${
        selectedSupplier?.alt_client ? selectedSupplier?.alt_client : "0"
      }`;
    }
    return "";
  };
  const isSupportingDocBtnDisabled = () => {
    if (invoiceId) {
      return FileStreamObj.store_documents_in_database === 0 && FileStreamObj.use_file_server === 0;
    }
    return true;
  };
  // Reset Invoice order fields in add view
  useEffect(() => {
    if (!invoiceId) {
      switch (currentInvoiceType) {
        case INVOICE_TYPE.NONORDERINV:
          reset({
            supplier: "",
            long_inv_no: "",
            disp_inv_no: "",
            inv_date: "",
            ordernum: "",
            total: "0.00",
            pay_by: "",
            bank_description: "",
            period: "",
            on_hold: "F",
            inv_notes: "",
            narrative: "",
            source: "",
            matched_inv_no: ""
          });
          break;
        case INVOICE_TYPE.SUNDRYINV:
          reset({
            supplier: "",
            long_inv_no: "",
            disp_inv_no: "Sundry",
            inv_date: Date(),
            ordernum: "",
            total: "0.00",
            pay_by: "",
            bank_description: "Bank Account",
            period: "",
            on_hold: "F",
            inv_notes: "",
            narrative: "",
            source: "",
            matched_inv_no: ""
          });
          break;

        default:
          reset();
      }
    }
  }, [invoiceId]);

  useEffect(() => {
    if (
      invoiceDetails?.client_id &&
      invoiceDetailStatus === STATUS.SUCCESS &&
      invoiceDetails?.invoice_type === invoiceOrderType.pc
    ) {
      dispatch(
        getInvoiceNumberDetails({
          clientId: invoiceDetails?.client_id,
          callback: (invoiceNumebrList) => {
            if (invoiceNumebrList && invoiceNumebrList.length > 0) {
              const invoiceNum = invoiceNumebrList.filter(
                (col: any) => col.id === invoiceDetails?.matched_invoice_id
              )[0].code;
              setValue("matched_inv_no", invoiceNum);
            } else {
              setValue("matched_inv_no", "");
              setValue("matched_inv_id", "");
            }
          }
        })
      );
    }
  }, [invoiceDetails?.client_id]);

  const getNarrative = () => {
    if (fields?.narrative && fields?.narrative !== BOOLEAN_DATA.STRINGFALSE) {
      return invoiceDetails?.narrative;
    }
    return invoiceDetails?.narrative ? invoiceDetails?.narrative : specialCharacters.HYPHEN;
  };

  const getInvNotes = () => {
    if (fields?.inv_notes && fields?.inv_notes !== BOOLEAN_DATA.STRINGFALSE) {
      return invoiceDetails?.inv_notes;
    }
    return invoiceDetails?.inv_notes ? invoiceDetails?.inv_notes : specialCharacters.HYPHEN;
  };

  const FFreeTextOrderInvoice = (val: string) => {
    if (val === invoiceLineTypes.FREETEXTORDERLINE) {
      return true;
    }
    return false;
  };

  const fIsStandardLine = (rowData: { [key: string]: any }) => {
    if (rowData) {
      let filteredInvoiceOrderType;
      if (orderno) {
        filteredInvoiceOrderType = invoiceAllOrder?.filter((key) => key.id.toString() === orderno)[0]?.order_type;
      } else {
        filteredInvoiceOrderType = historyState?.invoiceDetails?.order_type ?? orderSelectedRow?.order_type;
      }
      if (rowData.line_type === invoiceLineTypes.INVOICELINE && !FFreeTextOrderInvoice(filteredInvoiceOrderType)) {
        return true;
      }
      return false;
    }
    return false;
  };

  useEffect(() => {
    if (isSuppliersModal) {
      if (invoiceDetails?.invoice_type === invoiceOrderType.pi) {
        if (invoiceDetails?.order_id !== "" && invoiceDetails?.order_id !== null) {
          dispatch(getInvoiceSupplierAll({ clientId: invoiceDetails?.client_id }));
        } else if (invoiceDetails?.sundry_invoice === sundryInvoiceType.t) {
          dispatch(getSundrySuppliersAll({ clientId: invoiceDetails?.client_id }));
        } else {
          dispatch(getInvoiceSupplierAll({ clientId: invoiceDetails?.client_id }));
        }
      } else if (invoiceDetails?.invoice_type === invoiceOrderType.pc) {
        dispatch(getInvoiceSupplierAll({ clientId: invoiceDetails?.client_id }));
      }
    }
  }, [invoiceDetails, isSuppliersModal]);

  const supportingDocumentAPI = async () => {
    const response = await dispatch(supportingDocumentCount(invoiceId));
    if (response?.payload) setSupportingDocument(response?.payload);
  };

  useEffect(() => {
    if (invoiceId) {
      supportingDocumentAPI();
    }
  }, [invoiceId]);

  const getInputStreamFileAPI = async () => {
    const response: any = await dispatch(getInputStreamFile());
    setInputFileStreamObj({
      store_documents_in_database: response.payload.store_documents_in_database,
      use_file_server: response.payload.use_file_server
    });
  };

  useEffect(() => {
    getInputStreamFileAPI();
  }, [invoiceId]);

  const piLineEditClick = () => {
    if (selectedRow?.type === invoiceLineTypes.FREETEXTORDERLINE) {
      setLineType("dtFreeTextInv");
    } else if (
      selectedRow?.line_type === invoiceLineTypes.INVOICELINE &&
      currentInvoiceType === INVOICE_TYPE.ORDERINV
    ) {
      setLineType("dtOrderInv");
    } else if (
      selectedRow?.line_type === invoiceLineTypes.INVOICELINE &&
      currentInvoiceType !== INVOICE_TYPE.ORDERINV
    ) {
      setLineType("dtNonOrderInv");
    } else if (selectedRow?.line_type === invoiceLineTypes.LINETYPEP) {
      setLineType("dtPostAndPacking");
    } else if (selectedRow?.line_type === invoiceLineTypes.LINETYPEV) {
      setLineType("dtVAT");
    }
  };

  useEffect(() => {
    piLineEditClick();
  }, [selectedRow]);

  const updateOldVatValues = (oldVatId: any, oldVatAmt: any, vat_ledger_id: any) => {
    const newVatAmt = 0;
    let newVatLineCost = 0;

    if (oldVatId !== 0) {
      const ledgerId = vat_ledger_id;

      const updateOldVatRow = () => {
        const foundItemAndIndex = historyState?.invoiceLineList
          ?.map((item: any, index: number) => {
            if (item?.ledger_id === ledgerId && item?.line_type === invoiceLineTypes?.LINETYPEV) {
              return { ...item, index };
            }
            return undefined;
          })
          .filter((t: any) => t)
          ?.at(0);
        if (foundItemAndIndex) {
          newVatLineCost = Number(foundItemAndIndex?.line_cost - oldVatAmt);

          if (newVatLineCost <= 0) {
            newVatLineCost = newVatAmt;
          }
          const temp: any = historyState?.invoiceLineList;
          const flag = historyState?.invoiceLineList?.some(
            (t: any) => t?.vat_id && Number(t?.vat_id === oldVatId) && t?.line_cost > 0
          );
          const vatLineIds = historyState?.vatDeletedList ?? [];
          if (flag) {
            temp[foundItemAndIndex?.index] = { ...temp[foundItemAndIndex?.index], line_cost: newVatLineCost };
          } else {
            if (foundItemAndIndex.invoice_line_id) vatLineIds.push(foundItemAndIndex.invoice_line_id);
            temp?.splice(foundItemAndIndex?.index, 1);
          }
          const updateHistory = {
            ...(history.location.state as any),
            vatDeletedList: [...vatLineIds],
            invoiceLineList: [...temp]
          };
          history.replace({ ...history.location, state: updateHistory });
        }
      };
      updateOldVatRow();
    }
  };

  const isDisableOnHold = () => {
    if (invoiceId) {
      switch (invoiceDetails?.status) {
        case INVOICE_STATUS.UNAUTHORISED:
        case INVOICE_STATUS.AUTHORISED:
        case INVOICE_STATUS.FULLY_AUTHORISED:
        case INVOICE_STATUS.PASSED_FOR_PAYMENT:
        case INVOICE_STATUS.PART_AUTHORISED:
        case INVOICE_STATUS.PART_PAID:
        case INVOICE_STATUS.ON_HOLD:
          return false;
        default:
          return true;
      }
    }
    return false;
  };
  const pageTitle = () => {
    if (!invoiceId) {
      if (currentInvoiceType === INVOICE_TYPE.SUNDRYINV) {
        return t("viewInvoiceCreditNote.sundryInvoiceTitle");
      }
      if (currentInvoiceType === INVOICE_TYPE.NONORDERINV) {
        return t("viewInvoiceCreditNote.nonOrderInvoiceTitle");
      }
      if (currentInvoiceType === INVOICE_TYPE?.ORDERINV) {
        return t("viewInvoiceCreditNote.orderInvoicetitle");
      }
    }
    return t("viewInvoiceCreditNote.title");
  };

  const confirmInvoiceModal = async (message: any) =>
    setPromise((resolve: (arg0: boolean) => void) => {
      dispatch(
        uiActions.confirmPopup({
          title: t("alertMessage.title"),
          message,
          yesCallback: () => {
            if (resolve) resolve(true);
          },
          noCallback: () => {
            if (resolve) resolve(false);
          },
          type: MODAL_TYPE.CONFIRMV2
        })
      );
    });

  // This will handle edit route for unauthorized and authorized
  const handleEditRoute = (data?: any) => {
    const supplierPath = getSupplierPath();
    const editable = [INVOICE_STATUS.UNAUTHORISED, INVOICE_STATUS?.AUTHORISED];
    if (!supplierPath && editable.includes(data?.status || listrow?.status)) {
      return "edit-";
    }
    return "";
  };
  //

  const onSubmit = async () => {
    let isError = false;
    let result: boolean;
    const formSumbit = handleSubmit(
      async (data) => {
        let isValid = true;
        const orderId = orderno ?? data?.order_id;
        dispatch(invoiceLineItemAction.setInvoiceLineItemSegregate(historyState?.invoiceLineList));
        // TODO send deleted array in Save Payload
        if (historyState?.vatDeletedList) {
          dispatch(ioActions.setDeleteLine(historyState?.vatDeletedList));
        }

        /**
         * This condition is check wheather supplier is on hold or not, also it will check that the supplier is in use mode
         */

        // For Supplier on hold modal
        if (
          selectedSupplier?.on_hold === BOOLEAN_DATA.True ||
          (selectedSupplier?.in_use === BOOLEAN_DATA.False &&
            currentInvoiceType !== INVOICE_TYPE.ORDERINV &&
            !invoiceId)
        ) {
          if (selectedSupplier?.on_hold === BOOLEAN_DATA.True) {
            setMessage(
              t("invoiceNote.onHoldSupplier", {
                invNumber: watch("disp_inv_no")
              })
            );
          } else {
            setMessage(
              t("invoiceNote.notInUseSupplier", {
                invNumber: watch("disp_inv_no")
              })
            );
          }
          setIsOpenAlert(true);
          isValid = false;
          isError = true;
          return;
        }

        if (
          (Array?.isArray(historyState?.invoiceLineList) && historyState?.invoiceLineList?.length === 0) ||
          getTotalAmountWithVal() === "0.00"
        ) {
          setMessage(t("invoiceNote.invoiceLineTotal"));
          setIsOpenAlert(true);
          isValid = false;
          isError = true;
          return;
        }
        const total = watch("total");
        if (
          parseFloat(String(getTotalAmountWithVal()).replace(/,/g, "")) !==
          Math.abs(parseFloat(total!.replace(/,/g, "")))
        ) {
          result = await confirmInvoiceModal(
            t("invoiceNote.invTotalValidate", {
              totalAmt: getTotalAmountWithVal(),
              invTotal: Math.abs(parseFloat(total!.replace(/,/g, "")))
            })
          );
          if (result) {
            isError = false;
            setValue("total", totalLineItemVal);
          } else {
            isError = true;
            dispatch(invActions.setAllowDuplicateVal(0));
            setValue("total", historyState?.invoiceDetails?.total ?? "");
          }
          setToSession("validateFinancial", true);
          isValid = false;
        }

        if (getSessionItem("validateFinancial") && !invoiceId && watch("inv_date") !== undefined) {
          const invDate = watch("inv_date");
          const partsInv = invDate?.split("/");
          const invSelectedDate = partsInv ? new Date(`${partsInv[2]}-${partsInv[1]}-${partsInv[0]}`) : new Date();
          const yearStartDate = new Date(financialYearInfo?.yearStartDate).toLocaleDateString("en-GB", {
            year: "numeric",
            month: "2-digit",
            day: "2-digit"
          });
          const nextYearStartDate = new Date(financialYearInfo?.nextYearStartDate).toLocaleDateString("en-GB", {
            year: "numeric",
            month: "2-digit",
            day: "2-digit"
          });
          const startDate = convertDateWithLeadingZero(yearStartDate);
          const endDate = convertDateWithLeadingZero(nextYearStartDate);
          if (
            // It will be dynamic based on year selection, need to implement with api call
            invSelectedDate < new Date(startDate) ||
            invSelectedDate >= new Date(endDate)
          ) {
            const invoiceTypeTitle =
              currentInvoiceType === INVOICE_TYPE?.CREDITNOTEINV
                ? t("invoiceNote.invoiceTypeCreditNote")
                : t("invoiceNote.invoice");
            result = await confirmInvoiceModal(
              t("invoiceNote.finYearValidate", {
                invDate,
                invoiceTypeTitle
              })
            );
            if (result) {
              isError = false;
            } else {
              isError = true;
              setValue("total", historyState?.invoiceDetails?.total ?? "");
            }
            setToSession("validateFinancial", false);
            isValid = false;
          }
        }
        if (isValid || result !== false || result === undefined) {
          dispatch(invoiceLineItemAction.setInvoiceLineItemSegregate(historyState?.invoiceLineList));
          await dispatch(
            addInvoice({
              data,
              callback: async (data: any) => {
                setSubmittedData(data);
                if (data.messageType === INVOICE_MSG_TYPE.ONE) {
                  setSaveDuplicateMsg(t("invoiceNote.duplicateFullInvNumber"));
                  setDuplicateInvoice(true);
                }
                if (data.messageType === INVOICE_MSG_TYPE.TWO) {
                  setSaveDuplicateMsg(t("invoiceNote.duplicateInvNumber"));
                  setIsFullInvoiceNoDuplicate(true);
                }
                if (data.validationType === INVOICE_MSG_TYPE.ONE) {
                  setMessage(t(data.message));
                  setIsOpenAlert(true);
                  return;
                }
                if (data.messageType === INVOICE_MSG_TYPE.ZERO) {
                  dispatch(invActions.setAllowDuplicateVal(data.messageType));
                  checkInvoiceTypeAndRedirect(data);
                }
                if (data?.invoiceId !== null) {
                  setIsChanged(false);
                  dispatch(invoiceLineItemAction.setIsInvSaveSuccess(true));
                  dispatch(invoiceLineItemAction.resetInvoiceLineItem());
                  dispatch(invoiceLineItemAction.resetInvoiceVatLineItem());
                  dispatch(invActions.resetInvoiceDetails());
                  dispatch(InvoiceSupplierAction.resetSelectedSupplier());
                  dispatch(InvoiceSupplierAction.resetSelectedRow());
                  dispatch(ioNoteListActions.resetLineParts());
                  const supplierPath = getSupplierPath();
                  let invoiceViewLink: any;

                  if (currentInvoiceType === INVOICE_TYPE.NONORDERINV) {
                    invoiceViewLink = `${supplierPath}/invoice-credit-note/${handleEditRoute(
                      data
                    )}nonorder-invoice/invoiceId/${data?.invoiceId}`;
                  } else if (currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV) {
                    invoiceViewLink = `${supplierPath}/invoice-credit-note/${handleEditRoute(
                      data
                    )}credite-note/invoiceId/${data?.invoiceId}`;
                  } else if (currentInvoiceType === INVOICE_TYPE.ORDERINV) {
                    invoiceViewLink = `${supplierPath}/invoice-credit-note/${handleEditRoute(
                      data
                    )}order-invoice/orderno/${orderId}/invoiceId/${data?.invoiceId}`;
                  }
                  if (invoiceId) {
                    history.push(invoiceViewLink);
                    history.replace({ ...history.location, state: undefined });
                    dispatch(invoiceLineItemAction.setSelectedRow(undefined));
                    /** invoiceIsNext is used for stop navigation if user coming from the next or previous button */
                    if (!getSessionItem("invoiceIsNext")) {
                      setIsRerender(!isRerender);
                    }
                  } else {
                    history.push(invoiceViewLink);
                  }
                }
              }
            })
          );
        }
      },
      (error) => {
        setMessage(t("common.invalidData"));
        setIsOpenAlert(true);
        isError = true;
      }
    );
    await formSumbit();
    return isError;
  };

  const calculatePayByDateAndPostingPeriod = () => {
    if (watch("inv_date") && isFutureDate(watch("inv_date"))) {
      dispatch(
        invoiceGetPayByDate({
          date: watch("inv_date")!,
          callback: (data: any) => {
            if (data && data >= 0 && postingPeriodDetails && postingPeriodDetails.length > 0) {
              const payfrom = postingPeriodDetails.filter((s) => s.code === String(data))[0];
              setValue("period", payfrom?.code);
              setValue("month", payfrom?.description);
              trigger("period");
              trigger("pay_by");
              dispatch(postingPeriodActions.selectPostingPeriod(payfrom));
            } else {
              (async () => {
                const resultFinYear: any = await dispatch(getFinancialYear(getCurrentFinancialYear()));
                if (resultFinYear?.meta.requestStatus === RESPONSE_STATUS.FULFILLED) {
                  const payfrom = postingPeriodDetails.filter(
                    (s) => s.code === String(resultFinYear?.payload?.lowest_ap)
                  )[0];
                  setValue("period", payfrom?.code);
                  setValue("month", payfrom?.description);
                  trigger("period");
                  trigger("pay_by");
                  dispatch(postingPeriodActions.selectPostingPeriod(payfrom));
                }
              })();
            }
          }
        })
      );
      if (
        selectedSupplier &&
        watch("inv_date") !== undefined &&
        (watch("pay_by") === "" || !isPayByDateFuture(watch("pay_by")))
      ) {
        const paidValue = addDaysToDate(watch("inv_date")!, selectedSupplier.credit_terms);
        setValue("pay_by", formatToTwoDigits(paidValue));
      } else if (!selectedSupplier && watch("inv_date") !== undefined) {
        setValue("pay_by", formatToTwoDigits(watch("inv_date")));
      }
    }
  };

  const updateLinesInHistory = (list: any) => {
    const updatedHistory = {
      ...(history.location.state as any),
      invoiceLineList: list
    };
    history.replace({ ...history.location, state: updatedHistory });
  };

  const clearHistoryState = () => {
    history.replace({ ...history.location, state: undefined });
  };

  // This function is being used for only order invoice while creating
  const submitOrderNumber = async (row: any, submitFrom?: string) => {
    if (!row) return;
    dispatch(coActions.setOrderSelectedRow(row));
    setValue("ordernum", row?.code); // order display in UI
    setValue("order_id", row?.id); // save order id for payload
    const foundSupp = suppliersList?.clientDetails?.find((t: any) => t?.client_id === row.client_id);
    const foundPayfrom = paymentDetails.find((s) => s.id === row?.bank_id);
    if (foundPayfrom) dispatch(payFromActions.selectPaymentMethod(foundPayfrom));
    if (submitFrom !== "suggested") {
      if (foundSupp) dispatch(InvoiceSupplierAction?.setSelectedRow(foundSupp));
    }
    const list: any = await dispatch(getInvoiceNoteLineItem({ invoiceID: null, OrderId: row?.id }));
    if (list?.payload) updateLinesInHistory(list?.payload);
    const res: any = await dispatch(orderlastUpdateVal(row?.id));
    if (res?.payload) setValue("ord_last_update", res?.payload?.last_update);
  };

  const handleSelectedPostingPeriod = (selectedItem: any) => {
    const payfrom = postingPeriodDetails.filter((s) => s.id === selectedItem?.value)[0];
    if (selectedItem?.text) {
      setValue("period", String(selectedItem.text));
      setValue("month", payfrom.description);
    } else {
      setValue("period", "");
      setValue("month", "");
    }
    dispatch(postingPeriodActions.selectPostingPeriod(payfrom));
  };
  const updatedHistoryState = {
    ...(history.location.state as any)
  };
  const getTotalVal = () => {
    if (Array.isArray(updatedHistoryState?.invoiceLineList) && updatedHistoryState?.invoiceLineList.length > 0) {
      const totalScore = updatedHistoryState?.invoiceLineList?.reduce((acc: any, t: any) => {
        if (t?.line_type === invoiceLineTypes?.LINETYPEV) {
          return Number(acc + Number(t?.line_cost));
        }
        return acc;
      }, 0);
      return numberFormatter.format(totalScore);
    }
    return numberFormatter.format(0);
  };

  const getTotalAmountWithVal = () => {
    if (Array.isArray(updatedHistoryState?.invoiceLineList) && updatedHistoryState?.invoiceLineList.length > 0) {
      let itemTotal: any;
      const totalScoreInvoiceLine: any = updatedHistoryState?.invoiceLineList?.reduce(
        (acc: any, cost: any) => acc + Number(cost.line_cost),
        0
      );
      if (invoiceLineItemVat.length > 0) {
        const totalScoreVat: any = invoiceLineItemVat?.reduce((acc, cost) => acc + Number(cost.line_cost), 0);
        itemTotal = numberFormatter.format(parseFloat(totalScoreInvoiceLine) + parseFloat(totalScoreVat));
        return itemTotal;
      }
      itemTotal = numberFormatter.format(totalScoreInvoiceLine);
      dispatch(invActions.addLineItemTotal(itemTotal));
      return itemTotal;
    }
    return numberFormatter.format(0);
  };

  const isFutureDate = (dateString: any) => {
    // Assuming dateString is in format YYYY-MM-DD
    const parts = dateString.split("/");
    const selectedDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
    const today = new Date();
    return selectedDate < today;
  };
  const isPayByDateFuture = (dateString: any) => {
    // Assuming dateString is in format YYYY-MM-DD
    if (watch("inv_date") && isFutureDate(watch("inv_date"))) {
      const parts = dateString.split("/");
      const selectedDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
      const invDate = watch("inv_date");
      const partsInv = invDate?.split("/");
      if (partsInv !== undefined) {
        const invSelectedDate = new Date(`${partsInv[2]}-${partsInv[1]}-${partsInv[0]}`);
        return selectedDate >= invSelectedDate;
      }
      return false;
    }
    return true;
  };

  const getOrderInvTotalVal = () => {
    const totalVal = watch("total");
    if (currentInvoiceType === INVOICE_TYPE.ORDERINV && totalVal !== null && totalVal !== undefined) {
      return String(Math.abs(parseFloat(totalVal)));
    }
    return String(0);
  };

  const isInvoiceTotalFocus = () => {
    if (
      invoiceDetails?.status === INVOICE_STATUS.AUTHORISED ||
      invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED
    ) {
      return true;
    }
    return false;
  };
  useEffect(() => {
    setTimeout(() => {
      invoiceFocusField();
    }, 500);
  }, [invoiceNoteLineItem]);
  const invoiceOrderNonOrderRender = () => {
    // Sundry, Non Order, credit invoiceINVOICE_TYPE.NONORDERINV
    // Non-Order
    if (currentInvoiceType === INVOICE_TYPE.NONORDERINV || currentInvoiceType === INVOICE_TYPE.SUNDRYINV) {
      return (
        <>
          <Grid className="mt-8">
            <GridItem
              lg={4}
              xl={4}
            >
              <InputDate
                searchable={false}
                dateSeparator={dateSeparator.forwardSlash}
                labelText={
                  invoiceDetails?.invoice_type === "PC"
                    ? t("invoiceNote.creditDate")
                    : t("viewInvoiceCreditNote.invoiceDate")
                }
                id="invoiceDate"
                value={watch("inv_date")}
                className={fields?.inv_date === "false" ? "not-in-use" : ""}
                inputRef={(e) => register("inv_date").ref(e)}
                name={
                  register("inv_date", {
                    required: true,
                    validate: (value) => isFutureDate(value)
                  }).name
                }
                onDateChange={(date) => {
                  setValue("inv_date", date);
                }}
                onBlur={(e: any) => {
                  setValue("inv_date", e as any);
                  trigger("inv_date");
                  calculatePayByDateAndPostingPeriod();
                }}
                validationTextLevel={errors.inv_date ? ValidationTextLevel.Error : undefined}
                disabled={fields?.inv_date === "false"}
              />
            </GridItem>
            {invoiceDetails?.order_id ? (
              <GridItem
                lg={4}
                xl={4}
              >
                {!invoiceDetails?.order_id && invoiceDetails?.invoice_type === "PC" ? (
                  <>
                    <Input
                      id="invoiceNumber"
                      searchable={false}
                      labelText={t("viewInvoiceCreditNote.invoiceNumber")}
                      value={getValues("matched_inv_no")}
                      button={
                        <>
                          <Button
                            color={ButtonColor.Secondary}
                            onClick={() => {}}
                            className={
                              invoiceDetails.status === INVOICE_STATUS.AUTHORISED ||
                              invoiceDetails.status === INVOICE_STATUS.UNAUTHORISED
                                ? "essui-button-icon-only--small"
                                : "essui-button-icon-only--small disabled"
                            }
                            disabled={
                              !(
                                invoiceDetails.status === INVOICE_STATUS.AUTHORISED ||
                                invoiceDetails.status === INVOICE_STATUS.UNAUTHORISED
                              )
                            }
                            size={ButtonSize.Small}
                          >
                            <Icon
                              color={IconColor.Primary500}
                              size={IconSize.Medium}
                              name="search"
                            />
                          </Button>
                        </>
                      }
                      className={fields?.matched_inv_no === "false" ? "not-in-use" : ""}
                      disabled={fields?.matched_inv_no === "false"}
                    />
                  </>
                ) : (
                  ""
                )}
              </GridItem>
            ) : null}
            <GridItem
              lg={4}
              xl={4}
            >
              <FormLabel>{t("viewInvoiceCreditNote.source")}</FormLabel>
              <div className="essui-textinput essui-textinput--medium border-0 playback">
                {getValues("source") ? getValues("source") : specialCharacters.HYPHEN}
              </div>
            </GridItem>
            <GridItem
              lg={4}
              xl={4}
            >
              <FormLabel className={`${fields?.total === "false" ? "mb-16" : ""}`}>
                {invoiceDetails?.invoice_type === "PC"
                  ? t("viewInvoiceCreditNote.creditNoteTotal")
                  : t("viewInvoiceCreditNote.invoiceTotal")}
              </FormLabel>
              {fields?.total === "false" ? (
                <span className="mt-8">{usNumberFormat(Number(watch("total")))}</span>
              ) : (
                <NumberInput
                  id=""
                  autoFocus={isInvoiceTotalFocus()}
                  defaultValue={watch("total") || "0.00"}
                  className={fields?.total === "false" ? "not-in-use" : ""}
                  disabled={fields?.total === "false"}
                  decimals={2}
                  maxLength={12}
                  name={
                    register("total", {
                      required: true,
                      validate: (value) => value !== "0.00"
                    }).name
                  }
                  onChange={(e) => {
                    if (e.target.value === KEYBOARD_STRING.Zero || e.target.value === KEYBOARD_STRING.DecimalZero) {
                      register("total").onChange(e);
                      setValue("total", "0.00", { shouldDirty: true });
                      trigger("total");
                    } else {
                      register("total").onChange(e);
                      setValue("total", e.target.value, { shouldDirty: true });
                      trigger("total");
                    }
                  }}
                  onBlur={() => trigger("total")}
                  inputRef={(e) => register("total").ref(e)}
                  validationTextLevel={errors.total ? ValidationTextLevel.Error : undefined}
                />
              )}
            </GridItem>
          </Grid>
          <Grid className="mt-8">
            <GridItem
              lg={4}
              xl={4}
            >
              {invoiceDetails?.invoice_type === "PC" ? (
                ""
              ) : (
                <>
                  <InputDate
                    id="invoicePayByDate"
                    searchable={false}
                    dateSeparator={dateSeparator.forwardSlash}
                    labelText={t("viewInvoiceCreditNote.paidByDate")}
                    value={watch("pay_by")}
                    className={fields?.pay_by === "false" ? "not-in-use" : ""}
                    inputRef={(e) => register("pay_by").ref(e)}
                    disabled={fields?.pay_by === "false"}
                    name={
                      register("pay_by", {
                        required: true,
                        validate: (value) => isPayByDateFuture(value)
                      }).name
                    }
                    onDateChange={(date, e) => {
                      setValue("pay_by", date, { shouldDirty: true });
                      register("pay_by").onChange(e);
                    }}
                    onBlur={(e: any) => {
                      setValue("pay_by", e as any);
                      trigger("pay_by");
                    }}
                    validationTextLevel={errors.pay_by ? ValidationTextLevel.Error : undefined}
                  />
                </>
              )}
            </GridItem>
            <GridItem
              lg={4}
              xl={4}
            >
              <Input
                id="payFrom"
                searchable
                disabled={!!invoiceId}
                className={invoiceId ? "mode--disabled" : ""}
                labelText={
                  invoiceDetails?.invoice_type === "PC"
                    ? t("viewInvoiceCreditNote.payTo")
                    : t("viewInvoiceCreditNote.payFrom")
                }
                value={watch("bank_description")}
                searchItems={paymentDetails.map((p) => ({ text: p?.code, value: p?.id }))}
                onSelect={(selectedItem) => {
                  const payfrom = paymentDetails.filter((s) => s.id === selectedItem?.value)[0];
                  if (selectedItem?.text) {
                    setValue("bank_description", selectedItem.text!);
                    setValue("bank_id", payfrom?.id);
                  }
                  dispatch(payFromActions.selectPaymentMethod(payfrom));
                }}
                onNoSelection={() => {
                  setIsPayFromModalOpen(true);
                  setValue("bank_description", "");
                  setValue("bank_id", "");
                }}
                onBlur={() => trigger("bank_description")}
                onChange={(e) => {
                  register("bank_description").onChange(e);
                  if (!e.target.value) {
                    dispatch(payFromActions.selectPaymentMethod(undefined));
                  }
                }}
                button={
                  <Button
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      setIsPayFromModalOpen(true);
                    }}
                    className={
                      invoiceId ? "essui-button-icon-only--small mode--disabled" : "essui-button-icon-only--small"
                    }
                    disabled={fields?.eiBrPayFrom?.enable === false}
                    size={ButtonSize.Small}
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                }
                inputRef={(e) => register("bank_description").ref(e)}
                name={register("bank_description", { required: true }).name}
                validationTextLevel={errors.bank_description ? ValidationTextLevel.Error : undefined}
              />
            </GridItem>
            <GridItem
              lg={4}
              xl={4}
              className="posting-period"
            >
              {!isCentralProcessed ? (
                <Input
                  id="postingPeriod"
                  searchable
                  labelText={t("viewInvoiceCreditNote.postingPeriod")}
                  inputWidth={45}
                  searchItems={(postingPeriodDetails || []).map((p) => ({ text: p?.code, value: p?.id }))}
                  onSelect={(selectedItem) => {
                    handleSelectedPostingPeriod(selectedItem);
                  }}
                  onNoSelection={() => {
                    setPostingPeriodModalOpen(true);
                  }}
                  onChange={(e) => {
                    setValue("period", e.target.value);
                    register("period").onChange(e);
                    if (!e.target.value) {
                      dispatch(postingPeriodActions.selectPostingPeriod(undefined));
                      setValue("month", specialCharacters.BLANKVALUE);
                    }
                  }}
                  onBlur={() => trigger("period")}
                  className={fields?.period === "false" ? "mode--disabled" : ""}
                  disabled={fields?.period === "false"}
                  value={getValues("period")}
                  inputRef={(e) => register("period").ref(e)}
                  name={register("period", { required: true }).name}
                  validationTextLevel={errors.period ? ValidationTextLevel.Error : undefined}
                  onPending={handlePostingPendingState}
                  button={
                    <>
                      <TextInput
                        id="desc"
                        className={`width55 ${fields?.period === "false" ? "disabled" : ""}`}
                        value={getValues("month")}
                        name={register("month", { required: true }).name}
                        onChange={(e) => {
                          register("month").onChange(e);
                        }}
                        disabled
                      />

                      <Button
                        color={ButtonColor.Secondary}
                        onClick={() => {
                          setPostingPeriodModalOpen(true);
                        }}
                        className={
                          invoiceId ? "essui-button-icon-only--small mode--disabled" : "essui-button-icon-only--small"
                        }
                        disabled={!!invoiceId}
                        size={ButtonSize.Small}
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                />
              ) : null}
            </GridItem>
          </Grid>
        </>
      );
    }
    // Credit Note
    if (currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV) {
      return (
        <>
          <Grid className="mt-8">
            <GridItem
              lg={4}
              xl={4}
            >
              <InputDate
                searchable={false}
                dateSeparator={dateSeparator.forwardSlash}
                labelText={
                  invoiceDetails?.invoice_type === "PC"
                    ? t("invoiceNote.creditDate")
                    : t("viewInvoiceCreditNote.invoiceDate")
                }
                id="invoiceDate"
                value={watch("inv_date")}
                className={fields?.inv_date === "false" ? "not-in-use" : ""}
                inputRef={(e) => register("inv_date").ref(e)}
                name={
                  register("inv_date", {
                    required: true,
                    validate: (value) => isFutureDate(value)
                  }).name
                }
                onDateChange={(date) => {
                  setValue("inv_date", date);
                }}
                onBlur={(e: any) => {
                  setValue("inv_date", e as any);
                  trigger("inv_date");
                  calculatePayByDateAndPostingPeriod();
                }}
                validationTextLevel={errors.inv_date ? ValidationTextLevel.Error : undefined}
                disabled={fields?.inv_date === BOOLEAN_DATA?.STRINGFALSE}
              />
            </GridItem>
            <GridItem
              lg={4}
              xl={4}
            >
              {invoiceDetails?.invoice_type === "PC" || currentInvoiceType === INVOICE_TYPE?.CREDITNOTEINV ? (
                <>
                  <Input
                    id="invoiceNumber"
                    className={fields?.matched_inv_no === "false" ? "mode--disabled" : ""}
                    disabled={fields?.matched_inv_no === "false"}
                    searchable
                    labelText={t("viewInvoiceCreditNote.invoiceNumber")}
                    value={watch("matched_inv_no")}
                    name={register("matched_inv_no").name}
                    searchItems={matchedInvoiceDetails.map((p) => ({ text: p?.code, value: p?.id }))}
                    onSelect={(selectedItem) => {
                      const payfrom = paymentDetails.filter((s) => s.id === selectedItem?.value)[0];
                      if (selectedItem?.text) {
                        setValue("matched_inv_no", selectedItem.text!);
                      }
                      dispatch(matchedInvoice.selectMatchedInvoice(payfrom));
                    }}
                    onNoSelection={() => {
                      setIsMatchedInvoiceModal(true);
                      setValue("matched_inv_no", "");
                      setValue("matched_inv_id", "");
                    }}
                    onBlur={() => trigger("matched_inv_no")}
                    onChange={(e) => {
                      register("matched_inv_no").onChange(e);
                      if (!e.target.value) {
                        dispatch(matchedInvoice.selectMatchedInvoice(""));
                      }
                    }}
                    button={
                      <>
                        <Button
                          color={ButtonColor.Secondary}
                          onClick={() => setIsMatchedInvoiceModal(true)}
                          className={
                            fields?.matched_inv_no === "false"
                              ? "essui-button-icon-only--small mode--disabled"
                              : "essui-button-icon-only--small"
                          }
                          disabled={fields?.matched_inv_no === "false"}
                          size={ButtonSize.Small}
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="search"
                          />
                        </Button>
                      </>
                    }
                  />
                </>
              ) : (
                ""
              )}
            </GridItem>
            <GridItem
              lg={4}
              xl={4}
            >
              <FormLabel>{t("viewInvoiceCreditNote.source")}</FormLabel>
              <div className="essui-textinput essui-textinput--medium border-0 playback">
                {getValues("source") ? getValues("source") : specialCharacters.HYPHEN}
              </div>
            </GridItem>

            <Grid className="mt-8" />
            <GridItem
              lg={4}
              xl={4}
            >
              <FormLabel className={`${fields?.total === "false" ? "mb-16" : ""}`}>
                {invoiceDetails?.invoice_type === "PC" || currentInvoiceType === INVOICE_TYPE?.CREDITNOTEINV
                  ? t("viewInvoiceCreditNote.creditNoteTotal")
                  : t("viewInvoiceCreditNote.invoiceTotal")}
              </FormLabel>
              {fields?.total === "false" ? (
                <span>{usNumberFormat(Number(watch("total")))}</span>
              ) : (
                <NumberInput
                  id=""
                  autoFocus={isInvoiceTotalFocus()}
                  defaultValue={watch("total")}
                  decimals={2}
                  maxLength={12}
                  className={fields?.total === "false" ? "not-in-use" : ""}
                  disabled={fields?.total === "false"}
                  name={
                    register("total", {
                      required: true,
                      validate: (value) => value !== "0.00"
                    }).name
                  }
                  onChange={(e) => {
                    if (e.target.value === KEYBOARD_STRING.Zero || e.target.value === KEYBOARD_STRING.DecimalZero) {
                      register("total").onChange(e);
                      setValue("total", "0.00", { shouldDirty: true });
                      trigger("total");
                    } else {
                      register("total").onChange(e);
                      setValue("total", e.target.value, { shouldDirty: true });
                      trigger("total");
                    }
                  }}
                  onBlur={() => trigger("total")}
                  inputRef={(e) => register("total").ref(e)}
                  validationTextLevel={errors.total ? ValidationTextLevel.Error : undefined}
                />
              )}
            </GridItem>
            <GridItem
              lg={4}
              xl={4}
            >
              <Input
                id="payFrom"
                searchable
                className={fields?.bank_description === "false" ? "mode--disabled" : ""}
                disabled={fields?.bank_description === "false"}
                labelText={
                  invoiceDetails?.invoice_type === "PC" || currentInvoiceType === INVOICE_TYPE?.CREDITNOTEINV
                    ? t("viewInvoiceCreditNote.payTo")
                    : t("viewInvoiceCreditNote.payFrom")
                }
                value={watch("bank_description")}
                searchItems={paymentDetails.map((p) => ({ text: p?.code, value: p?.id }))}
                onSelect={(selectedItem) => {
                  const payfrom = paymentDetails.filter((s) => s.id === selectedItem?.value)[0];
                  if (selectedItem?.text) {
                    setBankName(selectedItem?.text);
                    setValue("bank_description", selectedItem.text!);
                    setValue("bank_id", payfrom?.id);
                  }
                  dispatch(payFromActions.selectPaymentMethod(payfrom));
                }}
                onNoSelection={() => {
                  setIsPayFromModalOpen(true);
                  setValue("bank_description", "");
                  setValue("bank_id", "");
                }}
                onBlur={() => trigger("bank_description")}
                onChange={(e) => {
                  register("bank_description").onChange(e);
                  if (!e.target.value) {
                    dispatch(payFromActions.selectPaymentMethod(undefined));
                  }
                }}
                button={
                  <Button
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      setIsPayFromModalOpen(true);
                    }}
                    className={
                      fields?.bank_description === "false"
                        ? "essui-button-icon-only--small mode--disabled"
                        : "essui-button-icon-only--small"
                    }
                    disabled={fields?.bank_description === "false"}
                    size={ButtonSize.Small}
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                }
                inputRef={(e) => register("bank_description").ref(e)}
                name={register("bank_description", { required: true }).name}
                validationTextLevel={errors.bank_description ? ValidationTextLevel.Error : undefined}
              />
            </GridItem>

            <GridItem
              lg={4}
              xl={4}
              className="posting-period"
            >
              {!isCentralProcessed ? (
                <Input
                  id="postingPeriod"
                  searchable
                  labelText={t("viewInvoiceCreditNote.postingPeriod")}
                  inputWidth={45}
                  searchItems={(postingPeriodDetails || []).map((p) => ({ text: p?.code, value: p?.id }))}
                  onSelect={(selectedItem) => {
                    const payfrom = postingPeriodDetails.filter((s) => s.id === selectedItem?.value)[0];
                    if (selectedItem?.text) {
                      setValue("period", String(selectedItem.text));
                      setValue("month", payfrom.description);
                    } else {
                      setValue("period", "");
                      setValue("month", "");
                    }
                    dispatch(postingPeriodActions.selectPostingPeriod(payfrom));
                  }}
                  onNoSelection={() => {
                    setPostingPeriodModalOpen(true);
                  }}
                  onChange={(e) => {
                    setValue("period", e.target.value);
                    register("period").onChange(e);
                    if (!e.target.value) {
                      dispatch(postingPeriodActions.selectPostingPeriod(undefined));
                      setValue("month", specialCharacters.BLANKVALUE);
                    }
                  }}
                  onPending={handlePostingPendingState}
                  onBlur={() => trigger("period")}
                  className={fields?.period === "false" ? "mode--disabled" : ""}
                  disabled={fields?.period === "false"}
                  value={getValues("period")}
                  inputRef={(e) => register("period").ref(e)}
                  name={register("period", { required: true }).name}
                  validationTextLevel={errors.period ? ValidationTextLevel.Error : undefined}
                  button={
                    <>
                      <TextInput
                        id="desc"
                        className={`width55 ${fields?.period === "false" ? " disabled" : ""}`}
                        value={getValues("month")}
                        name={register("month", { required: true }).name}
                        onChange={(e) => {
                          register("month").onChange(e);
                        }}
                        disabled
                      />

                      <Button
                        color={ButtonColor.Secondary}
                        onClick={() => {
                          setPostingPeriodModalOpen(true);
                        }}
                        className={
                          fields?.period === "false"
                            ? "essui-button-icon-only--small mode--disabled"
                            : "essui-button-icon-only--small"
                        }
                        disabled={fields?.period === "false"}
                        size={ButtonSize.Small}
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                />
              ) : null}
            </GridItem>
          </Grid>
        </>
      );
    }
    // Order Invoice
    return (
      <>
        <Grid className="mt-8">
          <GridItem
            lg={4}
            xl={4}
          >
            <InputDate
              searchable={false}
              dateSeparator={dateSeparator.forwardSlash}
              labelText={
                invoiceDetails?.invoice_type === "PC"
                  ? t("invoiceNote.creditDate")
                  : t("viewInvoiceCreditNote.invoiceDate")
              }
              id="invoiceDate"
              value={watch("inv_date")}
              className={fields?.inv_date === "false" ? "not-in-use" : ""}
              inputRef={(e) => register("inv_date").ref(e)}
              name={
                register("inv_date", {
                  required: true,
                  validate: (value) => isFutureDate(value)
                }).name
              }
              onDateChange={(date) => {
                setValue("inv_date", date);
              }}
              onBlur={(e: any) => {
                setValue("inv_date", e as any);
                trigger("inv_date");
                calculatePayByDateAndPostingPeriod();
              }}
              validationTextLevel={errors.inv_date ? ValidationTextLevel.Error : undefined}
              disabled={fields?.inv_date === "false"}
            />
          </GridItem>
          <GridItem
            lg={4}
            xl={4}
          >
            <Input
              id="orderNumber"
              searchable
              disabled={!!invoiceId || method === METHOD?.EDIT || getSessionItem("isHotKey")}
              className={invoiceId || method === METHOD?.EDIT ? "mode--disabled" : ""}
              labelText={t("viewInvoiceCreditNote.orderNumber")}
              value={watch("ordernum")}
              searchItems={orderBrowseDetail.map((p: any) => ({ text: p?.code, value: p?.id }))}
              onSelect={(selectedItem) => {
                setSelectedFromOrder(true);
                const found = orderBrowseDetail.find((s: any) => s.id === selectedItem?.value);
                if (found) {
                  submitOrderNumber(found);
                }
              }}
              onNoSelection={() => {
                setOrderBrowseModal(true);
              }}
              onBlur={() => trigger("ordernum")}
              onChange={(e) => {
                register("ordernum").onChange(e);
                if (!e.target.value) {
                  dispatch(coActions.setOrderSelectedRow(undefined));
                  submitOrderNumber(undefined);
                }
              }}
              button={
                <>
                  <Button
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      setOrderBrowseModal(true);
                    }}
                    disabled={!isOrderModeAdd || method === METHOD?.EDIT || getSessionItem("isHotKey")}
                    className={`${
                      !isOrderModeAdd || method === METHOD?.EDIT
                        ? "essui-button-icon-only--small mode--disabled"
                        : "essui-button-icon-only--small"
                    }`}
                    size={ButtonSize.Small}
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                  {getSessionItem("isHotKey") ? (
                    <div className="hot-key-class" />
                  ) : (
                    <Button
                      color={ButtonColor.Secondary}
                      onClick={() => {}}
                      className="btnclass orderview-child-align-center essui-button-icon-only--small"
                      size={ButtonSize.Small}
                      disabled={!orderPrefixDetail?.order_prefix && !invoiceDetails?.order_prefix}
                    >
                      <Icon
                        color={IconColor.Primary500}
                        size={IconSize.Medium}
                        name="view"
                        onClick={() => openOrderViewPage()}
                      />
                    </Button>
                  )}
                  <Button
                    color={ButtonColor.Secondary}
                    className={`btnclass essui-button-icon-only--small orderview-child-align-center ${
                      isDisabled ? "" : null
                    }`}
                    size={ButtonSize.Small}
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      onClick={() => setIsInvoiceDifferences(true)}
                      name="warning--alt"
                    />
                  </Button>
                </>
              }
              inputRef={(e) => register("ordernum").ref(e)}
              name={register("ordernum", { required: true }).name}
              validationTextLevel={errors.ordernum ? ValidationTextLevel.Error : undefined}
            />
          </GridItem>
        </Grid>

        <Grid className="mt-8">
          <GridItem
            lg={4}
            xl={4}
          >
            <FormLabel>{t("viewInvoiceCreditNote.source")}</FormLabel>
            <div className="essui-textinput essui-textinput--medium border-0 playback">
              {getValues("source") ? getValues("source") : specialCharacters.HYPHEN}
            </div>
          </GridItem>

          <GridItem
            lg={4}
            xl={4}
          >
            <FormLabel className={`${fields?.total === "false" ? "mb-16" : ""}`}>
              {invoiceDetails?.invoice_type === "PC" || currentInvoiceType === INVOICE_TYPE?.CREDITNOTEINV
                ? t("viewInvoiceCreditNote.creditNoteTotal")
                : t("viewInvoiceCreditNote.invoiceTotal")}
            </FormLabel>
            {fields?.total === "false" ? (
              <span className="mt-8">{usNumberFormat(Number(watch("total")))}</span>
            ) : (
              <NumberInput
                id=""
                autoFocus={isInvoiceTotalFocus()}
                defaultValue={getOrderInvTotalVal()}
                decimals={2}
                maxLength={12}
                className={fields?.total === "false" ? "not-in-use" : ""}
                disabled={fields?.total === "false"}
                name={
                  register("total", {
                    required: true,
                    validate: (value) => value !== "0.00"
                  }).name
                }
                onChange={(e) => {
                  if (e.target.value === KEYBOARD_STRING.Zero || e.target.value === KEYBOARD_STRING.DecimalZero) {
                    register("total").onChange(e);
                    setValue("total", "0.00", { shouldDirty: true });
                    trigger("total");
                  } else {
                    register("total").onChange(e);
                    setValue("total", e.target.value, { shouldDirty: true });
                    trigger("total");
                  }
                }}
                onBlur={() => trigger("total")}
                inputRef={(e) => register("total").ref(e)}
                validationTextLevel={errors.total ? ValidationTextLevel.Error : undefined}
              />
            )}
          </GridItem>
          <GridItem
            lg={4}
            xl={4}
          >
            {invoiceDetails?.invoice_type === "PC" ? (
              ""
            ) : (
              <>
                <InputDate
                  id="invoicePayByDate"
                  searchable={false}
                  dateSeparator={dateSeparator.forwardSlash}
                  labelText={t("viewInvoiceCreditNote.paidByDate")}
                  value={watch("pay_by")}
                  className={fields?.pay_by === "false" ? "not-in-use" : ""}
                  inputRef={(e) => register("pay_by").ref(e)}
                  disabled={fields?.pay_by === "false"}
                  name={
                    register("pay_by", {
                      required: true,
                      validate: (value) => isPayByDateFuture(value)
                    }).name
                  }
                  onDateChange={(date, e) => {
                    setValue("pay_by", date, { shouldDirty: true });
                    register("pay_by").onChange(e);
                  }}
                  onBlur={(e: any) => {
                    setValue("pay_by", e as any);
                    trigger("pay_by");
                  }}
                  validationTextLevel={errors.pay_by ? ValidationTextLevel.Error : undefined}
                />
              </>
            )}
          </GridItem>
        </Grid>

        <Grid className="mt-8">
          <GridItem
            lg={4}
            xl={4}
          >
            <Input
              id="payFrom"
              searchable
              disabled={!!invoiceId}
              className={invoiceId ? "mode--disabled" : ""}
              labelText={
                invoiceDetails?.invoice_type === "PC"
                  ? t("viewInvoiceCreditNote.payTo")
                  : t("viewInvoiceCreditNote.payFrom")
              }
              value={watch("bank_description")}
              searchItems={paymentDetails.map((p) => ({ text: p?.code, value: p?.id }))}
              onSelect={(selectedItem) => {
                const payfrom = paymentDetails.find((s) => s.id === selectedItem?.value);
                if (selectedItem?.text) {
                  setValue("bank_description", selectedItem.text!);
                  setValue("bank_id", payfrom?.id);
                }
                dispatch(payFromActions.selectPaymentMethod(payfrom));
              }}
              onNoSelection={() => {
                setIsPayFromModalOpen(true);
                setValue("bank_description", "");
                setValue("bank_id", "");
              }}
              onBlur={() => trigger("bank_description")}
              onChange={(e) => {
                register("bank_description").onChange(e);
                if (!e.target.value) {
                  clearPayToRow();
                }
              }}
              button={
                <Button
                  color={ButtonColor.Secondary}
                  onClick={() => {
                    setIsPayFromModalOpen(true);
                  }}
                  className={
                    invoiceId ? "essui-button-icon-only--small mode--disabled" : "essui-button-icon-only--small"
                  }
                  disabled={fields?.eiBrPayFrom?.enable === false}
                  size={ButtonSize.Small}
                >
                  <Icon
                    color={IconColor.Primary500}
                    size={IconSize.Medium}
                    name="search"
                  />
                </Button>
              }
              inputRef={(e) => register("bank_description").ref(e)}
              name={register("bank_description", { required: true }).name}
              validationTextLevel={errors.bank_description ? ValidationTextLevel.Error : undefined}
            />
          </GridItem>

          <GridItem
            lg={4}
            xl={4}
            className="posting-period"
          >
            {!isCentralProcessed ? (
              <Input
                id="postingPeriod"
                searchable
                labelText={t("viewInvoiceCreditNote.postingPeriod")}
                inputWidth={45}
                searchItems={(postingPeriodDetails || []).map((p) => ({ text: p?.code, value: p?.id }))}
                onSelect={(selectedItem) => {
                  const payfrom = postingPeriodDetails.filter((s) => s.id === selectedItem?.value)[0];
                  if (selectedItem?.text) {
                    setValue("period", String(selectedItem.text));
                    setValue("month", payfrom.description);
                  } else {
                    setValue("period", "");
                    setValue("month", "");
                  }
                  dispatch(postingPeriodActions.selectPostingPeriod(payfrom));
                }}
                onNoSelection={() => {
                  setPostingPeriodModalOpen(true);
                }}
                onChange={(e) => {
                  setValue("period", e.target.value);
                  register("period").onChange(e);
                  if (!e.target.value) {
                    dispatch(postingPeriodActions.selectPostingPeriod(undefined));
                    setValue("month", specialCharacters.BLANKVALUE);
                  }
                }}
                onPending={handlePostingPendingState}
                className={fields?.period === "false" ? "mode--disabled" : ""}
                disabled={fields?.period === "false"}
                value={getValues("period")}
                inputRef={(e) => register("period").ref(e)}
                name={register("period", { required: true }).name}
                onBlur={() => trigger("period")}
                validationTextLevel={errors.period ? ValidationTextLevel.Error : undefined}
                button={
                  <>
                    <TextInput
                      id="desc"
                      className={`width55 ${fields?.period === "false" ? " disabled" : ""}`}
                      value={getValues("month")}
                      name={register("month", { required: true }).name}
                      onChange={(e) => {
                        register("month").onChange(e);
                      }}
                      disabled
                    />

                    <Button
                      color={ButtonColor.Secondary}
                      onClick={() => {
                        setPostingPeriodModalOpen(true);
                      }}
                      className={
                        invoiceId ? "essui-button-icon-only--small mode--disabled" : "essui-button-icon-only--small"
                      }
                      disabled={!!invoiceId}
                      size={ButtonSize.Small}
                    >
                      <Icon
                        color={IconColor.Primary500}
                        size={IconSize.Medium}
                        name="search"
                      />
                    </Button>
                  </>
                }
              />
            ) : null}
          </GridItem>
        </Grid>
      </>
    );
  };

  const validateLine = () => {
    if (watch("inv_date") && selectedSupplier) {
      const invSupplierOpenedDate = splitDateFromTtoNormal(selectedSupplier?.opened);
      const invDate = watch("inv_date");
      const partsInv = invDate?.split("/");
      if (partsInv !== undefined) {
        const invSelectedDate = new Date(`${partsInv[2]}-${partsInv[1]}-${partsInv[0]}`);
        if (currentInvoiceType !== INVOICE_TYPE.CREDITNOTEINV) {
          if (invSelectedDate.getTime() < invSupplierOpenedDate.getTime()) {
            setMessage(
              t("invoiceNote.supplierAccountDateValidate", {
                invSupDate: dateConvertInDDslashMMslashYYYY(invSupplierOpenedDate, "")
              })
            );
            setIsOpenAlert(true);
            return false;
          }
        } else if (currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV) {
          if (invSelectedDate.getTime() < invSupplierOpenedDate.getTime()) {
            setMessage(
              t("invoiceNote.supplierAccountDateValidate", {
                invSupDate: dateConvertInDDslashMMslashYYYY(invSupplierOpenedDate, "")
              })
            );
            setIsOpenAlert(true);
            return false;
          }
        }
      }
    }
    return true;
  };

  const handleLineItemDetails = (METHODS: string | undefined, lineType?: string, selectedIndex?: number) => {
    const validateLineItem = validateLine();
    if (validateLineItem) {
      const historyState = {
        ...(history.location.state as any),
        invoiceId,
        orderno: orderno || orderSelectedRow?.id,
        method: METHODS,
        lineTypeVal: lineType,
        invoiceDetails: { ...getValues(), order_type: orderSelectedRow?.order_type },
        invoiceLineList,
        selectedIndex
      };
      let navPath = "";
      const supplierPath = getSupplierPath();
      if (currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV) {
        if (invoiceId) {
          navPath = `${supplierPath}/invoice-credit-note/${handleEditRoute()}credite-note/invoiceId/${invoiceId}${
            METHODS === METHOD.ADD ? "/add/add-item" : "/add/edit-item"
          }`;
        } else {
          navPath = `${supplierPath}/invoice-credit-note/${handleEditRoute()}credit-note/${
            METHODS === METHOD.ADD ? "add/line-item" : "add/edit-line-item"
          }`;
        }
        history.push(navPath, historyState);
      } else if (currentInvoiceType === INVOICE_TYPE.NONORDERINV) {
        if (invoiceId) {
          if (lineType === INVOICE_LINE_TYPE.DTPOSTANDPACKING) {
            navPath = `${supplierPath}/invoice-credit-note/${handleEditRoute()}nonorder-invoice/invoiceId/${invoiceId}${
              METHODS === METHOD.ADD ? "/add/add-post-packing" : "/add/edit-post-packing"
            }`;
          } else {
            navPath = `${supplierPath}/invoice-credit-note/${handleEditRoute()}nonorder-invoice/invoiceId/${invoiceId}${
              METHODS === METHOD.ADD ? "/add/add-item" : "/add/edit-item"
            }`;
          }
        } else if (lineType === INVOICE_LINE_TYPE.DTPOSTANDPACKING) {
          navPath = `${supplierPath}/invoice-credit-note/non-order/${
            METHODS === METHOD.ADD ? "add/post-packing" : "add/edit-post-packing"
          }`;
        } else {
          navPath = `${supplierPath}/invoice-credit-note/non-order/${
            METHODS === METHOD.ADD ? "add/line-item" : "add/edit-line-item"
          }`;
        }
        history.push(navPath, historyState);
      } else if (currentInvoiceType === INVOICE_TYPE.ORDERINV) {
        if (invoiceId) {
          if (lineType === INVOICE_LINE_TYPE.DTPOSTANDPACKING) {
            history.push(
              `${supplierPath}/invoice-credit-note/${handleEditRoute()}order-invoice/orderno/${orderno}/invoiceId/${invoiceId}${
                METHODS === METHOD.ADD ? "/add/add-post-packing" : "/add/edit-post-packing"
              }`,
              historyState
            );
          } else {
            history.push(
              `${supplierPath}/invoice-credit-note/${handleEditRoute()}order-invoice/orderno/${orderno}/invoiceId/${invoiceId}${
                METHODS === METHOD.ADD ? "/add/add-item" : "/add/edit-item"
              }`,
              historyState
            );
          }
        } else if (lineType === INVOICE_LINE_TYPE.DTPOSTANDPACKING) {
          history.push(
            `${supplierPath}/invoice-credit-note/order/${
              METHODS === METHOD.ADD ? "add/post-packing" : "add/edit-post-packing"
            }`,
            historyState
          );
        } else {
          history.push(
            `${supplierPath}/invoice-credit-note/order/${
              METHODS === METHOD.ADD ? "add/line-item" : "add/edit-line-item"
            }`,
            historyState
          );
        }
      }
    }
  };

  useEffect(() => {
    reset((prev) => ({
      ...prev,
      ...historyState?.invoiceDetails
    }));
  }, [historyState, isundoInvoiceDetail]);

  const convertOrder = (orderString: any) => {
    switch (orderString.toUpperCase()) {
      case "E":
        return CONVERT_ORDER.E;
      case "M":
        return CONVERT_ORDER.M;
      case "P":
        return CONVERT_ORDER.P;
      case "W":
        return CONVERT_ORDER.W;
      case "X":
        return CONVERT_ORDER.X;
      default:
        return COMMON_MSG.NOTFOUND;
    }
  };

  const selectSupplier = (row?: { [key: string]: any }, value?: string) => {
    const client = row;
    const dirty = !!((orderno && invoiceDetails?.at(0)?.client_id !== row?.client_id) || isDirty);
    if (client) {
      let address = "";
      for (let i = 1; i <= maxSupplierAddresses; i += 1) {
        if (client?.[`address${i}`]) {
          address += `${client?.[`address${i}`]}\n`;
        }
      }
      if (client?.post_code) {
        address += client?.post_code;
      }
      setValue("supplier", client.name, { shouldValidate: true, shouldDirty: dirty });
      setValue("client_id", client.client_id, { shouldValidate: true, shouldDirty: dirty });
      setValue("supplier_address", address, { shouldValidate: true, shouldDirty: dirty });
    } else {
      setValue("client_id", specialCharacters.BLANKVALUE);
      setValue("supplier_address", specialCharacters.BLANKVALUE);
    }
    trigger("supplier");
  };
  useEffect(() => {
    if (selectedSupplier && !invoiceId) {
      selectSupplier(selectedSupplier);
    }
  }, [selectedSupplier, orderBrowseDetail]);

  // To manage posting period pending state while entering keywork

  const handlePostingPendingState = useCallback(
    (suggested: any) => {
      if (suggested) {
        const found = postingPeriodDetails?.find((t) => t?.id === suggested?.value);
        setValue("month", found?.description);
      }
    },
    [postingPeriodDetails]
  );

  // This is only for when user comes on detail page from supplier
  useEffect(() => {
    if (orderIdFromSupplier && isArrayLength(orderBrowseDetail)) {
      const found = orderBrowseDetail?.find((t: any) => Number(t?.id) === Number(orderIdFromSupplier));
      if (found) {
        const fn = async () => {
          const res: any = await dispatch(getInvoicePrintAndBank(found?.id));
          if (res?.payload?.no_prints === 0) {
            setPrintAlert(true);
          }
        };
        fn();
        submitOrderNumber(found);
        setValue("ordernum", found?.code);
        dispatch(coActions.setOrderSelectedRow(found));
        dispatch(orderBrowseActions.setOrderBrowserDetail(found));
      }
    }
    return () => {
      dispatch(orderBrowseActions.filterOrderById(null));
    };
  }, [orderIdFromSupplier, orderBrowseDetail, dispatch]);
  //

  // To manage ordernum and line item while entering keyword
  const debouncedSuppValue = useDebounce(watch("supplier") || "", 300);
  const supplierFindTerm = suggestedSupplier?.value || selectedSupplier?.client_id;
  const handleSuggetedSupplierOnKeyword = useCallback(async () => {
    if (currentInvoiceType !== INVOICE_TYPE.ORDERINV || selectedFromOrder) return; // return if invoice is not order inv

    if (debouncedSuppValue && supplierFindTerm && suppliersList?.clientDetails) {
      const findSuppFromList = suppliersList?.clientDetails?.find((row: any) => row?.client_id === supplierFindTerm);
      const found = orderBrowseDetail?.filter((t: any) => t?.client_id === findSuppFromList?.client_id);
      if (Array.isArray(found) && found.length === 1) {
        // Prefill order number if there's only one item in list
        const row = found?.at(0) ?? "";
        const res: any = await dispatch(getInvoicePrintAndBank(row?.id));
        if (res?.payload?.no_prints === 0) {
          setPrintAlert(true);
        }
        submitOrderNumber(row, "suggested");
        setValue("ordernum", row?.code);
        dispatch(coActions.setOrderSelectedRow(row));
      } else if (!method) {
        setValue("ordernum", "");
        setValue("order_id", "");
        dispatch(coActions.setOrderSelectedRow(undefined));
        setSuggestedSupplier(undefined);
        dispatch(invoiceLineItemAction.updateInvoiceLineItem([]));
        clearHistoryState();
      }
    } else if (!selectedSupplier) {
      setValue("ordernum", "");
      setValue("order_id", "");
      dispatch(coActions.setOrderSelectedRow(undefined));
      setSuggestedSupplier(undefined);
      dispatch(invoiceLineItemAction.updateInvoiceLineItem([]));
      clearHistoryState();
    }
  }, [debouncedSuppValue, orderBrowseDetail, suppliersList?.clientDetails, supplierFindTerm]);

  useEffect(() => {
    if (!invoiceId && !method) {
      handleSuggetedSupplierOnKeyword();
    }
  }, [handleSuggetedSupplierOnKeyword]);
  //

  // clear list state and supplier based on orderno
  useEffect(() => {
    if (method !== METHOD?.EDIT) {
      if (currentInvoiceType === INVOICE_TYPE?.ORDERINV && !selectedSupplier && !invoiceId) {
        setValue("ordernum", "");
        dispatch(coActions.setOrderSelectedRow(undefined));
        clearHistoryState();
        dispatch(invoiceLineItemAction.updateInvoiceLineItem([]));
      }
    }
  }, [selectedSupplier]);

  useEffect(() => {
    if (method !== METHOD?.EDIT) {
      if (currentInvoiceType === INVOICE_TYPE?.ORDERINV && !invoiceId && !orderSelectedRow) {
        dispatch(invoiceLineItemAction.updateInvoiceLineItem([]));
        clearHistoryState();
      }
      if (currentInvoiceType === INVOICE_TYPE?.ORDERINV && orderSelectedRow && !invoiceId) {
        dispatch(getInvoiceOrderPrefix({ orderId: orderSelectedRow?.id }));
      }
    }
  }, [orderSelectedRow]);

  useEffect(() => {
    if (supplierListBrowse && supplierListBrowse.length > 0 && invoiceId && supplierStatus === STATUS.SUCCESS) {
      const supplier = supplierListBrowse?.filter((s) => s.client_id === invoiceDetails?.client_id)?.at(0);
      dispatch(InvoiceSupplierAction.setSelectedRow(supplier));
    }
  }, [supplierListBrowse, invoiceDetails]);

  const handelInvNumber = (event: any) => {
    if (event.target.value && event.target.value.length > NUMBER_LENGTH.FIFTEEN) {
      const lastFifteenCharacters = event.target.value?.substring(event.target.value?.length - NUMBER_LENGTH.FIFTEEN);
      setValue("disp_inv_no", lastFifteenCharacters);
      trigger("disp_inv_no");
    } else {
      setValue("disp_inv_no", event.target.value);
      trigger("disp_inv_no");
    }
  };

  const handleOnHoldOrIsInUser = (supplierListBrowse: any) => {
    if (supplierListBrowse?.at(0)?.on_hold === BOOLEAN_DATA.True) {
      return (
        <span>
          <Tag
            text={t("invoiceNote.supplierOnHold")}
            size={TagSize.Small}
            color={TagColor.Warning}
          />
        </span>
      );
    }
    if (supplierListBrowse?.at(0)?.in_use === BOOLEAN_DATA.False) {
      return (
        <span>
          <Tag
            text={t("invoiceNote.supplierNotInUse")}
            size={TagSize.Small}
            color={TagColor.Warning}
          />
        </span>
      );
    }
    if (!invoiceId && selectedSupplier && selectedSupplier?.on_hold === BOOLEAN_DATA.True) {
      return (
        <span>
          <Tag
            text={t("invoiceNote.supplierOnHold")}
            size={TagSize.Small}
            color={TagColor.Warning}
          />
        </span>
      );
    }
    if (!invoiceId && selectedSupplier && selectedSupplier?.in_use === BOOLEAN_DATA.False) {
      return (
        <span>
          <Tag
            text={t("invoiceNote.supplierNotInUse")}
            size={TagSize.Small}
            color={TagColor.Warning}
          />
        </span>
      );
    }
    return "";
  };
  const invoiceTypeInUrlFormat = () => {
    let invoiceTypeStr = "";
    if (invoiceDetails?.invoice_type === invoiceOrderType.pi) {
      if (invoiceDetails?.order_id !== "" && invoiceDetails?.order_id !== null) {
        invoiceTypeStr = handleEditRoute() ? invoiceTypesName.EDIT_ORDER_INVOICE : invoiceTypesName?.ORDER_INVOICE;
      } else if (invoiceDetails?.sundry_invoice === sundryInvoiceType.t) {
        invoiceTypeStr = invoiceTypesName?.SUNDARY_INVOICE;
      } else {
        invoiceTypeStr = handleEditRoute()
          ? invoiceTypesName.EDIT_NON_ORDER_INVOICE
          : invoiceTypesName?.NON_ORDER_INVOICE;
      }
    } else if (invoiceDetails?.invoice_type === invoiceOrderType.pc) {
      invoiceTypeStr = handleEditRoute() ? invoiceTypesName.EDIT_CREDIT_NOTE : invoiceTypesName?.CREDIT_NOTE;
    }
    return invoiceTypeStr;
  };

  const openOrderViewPage = () => {
    let purchaseOrderDetailsLink = "";
    if (!invoiceId) {
      purchaseOrderDetailsLink = `${getSupplierPath()}/invoice-credit-note/order/add/purchase-orders/view/${
        orderPrefixDetail?.order_no
      }?prefix=${
        (orderPrefixDetail?.order_prefix?.charAt(0) ?? "").toUpperCase() +
        orderPrefixDetail?.order_prefix?.slice(1).toLowerCase()
      }${orderPrefixDetail?.full_order_no ? `&fullOrderNo=${encodeURI(orderPrefixDetail?.full_order_no)}` : ""}`;
    } else {
      const modifyUrlForOrderInvoie = invoiceDetails?.order_no
        ? `${invoiceTypeInUrlFormat()}/orderno/${invoiceDetails?.order_id}/invoiceId/${invoiceDetails?.invoice_id}`
        : `${invoiceTypeInUrlFormat()}/invoiceId/${invoiceDetails?.invoice_id}`;
      purchaseOrderDetailsLink = `${getSupplierPath()}/invoice-credit-note/${modifyUrlForOrderInvoie}/purchase-orders/view/${
        invoiceDetails?.order_no
      }?prefix=${
        invoiceDetails?.order_prefix?.charAt(0)?.toUpperCase() + invoiceDetails?.order_prefix?.slice(1).toLowerCase()
      }${invoiceDetails?.full_order_no ? `&fullOrderNo=${encodeURI(invoiceDetails?.full_order_no)}` : ""}`;
    }
    history.push(purchaseOrderDetailsLink);
  };

  const setSupportingDocumentModalOpen = () => {
    localStorage.setItem("SaveImageText", "true");
    const redirectURLSupportingDoc = invoiceData?.order_id
      ? `${getSupplierPath()}/invoice-credit-note/${invoiceTypeInUrlFormat()}/orderno/${
          invoiceData?.order_id
        }/invoiceId/${invoiceId}/suporting-documents`
      : `${getSupplierPath()}/invoice-credit-note/${invoiceTypeInUrlFormat()}/invoiceId/${invoiceId}/suporting-documents`;

    history.push(redirectURLSupportingDoc);
  };
  const invoiceTypeForCurretRecord = (firstInvoice: any) => {
    let invoiceTypeStr = "";
    if (firstInvoice?.invoice_type === invoiceOrderType.pi) {
      if (firstInvoice?.order_id !== "" && firstInvoice?.order_id !== null) {
        invoiceTypeStr = invoiceTypesName?.ORDER_INVOICE;
      } else if (firstInvoice?.sundry_invoice === sundryInvoiceType.t) {
        invoiceTypeStr = invoiceTypesName?.SUNDARY_INVOICE;
      } else {
        invoiceTypeStr = invoiceTypesName?.NON_ORDER_INVOICE;
      }
    } else if (firstInvoice?.invoice_type === invoiceOrderType.pc) {
      invoiceTypeStr = invoiceTypesName?.CREDIT_NOTE;
    }
    return invoiceTypeStr;
  };
  const handleredirectOnNextRecordClick = () => {
    setRedirectLoading(true);
    dispatch(
      getInvoiceOrdersFilter({
        ...filterState,
        invoiceId: null,
        callback: (response: any) => {
          if (Array.isArray(response?.invoices) && response?.invoices?.length > 0) {
            const firstInvoice = response.invoices.at(0);
            if (firstInvoice) {
              const urlForRedirectRecord = firstInvoice?.order_id
                ? `/invoice-credit-note/${invoiceTypeForCurretRecord(firstInvoice)}/orderno/${
                    firstInvoice?.order_id
                  }/invoiceId/${firstInvoice?.invoice_id}`
                : `/invoice-credit-note/${invoiceTypeForCurretRecord(firstInvoice)}/invoiceId/${
                    firstInvoice?.invoice_id
                  }`;
              setRedirectLoading(false);
              history.push(urlForRedirectRecord);
            }
          } else {
            history.push("/invoice-credit-note"); // Change done as part of static UI removal task
          }
          setRedirectLoading(false);
        }
      })
    );
  };
  const selectRowHandler = (row: { [key: string]: any } | undefined) => {
    dispatch(invoiceLineItemAction.resetInvoiceLineItem());
    dispatch(invoiceLineItemAction.resetInvoiceVatLineItem());
    const invTypeVal = getInvoiceTypeValue(row);
    const invoiceRedirectLink = getInvoiceDetailsUrl(row, invTypeVal);
    clearHistoryState();
    history.push(invoiceRedirectLink, {
      ...(history.location.state as any)
    });
  };

  const onchangePrevRecord: onChangeType = (e, page: any) => {
    dispatch(
      getInvoiceOrdersFilter({
        ...filterState,
        pageNumber: page,
        pageSize: String(historyState?.invoiceList?.pageSize),
        invoiceId: null,
        callback: (data) => {
          dispatch(ioActions.setSelectedRow(data.invoices?.at(data.invoices?.length - 1)));
          historyState.invoiceList = data;
          selectRowHandler(data.invoices?.at(data.invoices?.length - 1));
        }
      })
    );
  };

  const onChangeHandler: onChangeType = (e, page: any) => {
    dispatch(
      getInvoiceOrdersFilter({
        ...filterState,
        pageNumber: page,
        pageSize: String(historyState?.invoiceList?.pageSize),
        lookingFor: "",
        invoiceId: null,
        callback: (data) => {
          if (historyState?.invoiceList === undefined) {
            historyState.invoiceList = data;
            dispatch(ioActions.setSelectedRow(data.invoices?.at(1)));
            selectRowHandler(data.invoices?.at(1));
          } else {
            historyState.invoiceList = data;
            dispatch(ioActions.setSelectedRow(data.invoices?.at(0)));
            selectRowHandler(data.invoices?.at(0));
          }
        }
      })
    );
  };

  const selectPrevRecord = (e: SyntheticEvent) => {
    if (listrow && historyState?.invoiceList?.invoices.length > 0) {
      const invoiceList = historyState?.invoiceList?.invoices;
      const indexNo = invoiceList?.findIndex((row: { [key: string]: any }) => row?.invoice_id === listrow?.invoice_id);
      if (indexNo > 0) {
        dispatch(ioActions.setSelectedRow(invoiceList[indexNo - 1]));
        selectRowHandler(invoiceList[indexNo - 1]);
      } else if (historyState?.invoiceList?.currentPage > 1) {
        onchangePrevRecord(e, historyState?.invoiceList?.currentPage - 1);
      } else if (history.location.pathname === "/invoice-credit-note/add") {
        selectRowHandler(invoiceList[indexNo]);
      }
    } else if (invoiceId) {
      dispatch(
        getInvoiceOrdersFilter({
          ...filterState,
          pageNumber: "1",
          pageSize: "10",
          invoiceId,
          callback: (data) => {
            historyState.invoiceList = data;
            const invoiceList = historyState?.invoiceList?.invoices;
            const indexNo = invoiceList?.findIndex(
              (row: { [key: string]: any }) => row?.invoice_id === listrow?.invoice_id
            );
            if (indexNo > 0) {
              dispatch(ioActions.setSelectedRow(invoiceList[indexNo - 1]));
              selectRowHandler(invoiceList[indexNo - 1]);
            } else if (historyState?.invoiceList?.currentPage > 1) {
              onchangePrevRecord(e, historyState?.invoiceList?.currentPage - 1);
            } else if (history.location.pathname === "/invoice-credit-note/add") {
              selectRowHandler(invoiceList[indexNo]);
            }
          }
        })
      );
    }
  };
  const selectNextRecord = (e: SyntheticEvent) => {
    if (history.location.pathname.includes("/supplier")) {
      historyState.invoiceList = { ...historyState.invoiceList, invoices: [] };
    }
    if (listrow && historyState?.invoiceList?.invoices.length > 0) {
      const invoiceList = historyState?.invoiceList?.invoices;
      const indexNo = invoiceList?.findIndex((row: { [key: string]: any }) => row?.invoice_id === listrow?.invoice_id);
      if (
        indexNo < 9 &&
        (invoiceList.length - 1 !== indexNo ||
          historyState?.invoiceList?.currentPage !== historyState?.invoiceList?.totalPages)
      ) {
        dispatch(ioActions.setSelectedRow(invoiceList[indexNo + 1]));
        selectRowHandler(invoiceList[indexNo + 1]);
      } else if (historyState?.invoiceList?.currentPage < historyState?.invoiceList?.totalPages) {
        const tempPageNumber = Number(getSessionItem("filterState").pageNumber);
        onChangeHandler(e, tempPageNumber + 1);
      }
    } else if (invoiceId) {
      dispatch(
        getInvoiceOrdersFilter({
          ...filterState,
          pageNumber: "1",
          pageSize: "10",
          invoiceId,
          callback: (data) => {
            historyState.invoiceList = data;
            const invoiceList = historyState?.invoiceList?.invoices;
            const indexNo = invoiceList?.findIndex(
              (row: { [key: string]: any }) => row?.invoice_id === listrow?.invoice_id
            );
            if (
              indexNo < 9 &&
              (invoiceList.length - 1 !== indexNo ||
                historyState?.invoiceList?.currentPage !== historyState?.invoiceList?.totalPages)
            ) {
              dispatch(ioActions.setSelectedRow(invoiceList[indexNo + 1]));
              selectRowHandler(invoiceList[indexNo + 1]);
            } else if (historyState?.invoiceList?.currentPage < historyState?.invoiceList?.totalPages) {
              const tempPageNumber = historyState?.invoiceList?.currentPage;
              onChangeHandler(e, tempPageNumber + 1);
            }
          }
        })
      );
    } else if (historyState?.invoiceList.invoices.length <= 0 || historyState?.invoiceList === undefined) {
      onChangeHandler(e, 1);
    }
  };

  const getClassForStatus = () => {
    switch (currentInvoiceType) {
      case INVOICE_TYPE.ORDERINV:
        return "height-162";
      case INVOICE_TYPE.NONORDERINV:
        return "height-162";
      case INVOICE_TYPE.SUNDRYINV:
        return "height-160";
      case INVOICE_TYPE.CREDITNOTEINV:
        return "height-154";
      default:
        return "height-162";
    }
  };

  // handle prefill invoice number if there only on in list based on supplier select
  const selectedInvoiceRow = (row: any) => {
    setValue("matched_inv_no", row?.code);
    setValue("matched_inv_id", row?.id);
    trigger("matched_inv_no");
    dispatch(matchedInvoice.selectMatchedInvoice(row));
  };

  const selectedPayTo = (row: any) => {
    setValue("bank_description", row.code);
    setValue("bank_id", row?.id);
    dispatch(payFromActions.selectPaymentMethod(row));
  };
  const clearPayToRow = () => {
    setValue("bank_description", "");
    setValue("bank_id", "");
    dispatch(payFromActions.selectPaymentMethod(undefined));
  };

  const clearInvoiceRow = () => {
    setValue("matched_inv_no", "");
    setValue("matched_inv_id", "");
    dispatch(matchedInvoice.selectMatchedInvoice(undefined));
  };

  const getAndSetBankAccordingly = async (invoiceId: number | string) => {
    const res = await dispatch(getBankBySupplierId({ invoiceId }));
    const bankID = res?.payload;
    if (bankID) {
      const found = paymentDetails?.find((t) => t.id === bankID);
      if (found) {
        selectedPayTo(found);
      }
    }
  };

  const manageInvoiceNumberOnSupplier = useCallback(async () => {
    if (selectedSupplier && Array.isArray(matchedInvoiceDetails) && matchedInvoiceDetails.length === 1) {
      selectedInvoiceRow(matchedInvoiceDetails?.at(0));
      await getAndSetBankAccordingly(matchedInvoiceDetails?.at(0)?.id);
    } else if (!selectedSupplier || matchedInvoiceDetails?.length === 0) {
      clearInvoiceRow();
    }
  }, [selectedSupplier, matchedInvoiceDetails, paymentDetails]);

  useEffect(() => {
    if (currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV && !invoiceId) {
      manageInvoiceNumberOnSupplier();
    }
  }, [manageInvoiceNumberOnSupplier]);

  // Prefill bank based on invoice
  const prefillPayFromBasedOnInv = useCallback(async () => {
    await getAndSetBankAccordingly(selectedInvNumber?.id);
  }, [selectedInvNumber]);

  useEffect(() => {
    if (selectedInvNumber) {
      prefillPayFromBasedOnInv();
    }
  }, [prefillPayFromBasedOnInv]);

  // scroll table for selectedRow
  useEffect(() => {
    setTimeout(() => {
      if (historyState?.invoiceLineList) {
        const element = document.getElementById(
          `rowIndex-invoiceOrderLine-${historyState?.invoiceLineList.indexOf(selectedRow)}`
        );
        element?.scrollIntoView({ block: "center", behavior: "smooth" });
      }
    }, 2000);
  }, [historyState?.invoiceLineList]);

  // first row selected On Browser Reload
  useEffect(() => {
    if (!selectedRow) {
      dispatch(invoiceLineItemAction.setSelectedRow(historyState?.invoiceLineList?.at(0)));
    }
  }, [selectedRow]);

  useEffect(() => {
    if (isHotKey) {
      if (historyState?.invoiceLineList?.length > 0) {
        const filteredInvoice = historyState?.invoiceLineList?.filter(
          (val: any) => val.line_type === invoiceLineType.strInvoiceLine
        );
        dispatch(invoiceLineItemAction.setSelectedRow(filteredInvoice?.at(-1)));
      }
    }
  }, [isHotKey, dispatch, historyState]);

  return (
    <>
      {isLoading ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        <>
          <Layout
            pageTitle={pageTitle()}
            className="invoice-credit-note"
            rightContent={
              <InvoiceOrderTools
                setIsViewDetail={setIsViewDetail}
                isDirty={isDirty}
                setPromise={setPromise}
                resolve={resolve}
                resetForm={resetForm}
                setIsChanged={setIsChanged}
                setIsRerender={setIsRerender}
                isRerender={isRerender}
                isChanged={isChanged}
                isHotKeyCalled={(isHotKey: boolean) => {
                  setIsHotKeyCalled(isHotKey);
                }}
                goToPrevRecord={(e) => {
                  selectPrevRecord(e);
                }}
                goToNextRecord={(e) => {
                  selectNextRecord(e);
                }}
                onSubmit={() => onSubmit()}
              />
            }
            toolbar={
              <InvoiceOrderPageToolbar
                onSubmit={onSubmit}
                isDirty={isDirty}
              />
            }
            isBreadcrumbRequired
          >
            <Grid>
              <GridItem
                lg={3}
                xl={3}
                className="border-right"
              >
                <Grid>
                  <GridItem
                    lg={12}
                    xl={12}
                  >
                    {/* This is only for order invoice */}
                    {currentInvoiceType === INVOICE_TYPE.ORDERINV ? (
                      <Input
                        id="supplier"
                        searchable
                        searchItems={suppliersList?.clientDetails?.map((s) => ({ text: s.name, value: s.client_id }))}
                        className={invoiceId || method === METHOD?.EDIT ? "mode--disabled" : ""}
                        onSelect={(selectedItem) => {
                          setSelectedFromOrder(false);
                          clearInvoiceRow();
                          const supplier = suppliersList?.clientDetails
                            ?.filter((s) => s.client_id === selectedItem?.value)
                            ?.at(0);
                          if (selectedItem?.text) {
                            dispatch(InvoiceSupplierAction.setSelectedRow(supplier));
                          } else {
                            selectSupplier(undefined);
                            dispatch(InvoiceSupplierAction.setSelectedRowUndefined(supplier));
                          }
                        }}
                        button={
                          <Button
                            color={ButtonColor.Secondary}
                            onClick={() => {
                              setIsSuppliersModal(true);
                            }}
                            className={` btnclass essui-button-icon-only--small`}
                            size={ButtonSize.Small}
                          >
                            <Icon
                              color={IconColor.Primary500}
                              size={IconSize.Medium}
                              name="search"
                            />
                          </Button>
                        }
                        onNoSelection={() => setIsSuppliersModal(true)}
                        disabled={isDisabled || !!invoiceId || method === METHOD?.EDIT}
                        onChange={(e) => {
                          register("supplier").onChange(e);
                          if (!e.target.value) {
                            selectSupplier(undefined);
                            dispatch(InvoiceSupplierAction.setSelectedRowUndefined());
                          }
                        }}
                        onPending={(selected) => {
                          if (selected) {
                            const found = suppliersList?.clientDetails?.find((p) => p?.client_id === selected?.value);
                            if (found) {
                              setSuggestedAdress(found);
                            }
                            setSuggestedSupplier(selected);
                          }
                        }}
                        onBlur={() => trigger("supplier")}
                        value={getValues("supplier")}
                        labelText={t("viewInvoiceCreditNote.supplier")}
                        inputRef={(e) => register("supplier").ref(e)}
                        name={register("supplier", { required: true }).name}
                        validationTextLevel={errors.supplier ? ValidationTextLevel.Error : undefined}
                      />
                    ) : (
                      // This is only for other than order invoice
                      <>
                        <Input
                          id="supplier"
                          searchable
                          searchItems={suppliersList?.clientDetails?.map((s) => ({ text: s.name, value: s.client_id }))}
                          onSelect={(selectedItem) => {
                            const supplier = suppliersList?.clientDetails?.find(
                              (s) => s.client_id === selectedItem?.value
                            );
                            if (selectedItem?.text) {
                              dispatch(InvoiceSupplierAction.setSelectedRow(supplier));
                            } else {
                              selectSupplier(undefined);
                              dispatch(InvoiceSupplierAction.setSelectedRowUndefined(supplier));
                            }
                          }}
                          button={
                            <Button
                              color={ButtonColor.Secondary}
                              onClick={() => {
                                setIsSuppliersModal(true);
                              }}
                              className={` btnclass essui-button-icon-only--small`}
                              size={ButtonSize.Small}
                            >
                              <Icon
                                color={IconColor.Primary500}
                                size={IconSize.Medium}
                                name="search"
                              />
                            </Button>
                          }
                          onNoSelection={() => {
                            setIsSuppliersModal(true);
                            setValue("supplier", "");
                            setValue("client_id", "");
                          }}
                          disabled={isDisabled}
                          onChange={(e) => {
                            register("supplier").onChange(e);
                            if (!e.target.value) {
                              selectSupplier(undefined);
                              trigger("supplier");
                              dispatch(InvoiceSupplierAction.setSelectedRowUndefined());
                            }
                          }}
                          onPending={(selected) => {
                            const found = suppliersList?.clientDetails?.find((p) => p?.client_id === selected?.value);
                            if (found) {
                              setSuggestedAdress(found);
                            }
                          }}
                          value={watch("supplier")}
                          labelText={t("viewInvoiceCreditNote.supplier")}
                          inputRef={(e) => register("supplier").ref(e)}
                          onBlur={() => trigger("supplier")}
                          name={register("supplier", { required: true }).name}
                          validationTextLevel={errors.supplier ? ValidationTextLevel.Error : undefined}
                        />
                      </>
                    )}
                  </GridItem>

                  <GridItem
                    xl={12}
                    className={`wrap-data mt-8 ${getClassForStatus()}`}
                  >
                    {/* Suggesed address will be appear while user enter any keyword */}
                    {getValues("supplier") && (selectedSupplier || suggestedAddress)
                      ? getAddress(selectedSupplier || suggestedAddress)
                      : ""}
                    {handleOnHoldOrIsInUser(supplierListBrowse)}
                  </GridItem>

                  <GridItem
                    lg={12}
                    xl={12}
                  >
                    <Input
                      id="status"
                      searchable={false}
                      value={invoiceDetails?.description ? invoiceDetails?.description : specialCharacters.HYPHEN}
                      button={
                        <Button
                          color={ButtonColor.Secondary}
                          onClick={() => setIsAuditModalOpen(true)}
                          size={ButtonSize.Small}
                          disabled={!invoiceId}
                          className="essui-button-icon-only--small"
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="view"
                          />
                        </Button>
                      }
                      disabled
                      labelText={t("viewInvoiceCreditNote.status")}
                    />
                  </GridItem>
                  <GridItem className="mt-16">
                    <FormLabel>{invoiceDetails?.transfer_text ? invoiceDetails?.transfer_text : null}</FormLabel>
                  </GridItem>
                </Grid>
              </GridItem>
              <GridItem
                lg={9}
                xl={9}
              >
                <Grid>
                  <GridItem
                    lg={4}
                    xl={4}
                  >
                    <Input
                      id="fullInvoiceNumber"
                      searchable={false}
                      labelText={
                        invoiceDetails?.invoice_type === "PC" || currentInvoiceType === INVOICE_TYPE?.CREDITNOTEINV
                          ? t("viewInvoiceCreditNote.fullCreditNoteNo")
                          : t("viewInvoiceCreditNote.fullInvoiceNumber")
                      }
                      maxLength={30}
                      value={watch("long_inv_no")}
                      inputRef={(e) => register("long_inv_no").ref(e)}
                      name={register("long_inv_no").name}
                      className={fields?.long_inv_no === "false" ? "not-in-use" : ""}
                      onBlur={(e) => handelInvNumber(e)}
                      onChange={(e) => setValue("long_inv_no", e.target.value)}
                      disabled={fields?.long_inv_no === "false"}
                    />
                  </GridItem>
                  <GridItem
                    lg={4}
                    xl={4}
                  >
                    <Input
                      id="invoiceNumber"
                      searchable={false}
                      labelText={
                        invoiceDetails?.invoice_type === "PC" || currentInvoiceType === INVOICE_TYPE?.CREDITNOTEINV
                          ? t("viewInvoiceCreditNote.creditNoteNumber")
                          : t("viewInvoiceCreditNote.invoiceNumber")
                      }
                      maxLength={15}
                      value={watch("disp_inv_no")}
                      className={fields?.disp_inv_no === "false" ? "not-in-use" : ""}
                      disabled={isDisabled}
                      onChange={(e) => {
                        register("disp_inv_no").onChange(e);
                      }}
                      onBlur={() => {
                        trigger("disp_inv_no");
                      }}
                      inputRef={(e) => register("disp_inv_no").ref(e)}
                      name={register("disp_inv_no", { required: true }).name}
                      validationTextLevel={errors.disp_inv_no ? ValidationTextLevel.Error : undefined}
                    />
                  </GridItem>
                </Grid>
                {invoiceOrderNonOrderRender()}
                <Grid
                  align="center"
                  className="mt-8"
                >
                  <GridItem
                    lg={4}
                    xl={4}
                  >
                    <div className="essui-textinput--medium on-hold playback">
                      <CheckBox
                        isSelected={watch("on_hold") === BOOLEAN_DATA.True}
                        label={t("viewInvoiceCreditNote.onHold")}
                        disabled={isDisableOnHold()}
                        onChange={(e: any) => {
                          const val = e.target.checked;
                          setValue("on_hold", val ? BOOLEAN_DATA.True : BOOLEAN_DATA.False, { shouldDirty: true });
                          register("on_hold").onChange(e);
                        }}
                      />
                    </div>
                  </GridItem>
                  <GridItem
                    lg={8}
                    xl={8}
                  >
                    <Input
                      id="invoiceNotes"
                      searchable={false}
                      labelText={
                        invoiceDetails?.invoice_type === "PC" ||
                        (!invoiceId && currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV)
                          ? t("invoiceNote.creditNoteNotes")
                          : t("viewInvoiceCreditNote.invoiceNotes")
                      }
                      buttonPosition="Left"
                      value={watch("inv_notes")}
                      readOnly
                      button={
                        <>
                          <Button
                            color={ButtonColor.Secondary}
                            onClick={() => setIsInvoiceNotesModalOpen(true)}
                            className={` btnclass essui-button-icon-only--small`}
                            size={ButtonSize.Small}
                          >
                            <Icon
                              color={IconColor.Primary500}
                              size={IconSize.Medium}
                              name="edit--alt"
                            />
                          </Button>
                        </>
                      }
                      inputRef={(e) => register("inv_notes").ref(e)}
                      onChange={(e) => register("inv_notes").onChange(e)}
                      name={register("inv_notes").name}
                      className={fields?.inv_notes === "false" ? "disabled essui-textinput--disabled" : ""}
                    />
                  </GridItem>
                </Grid>
                <div className={`${currentInvoiceType === INVOICE_TYPE.NONORDERINV && "mt-16"}`}>
                  <Divider orientation={Orientation.HORIZONTAL} />
                </div>
              </GridItem>
            </Grid>
            <Grid className="mt-8">
              <GridItem
                lg={12}
                xl={12}
              >
                <FormLabel>{t("viewInvoiceCreditNote.narrative")}</FormLabel>
                <Input
                  searchable={false}
                  id="narrative"
                  value={watch("narrative")}
                  inputRef={(e) => register("narrative").ref(e)}
                  name={register("narrative").name}
                  className={fields?.narrative === "false" ? "disabled not-in-use" : ""}
                  onChange={(e) => register("narrative").onChange(e)}
                  disabled={fields?.narrative === "false"}
                />
              </GridItem>
            </Grid>
          </Layout>
          <Layout
            isBreadcrumbRequired={false}
            className="invoice-credit-note"
            type="transparent"
          >
            <div className="grid-table">
              <GridTableNew
                dataTestId="invoiceOrderLine"
                stickyHeader
                isScrollable
                filters={
                  !invoiceId ||
                  invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED ||
                  invoiceDetails?.status === INVOICE_STATUS.AUTHORISED ? (
                    <Grid justify="flex-end">
                      <GridItem xl={2}>
                        <div className="toolbar__btn d-flex justify-end">
                          <Button
                            className={`essui-button essui-button--small ${
                              !(
                                currentInvoiceType !== INVOICE_TYPE.ORDERINV &&
                                invoiceDetails?.source !== viewPageStatus.XML
                              ) && "disabled"
                            }`}
                            size={ButtonSize.Small}
                            aria-label="FocusMode"
                            title="Add a New Line"
                            disabled={
                              !(
                                currentInvoiceType !== INVOICE_TYPE.ORDERINV &&
                                invoiceDetails?.source !== viewPageStatus.XML
                              )
                            }
                            onClick={async () => {
                              const result = await trigger();
                              if (result) {
                                handleLineItemDetails(METHOD.ADD, INVOICE_LINE_TYPE.DTNONORDERINV);
                                dispatch(invoiceLineItemAction.setSelectedRow(undefined));
                              } else {
                                setMessage(t("common.invalidData"));
                                setIsOpenAlert(true);
                              }
                            }}
                          >
                            <AddLarge
                              size="18"
                              color={
                                !(invoiceDetails?.order_id === "" || invoiceDetails?.order_id === null) &&
                                invoiceDetails?.source !== viewPageStatus.XML
                                  ? ""
                                  : "black"
                              }
                            />
                          </Button>
                          {invoiceDetails?.invoice_type === invoiceOrderType.pc ||
                          currentInvoiceType === INVOICE_TYPE.CREDITNOTEINV ? (
                            ""
                          ) : (
                            <Button
                              className="essui-button essui-button--small"
                              size={ButtonSize.Small}
                              aria-label="FocusMode"
                              title="Add a Post & Packing Line"
                              disabled={invoiceDetails?.source === viewPageStatus.XML}
                              onClick={async () => {
                                const result = await trigger();
                                if (result) {
                                  handleLineItemDetails(METHOD.ADD, INVOICE_LINE_TYPE.POSTNPAKING);
                                  dispatch(invoiceLineItemAction.setSelectedRow(undefined));
                                } else {
                                  setMessage(t("common.invalidData"));
                                  setIsOpenAlert(true);
                                }
                              }}
                            >
                              <WatsonHealth3DSoftware
                                size={18}
                                color="white"
                              />
                            </Button>
                          )}
                        </div>
                      </GridItem>
                    </Grid>
                  ) : (
                    ""
                  )
                }
                selectedRow={selectedRow}
                selectedRowHandler={(row) => {
                  dispatch(invoiceLineItemAction.setSelectedRow(row));
                }}
                columnDef={
                  invoiceDetails?.order_id || currentInvoiceType === INVOICE_TYPE?.ORDERINV
                    ? orderLineItemsOrderInvoiceColumnDef
                    : nonOrderLineItemsOrderInvoiceColumnDef
                }
                dataSource={historyState?.invoiceLineList || []}
                isLoading={isLoading}
                customCell={CustomCell}
              />
            </div>
          </Layout>

          <Layout
            isBreadcrumbRequired={false}
            className="invoice-credit-note"
          >
            <Grid>
              <GridItem
                xl={10}
                md={6}
              >
                <Grid className="mb-24">
                  <GridItem
                    xl={4}
                    md={3}
                  >
                    <FormLabel>{t("viewInvoiceCreditNote.ledgerCode")}</FormLabel>
                    <div className="essui-textinput--medium border-0 playback">
                      {invoiceId ? (
                        <>{selectedRow?.at_full_ledger ? selectedRow?.at_full_ledger : specialCharacters.HYPHEN}</>
                      ) : (
                        <>
                          {selectedRow?.ledger_code && selectedRow?.ledger_des
                            ? `(${selectedRow?.ledger_code}) ${selectedRow?.ledger_des}`
                            : specialCharacters.HYPHEN}
                        </>
                      )}
                    </div>
                  </GridItem>
                  <GridItem
                    xl={8}
                    md={5}
                  >
                    <FormLabel>{t("viewInvoiceCreditNote.costCentre")}</FormLabel>
                    <div className="essui-textinput--medium border-0 playback">
                      {invoiceId ? (
                        <>
                          {selectedRow?.at_full_cost_centre
                            ? selectedRow?.at_full_cost_centre
                            : specialCharacters.HYPHEN}
                        </>
                      ) : (
                        <>
                          {selectedRow?.cost_code && selectedRow?.cost_des
                            ? `(${selectedRow?.cost_code}) ${selectedRow?.cost_des}`
                            : specialCharacters.HYPHEN}
                        </>
                      )}
                    </div>
                  </GridItem>
                </Grid>
                <Grid>
                  <GridItem
                    xl={4}
                    md={3}
                  >
                    <FormLabel>{t("viewInvoiceCreditNote.transId")}</FormLabel>
                    <div className="essui-textinput--medium border-0 playback">
                      {invoiceDetails?.trans_no ? invoiceDetails?.trans_no : specialCharacters.HYPHEN}
                    </div>
                  </GridItem>
                  <GridItem
                    xl={3}
                    md={2}
                  >
                    <FormLabel>{t("viewInvoiceCreditNote.totalVat")}</FormLabel>
                    <div className="essui-textinput--medium border-0 playback">
                      <>{getTotalVal()}</>
                    </div>
                  </GridItem>
                  <GridItem
                    xl={5}
                    md={3}
                  >
                    <FormLabel>{t("viewInvoiceCreditNote.invoiceTotalIncludingVat")}</FormLabel>
                    <div className="essui-textinput--medium border-0 playback">
                      <>{getTotalAmountWithVal()}</>
                    </div>
                  </GridItem>
                </Grid>
              </GridItem>
              {!isViewPaymentPageFromSupplier() && !isViewPaymentFromChequeProcessing() && (
                <GridItem
                  xl={2}
                  md={2}
                  className="supporting-doc"
                >
                  <Button
                    disabled={isSupportingDocBtnDisabled()}
                    color={ButtonColor.Primary}
                    size={ButtonSize.Small}
                    onClick={setSupportingDocumentModalOpen}
                  >
                    {supportingDocument === 0 || supportingDocument === undefined
                      ? `${t("invoiceScanDoc.supportingDocument")} (0)`
                      : `${t("invoiceScanDoc.supportingDocument")} (${supportingDocument})`}
                  </Button>
                </GridItem>
              )}
            </Grid>
          </Layout>
        </>
      )}

      <InvoiceAuditSummaryModal
        isOpen={isAuditModalOpen}
        setOpen={setIsAuditModalOpen}
      />
      <InvoiceLineItemModal
        isOpen={isViewInvoiceLineItem}
        setOpen={setIsViewInvoiceLineItem}
      />
      <InvoiceNotesModal
        isOpen={isInvoiceNotesModalOpen}
        setOpen={setIsInvoiceNotesModalOpen}
      />
      <VatLineDetailsModal
        isOpen={isVatLineDetailModalOpen}
        setOpen={setIsVatLineDetailModalOpen}
      />
      <InvoiceDifferenceModal
        watch={watch}
        isOpen={isInvoiceDifferences}
        setOpen={setIsInvoiceDifferences}
      />
      <SuppliersModal
        isOpen={isSuppliersModal}
        setOpen={setIsSuppliersModal}
        setSelectedFromOrder={setSelectedFromOrder}
        clearInvoiceRow={clearInvoiceRow}
        handleSuggetedSupplierOnKeyword={handleSuggetedSupplierOnKeyword}
        setSuggestedSupplier={setSuggestedSupplier}
        viewDetailsAction={isViewDetail}
        supplierDetailsData={supplier}
        headerTitle={t(`${invoiceId ? "supplier.supplierDetails" : "supplier.supplierBrowse"}`)}
      />
      <InvoiceFromModal
        isOpen={isPayFromModalOpen}
        setOpen={setIsPayFromModalOpen}
        selectedRow={(row) => {
          setValue("bank_description", row?.code);
          trigger("bank_description");
          dispatch(payFromActions.selectPaymentMethod(row));
        }}
      />

      <PostingPeriodModal
        isOpen={isPostingPeriodModalOpen}
        setOpen={setPostingPeriodModalOpen}
        selectedRow={(row) => {
          setValue("period", String(row.code));
          setValue("month", row?.description);
          dispatch(postingPeriodActions.selectPostingPeriod(row));
          trigger("period");
        }}
      />

      <ConfirmModal
        isOpen={isDuplicateInvoice}
        setOpen={(flag) => dispatch(uiActions.alertPopup({ enable: flag }))}
        title={t("alertMessage.title")}
        message={saveDuplicateMsg}
        confirm={() => {
          setValue("total", totalLineItemVal);
          onSubmit();
          setDuplicateInvoice(false);
          dispatch(invActions.setAllowDuplicateVal(INVOICE_MSG_TYPE.ONE));
        }}
        callback={(data) => {
          if (!data.confirm) {
            dispatch(invActions.setAllowDuplicateVal(0));
            setDuplicateInvoice(false);
            setToSession("validateFinancial", true);
            setValue("total", historyState?.invoiceDetails?.total ?? "");
          }
        }}
      />
      <ConfirmModal
        isOpen={isFullInvoiceNoDuplicate}
        setOpen={(flag) => dispatch(uiActions.alertPopup({ enable: flag }))}
        title={t("alertMessage.title")}
        message={saveDuplicateMsg}
        confirm={() => {
          setValue("total", totalLineItemVal);
          onSubmit();
          setIsFullInvoiceNoDuplicate(false);
          dispatch(invActions.setAllowDuplicateVal(INVOICE_MSG_TYPE.TWO));
        }}
        callback={(data) => {
          if (!data.confirm) {
            dispatch(invActions.setAllowDuplicateVal(0));
            setIsFullInvoiceNoDuplicate(false);
            setToSession("validateFinancial", true);
            setValue("total", historyState?.invoiceDetails?.total ?? "");
          }
        }}
      />
      <Modalv2
        isOpen={isOpenAlert}
        header={t("common.simsFMSModule")}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setIsOpenAlert(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
        className="confirm-modal-text"
      >
        <>
          <Notification
            actionElement={1}
            className="confirm-modal-text"
            dataTestId="delete-new-warning-id"
            escapeExits
            id="delete-new-warning-id"
            hideCloseButton
            status={NotificationStatus.WARNING}
            title={message}
          />
        </>
      </Modalv2>
      <MatchedInvoiceBrowseModal
        isOpen={isMatchedInvoiceModal}
        setOpen={setIsMatchedInvoiceModal}
        selectedRow={(row) => {
          setValue("matched_inv_no", row?.code);
          setValue("matched_inv_id", row?.id);
          trigger("matched_inv_no");
          dispatch(matchedInvoice.selectMatchedInvoice(row));
        }}
      />
      <Modalv2
        header={t("invoiceNote.invoiceModalCancel")}
        isOpen={Boolean(redirectAlertModal)}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              dispatch(invActions.setRedirectAlertModal(false));
              if (isFocus === false) {
                history.push("/invoice-credit-note");
              } else {
                handleredirectOnNextRecordClick();
                history.replace({ ...history.location, state: undefined });
                dispatch(invoiceLineItemAction.updateInvoiceLineItem([]));
              }
            }}
          >
            {t("common.ok")}
          </Button>
        }
      >
        <Notification
          actionElement={1}
          dataTestId="warning-id"
          escapeExits
          id="warning-id"
          hideCloseButton
          status={NotificationStatus.WARNING}
          title={t("invoiceNote.alertForFirstRecordRedirect")}
          className="mb-18 confirm-modal-text"
        />
      </Modalv2>

      <OrderBrowseModal
        // setFinalLineItem={setFinalLineItem}
        setOrderBrowseModal={setOrderBrowseModal}
        orderBrowseModal={orderBrowseModal}
        submitOrderNumber={submitOrderNumber}
        setSelectedFromOrder={setSelectedFromOrder}
        selectedSupplier={selectedSupplier}
        setPrintAlert={setPrintAlert}
      />

      <Modalv2
        isOpen={isPrintAlert}
        header={t("common.simsFMSModule")}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setPrintAlert(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
      >
        <>
          <Notification
            actionElement={1}
            className="confirm-modal-text"
            dataTestId="delete-new-warning-id"
            escapeExits
            id="delete-new-warning-id"
            hideCloseButton
            status={NotificationStatus.WARNING}
            title={t("creatOrderInvoice.printAlertMsg")}
          />
        </>
      </Modalv2>
    </>
  );
};

export default InvoiceOrderView;

type OptionProps = {
  iconName?: string;
  optionName: string;
  children?: ReactNode;
};
const RowAction = ({ iconName, optionName, children }: OptionProps) => (
  <div className="option">
    {iconName ? (
      <Icon
        size={IconSize.Medium}
        name={iconName}
      />
    ) : (
      children
    )}
    {optionName}
  </div>
);

RowAction.defaultProps = {
  iconName: undefined,
  children: undefined
};
