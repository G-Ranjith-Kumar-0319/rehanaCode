import GridRowActions, { OptionsType } from "@/components/GridRowActions/GridRowActions";
import { cellRendererType } from "@/components/GridTable/GridTable";
import { AppDispatch, useAppSelector } from "@/store/store";
import {
  DELIV_STATUS,
  INVOICE_STATUS,
  INVOICE_TYPE,
  METHOD,
  STATUS,
  invoiceLineTypes,
  specialCharacters,
  viewPageStatus
} from "@/types/UseStateType";
import { deliveryStatus, orderStatus } from "@/utils/constants";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, ISelectedItem, Icon, IconSize, NotificationStatus } from "@essnextgen/ui-kit";
import { ReactNode, SyntheticEvent, useContext, useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import {
  getInvoiceNoteLineItem,
  actions as invoiceLineItemAction
} from "@/pages/Invoice/State/InvoiceNoteLineItem.slice";
import { useDispatch } from "react-redux";
import InvoiceLineItemModal from "@/shared/components/InvoiceLineItemModal/InvoiceLineItemModal";

type clickHandlerType = (e: SyntheticEvent, selectedItem: ISelectedItem) => void;
type ObjectType =
  | {
      [key: string]: any;
    }
  | undefined;

const CustomCell = ({ field, row }: cellRendererType) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { orderno, invoiceId } = useParams<{ orderno: string; invoiceId: any }>();
  const [isViewInvoiceLineItem, setIsViewInvoiceLineItem] = useState<boolean>(false);
  const currentInvoiceType = sessionStorage.getItem("invoiceType");
  const [lineType, setLineType] = useState<string>("");
  const history = useHistory();
  const historyState = history.location.state as any;
  const dispatch = useDispatch<AppDispatch>();
  const { invoiceDetails, invoiceAllOrder } = useAppSelector((state) => state.invoiceDetails);
  const { orderSelectedRow } = useAppSelector((state) => state.createOrderInvoice);
  const { invoiceNoteLineItem, selectedRow } = useAppSelector((state) => state.invoiceNoteLineItem);
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const handleDeleteDisable = (selectedRow: any) => {
    if (historyState?.invoiceLineList?.length > 0) {
      if (
        invoiceDetails?.source !== viewPageStatus.XML &&
        ((selectedRow?.line_type === DELIV_STATUS.PART_DELIVERED && currentInvoiceType === INVOICE_TYPE?.ORDERINV) ||
          (selectedRow?.line_type !== invoiceLineTypes.LINETYPEV && currentInvoiceType !== INVOICE_TYPE?.ORDERINV))
      ) {
        return false;
      }
    }
    return true;
  };
  const options: OptionsType[] = [
    {
      text: "edit",
      value: "edit",
      children: <RowAction optionName={t("invoiceNote.editCurrentLine")} />
    },
    {
      text: "clear",
      value: "clear",
      disabled: handleDeleteDisable(row),
      children: <RowAction optionName={t("invoiceNote.deleteCurrentLine")} />
    }
  ];

  const orderLineActionHandler: clickHandlerType = async (e, selectedItem) => {
    dispatch(invoiceLineItemAction.setSelectedRowCustomCell(selectedItem));
    dispatch(invoiceLineItemAction.setSelectedRowCustomCellRow(row));
  };

  const fIsStandardLine = (rowData: { [key: string]: any }) => {
    if (rowData) {
      let filteredInvoiceOrderType;
      if (orderno) {
        filteredInvoiceOrderType = invoiceAllOrder?.filter((key) => key.id.toString() === orderno)[0]?.order_type;
      } else {
        filteredInvoiceOrderType = historyState?.invoiceDetails?.order_type ?? orderSelectedRow?.order_type;
      }
      if (rowData.line_type === invoiceLineTypes.INVOICELINE && !FFreeTextOrderInvoice(filteredInvoiceOrderType)) {
        return true;
      }
      return false;
    }
    return false;
  };
  const FFreeTextOrderInvoice = (val: string) => {
    if (val === invoiceLineTypes.FREETEXTORDERLINE) {
      return true;
    }
    return false;
  };
  const getContent = () => {
    if (field === "inv_unit_cost" && row) {
      return (
        <>
          <div>
            {!fIsStandardLine(row) && row?.inv_unit_cost !== specialCharacters.BLANKVALUE
              ? specialCharacters.HYPHEN
              : numberFormatter.format(row?.inv_unit_cost)}
          </div>
        </>
      );
    }
    if (field === "discount" && row) {
      return (
        <>
          <div>
            {row?.discount || row?.discount === 0 ? numberFormatter.format(row?.discount) : specialCharacters?.zero}
          </div>
        </>
      );
    }
    if (field === "line_cost" && row) {
      return (
        <>
          <div>{numberFormatter.format(row?.line_cost)}</div>
        </>
      );
    }
    if (field === "qty_out" && row) {
      return (
        <>
          <div>
            {!fIsStandardLine(row) && row?.qty_out !== specialCharacters.BLANKVALUE
              ? specialCharacters.HYPHEN
              : row?.qty_out}
          </div>
        </>
      );
    }
    if (field === "qty_inv" && row) {
      return (
        <>
          <div>
            {!fIsStandardLine(row) && row?.qty_inv !== specialCharacters.BLANKVALUE
              ? specialCharacters.HYPHEN
              : row?.qty_inv}
          </div>
        </>
      );
    }
    if (
      (field === "actions" && !invoiceId) ||
      invoiceDetails?.status === INVOICE_STATUS.UNAUTHORISED ||
      invoiceDetails?.status === INVOICE_STATUS.AUTHORISED
    ) {
      return (
        <GridRowActions
          name={
            <Icon
              size={IconSize.Medium}
              name="overflow-menu--horizontal"
            />
          }
          options={options}
          onClick={orderLineActionHandler}
          selectedRow={selectedRow}
        />
      );
    }
    return (
      <>
        <Button
          color={ButtonColor.Utility}
          className="segments-buttons"
          onClick={() => {
            setIsViewInvoiceLineItem(true);
            dispatch(invoiceLineItemAction.setSelectedRow(row));
          }}
          disabled={invoiceNoteLineItem?.length === 0}
        >
          {t("common.view02")}
        </Button>
        <InvoiceLineItemModal
          isOpen={isViewInvoiceLineItem}
          setOpen={setIsViewInvoiceLineItem}
        />
      </>
    );
  };
  return getContent();
};

export default CustomCell;

type OptionProps = {
  iconName?: string;
  optionName: string;
  children?: ReactNode;
};
const RowAction = ({ iconName, optionName, children }: OptionProps) => (
  <div className="option">
    {iconName ? (
      <Icon
        size={IconSize.Medium}
        name={iconName}
      />
    ) : (
      children
    )}
    {optionName}
  </div>
);

RowAction.defaultProps = {
  iconName: undefined,
  children: undefined
};
