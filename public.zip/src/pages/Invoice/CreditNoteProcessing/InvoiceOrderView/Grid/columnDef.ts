import { TColumnDef } from "@/components/GridTable/GridTable";

const orderLineItemsOrderInvoiceColumnDef: TColumnDef = [
  {
    headerName: "Line No",
    field: "inv_line_number",
    align: "left"
  },
  {
    headerName: "Ref Line",
    field: "reference_line",
    align: "left"
  },
  {
    headerName: "Part No",
    field: "part_no",
    align: "left"
  },
  {
    headerName: "Description",
    field: "at_calc_item_des",
    align: "left"
  },
  {
    headerName: "Qty Out.",
    field: "qty_out",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Qty Inv.",
    field: "qty_inv",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Unit Cost",
    field: "inv_unit_cost",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Disc%",
    field: "discount",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Net Amount",
    field: "line_cost",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "VAT",
    field: "vat_code",
    align: "left"
  },
  {
    headerName: "",
    field: "actions",
    align: "right",
    cellRenderer: "GridCellLink"
  }
];

export const nonOrderLineItemsOrderInvoiceColumnDef: TColumnDef = [
  {
    headerName: "Line No",
    field: "inv_line_number",
    align: "left"
  },
  {
    headerName: "Ref Line",
    field: "reference_line",
    align: "left"
  },
  {
    headerName: "Ledger",
    field: "ledger_code",
    align: "left"
  },
  {
    headerName: "Ledger Description",
    field: "ledger_des",
    align: "left"
  },
  {
    headerName: "Cost Centre",
    field: "cost_code",
    align: "left"
  },
  {
    headerName: "Cost Centre Description",
    field: "cost_des",
    align: "left"
  },
  {
    headerName: "Net Amount",
    field: "line_cost",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "VAT",
    field: "vat_code",
    align: "left"
  },
  {
    headerName: "",
    field: "actions",
    align: "right",
    cellRenderer: "GridCellLink"
  }
];

export default orderLineItemsOrderInvoiceColumnDef;
