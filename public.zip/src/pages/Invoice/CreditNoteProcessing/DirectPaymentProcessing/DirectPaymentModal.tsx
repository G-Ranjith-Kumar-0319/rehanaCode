import GridTableNew from "@/components/GridTableNew/GridTableNew";
import useDebounce from "@/hooks/useDebounce";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { useAppSelector } from "@/store/store";
import { directPaymentProcessingColumnDef } from "@/utils/constants";
import findNearest from "@/utils/nearestSearch";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { FormLabel, Grid, GridItem, Segmented, TextInput, TextInputSize } from "@essnextgen/ui-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { actions } from "../../State/InvoiceDirectPaymentProcessing.slice";

const DirectPaymentModal = ({ isLoading, setCardRow }: any) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const { debitCardData, cardSelectedRow } = useAppSelector((state) => state.directPaymentProcess);
  const [search, setSearchTerm] = useState<string>("");
  const searchTerm = useDebounce(search, 500);
  const [localSelected, setLocalSelected] = useState(undefined);

  const handleSelectedRow = (row: any) => {
    if (row) {
      setCardRow(row);
      setLocalSelected(row);
    }
  };
  const directPaymentFilter = (value: any) => {
    setSearchTerm(value);
    if (!value) {
      setLocalSelected(debitCardData?.at(0));
    }
  };

  useEffect(() => {
    let found;
    if (searchTerm !== "" && debitCardData && debitCardData.length) {
      const key = "debit_card_holder";
      found = [...debitCardData]
        .filter((element) =>
          searchTerm ? element[key!]?.toString()?.toUpperCase()?.startsWith(searchTerm?.toUpperCase()) : false
        )
        .at(0);
      if (found && found !== undefined) handleSelectedRow(found);
      if (found === undefined) {
        found = findNearest(
          [...debitCardData],
          [{ fieldName: debitCardData?.debit_card_holder!, searchValue: searchTerm }],
          true
        );
        handleSelectedRow(found);
      }
      const element = document.getElementById(`rowIndex-invoiceDirectPaymentModal-${debitCardData.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [searchTerm, setCardRow]);

  useEffect(() => {
    const timer = setTimeout(() => {
      document.getElementById("looking-for")?.focus();
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <div className="grid-table">
        <GridTableNew
          filters={
            <>
              <LookingFor
                restrictInput={() => {}}
                initialValue={search}
                isInputReadOnly={false}
                callback={handleSelectedRow}
                changeHandler={directPaymentFilter}
                hasDatePicker={false}
                className="essui-global-typography-default-h2 looking-for-container"
              />
            </>
          }
          columnDef={directPaymentProcessingColumnDef}
          dataTestId="invoiceDirectPaymentModal"
          dataSource={debitCardData || []}
          selectedRow={localSelected || cardSelectedRow}
          selectedRowHandler={handleSelectedRow}
          isLoading={isLoading}
          onEnterKeyPress={() => {
            dispatch(actions.setSelectedRow(localSelected));
          }}
        />
      </div>
    </>
  );
};

export default DirectPaymentModal;
