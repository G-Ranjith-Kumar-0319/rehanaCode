import React, { useCallback, useEffect, useRef, useState } from "react";
import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import Modal from "@/components/Modal/Modal";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  Loader,
  LoaderType,
  Notification,
  NotificationStatus
} from "@essnextgen/ui-kit";

import { useAppDispatch, useAppSelector } from "@/store/store";
import { formatCardExpiryDate } from "@/utils/getDataSource";
import { useHistory, useParams } from "react-router-dom";
import { CARD_NUMBER_MASK, INVOICE_ROW, RESPONSE_STATUS, cardEditLength } from "@/types/UseStateType";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import {
  invoiceGetDebitCard,
  actions,
  invoiceDirectPaymentProccesing
} from "../../State/InvoiceDirectPaymentProcessing.slice";
import DirectPaymentModal from "./DirectPaymentModal";
import { getInvoiceOrdersFilter, actions as ioActions } from "../../State/InvoiceNoteList.slice";

export function getFirstElement(debitCardsArray: any) {
  if (Array.isArray(debitCardsArray) && debitCardsArray.length === 1) {
    return debitCardsArray[0];
  }
  return null;
}

const DirectPaymentProcessing = () => {
  const { invoiceDetails } = useAppSelector((state) => state.invoiceDetails);
  const { selectedRow, filterState, currentPage } = useAppSelector((state: any) => state.invoiceNote);
  const { isLoaded, cardSelectedRow, debitCardData, cardModaltitle, isChargeCard, storeCurrPage } = useAppSelector(
    (state: any) => state.directPaymentProcess
  );
  const { invoiceId } = useParams<{ orderno: string; invoiceId: any }>();
  const invoiceData = invoiceId ? invoiceDetails : selectedRow;
  const [isModalOpen, setModalOpen] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [isSaveLoading, setSaveLoading] = useState(false);
  const [getCardRow, setCardRow] = useState<any>();
  const [hasError, setError] = useState(false);
  const [cardValue, setCardValue] = useState(cardSelectedRow?.masked_card_number || CARD_NUMBER_MASK?.SIXTEEN_CHAR);
  const [paidByValue, setPaidByValue] = useState(cardSelectedRow?.debit_card_holder || "");
  const [expireDateValue, setExpireDateValue] = useState(
    cardSelectedRow?.disp_expiry_date ? cardSelectedRow?.disp_expiry_date : "-"
  );
  const [isCardNoValid, setCardNoValid] = useState(false);
  const [isPaidByValid, setPaidByValid] = useState(false);
  const [isOpenAlert, setIsOpenAlert] = useState<boolean>(false);
  const [toggle, setToggle] = useState(false);
  const { alert } = useAppSelector((state) => state.ui);
  const dispatch = useAppDispatch();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const {
    location: { pathname }
  } = history;
  const [isPageChanged, setIsPageChanged] = useState(false);
  const fetchCardData = async () => {
    setLoading(true);
    const data = await dispatch(invoiceGetDebitCard(invoiceData?.bank_id));
    if (data && data?.payload) {
      const updatedCardData = (data?.payload as any[]).map((item: any) => ({
        ...item,
        disp_expiry_date: formatCardExpiryDate(item?.disp_expiry_date)
      }));
      dispatch(actions.setDebitcardData(updatedCardData as any));
      dispatch(actions.setLoaded(true));
    } else {
      setError(true);
    }
    setLoading(false);
  };
  const onBlur = (e: any) => {
    if (e?.target?.value === CARD_NUMBER_MASK.SIXTEEN_CHAR) {
      setCardValue(CARD_NUMBER_MASK?.SIXTEEN_CHAR);
      setIsPageChanged(true);
      clearSelectedRow();
    } else if (cardValue?.length < cardEditLength?.maxLength) {
      // setCardNoValid(true);
    } else if (e?.target?.value === cardEditLength.maxLength) {
      setCardNoValid(false);
    }
  };

  const refreshPageAndGetUpdatedList = () => {
    dispatch(ioActions.setFilters({ ...filterState, invoiceId: selectedRow?.invoice_id, lookingFor: "" }));
  };

  const handleValidationAndAlert = () => {
    const isCardInvalid = cardValue?.length < cardEditLength?.maxLength;
    const isPaidByInvalid = !paidByValue || paidByValue.trim() === "";

    if (isCardInvalid || isPaidByInvalid) {
      setCardNoValid(isCardInvalid);
      setPaidByValid(isPaidByInvalid);
      setPaidByValue("");
      setIsOpenAlert(true);
      return true; // Validation failed
    }

    return false; // Validation passed
  };

  const directPaymentProcessingSave = async (e?: any) => {
    // e.preventDefault();
    if (handleValidationAndAlert()) {
      return;
    }
    if (!isCardNoValid && !isPaidByValid) {
      setSaveLoading(true);
      const res = await dispatch(
        invoiceDirectPaymentProccesing({
          bankId: invoiceData?.bank_id,
          invoiceId: invoiceData?.invoice_id,
          period: invoiceData?.period,
          debitCardId: cardSelectedRow?.debit_card_id,
          paymentBy: cardSelectedRow?.debit_card_holder,
          narrative: `Payment by ${isChargeCard ? "Charge Card" : "Debit Card"} no. ${
            cardSelectedRow?.debit_card_number
          } by ${cardSelectedRow?.debit_card_holder}`
        })
      );
      if (res?.meta?.requestStatus === RESPONSE_STATUS?.FULFILLED) {
        setIsPageChanged(false);
        refreshPageAndGetUpdatedList();
        history.goBack();
        clearSelectedRow();
      }
    } else {
      setIsOpenAlert(true);
    }
    setIsPageChanged(false);
    setSaveLoading(false);
  };

  const handleInputChange = (value: string) => {
    setIsPageChanged(true);
    if (value?.length === cardEditLength?.maxLength) {
      setCardNoValid(false);
    } else if (value?.length === cardEditLength?.length) {
      setPaidByValue("");
      setExpireDateValue("");
    } else {
      setIsPageChanged(true);
      setCardValue(value);
    }
  };

  const clearSelectedRow = () => {
    dispatch(actions.setSelectedRow(undefined));
    setPaidByValue("");
    setCardValue(CARD_NUMBER_MASK?.SIXTEEN_CHAR);
  };

  // clear data on unmount
  useEffect(
    () => () => {
      clearSelectedRow();
      setCardValue(CARD_NUMBER_MASK?.SIXTEEN_CHAR);
      setPaidByValue("");
    },
    []
  );

  useEffect(() => {
    if (!cardSelectedRow) {
      setPaidByValue("");
      setCardValue(CARD_NUMBER_MASK?.SIXTEEN_CHAR);
      setExpireDateValue("-");
    } else {
      setPaidByValue(cardSelectedRow?.debit_card_holder);
      setCardValue(cardSelectedRow?.masked_card_number);
      setExpireDateValue(cardSelectedRow?.disp_expiry_date);
      setModalOpen(false);
    }
  }, [cardSelectedRow]);

  let flag = false;
  // TODO: Breadcrumb keep your changes
  useEffect(() => {
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      if (
        // location.pathname === "/invoice-credit-note" &&
        (location.pathname === `/invoice-credit-note/nonorder-invoice/invoiceId/${invoiceId}` ||
          location.pathname === `/invoice-credit-note`) &&
        !alert?.enable &&
        (isPageChanged ||
          pathname === "/invoice-credit-note/non-order/add" ||
          pathname === "/invoice-credit-note/order/add" ||
          pathname === "/invoice-credit-note/credit-note/add")
      ) {
        dispatch(
          uiActions.confirmPopup({
            enable: true,
            message: t("alertMessage.keepChangesMsg"),
            title: t("common.simsFMSModule"),
            type: MODAL_TYPE.CONFIRMV2,
            yesCallback: async () => {
              let result;
              if (directPaymentProcessingSave) {
                directPaymentProcessingSave();
              }
            },
            noCallback: () => {
              flag = true;
              if (invoiceId) {
                history.push(`/invoice-credit-note/nonorder-invoice/invoiceId/${invoiceId}`);
              } else {
                history.push("/invoice-credit-note");
              }
            },
            isCancelBtnEnable: true
          })
        );

        if (!flag) {
          return false;
        }
      }
    });

    return () => {
      unblock();
    };
  }, [isPageChanged, cardValue]);

  return (
    <>
      {isSaveLoading ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        <Layout
          pageTitle={cardModaltitle}
          className="invoice-credit-note"
          isBreadcrumbRequired
        >
          <Grid className="mt-8">
            <GridItem
              lg={3}
              xl={3}
              sm={6}
            >
              <div className="table-controls">
                <div className="controls">
                  <FormLabel>{t("invoiceNote.vatAmount")}</FormLabel>
                  <div className="mt-16">
                    {invoiceData?.vat_total ? parseFloat(invoiceData?.vat_total).toFixed(2) : "0.00"}
                  </div>
                </div>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              xl={3}
              sm={6}
            >
              <div className="table-controls">
                <div className="controls">
                  <FormLabel>{t("viewInvoiceCreditNote.invoiceTotalIncludingVatDirectPayment")}</FormLabel>
                  <div className="mt-16">{invoiceData?.total ? parseFloat(invoiceData?.total).toFixed(2) : "0.00"}</div>
                </div>
              </div>
            </GridItem>
          </Grid>
          <Grid className="mt-16">
            <GridItem
              lg={3}
              xl={3}
              sm={6}
            >
              <Input
                searchItems={debitCardData.map((t: any) => ({
                  text: t?.masked_card_number,
                  value: t?.masked_card_number
                }))}
                onChange={(e: any) => handleInputChange(e?.target?.value)}
                onNoSelection={() => {
                  setModalOpen(true);
                  setCardValue(CARD_NUMBER_MASK?.SIXTEEN_CHAR);
                  setIsPageChanged(true);
                }}
                onKeyDown={(e: any) => {
                  if (e?.key === "Delete") {
                    e.preventDefault();
                  } else if (e?.key === "Backspace") {
                    const { value, selectionStart, selectionEnd } = e.target;
                    const maxLength = cardEditLength?.maxLength;
                    if (value.length === cardEditLength?.length) {
                      e.preventDefault();
                    } else if (selectionStart === 0 && selectionEnd >= maxLength - 4) {
                      e.preventDefault();
                    }
                  }
                }}
                onBlur={onBlur}
                onSelect={(selected) => {
                  if (selected) {
                    const found = debitCardData
                      ?.filter((card: any) => card?.masked_card_number === selected?.text)
                      .at(0);
                    if (found) {
                      dispatch(actions.setSelectedRow(found));
                      setIsPageChanged(true);
                    }
                  }
                }}
                searchable
                id="paidFromCard"
                value={cardValue}
                button={
                  <Button
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      if (!isLoaded) {
                        fetchCardData();
                      }
                      setModalOpen(true);
                    }}
                    className="btnclass essui-button-icon-only--small"
                    size={ButtonSize.Small}
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                }
                disabled={false}
                labelText={t("invoiceNote.paidFromCardDirect")}
                className={`${
                  isCardNoValid
                    ? "essui-textinput--error direct-payment-process-card-number"
                    : "direct-payment-process-card-number"
                }`}
              />
            </GridItem>
            <GridItem
              lg={3}
              sm={6}
              xl={3}
            >
              <div className="table-controls">
                <div className="controls">
                  <FormLabel>{t("supplierView.additionalTab.expiryDate")}</FormLabel>
                  <div className="mt-8">{expireDateValue}</div>
                </div>
              </div>
            </GridItem>
          </Grid>

          <Grid className="mt-8">
            <GridItem
              lg={5}
              xl={5}
            >
              <Input
                id="directPaidby"
                className={`${isPaidByValid ? "essui-textinput--error" : ""}`}
                searchable={false}
                value={paidByValue}
                onChange={(e) => {
                  setPaidByValue(e.target.value);
                  setIsPageChanged(true);
                }}
                onBlur={(e: any) => {
                  if (e.target.value) {
                    setPaidByValid(false);
                  }
                }}
                disabled={false}
                labelText={t("common.paidBy")}
              />
            </GridItem>
          </Grid>
          <Grid
            className="mt-16"
            justify="space-between"
          >
            <GridItem
              sm={8}
              lg={8}
              md={4}
            >
              {/* <Button
                size={ButtonSize.Small}
                onClick={() => {}}
                color={ButtonColor.Tertiary}
                iconPosition={ButtonIconPosition.Left}
              >
                {t("common.help")}
              </Button> */}
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </GridItem>
            <GridItem>
              <Grid
                className="action-buttons"
                justify="space-between"
              >
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={() => {
                    history.goBack();
                    if (!isPageChanged) {
                      clearSelectedRow();
                    }
                  }}
                >
                  {t("common.cancel")}
                </Button>
                &nbsp; &nbsp;
                <Button
                  size={ButtonSize.Small}
                  onClick={directPaymentProcessingSave}
                >
                  {t("common.pay")}
                </Button>
              </Grid>
            </GridItem>
          </Grid>
        </Layout>
      )}

      {/* Direct payment processing modal  */}
      <Modal
        header={t("invoiceNote.cardHolderDetails")}
        isOpen={isModalOpen}
        secondaryBtnText={t("common.selectButton")}
        className=""
        onClose={() => setModalOpen(false)}
        secondaryBtnType={ButtonColor.Primary}
        secondaryBtnClick={() => {
          dispatch(actions.setSelectedRow(getCardRow));
          setCardValue(getCardRow?.masked_card_number);
          setPaidByValue(getCardRow?.debit_card_holder);
          setExpireDateValue(getCardRow?.disp_expiry_date);
          setPaidByValid(false);
          setCardNoValid(false);
          setModalOpen(false);
        }}
        tertiaryBtnText={t("common.cancel")}
        tertiaryBtnClick={() => {
          setModalOpen(false);
        }}
        fourthiaryBtnClick={() => {}}
      >
        <DirectPaymentModal
          setCardValue={setCardValue}
          setCardRow={setCardRow}
          isLoading={isLoading}
        />
      </Modal>

      <Modalv2
        isOpen={isOpenAlert}
        header={t("common.simsFMSModule")}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              setIsOpenAlert(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
      >
        <>
          <Notification
            actionElement={1}
            dataTestId="delete-new-warning-id"
            escapeExits
            id="delete-new-warning-id"
            hideCloseButton
            status={NotificationStatus.WARNING}
            className="confirm-modal-text"
            title={t("invoiceNote.directPaySaveModalError")}
          />
        </>
      </Modalv2>
    </>
  );
};

export default DirectPaymentProcessing;
