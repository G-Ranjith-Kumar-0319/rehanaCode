import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import Modal from "@/components/Modal/Modal";
import "./DirectPaymentReversal.scss";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  Notification,
  Icon,
  IconColor,
  IconSize,
  Loader,
  LoaderType,
  Textarea,
  ValidationTextLevel,
  NotificationStatus
} from "@essnextgen/ui-kit";
import { useEffect, useLayoutEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "@/store/store";
import useQuery from "@/hooks/useQuery";
import UseStateType, { INVOICE_ROW, METHOD, STATUS } from "@/types/UseStateType";
import { formatCardExpiryDate } from "@/utils/getDataSource";
import { useHistory, useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import {
  invoiceGetDebitCard,
  actions,
  invoiceDirectPaymentProccesing,
  bankChargeCard,
  invoiceDebitRun,
  directCancelPayment
} from "../../State/InvoiceDirectPaymentProcessing.slice";
import { getInvoiceOrdersFilter, actions as ioActions } from "../../State/InvoiceNoteList.slice";
/* eslint-disable camelcase */
type InvoiceFormData = {
  reason: string;
  invoice_id: string;
};

type ModalType = {
  isOpen: boolean;
  method?: METHOD;
};
type FieldsType = InvoiceFormData;
const DirectPaymentReversal = () => {
  const { invoiceDetails } = useAppSelector((state) => state.invoiceDetails);
  const { selectedRow, filterState, currentPage } = useAppSelector((state: any) => state.invoiceNote);
  const { isLoaded, cardSelectedRow, cardModaltitle, invoicePaymentDetail } = useAppSelector(
    (state: any) => state.directPaymentProcess
  );
  const { isChargeCard, storeCurrPage } = useAppSelector((state) => state?.directPaymentProcess);
  const searchParams = useQuery();
  const { invoiceId } = useParams<{ orderno: string; invoiceId: any }>();
  const invoiceData = invoiceId ? invoiceDetails : selectedRow;
  const [isModalOpen, setModalOpen] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [isSaveLoading, setSaveLoading] = useState(false);
  const [getCardRow, setCardRow] = useState();
  const [hasError, setError] = useState(false);
  const dispatch = useAppDispatch();
  const [alertMessage, setAlertMessage] = useState<string>("");
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const {
    location: { pathname }
  } = history;
  const [isOrderLineDetailsModalOpen, setIsOrderLineDetailsModalOpenn] = useState<ModalType>({
    isOpen: false,
    method: METHOD.ADD
  });
  const [isOpenInvalidAlert, setIsOpenInvalidAlert] = useState<boolean>(false);
  const { alert } = useAppSelector((state) => state.ui);
  const refreshPageAndGetUpdatedList = () => {
    dispatch(ioActions.setFilters({ ...filterState, invoiceId: selectedRow?.invoice_id, lookingFor: "" }));
  };

  const {
    register,
    reset,
    getValues,
    setValue,
    handleSubmit,
    watch,
    trigger,
    formState: { errors, isDirty }
  } = useForm<InvoiceFormData>();
  useEffect(() => {
    setValue("invoice_id", invoiceData?.invoice_id);
    dispatch(
      invoiceDebitRun({
        invoiceID: invoiceData?.invoice_id,
        isChargeCard
      })
    );
  }, [invoiceData]);

  const onSubmit = handleSubmit(
    async (data) => {
      if (data) {
        if (invoiceData?.invoice_id) {
          const res = await dispatch(
            directCancelPayment({
              invoice_id: invoiceData?.invoice_id,
              reason: getValues("reason")
            })
          );
          if (res.meta.requestStatus === "fulfilled" && res.payload === "Successfully Update.") {
            refreshPageAndGetUpdatedList();
            history.goBack();
          }
        }
      }
    },
    (error) => {
      setAlertMessage(t("common.invalidData"));
      setIsOpenInvalidAlert(true);
    }
  );

  let flag = false;
  // TODO: Breadcrumb keep your changes
  useEffect(() => {
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      if (
        // location.pathname === "/invoice-credit-note" &&
        (location.pathname === `/invoice-credit-note/nonorder-invoice/invoiceId/${invoiceId}` ||
          location.pathname === `/invoice-credit-note`) &&
        !alert?.enable &&
        (isDirty ||
          pathname === "/invoice-credit-note/non-order/add" ||
          pathname === "/invoice-credit-note/order/add" ||
          pathname === "/invoice-credit-note/credit-note/add")
      ) {
        dispatch(
          uiActions.confirmPopup({
            enable: true,
            message: t("alertMessage.keepChangesMsg"),
            title: t("common.simsFMSModule"),
            type: MODAL_TYPE.CONFIRMV2,
            yesCallback: async () => {
              let result;
              if (onSubmit) {
                onSubmit();
              }
            },
            noCallback: () => {
              flag = true;
              if (invoiceId) {
                history.push(`/invoice-credit-note/nonorder-invoice/invoiceId/${invoiceId}`);
              } else {
                history.push("/invoice-credit-note");
              }
            },
            isCancelBtnEnable: true
          })
        );

        if (!flag) {
          return false;
        }
      }
    });

    return () => {
      unblock();
    };
  }, [alert?.enable, isDirty]);
  return (
    <>
      {isSaveLoading ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        <Layout
          pageTitle={t("invoiceNote.directpaymentReversal")}
          className="invoice-credit-note"
          isBreadcrumbRequired
        >
          <Grid>
            <GridItem
              lg={3}
              xl={3}
              sm={6}
            >
              <FormLabel>{t("invoiceNote.vatAmount")}</FormLabel>
              <div
                className="mt-8"
                id="vat"
              >
                {invoiceData?.vat_total ? parseFloat(invoiceData?.vat_total).toFixed(2) : "0.00"}
              </div>
            </GridItem>
            <GridItem
              lg={3}
              xl={3}
              sm={6}
            >
              <FormLabel>{t("viewInvoiceCreditNote.invoiceTotalIncludingVat")}</FormLabel>
              <div
                className="mt-8"
                id="totalVat"
              >
                {invoiceData?.total ? parseFloat(invoiceData?.total).toFixed(2) : "0.00"}
              </div>
            </GridItem>
          </Grid>
          <Grid className="mt-16">
            <GridItem
              lg={3}
              xl={3}
              sm={6}
            >
              <FormLabel>{t("common.paidBy")}</FormLabel>
              <div
                className="mt-8"
                id="paidBy"
              >
                {invoicePaymentDetail[0]?.actual_payment_by ? invoicePaymentDetail[0]?.actual_payment_by : "-"}
              </div>
            </GridItem>
            <GridItem
              lg={3}
              xl={3}
              sm={6}
            >
              <FormLabel>{t("invoiceNote.paidFromCardNumber")}</FormLabel>
              <div
                className="mt-8"
                id="paidBy"
              >
                {invoicePaymentDetail[0]?.debit_card_number
                  ? `xxxx-xxxx-xxx-${invoicePaymentDetail[0]?.debit_card_number}`
                  : "-"}
              </div>
            </GridItem>
          </Grid>
          <Grid className="mt-16">
            <GridItem
              lg={5}
              xl={5}
            >
              <div className="payment-desc-width ">
                <div className="payment-desc-width ">
                  <FormLabel>{t("invoiceNote.reasonForPaymentCancellation")}</FormLabel>
                  <div className="mt-8">
                    <Textarea
                      {...register("reason", { required: true })}
                      useAutoWidth={false}
                      cols={undefined}
                      rows={undefined}
                      value={getValues("reason")}
                      onChange={(e) => {
                        setValue("reason", e.currentTarget.value, { shouldDirty: true });
                        trigger("reason");
                      }}
                      validationTextLevel={errors.reason ? ValidationTextLevel.Error : undefined}
                    />
                  </div>
                </div>
              </div>
            </GridItem>
          </Grid>
          <Grid
            className="mt-16"
            justify="space-between"
          >
            <GridItem
              sm={8}
              lg={8}
              md={4}
            >
              {/* <Button
                size={ButtonSize.Small}
                onClick={() => {}}
                color={ButtonColor.Tertiary}
                iconPosition={ButtonIconPosition.Left}
              >
                {t("common.help")}
              </Button> */}
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </GridItem>
            <GridItem>
              <Grid
                className="action-buttons"
                justify="space-between"
              >
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={() => {
                    history.goBack();
                  }}
                >
                  {t("common.cancel")}
                </Button>
                &nbsp; &nbsp;
                <Button
                  size={ButtonSize.Small}
                  onClick={onSubmit}
                  // disabled={!cardSelectedRow}
                >
                  {t("common.reversePayment")}
                </Button>
              </Grid>
            </GridItem>
          </Grid>
        </Layout>
      )}
      <Modalv2
        isOpen={isOpenInvalidAlert}
        header={t("common.simsFMSModule")}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => setIsOpenInvalidAlert(false)}
          >
            {t("common.ok")}
          </Button>
        }
        className="confirm-modal-text"
        onClose={() => setIsOpenInvalidAlert(false)}
      >
        <>
          <Notification
            actionElement={1}
            dataTestId="invalid-input"
            escapeExits
            hideCloseButton
            status={NotificationStatus.ERROR}
            title={alertMessage}
          />
        </>
      </Modalv2>
    </>
  );
};

export default DirectPaymentReversal;
