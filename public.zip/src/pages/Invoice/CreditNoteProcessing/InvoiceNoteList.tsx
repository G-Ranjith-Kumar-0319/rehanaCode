import React, { SyntheticEvent, useContext, useEffect, useState } from "react";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  FormLabel,
  Grid,
  GridItem,
  IPaginationProps,
  ITableProps,
  Icon,
  Notification,
  NotificationStatus,
  Pagination
} from "@essnextgen/ui-kit";
import "./Style.scss";
import { Link, useHistory, useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import Layout from "@/components/Layout/Layout";
import { cellRendererType } from "@/components/GridTable/GridTable";
import { INVOICE_STATUS, MessageType, STATUS, invoiceTypesName, specialCharacters } from "@/types/UseStateType";
import { TagAll } from "@/shared/components/TagAll/TagAll";
import { invoiceOrderType, sundryInvoiceType } from "@/utils/constants";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { TTagDataParams } from "@/shared/components/TagAll/types";
import { supplierActions } from "@/pages/PurchaseOrder/state/Suppliers.slice";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import { RootContext, useAppContext } from "@/routes/Routes";
import { tagSupplierActions } from "@/shared/components/TagSupplier/state/TagSupplier.slice";
import { setToSession } from "@/utils/getDataSource";
import InvoiceOrderTools from "../InvoiceOrderToolbar";
import {
  authorizedTagged,
  getFilteredInvoice,
  getInvoiceOrdersFilter,
  getInvoicesByTagFilters,
  actions as ioActions
} from "../State/InvoiceNoteList.slice";
import { getInvoiceNoteStatus } from "../State/InvoiceNoteStatus.slice";
import CreditNoteFilters from "../Grid/CreditNoteFilters";
import InvoiceOrderPageToolbar from "../InvoiceOrderPageToolbar";
import { getInvoiceNoteType } from "../State/InvoiceNoteType.slice";
import { actions, actions as invNoteListAction } from "../State/InvoiceNoteLineItem.slice";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];

const InvoiceNoteList = (args: ITableProps) => {
  const dispatch = useDispatch<AppDispatch>();
  const {
    status,
    viewStatus,
    pageStatus,
    selectedRow,
    checkedRows,
    columnDef: poColumnDef,
    filterState,
    isFocus,
    checkedInvoices = [],
    isPrintLoading
  } = useAppSelector((state) => state.invoiceNote);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    invoices = [],
    currentPage,
    totalPages,
    pageSize
  } = useAppSelector((state) => state?.invoiceNote.invoiceNoteList);
  const [isTaggedOpen, setIsTaggedOpen] = useState<boolean>(false);
  const [currentPageState, setCurrentPageState] = useState<any>(currentPage);
  const { isDirectPaymentLoading } = useAppSelector((state) => state.directPaymentProcess);
  const { isChequePaymentLoading } = useAppSelector((state) => state.chequeDetails);
  const [isUnTagAll, setIsUnTagAll] = useState<boolean>(false);
  const [lookingFor, setLookingFor] = useState<string | undefined>(undefined);
  // Below states are managin multi authorization
  const [successCount, setSuccesCount] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [isNotifyModal, setNotifyModal] = useState<boolean>(false);
  const [isFinalSuccessModal, setFinalSuccessModal] = useState<boolean>(false);
  const [openConfirmation, setOpenConfirmation] = useState(false);
  const [currentRecordIndex, setCurrentRecordIndex] = useState(0);
  const [isMultiAuthLoading, setMultiAuthLoading] = useState<boolean>(false);
  const [messageType, setMessagetype] = useState<string>("");
  const history = useHistory();
  const historyState = { ...(history.location.state as any) };
  const { redirectToInvoiceDetailsLink } = useAppContext();
  const dataTestId = "invoiceList";
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;
  useEffect(() => {
    dispatch(getInvoiceNoteType());
    dispatch(getInvoiceNoteStatus());
    setToSession("isHotKey", false);
  }, []);
  // To Clear invoice line list and selected on list page
  useEffect(() => {
    dispatch(invNoteListAction.updateInvoiceLineItem([]));
    dispatch(invNoteListAction.setSelectedRow(undefined));
  }, []);

  useEffect(() => {
    if (isFocus) {
      dispatch(
        getInvoiceOrdersFilter({
          sequence: filterState?.sequence,
          status: filterState?.status,
          order: filterState?.order,
          pageNumber: filterState?.pageNumber,
          pageSize: filterState?.pageSize,
          type: filterState?.type,
          defaultSequence: filterState?.defaultSequence,
          callback: (response) => {
            if (response) {
              const selectedData = response.invoices
                ?.filter((item: any) => item.invoice_id === selectedRow?.invoice_id)
                ?.at(0);
              if (selectedData) {
                dispatch(ioActions.setSelectedRow(selectedData));
              } else {
                dispatch(ioActions.setSelectedRow(response.invoices?.at(0)));
              }
            }
          }
        })
      );
    } else if (filterState?.lookingFor) {
      dispatch(
        getFilteredInvoice({
          ...filterState,
          invoiceId: null,
          callback: lookingForApiCallback
        })
      );
    } else if (filterState?.invoiceId) {
      dispatch(
        getInvoiceOrdersFilter({
          ...filterState,
          lookingFor: "",
          callback: (response) => {
            if (response) {
              const currentInvoice = response.invoices;
              const selectedData = currentInvoice
                ?.filter((item: any) => item.invoice_id === response?.highlightInvoiceId)
                ?.at(0);
              if (selectedData) {
                dispatch(ioActions.setSelectedRow(selectedData));
              } else {
                dispatch(ioActions.setSelectedRow(response.invoices?.at(0)));
              }
            }
          }
        })
      );
    } else {
      dispatch(
        getInvoiceOrdersFilter({
          ...filterState,
          callback: (data) => {
            if (selectedRow && data.invoices && data.invoices.length > 0) {
              const newSelecteRow = data.invoices.find((res: any) => res.invoice_id === selectedRow.invoice_id);
              if (newSelecteRow) {
                dispatch(ioActions.setSelectedRow(newSelecteRow));
              } else {
                dispatch(ioActions.setSelectedRow(data.invoices?.at(0)));
              }
            } else {
              dispatch(ioActions.setSelectedRow(data?.invoices?.at(0)));
            }
          }
        })
      );
    }
  }, [filterState]);

  const lookingForApiCallback = (responseData: any) => {
    if (invoices && responseData) {
      if (responseData?.currentPage && currentPage !== responseData?.currentPage) {
        dispatch(
          getInvoiceOrdersFilter({
            ...filterState,
            invoiceId: null,
            pageNumber: responseData.currentPage ? responseData.currentPage : 1,
            defaultSequence: filterState?.defaultSequence,
            callback: (data) => {
              const found = findOrder(data?.invoices, responseData.highlightInvoiceId);
              if (found) {
                highlightSelectedRow(found);
              }
            }
          })
        );
      } else if (invoices && Array.isArray(invoices) && invoices.length && responseData?.highlightInvoiceId) {
        const found = findOrder(invoices, responseData.highlightInvoiceId);
        if (found) {
          highlightSelectedRow(found);
        }
      }
    }
  };

  const findOrder = (orders: any, highlightInvoiceId: number) => {
    const found = orders.find((order: any) => order.invoice_id === highlightInvoiceId);
    if (found) {
      return found;
    }

    return undefined;
  };

  const highlightSelectedRow = (foundRow: any) => {
    dispatch(ioActions.setSelectedRow(foundRow));
  };

  const onChangeHandler: onChangeType = (e, page) => {
    setLookingFor("");
    dispatch(ioActions.setFilters({ ...filterState, invoiceId: null, pageNumber: String(page), lookingFor: "" }));
  };

  const CustomCell = ({ field, row }: cellRendererType) => {
    let invoiceTypeStr = "";

    if (row?.invoice_type === invoiceOrderType.pi) {
      if (row?.order_id !== "" && row?.order_id !== null) {
        invoiceTypeStr = invoiceTypesName?.ORDER_INVOICE;
      } else if (row?.sundry_invoice === sundryInvoiceType.t) {
        invoiceTypeStr = invoiceTypesName?.SUNDARY_INVOICE;
      } else {
        invoiceTypeStr = invoiceTypesName?.NON_ORDER_INVOICE;
      }
    } else if (row?.invoice_type === invoiceOrderType.pc) {
      invoiceTypeStr = invoiceTypesName?.CREDIT_NOTE;
    }

    const invoiceOrderUrl = `invoice-credit-note/${invoiceTypeStr}${
      row?.order_id ? `/orderno/${row?.order_id}` : ""
    }/invoiceId/${row?.invoice_id ? row?.invoice_id : ""}`;

    const getContent = () => {
      if (field === "actionLink") {
        if (row && row.change_from_order === "T") {
          return (
            <Icon
              name="warning--alt"
              className="warning-action"
            />
          );
        }
        return (
          <Icon
            name="checkmark--alt"
            className="checkmark-action"
          />
        );
      }
      if (field === "detailLink") {
        return (
          <Button
            className="grid-actions__button m-auto"
            size={ButtonSize.Small}
            color={ButtonColor.Tertiary}
            onClick={() => {
              const { invoiceDetailsLink } = redirectToInvoiceDetailsLink(row!);
              history.push({
                pathname: invoiceDetailsLink
              });
            }}
            iconName="chevron--right"
          />
        );
      }

      if (field === "total" && row) {
        const numberFormatter = new Intl.NumberFormat("en-US", {
          style: "decimal",
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
        return (
          <>
            <div className="processing">{numberFormatter.format(row?.total)}</div>
          </>
        );
      }

      if (field === "inv_date" && row) {
        return (
          <>
            {new Date(row?.inv_date).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })}
          </>
        );
      }

      return null;
    };
    return getContent();
  };

  const unTagAll = () => {
    setIsUnTagAll(true);
    dispatch(ioActions.clearCheckedInvoices());
    dispatch(ioActions.unCheckAll());
  };

  const tagSubmitHandler = (type: string, params: TTagDataParams) => {
    const { supplier, notInsupplier, notInDate, date1, date2, tagBy, selectedView } = params || {};

    const inputParams: any = {
      supplier,
      notInsupplier,
      notInDate,
      date1,
      date2,
      tagBy,
      selectedView
    };

    inputParams.clientId = params.supplier;
    if (filterState?.status === null || filterState?.status === INVOICE_STATUS.UNAUTHORISED) {
      dispatch(
        getInvoicesByTagFilters({
          ...inputParams,
          callback: tagFiltersApiCallback
        })
      );
    }

    closeHandler();
  };

  const tagFiltersApiCallback = (response: Array<string>) => {
    setIsUnTagAll(false);
    if (filterState?.status === null || filterState?.status === INVOICE_STATUS.UNAUTHORISED) {
      dispatch(ioActions.setCheckedInvoices(response));
    }
  };

  const closeHandler = () => {
    setIsTaggedOpen(false);
    dispatch(tagSupplierActions.resetSelectedRow());
  };

  useEffect(() => {
    if (!isTaggedOpen) {
      dispatch(supplierActions.resetSelectedRow());
    } else {
      dispatch(ioActions.unCheckedAll());
      dispatch(ioActions.clearUncheckedRows());
    }
  }, [isTaggedOpen]);

  useEffect(() => {
    dispatch(ioActions.checkFiltered());
  }, [invoices]);

  const getTagModal = () => (
    <Dialog
      title={t("invoiceNote.tagInvoiceTitle")}
      className="invoice-note-tag"
      isOpen={isTaggedOpen}
      onClose={closeHandler}
    >
      <DialogContent className="tag-all-dialog-content">
        <TagAll
          filters={["supplier", "date"]}
          onSubmit={tagSubmitHandler}
          onCancel={closeHandler}
          supplierModalHeaderTitle={t("tagUntag.invoiceSupplierTitle")}
        />
      </DialogContent>
    </Dialog>
  );

  const refreshPage = () => {
    dispatch(
      getInvoiceOrdersFilter({
        sequence: filterState?.sequence,
        status: filterState?.status,
        order: filterState?.order,
        pageNumber: "1",
        pageSize: filterState?.pageSize,
        type: filterState?.type,
        defaultSequence: filterState?.defaultSequence,
        callback: (response: any) => {
          if (response?.invoices && response?.invoices?.length > 0) {
            const currentInvoice = response?.invoices?.at(0);
            dispatch(ioActions.setSelectedRow(currentInvoice));
          } else {
            dispatch(ioActions.clearInvoices());
          }
        }
      })
    );
  };
  // Multi Auth Tagged handle function
  const authorizedTaggedBtnClick = async (index: number, continueInvDiff: boolean, continuePPThreshold: boolean) => {
    setMultiAuthLoading(true);
    if (index < checkedInvoices.length) {
      setCurrentRecordIndex(index);
      const id: any = checkedInvoices[index];
      const res: any = await dispatch(
        authorizedTagged({
          invoice_id: id,
          continueInvDiff,
          continuePPThreshold
        })
      );
      setMultiAuthLoading(false);
      if (res?.payload?.validationType === 0) {
        setSuccesCount((count: number) => count + 1);
        authorizedTaggedBtnClick(index + 1, false, false);
      } else if (res?.payload?.validationType === 2) {
        setMessagetype(res?.payload?.messageType);
        setOpenConfirmation(true);
        setErrorMessage(res?.payload?.message);
      } else {
        setNotifyModal(true);
        setErrorMessage(res?.payload?.message);
      }
    } else {
      setFinalSuccessModal(true);
      setMultiAuthLoading(false);
    }
  };

  const refreshAndunCheckAll = () => {
    setFinalSuccessModal(false);
    setMultiAuthLoading(false);
    dispatch(ioActions.unCheckedAll());
    dispatch(ioActions.clearUncheckedRows());
    unTagAll();
    refreshPage();
    setSuccesCount(0);
  };

  const handleCheckedRow = (row: any) => {
    dispatch(ioActions.handleCheckbox({ row }));
  };

  const onchangePrevRecord: onChangeType = (e, page: any) => {
    dispatch(
      getInvoiceOrdersFilter({
        ...filterState,
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: "",
        callback: (data) => dispatch(ioActions.setSelectedRow(data.invoices?.at(data.invoices?.length - 1)))
      })
    );
  };

  const selectPrevRecord = (e: SyntheticEvent) => {
    if (selectedRow && invoices) {
      const indexNo = invoices.indexOf(selectedRow);
      const index = indexNo !== 0 ? indexNo - 1 : 0;
      document.getElementById(getIndex(dataTestId, index))?.focus();
      if (indexNo > 0) {
        dispatch(ioActions.setSelectedRow(invoices[indexNo - 1]));
      } else if (currentPage > 1) {
        onchangePrevRecord(e, currentPage - 1);
      }
    }
  };

  const selectNextRecord = (e: SyntheticEvent) => {
    if (selectedRow && invoices) {
      const indexNo = invoices.indexOf(selectedRow);
      const index = invoices.length - 1 > indexNo ? indexNo + 1 : invoices.length - 1;
      document.getElementById(getIndex(dataTestId, index))?.focus();
      if (indexNo < 9 && (invoices.length - 1 !== indexNo || currentPage !== totalPages)) {
        dispatch(ioActions.setSelectedRow(invoices[indexNo + 1]));
      } else if (currentPage < totalPages) {
        onChangeHandler(e, currentPage + 1);
      }
    }
  };

  return (
    <>
      <Layout
        pageTitle="Invoice/Credit Note Processing"
        className="invoice-order invoice-order__list"
        rightContent={
          <InvoiceOrderTools
            goToPrevRecord={(e) => {
              selectPrevRecord(e);
            }}
            goToNextRecord={(e) => {
              selectNextRecord(e);
            }}
          />
        }
        toolbar={<InvoiceOrderPageToolbar />}
        type="transparent"
      >
        <GridTableNew
          dataTestId="invoiceList"
          filters={
            <CreditNoteFilters
              lookingFor={lookingFor}
              setLookingFor={setLookingFor}
            />
          }
          dataSource={invoices || []}
          isLoading={
            pageStatus === STATUS.LOADING ||
            status === STATUS.LOADING ||
            viewStatus === STATUS.LOADING ||
            isMultiAuthLoading ||
            (isDirectPaymentLoading as any) ||
            (isChequePaymentLoading as any) ||
            (isPrintLoading as any)
          }
          columnDef={poColumnDef}
          checkedRows={checkedRows}
          footer={
            <Pagination
              count={totalPages}
              page={currentPage}
              onChange={onChangeHandler}
            />
          }
          customCell={CustomCell}
          selectedRow={selectedRow}
          selectedRowHandler={(row) => {
            if (status === STATUS.SUCCESS) {
              dispatch(ioActions.setSelectedRow(row));
            }
          }}
          checkedRowHandler={(row: any) => handleCheckedRow(row)}
          onEnterKeyPress={() => {
            const { invoiceDetailsLink } = redirectToInvoiceDetailsLink(selectedRow!);
            history.push({
              pathname: invoiceDetailsLink,
              state: { ...historyState }
            });
          }}
        />

        {getTagModal()}
      </Layout>
      <Layout
        isBreadcrumbRequired={false}
        className="invoice-order invoice-order__list"
      >
        <Grid justify="flex-end">
          <GridItem>
            <FormLabel>{t("purchaseOrder.selection")}</FormLabel>
            <div className="buttons">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={() => setIsTaggedOpen(true)}
              >
                {t("invoiceNote.tagUnauthorised")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={unTagAll}
                disabled={checkedInvoices?.length === 0}
              >
                {t("invoiceNote.unTagAll")}
              </Button>
            </div>
          </GridItem>
          <GridItem>
            <div className="essui-global-typography-default-h2 processing">
              <FormLabel>{t("invoiceNote.processing")}</FormLabel>
              <div className="buttons">
                <Button
                  disabled={checkedInvoices?.length === 0}
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={() => authorizedTaggedBtnClick(0, false, false)}
                >
                  {t("invoiceNote.authoriseTagged")}
                </Button>
              </div>
            </div>
          </GridItem>
        </Grid>
      </Layout>
      {/*  */}
      {/* Invoice Threshold & Order Difference Modal */}
      <ConfirmModal
        isOpen={openConfirmation}
        setOpen={setOpenConfirmation}
        title={t("invoiceNote.invoiceModalCancel")}
        className="cancel-popup"
        message={errorMessage}
        confirm={() => {
          setOpenConfirmation(false);
          if (messageType === MessageType?.orderDifference) {
            authorizedTaggedBtnClick(currentRecordIndex, true, false);
          } else {
            authorizedTaggedBtnClick(currentRecordIndex, true, true);
          }
        }}
        callback={(click) => {
          if (!click?.confirm) {
            authorizedTaggedBtnClick(currentRecordIndex + 1, false, false);
          } else {
            setOpenConfirmation(false);
          }
        }}
      />

      {/* Record error modal */}
      <Modalv2
        className="cancel-popup"
        header={t("invoiceNote.invoiceModalCancel")}
        isOpen={isNotifyModal}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              authorizedTaggedBtnClick(currentRecordIndex + 1, false, false);
              setNotifyModal(false);
            }}
          >
            {t("common.ok")}
          </Button>
        }
        onClose={() => {
          authorizedTaggedBtnClick(currentRecordIndex + 1, false, false);
          setNotifyModal(false);
        }}
      >
        <Notification
          actionElement={1}
          dataTestId="warning-id"
          escapeExits
          id="warning-id"
          hideCloseButton
          status={NotificationStatus.WARNING}
          title={errorMessage}
          className="mb-18 confirm-modal-text"
        />
      </Modalv2>

      {/*  */}

      {/* Notify modal for final multi auth result */}
      <Modalv2
        className="cancel-popup"
        onClose={refreshAndunCheckAll}
        header={t("invoiceNote.invoiceModalCancel")}
        isOpen={isFinalSuccessModal}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={refreshAndunCheckAll}
          >
            {t("common.ok")}
          </Button>
        }
      >
        <Notification
          actionElement={1}
          dataTestId="warning-id"
          escapeExits
          id="warning-id"
          hideCloseButton
          status={NotificationStatus.WARNING}
          title={t("invoiceNote.multiItemAuthorizesMessage", {
            count: successCount,
            totalChecked: checkedInvoices?.length
          })}
          className="mb-18 confirm-modal-text"
        />
      </Modalv2>

      {/*  */}
    </>
  );
};

export default InvoiceNoteList;
