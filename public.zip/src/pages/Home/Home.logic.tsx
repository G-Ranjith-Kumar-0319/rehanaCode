import React, { useEffect, useState } from "react";
// import { Address, IAddress } from "@essnextgen/ui-application-kit"
import { authService } from "@essnextgen/auth-ui";
import HomeView from "./Home.view";
import instance from "../../api/api";
import UseStateType from "../../types/UseStateType";

interface IProps {}

const Home: React.FC<IProps> = () => {
  const [info, setinfo] = useState({});
  const [showMenu, setShowMenu]: UseStateType<boolean> = useState(false);
  const [showProfileMenu, setShowProfileMenu]: UseStateType<boolean> = useState(false);
  const [showSettings, setShowSettings]: UseStateType<boolean> = useState(false);

  const toggleMenu: (e: React.SyntheticEvent) => void = (e: React.SyntheticEvent) => {
    e.preventDefault();
    setShowMenu(!showMenu);
  };
  const toggleProfileMenu: () => void = () => {
    setShowProfileMenu(!showProfileMenu);
  };

  const onClickShowDialog: (e: React.SyntheticEvent) => void = (e: React.SyntheticEvent) => {
    e.preventDefault();
    setShowSettings(true);
  };

  const dialogCloseHandler: (e: React.SyntheticEvent) => void = (e: React.SyntheticEvent) => {
    e.preventDefault();
    setShowSettings(false);
  };
  // useEffect(() => {
  //   alert(authService.getAuthTokens());
  // }, []);

  // useEffect(() => {
  //   async function fetchApi() {
  //     const response = await instance.getWithRetries(
  //       `${process.env.SERVER_URL}/orange`
  //     );
  //     setinfo(response.data.message);
  //   }
  //   fetchApi();
  // }, []);

  return (
    <>
      <HomeView
        info={info}
        onClickShowDialog={onClickShowDialog}
        showSettings={showSettings}
        dialogCloseHandler={dialogCloseHandler}
      />
    </>
  );
};

export default Home;
