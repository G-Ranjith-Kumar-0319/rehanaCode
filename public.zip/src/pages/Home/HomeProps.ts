import React from "react";

export interface IHomeViewProps {
  info: any;
  onClickShowDialog: (e: React.SyntheticEvent) => void;
  dialogCloseHandler: (e: React.SyntheticEvent) => void;
  showSettings: boolean;
}
