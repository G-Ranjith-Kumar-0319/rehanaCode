import { render, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import instance from "../../../api/api";
import Home from "../Index";
import withRender from "../../../shared/utils/test/withRender";

const MOCK_GET = {
  data: { message: "Something" },
  status: 200,
  statusText: "",
  headers: {},
  config: {}
};

const response = {
  data: { message: "" }
};
describe.skip("Home", () => {
  test("should render the component", () => {
    const { getByTestId } = withRender(<Home />);
    expect(getByTestId("home-page")).toBeInTheDocument();
  });

  test("should call axios in Hello World Component", async () => {
    jest.spyOn(instance, "getWithRetries").mockImplementation(() => MOCK_GET);
    const { getByText } = withRender(<Home />);
    await waitFor(() => {
      expect(getByText(/Something/i)).toBeInTheDocument();
    });
  });

  test("should call axios in Hello World Component", async () => {
    jest.spyOn(instance, "getWithRetries").mockImplementation(() => response);
    const { getByText } = withRender(<Home />);
    await waitFor(() => {
      expect(getByText(/Failed Response/i)).toBeInTheDocument();
    });
  });

  test("When click the settings icon, then should render the settings dialog", () => {
    const { getByTestId, queryByTestId } = render(<Home />);

    expect(queryByTestId("settings-dialog")).not.toBeInTheDocument();

    userEvent.click(getByTestId("show-settings"));

    // expect(getByTestId("settings-dialog")).toBeInTheDocument();
  });

  test("When click the close button inside the settings dialog, then should close the settings dialog", () => {
    const { getByTestId, queryByTestId } = render(<Home />);

    // expect(queryByTestId("settings-dialog")).not.toBeInTheDocument();

    userEvent.click(getByTestId("show-settings"));

    // expect(getByTestId("settings-dialog")).toBeInTheDocument();

    // userEvent.click(getByTestId("settings-dialog-close-btn"));

    expect(queryByTestId("settings-dialog")).not.toBeInTheDocument();
  });
});
