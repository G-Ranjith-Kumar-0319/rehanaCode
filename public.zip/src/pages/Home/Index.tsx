import Home from "./Home.logic";

export default Home;
