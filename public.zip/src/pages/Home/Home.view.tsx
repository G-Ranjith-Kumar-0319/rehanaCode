import Layout from "@/components/Layout/Layout";
import { IHomeViewProps } from "./HomeProps";
import "./Style.scss";

const HomeView: ({}: IHomeViewProps) => JSX.Element = ({}: IHomeViewProps) => (
  <div
    data-testid="home-page"
    className="home-page"
  >
    <Layout
      isBreadcrumbRequired={false}
      type="transparent"
    >
      <div className="essui-global-typography-default-h3">Coming Soon.....</div>
    </Layout>
  </div>
);

export default HomeView;
