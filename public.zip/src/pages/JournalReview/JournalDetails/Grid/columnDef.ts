import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const JournalSelectPeriodDef: TColumnDef = [
  {
    headerName: "Ledger Code",
    field: "ledger_code"
  },
  {
    headerName: "Fund",
    field: "fund_code_display",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Ledger Description",
    field: "ledger_des",
    columnWidth: 50
  },
  {
    headerName: "Cost Code",
    field: "cost_code"
  },
  {
    headerName: "Cost Centre",
    field: "cost_des"
  },
  {
    headerName: "Debit",
    field: "debit",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Credit",
    field: "credit",
    align: "right",
    cellRenderer: "GridCellLink"
  }
];

export default JournalSelectPeriodDef;
