import { cellRendererType } from "@/components/GridTable/GridTable";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { getDate } from "@/utils/getDataSource";

const CustomCell = ({ field, row }: cellRendererType) => {
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const getContent = () => {
    if (field === "debit") {
      const formattedDebit =
        row?.debit !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.debit) : specialCharacters.zero;
      return <>{formattedDebit}</>;
    }
    if (field === "credit") {
      return <>{row?.credit !== KEYBOARD_STRING.Zero ? numberFormatter.format(row?.credit) : specialCharacters.zero}</>;
    }
    if (field === "fund_code_display") {
      return <>{row?.fund_code_display !== " " ? row?.fund_code_display : "-"}</>;
    }
    if (field === "journal_date") {
      return <>{getDate(row?.journal_date)}</>;
    }
    return null;
  };
  return getContent();
};

export default CustomCell;
