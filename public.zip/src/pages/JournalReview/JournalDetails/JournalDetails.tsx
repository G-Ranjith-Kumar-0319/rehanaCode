import Layout from "@/components/Layout/Layout";
import { Grid, GridItem, Loader, LoaderType, Tag, TagColor, TagSize } from "@essnextgen/ui-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { SyntheticEvent, useEffect } from "react";
import { getDate } from "@/utils/getDataSource";
import { useHistory } from "react-router-dom";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import CustomCell from "./Grid/CustomCell";
import JournalSelectPeriodDef from "./Grid/columnDef";
import { getJournalDetails, getJournalReviewList, journalReviewActions } from "../state/JournalReviewList.slice";
import JournalReviewToolbar from "../JournalReviewToolbar";

const JournalDetails = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const { filterState, journalDetails, journalReviewApiStatus, selectedJournalReviewRow, journalReviewList } =
    useAppSelector((state) => state.journalReviewList);

  const { selectedJournalPeriod } = useAppSelector((state) => state.journalPeriod);

  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  useEffect(() => {
    dispatch(
      getJournalDetails({
        journalId: historyState?.selectedRowState?.journal_id
      })
    );
  }, []);

  const getTagElement = () =>
    historyState?.selectedRowState?.narrative ? (
      <div className="br-sub-title">
        <Tag
          text={`${selectedJournalReviewRow?.narrative} ${selectedJournalReviewRow?.pct_narrative || ""}`}
          size={TagSize.Large}
          color={TagColor.Highlight}
        />
      </div>
    ) : null;

  const goToRecord = (row: any) => {
    dispatch(journalReviewActions.setSelectedJournalReviewRow(row));
    dispatch(journalReviewActions.setSelectedJournalReviewUndoRow(row));
    dispatch(journalReviewActions.setFilters({ jrJournalId: row?.journal_id }));

    history.push({
      pathname: `/general-ledger/journal-review/view-journal-details/${row?.journal_id}`,
      state: {
        selectedRowState: row,
        isDirty: false
      }
    });
  };

  const selectPrevRecord = () => {
    const index = journalReviewList.journalReview.findIndex(
      (item) => item?.journal_id === selectedJournalReviewRow?.journal_id
    );

    if (index !== -1 && index > 0) {
      const row = journalReviewList.journalReview[index - 1];
      dispatch(journalReviewActions.setSelectedJournalReviewRow(row));
      goToRecord(row);
      dispatch(
        getJournalDetails({
          journalId: journalReviewList.journalReview[index - 1]?.journal_id
        })
      );
    } else if ((filterState?.pageNumber ?? 1) > 1) {
      const prevPage = (filterState?.pageNumber ?? 1) - 1;
      dispatch(journalReviewActions.setFilters({ ...filterState, pageNumber: prevPage, jrJournalId: undefined }));
      dispatch(
        getJournalReviewList({
          ...{ ...filterState, jrJournalId: undefined, periodView: selectedJournalPeriod?.code, pageNumber: prevPage },
          callback: (data) => {
            const row = (data?.journalReview as { [key: string]: any }[])?.at(
              (Number(filterState?.pageSize) ?? 10) - 1
            );
            dispatch(journalReviewActions.setSelectedJournalReviewRow(row));
            goToRecord(row);
          }
        })
      );
    }
  };

  const selectNextRecord = () => {
    const index = journalReviewList.journalReview.findIndex(
      (item) => item?.journal_id === selectedJournalReviewRow?.journal_id
    );

    if (index !== -1 && index < journalReviewList?.journalReview?.length - 1) {
      const row = journalReviewList.journalReview[index + 1];
      dispatch(journalReviewActions.setSelectedJournalReviewRow(row));
      goToRecord(row);
      dispatch(
        getJournalDetails({
          journalId: journalReviewList.journalReview[index + 1]?.journal_id
        })
      );
    } else if ((filterState?.pageNumber ?? 1) < journalReviewList?.totalPages) {
      const nextPage = (filterState?.pageNumber ?? 1) + 1;
      dispatch(journalReviewActions.setFilters({ ...filterState, pageNumber: nextPage, jrJournalId: undefined }));
      dispatch(
        getJournalReviewList({
          ...{ ...filterState, jrJournalId: undefined, periodView: selectedJournalPeriod?.code, pageNumber: nextPage },
          callback: (data) => {
            const row = (data?.journalReview as { [key: string]: any }[])?.at(0);
            dispatch(journalReviewActions.setSelectedJournalReviewRow(row));
            goToRecord(row);
          }
        })
      );
    }
  };

  const navigateToViewPage = () => {
    history.push({
      pathname: `/general-ledger/journal-review`
    });
  };

  const onFocusClickHandler = () => {
    dispatch(journalReviewActions.setSelectedJournalReviewRow(selectedJournalReviewRow));
    dispatch(
      journalReviewActions.setFilters({
        jrJournalId: selectedJournalReviewRow?.journal_id
      })
    );
    dispatch(journalReviewActions.setIsFocus(true));
    navigateToViewPage();
  };

  return (
    <>
      {journalReviewApiStatus === STATUS.LOADING ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText={t("common.loading")}
        />
      ) : (
        <>
          <Layout
            pageTitle={t("journalReviewDetails.pageTitle")}
            isBreadcrumbRequired
            rightContent={
              <JournalReviewToolbar
                goToPrevRecord={selectPrevRecord}
                goToNextRecord={selectNextRecord}
                onFocusClickHandler={onFocusClickHandler}
              />
            }
            isSubTitle={getTagElement()}
          >
            <Grid className="mt-8">
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("journalReviewDetails.period")}</div>
                  <div className="mt-8">
                    {selectedJournalReviewRow?.period_no} {selectedJournalReviewRow?.description}
                  </div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("journalReviewDetails.date")}</div>
                  <div className="mt-8">{getDate(selectedJournalReviewRow?.journal_date)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("journalReviewDetails.debit")}</div>
                  <div className="mt-8">{numberFormatter.format(selectedJournalReviewRow?.debit)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("journalReviewDetails.credit")}</div>
                  <div className="mt-8">{numberFormatter.format(selectedJournalReviewRow?.credit)}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("journalReviewDetails.type")}</div>
                  <div className="mt-8">{selectedJournalReviewRow?.journal_type_mapping}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("journalReviewDetails.user")}</div>
                  <div className="mt-8">{selectedJournalReviewRow?.user_code}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                sm={2}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("journalReviewDetails.journalNo")}</div>
                  <div className="mt-8">{selectedJournalReviewRow?.det_num}</div>
                </div>
              </GridItem>
              <GridItem
                lg={12}
                xl={12}
                sm={4}
              >
                <div className="">
                  <div className="essui-form-label">{t("journalReviewDetails.narrative")}</div>
                  <div className="mt-8">{`${selectedJournalReviewRow?.narrative} ${
                    selectedJournalReviewRow?.pct_narrative || ""
                  }`}</div>{" "}
                </div>
              </GridItem>
            </Grid>
          </Layout>

          <Layout
            isBreadcrumbRequired={false}
            type="transparent"
          >
            <GridTableNew
              columnDef={JournalSelectPeriodDef}
              dataSource={journalDetails?.journalReviewDetails || []}
              isLoading={false}
              customCell={CustomCell}
              isScrollable
            />
          </Layout>
        </>
      )}
    </>
  );
};

export default JournalDetails;
