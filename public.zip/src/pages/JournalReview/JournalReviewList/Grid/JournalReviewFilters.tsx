import React, { useEffect, useState } from "react";
import {
  Dropdown,
  DropdownItem,
  FormLabel,
  RadioButton,
  RadioLabelPosition,
  TextInputSize,
  ISelectedItem,
  Button,
  Icon,
  ButtonColor,
  ButtonSize,
  IconColor,
  IconSize
} from "@essnextgen/ui-kit";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { getCurrentFinancialYear, STATUS, KEYBOARD_STRING } from "@/types/UseStateType";
import Input from "@/components/Input/Input";
import { useAppDispatch, AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import columnDef from "./columnDef";
import useJournalReviewFilters from "./useJournalReviewFilters";
import JournalPeriodModal from "../JournalPeriodModal/JournalPeriodModal";
import { actions, getJournalPeriods } from "../../state/JournalPeriod.slice";

import { getJournalReviewType } from "../../state/JournalReviewType.slice";
import sequenceColDef from "./SequenceDef";
import { PeriodSequenceType, PeriodSequenceValue } from "../JournalPeriodModal/ColumnDefs";

const JournalReviewFilters = ({ lookingFor, setLookingFor }: any) => {
  const [showPeriodModal, setShowPeriodModal] = useState(false);
  const [search, setSearch] = useState<string | undefined>();

  const dispatch = useAppDispatch();

  const {
    t,
    filterState,
    journalReviewApiStatus,
    JournalReviewViewSelected,
    lookingForChangehandler,
    lookingForCallback,
    onSequenceChange,
    onViewSelection,
    selectedJournalPeriod,
    journalPeriods
  } = useJournalReviewFilters();

  useEffect(() => {
    dispatch(getJournalPeriods({ financialYear: getCurrentFinancialYear(), sequence: PeriodSequenceType.PERIOD }));
    dispatch(actions.setFilters({ sequenceValue: PeriodSequenceValue.PERIOD }));
  }, []);

  const handleTypeFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey =
      e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp || e.key === KEYBOARD_STRING.Enter;
    if (isArrowKey) {
      e.preventDefault();
      e.stopPropagation();
    }
  };

  const handleSelect = (selectedItem: ISelectedItem | undefined) => {
    if (selectedItem) {
      setSearch(selectedItem.value);
      dispatch(
        actions.selectRow({
          code: selectedItem.text,
          description: selectedItem.value
        })
      );
    } else {
      setShowPeriodModal(true);
    }
  };

  useEffect(() => {
    dispatch(getJournalReviewType());
  }, []);

  const { status, selectedType, error, journalReviewType } = useAppSelector((state) => state.journalReviewType);

  return (
    <div className="filters">
      <LookingFor
        initialValue={filterState?.lookingFor}
        callback={lookingForCallback}
        changeHandler={lookingForChangehandler}
        hasDatePicker
        disableDatePicker={filterState?.sequenceValue !== "journal_date"}
        isInputReadOnly={journalReviewApiStatus === STATUS.LOADING}
        className="essui-global-typography-default-h2 looking-for-container"
      />
      <div className="essui-global-typography-default-h2 sequence-container">
        <FormLabel>{t("journalReviewList.sequence")}</FormLabel>
        <div className="sequence">
          <div className="essui-textinput sequence-fields">
            {(sequenceColDef.filter((col) => !!col.sequence) || []).map((column, index) => {
              const sequenceId = `sequence=${index + 1}`;
              return (
                <RadioButton
                  id="journal-review-filter-sequence-btn"
                  label={column.sequenceName ? column.sequenceName : column.headerName}
                  labelPosition={RadioLabelPosition.Right}
                  value={column.field}
                  onChange={() => {
                    onSequenceChange(column, index);
                  }}
                  isSelected={filterState?.sequenceValue === column.field}
                  key={sequenceId}
                  name={column.field}
                />
              );
            })}
          </div>
        </div>
      </div>
      <div className="view-filter">
        <FormLabel forId="view">{t("journalReviewList.view")}</FormLabel>
        <Dropdown
          id="ddFilterView"
          size={TextInputSize.Medium}
          searchable
          selectedItem={JournalReviewViewSelected}
          isScrollbarVisible
          onKeyDown={handleTypeFieldKeyDown}
          onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => onViewSelection(item)}
        >
          {(journalReviewType || []).map((view: any, i: any) => {
            const id = `dropdown-${i}`;
            return (
              <DropdownItem
                key={id}
                id={id}
                text={view.description}
                value={view.code}
              >
                {view.description}
              </DropdownItem>
            );
          })}
        </Dropdown>
      </div>

      <div className="journal-period-container">
        <FormLabel forId="view">{t("journalReviewList.journerPeriod")}</FormLabel>

        <div className="input-container">
          <Input
            id="journal-review-code-input-search"
            name="journal-review-code-input-search"
            disabled={filterState?.sequenceValue !== "str_period_no"}
            searchable
            value={search ?? selectedJournalPeriod?.code}
            searchItems={journalPeriods.map((period) => ({
              text: period.code,
              value: period.description
            }))}
            onKeyDown={(e) => {
              e.stopPropagation();
            }}
            onNoSelection={() => {
              setShowPeriodModal(true);
              return false;
            }}
            onSelect={handleSelect}
          />
          <Input
            id="ournal-review-description-input-search"
            searchable
            inputWidth={140}
            value={selectedJournalPeriod?.description ?? ""}
            disabled={filterState?.sequenceValue !== "str_period_no"}
            button={
              <Button
                id="journal-review-search-btn"
                color={ButtonColor.Secondary}
                onClick={() => {
                  setShowPeriodModal(!showPeriodModal);
                }}
                className="essui-button-icon-only--small"
                size={ButtonSize.Small}
                aria-label="search"
                disabled={filterState?.sequenceValue !== "str_period_no"}
              >
                <Icon
                  color={IconColor.Primary500}
                  size={IconSize.Medium}
                  name="search"
                />
              </Button>
            }
          />
        </div>
        <div
          id="modal"
          className="modal"
        >
          <div className="modal-content">
            {showPeriodModal && (
              <JournalPeriodModal
                setOpen={setShowPeriodModal}
                isOpen={showPeriodModal}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default React.memo(JournalReviewFilters);
