import { cellRendererType } from "@/components/GridTable/GridTable";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import { usNumberFormat } from "@/utils/getDataSource";
import { useHistory } from "react-router-dom";
import { AppDispatch } from "@/store/store";
import { useDispatch } from "react-redux";
import { journalReviewActions } from "../../state/JournalReviewList.slice";

const CustomCell = ({ field, row }: cellRendererType) => {
  const dispatch = useDispatch<AppDispatch>();

  const history = useHistory();

  const handleButtonClick = () => {
    dispatch(journalReviewActions.setSelectedJournalReviewRow(row));
    dispatch(journalReviewActions.setSelectedJournalReviewUndoRow(row));
    dispatch(journalReviewActions.setFilters({ highlightJournalId: row?.journal_id }));

    history.push({
      pathname: `/general-ledger/journal-review/view-journal-details/${row?.journal_id}`,
      state: {
        selectedRowState: row,
        isDirty: false
      }
    });
  };

  const getContent = () => {
    switch (field) {
      case "detailLink":
        return (
          <Button
            id="journal-review-page-detail-link-btn"
            className="grid-actions__button m-auto"
            size={ButtonSize.Small}
            color={ButtonColor.Tertiary}
            iconName="chevron--right"
            onClick={handleButtonClick}
          />
        );
      case "journal_date":
        return (
          <>
            {new Date(row?.journal_date).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })}
          </>
        );
      case "credit":
        return <>{usNumberFormat(row?.credit)}</>;
      case "narrative":
        return <>{`${row?.narrative} ${row?.pct_narrative || ""}`}</>;
      default: {
        return <div />;
      }
    }
  };
  return getContent();
};

export default CustomCell;
