import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const JournalReviewColDef: TColumnDef = [
  {
    headerName: "Number",
    field: "det_num",
    sequence: true,
    sequenceName: "Journal Voucher No."
  },
  {
    headerName: "Type",
    field: "journal_type_mapping",
    sequence: true,
    sequenceName: "Type"
  },
  {
    headerName: "Date",
    field: "journal_date",
    cellRenderer: "GridCellLink",
    sequence: true,
    sequenceName: "Date"
  },
  {
    headerName: "Period",
    field: "str_period_no",
    sequence: true,
    sequenceName: "Period"
  },
  {
    headerName: "User ID",
    field: "user_code",
    sequence: true,
    sequenceName: "User ID"
  },
  {
    headerName: "Narrative",
    field: "narrative",
    sequence: true,
    sequenceName: "Narrative",
    cellRenderer: "GridCellLink",
    columnWidth: 50
  },
  {
    headerName: "Amount",
    cellRenderer: "GridCellLink",
    align: "right",
    field: "credit"
  },
  {
    headerName: "",
    field: "detailLink",
    cellRenderer: "GridCellLink"
  }
];

export default JournalReviewColDef;
