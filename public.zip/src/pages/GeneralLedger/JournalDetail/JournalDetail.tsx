import Layout from "@/components/Layout/Layout";
import { Grid, GridItem, Tag, TagColor, TagSize } from "@essnextgen/ui-kit";

const JournalDetail = () => {
  const getTagElement = () => (
    <div className="heading__tag">
      <Tag
        text="Opening balance journal"
        size={TagSize.Large}
        color={TagColor.Highlight}
      />
    </div>
  );
  return (
    <>
      <Layout
        pageTitle="Journal Detail"
        isSubTitle={getTagElement()}
        className="page__title_tag"
        isBreadcrumbRequired
      >
        <Grid className="mt-8">
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-16">
              <div className="essui-form-label">Period</div>
              <div className="mt-8">0 O/B</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-16">
              <div className="essui-form-label">Date</div>
              <div className="mt-8">12 Jul 2023</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-16">
              <div className="essui-form-label">Debit</div>
              <div className="mt-8">625,225.17</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-16">
              <div className="essui-form-label">Credit</div>
              <div className="mt-8">625,225.17</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-16">
              <div className="essui-form-label">Type</div>
              <div className="mt-8">GL</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-16">
              <div className="essui-form-label">User</div>
              <div className="mt-8">SYS</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-16">
              <div className="essui-form-label">Journal No.</div>
              <div className="mt-8">127925</div>
            </div>
          </GridItem>
          <GridItem
            lg={12}
            xl={12}
            sm={4}
          >
            <div className="">
              <div className="essui-form-label">Narrative</div>
              <div className="mt-8">Opening balance journal</div>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};

export default JournalDetail;
