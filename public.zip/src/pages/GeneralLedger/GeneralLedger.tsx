import Layout from "@/components/Layout/Layout";
import { ServiceUnavailable as ServiceUnavailablePage } from "@essnextgen/ui-error-pages-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Grid, GridItem } from "@essnextgen/ui-kit";

export const GeneralLedger: ({}) => JSX.Element = ({}: any) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <>
      <Layout
        pageTitle={t("General Ledger")}
        isBreadcrumbRequired
        className="general-ledger wrapper__radius--0"
      >
        <Grid>
          <GridItem className="essui-global-typography-default-h3">We are Almost Ready!</GridItem>
        </Grid>
        <Grid>
          <GridItem className="mt-10">
            Thank you for your patience. Our team is working hard to bring you something amazing. Stay tuned for
            updates!
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};
export default GeneralLedger;
