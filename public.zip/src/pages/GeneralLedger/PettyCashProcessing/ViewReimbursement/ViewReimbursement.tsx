import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  ISelectedItem,
  Loader,
  LoaderType,
  Tag,
  TagColor,
  TagSize,
  TextInput,
  NotificationStatus,
  Notification
} from "@essnextgen/ui-kit";
import "./Style.scss";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { STATUS } from "@/types/UseStateType";
import SelectChequeBookModal from "@/shared/components/SelectChequeBookModal/SelectChequeBookModal";
import PettyCashPeriodBrowseModal from "@/shared/components/PettyCashPeriodBrowse/PettyCashPeriodBrowseModal";
import NumberInput from "@/components/NumberInput/NumberInput";

import AlertModal from "@/shared/components/AlertModal/AlertModal";
import Modal from "@/components/Modal/Modal";
import { isCharacter, isSpecialChar } from "@/utils/getDataSource";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import TextInputMask from "@/components/Input/InputMask";
import { isDisabled } from "@testing-library/user-event/dist/utils";
import PettyCashToolbar from "../PettyCashToolbar";
import PettyCashPageToolbar from "../PettyCashPageToolbar";
import useViewReimbursement from "./useViewReimbursement";

const ViewReimbursement = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const UNPOSTED = {
    Unposted_Exp: "Unposted Expenditure"
  };
  const {
    historyState,
    postingPeriodMonth,
    numberFormatter,
    reimbursmentStatus,
    pettyCashAccountsHidden,
    pettyCashTransaction,
    chequeNoVal,
    handleViewAdjustmentClick,
    handleViewOriginalClick,
    selectNextRecord,
    setPrintButtonClicked,
    selectPrevRecord,
    pcTransId,
    postingPeriodDetails,
    printChequeStatus,
    printButtonClicked,
    onSelectRowDate,
    handleCheckNo,
    onPostingPeriodSelectedRow,
    onPaymentPeriodChange,
    onPaymentPeriodNoSelection,
    onPaymentPeriodSelection,
    onSelectRowCheque,
    onChequeBookSelectedRow,
    onChequeBookNoSelection,
    onChequeBookChange,
    onChequeBookSelection,
    setShowPostingPeriodModal,
    chequeBookList,
    reimbursmentSaveStatus,
    setIsChequeBookModalOpen,
    isChequeBookModalOpen,
    showPostingPeriodModal,
    setValue,
    getValues,
    getHeaderValue,
    handleInputChange,
    errors,
    isRequiredPayeeName,
    ValidationTextLevel,
    register,
    onSubmit,
    watch,
    saveChangesModal,
    openSaveChangesModal,
    setOpenSaveChangesModal,
    setOpenValidationModal,
    openValidationModal,
    showUniqueChequeError,
    setShowUniqueChequeError,
    uniqueChequeErrMsg,
    onFocusClickHandler,
    resetOnFocus,
    goToAdd,
    undoChangeHandler,
    isUndoModalOpen,
    chequeNoError,
    setIsUndoModalOpen,
    resetOnFocusAndNavigate,
    undoChangeAndNavigate,
    formDataToSave,
    saveReimbursementData,
    openInvalidChequeNoErr,
    setOpenInvalidChequeNoErr,
    isInputClassReq,
    getInitialPayeeCheque,
    adjustTransHandler,
    isCancelDisabled,
    isAdjustTransDisabled,
    showOverdrawnErrorModal,
    setShowOverdrawnErrorModal,
    postReimbursementData,
    onPrintCheque
  } = useViewReimbursement();

  const getTagElement = () => {
    if (historyState?.mode || historyState?.isAdjust) {
      return (
        <div className="reimbursement-sub-title">
          <Tag
            text={t("common.pendingAllocation")}
            size={TagSize.Large}
            color={TagColor.Highlight}
          />
          <Tag
            text={t("viewReimbursement.unpostedReimbursement")}
            size={TagSize.Large}
            color={TagColor.Highlight}
          />
        </div>
      );
    }
    const transNo = pettyCashTransaction?.trans_no;
    const narrative = pettyCashTransaction?.narrative;

    if (!transNo && !narrative) {
      return null;
    }
    return (
      <div className="reimbursement-sub-title">
        {transNo && (
          <Tag
            text={transNo}
            size={TagSize.Large}
            color={TagColor.Highlight}
          />
        )}
        {narrative && (
          <Tag
            text={narrative}
            size={TagSize.Large}
            color={TagColor.Highlight}
          />
        )}
      </div>
    );
  };

  return (
    <>
      {reimbursmentStatus === STATUS.LOADING ||
      reimbursmentSaveStatus === STATUS.LOADING ||
      printChequeStatus === STATUS.LOADING ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        <>
          <Layout
            pageTitle={
              historyState?.mode || historyState?.isAdjust
                ? t("viewReimbursement.addReimbursTitle")
                : t("viewReimbursement.viewReimbursTitle")
            }
            className="petty-cash-processing wrapper__radius--0"
            isBreadcrumbRequired
            isSubTitle={getTagElement()}
            rightContent={
              <PettyCashToolbar
                onSubmit={saveChangesModal}
                onFocusClickHandler={onFocusClickHandler}
                isAddDisable={historyState?.mode}
                isPrintDisable
                goToPrevRecord={historyState?.mode ? saveChangesModal : selectPrevRecord}
                goToNextRecord={historyState?.mode ? saveChangesModal : selectNextRecord}
                goToAdd={goToAdd}
                isDeleteDisable={pettyCashTransaction?.narrative !== UNPOSTED.Unposted_Exp}
                undoChangeHandler={undoChangeHandler}
              />
            }
            toolbar={
              <PettyCashPageToolbar
                isPostDisabled={!(historyState.mode === "add" || historyState?.isAdjust)}
                adjustTransHandler={adjustTransHandler}
                isAdjustTransDisabled={isAdjustTransDisabled()}
                isCancelDisabled={isCancelDisabled()}
                pcTransId={pcTransId}
                onSubmit={() => onSubmit()}
              />
            }
          >
            <Grid className="row-gap-16 br-0">
              <GridItem
                lg={3}
                xl={3}
                md={4}
                sm={4}
              >
                <div>
                  <div className="essui-form-label">{t("viewReimbursement.pcAccount")}</div>
                  <div className="mt-8">{getHeaderValue("pc_acc_des")}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                md={4}
                sm={4}
              >
                <div>
                  <div className="essui-form-label">{t("viewReimbursement.cashInHand")}</div>
                  <div className="mt-8">{numberFormatter.format(getHeaderValue("cash_in_hand"))}</div>
                </div>
              </GridItem>
              <GridItem
                lg={3}
                xl={3}
                md={4}
                sm={4}
              >
                <div>
                  <div className="essui-form-label">{t("viewReimbursement.unpostedExpenditure")}</div>
                  <div className="mt-8">{numberFormatter.format(getHeaderValue("unposted_exp"))}</div>
                </div>
              </GridItem>
            </Grid>
          </Layout>

          <Layout
            className="petty-cash-transaction"
            isBreadcrumbRequired={false}
          >
            <Grid className="row-gap-16">
              <GridItem
                sm={4}
                md={12}
                lg={12}
                xl={12}
              >
                <div>
                  <div className="essui-form-label">{t("viewReimbursement.transactionNumber")}</div>
                  <div className="mt-8">
                    {historyState?.mode || historyState?.isAdjust
                      ? t("common.pendingAllocation")
                      : pettyCashTransaction?.trans_no}
                  </div>
                </div>
              </GridItem>
            </Grid>
            <Grid className="mt-8 row-gap-8">
              <GridItem
                xl={3}
                lg={4}
                md={4}
                sm={4}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("viewReimbursement.date")}</div>
                  <div className="height__equal--input">
                    {pettyCashTransaction
                      ? new Date(pettyCashTransaction.date_posted).toLocaleDateString("en-GB", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric"
                        })
                      : new Date().toLocaleDateString("en-GB", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric"
                        })}
                  </div>
                </div>
              </GridItem>
              <GridItem
                xl={3}
                lg={4}
                md={4}
                sm={4}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("viewReimbursement.generalLedgerJournal")}</div>
                  <div className="height__equal--input">
                    {pettyCashTransaction ? pettyCashTransaction.det_num : "-"}
                  </div>
                </div>
              </GridItem>
              <GridItem
                xl={3}
                lg={4}
                md={4}
                sm={4}
              >
                <Grid>
                  <GridItem>
                    <Input
                      id="txtPaymentPeriod"
                      disabled={!historyState?.mode || !!historyState?.isAdjust}
                      searchable
                      searchItems={postingPeriodDetails.map((p) => ({ text: p.formattedCode, value: p.description }))}
                      onSelect={(selectedItem: ISelectedItem | undefined) => onPaymentPeriodSelection(selectedItem)}
                      labelText={t("pettyCash.period")}
                      inputWidth={50}
                      onNoSelection={onPaymentPeriodNoSelection}
                      value={getValues("period_posted")}
                      inputRef={(e) => register("period_posted").ref(e)}
                      name={register("period_posted", { required: true }).name}
                      onChange={onPaymentPeriodChange}
                      validationTextLevel={errors.period_posted ? ValidationTextLevel.Error : undefined}
                      button={
                        <>
                          <TextInput
                            className="read-only"
                            id="txtPaymentDescription"
                            inputWidth={60}
                            value={String(getValues("period_posted")) === "" ? "" : postingPeriodMonth}
                            name={register("paymentDescription").name}
                            disabled
                          />
                          <Button
                            color={ButtonColor.Secondary}
                            onClick={() => setShowPostingPeriodModal(true)}
                            size={ButtonSize.Small}
                            className="essui-button-icon-only--small"
                            disabled={!historyState?.mode}
                          >
                            <Icon
                              color={IconColor.Primary500}
                              size={IconSize.Medium}
                              name="search"
                            />
                          </Button>
                        </>
                      }
                    />
                  </GridItem>
                </Grid>
              </GridItem>
              <GridItem
                xl={3}
                lg={4}
                md={4}
                sm={4}
              >
                <div>
                  <div className="essui-form-label">{t("viewReimbursement.amount")}</div>
                  {historyState?.mode || historyState?.isAdjust ? (
                    <NumberInput
                      id="txtChequeBook"
                      decimals={2}
                      defaultValue={watch("amount") || "0.00"}
                      maxLength={5}
                      name={register("amount", { required: true }).name}
                      inputRef={(e) => register("amount").ref(e)}
                      onChange={(e) => {
                        setValue("amount", e.target.value);
                        register("amount").onChange(e);
                      }}
                      validationTextLevel={errors.amount ? ValidationTextLevel.Error : undefined}
                    />
                  ) : (
                    <div className="height__equal--input">{numberFormatter.format(getValues("amount"))}</div>
                  )}
                </div>
              </GridItem>
              <GridItem
                xl={3}
                lg={4}
                md={4}
                sm={4}
              >
                <div className="mb-16">
                  <div className="essui-form-label">{t("viewReimbursement.drawnFrom")}</div>
                  <div className="height__equal--input">
                    {getHeaderValue("source_des").length > 0 ? getHeaderValue("source_des") : "N/A"}
                  </div>
                </div>
              </GridItem>
              <GridItem
                xl={3}
                lg={4}
                md={4}
                sm={4}
              >
                <Input
                  id="txtChequeBooks"
                  searchable
                  searchItems={chequeBookList.map((row) => ({ text: row?.number_range, value: row?.next_no }))}
                  onSelect={(selectedItem: ISelectedItem | undefined) => onChequeBookSelection(selectedItem)}
                  labelText={t("pettyCash.chequeBook")}
                  onNoSelection={onChequeBookNoSelection}
                  value={getValues("number_range")}
                  inputRef={(e) => register("number_range").ref(e)}
                  name={register("number_range").name}
                  onChange={onChequeBookChange}
                  inputWidth={160}
                  disabled={
                    !(
                      (historyState?.mode && historyState?.headerData?.source_type === "BK") ||
                      (historyState?.isAdjust &&
                        pettyCashAccountsHidden?.source_type === "BK" &&
                        !historyState?.selectedRowState?.cheque_book_id)
                    )
                  }
                  button={
                    <>
                      <TextInput
                        className="read-only"
                        id="txtPaymentDescription"
                        value={getValues("number_range") === "" ? "" : getValues("next_no")}
                        name={register("next_no").name}
                        disabled
                      />
                      <Button
                        color={ButtonColor.Secondary}
                        onClick={() => {
                          setIsChequeBookModalOpen(true);
                        }}
                        size={ButtonSize.Small}
                        disabled={
                          !(
                            (historyState?.mode && historyState?.headerData?.source_type === "BK") ||
                            (historyState?.isAdjust &&
                              pettyCashAccountsHidden?.source_type === "BK" &&
                              !historyState?.selectedRowState?.cheque_book_id)
                          )
                        }
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                />
              </GridItem>
              <GridItem
                xl={3}
                lg={4}
                md={4}
                sm={4}
              >
                <div>
                  <FormLabel forId="txtChequeNumber">{t("viewReimbursement.chequeNumber")}</FormLabel>
                  <div className="d-flex align-center gap-8 cheque__number">
                    <TextInputMask
                      {...register("cheque_no", {
                        required: historyState?.mode && historyState?.headerData?.source_type === "BK"
                      })}
                      className={`essui-textinput w-100 essui-textinput--medium ${
                        chequeNoError ? "essui-textinput--error" : ""
                      } ${
                        !(
                          (historyState?.mode && historyState?.headerData?.source_type === "BK") ||
                          (historyState?.isAdjust &&
                            pettyCashAccountsHidden?.source_type === "BK" &&
                            !historyState?.selectedRowState?.cheque_book_id)
                        )
                          ? "essui-textinput--disabled"
                          : ""
                      }`}
                      maskId="chequeNo"
                      maskType="tel"
                      maskElement="999999"
                      maskChar=" "
                      value={getValues("cheque_no") ?? "000000"}
                      disabled={
                        !(
                          (historyState?.mode && historyState?.headerData?.source_type === "BK") ||
                          (historyState?.isAdjust &&
                            pettyCashAccountsHidden?.source_type === "BK" &&
                            !historyState?.selectedRowState?.cheque_book_id)
                        )
                      }
                      onChange={handleInputChange}
                      onBlur={handleCheckNo}
                    />
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      disabled={
                        !(
                          (historyState?.mode && historyState?.headerData?.source_type === "BK") ||
                          (historyState?.isAdjust &&
                            pettyCashAccountsHidden?.source_type === "BK" &&
                            !historyState?.selectedRowState?.cheque_book_id)
                        )
                      }
                      onClick={() => {
                        setPrintButtonClicked(true);
                        onPrintCheque();
                      }}
                    >
                      {t("viewReimbursement.printCheque")}
                    </Button>
                  </div>
                </div>
              </GridItem>
              {pettyCashTransaction?.bank_statement_no !== "-1" && historyState.mode !== "add" && (
                <GridItem
                  xl={3}
                  lg={3}
                  md={4}
                  sm={4}
                >
                  <div>
                    <div className="essui-form-label">{t("viewReimbursement.reconciledBankStatement")}:</div>
                    <div className="height__equal--input"> {pettyCashTransaction?.bank_statement_no}</div>
                  </div>
                </GridItem>
              )}

              <GridItem
                xl={12}
                lg={12}
                md={12}
                sm={4}
              >
                <div>
                  <div className="essui-form-label">{t("viewReimbursement.chequePayee")}</div>
                  <Input
                    value={getInitialPayeeCheque()}
                    searchable
                    maxLength={100}
                    disabled={
                      !(
                        (historyState?.mode && historyState?.headerData?.source_type === "BK") ||
                        (historyState?.isAdjust &&
                          pettyCashAccountsHidden?.source_type === "BK" &&
                          !historyState?.selectedRowState?.cheque_book_id)
                      )
                    }
                    id="txtChequeBook"
                    inputRef={(e) => register("payee_name").ref(e)}
                    onChange={register("payee_name").onChange}
                    name={register("payee_name", { required: isRequiredPayeeName }).name}
                    className={isInputClassReq()}
                    validationTextLevel={errors.payee_name ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
              <GridItem
                xl={12}
                lg={12}
                md={12}
                sm={4}
              >
                <div className="">
                  <div className="essui-form-label">{t("viewReimbursement.narrative")}</div>
                  <Input
                    id="txtNarrative"
                    value={getValues("narrative")}
                    searchable
                    maxLength={40}
                    disabled={!(historyState?.mode || historyState.isAdjust)}
                    inputRef={(e) => register("narrative").ref(e)}
                    onChange={register("narrative").onChange}
                    name={register("narrative", { required: true }).name}
                    className={historyState?.mode || historyState.isAdjust ? "" : "not-in-use"}
                    validationTextLevel={errors.narrative ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
            </Grid>
          </Layout>
          <Layout
            isBreadcrumbRequired={false}
            className=""
          >
            <Grid>
              <GridItem
                sm={6}
                md={{
                  offset: 2,
                  span: 6
                }}
                lg={{
                  offset: 6,
                  span: 6
                }}
                xl={{
                  offset: 6,
                  span: 6
                }}
              >
                <div className="d-flex gap-8 justify-end flex-wrap">
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={handleViewOriginalClick}
                    disabled={!pettyCashTransaction?.orig_trans_id || historyState?.isAdjust}
                  >
                    {t("viewReimbursement.viewOriginal")}
                  </Button>
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={handleViewAdjustmentClick}
                    disabled={!pettyCashTransaction?.adj_trans_id || historyState?.isAdjust}
                  >
                    {t("viewReimbursement.viewAdjustment")}
                  </Button>
                </div>
              </GridItem>
            </Grid>
          </Layout>
          <SelectChequeBookModal
            isOpen={isChequeBookModalOpen}
            setOpen={setIsChequeBookModalOpen}
            onSelectRowChequeBook={onChequeBookSelectedRow}
            selectedRow={onSelectRowCheque}
          />
          <PettyCashPeriodBrowseModal
            isOpen={showPostingPeriodModal}
            setOpen={setShowPostingPeriodModal}
            title={t("common.periodBrowse")}
            selectedRow={onPostingPeriodSelectedRow}
            onSelectRowDate={onSelectRowDate}
          />
          <Modal
            className="confirm-delete-modal"
            primaryBtnText={t("common.yes")}
            secondaryBtnText={t("common.no")}
            tertiaryBtnText={t("common.cancel")}
            primaryBtnType={ButtonColor.Primary}
            secondaryBtnType={ButtonColor.Secondary}
            tertiaryBtnClick={() => setOpenSaveChangesModal(false)}
            secondaryBtnClick={() => {
              resetOnFocusAndNavigate();
              setOpenSaveChangesModal(false);
            }}
            primaryBtnClick={(e) => {
              resetOnFocus();
              setOpenSaveChangesModal(false);
              onSubmit();
            }}
            isOpen={openSaveChangesModal}
            header={t("common.simsFMSModule")}
          >
            <>
              <Notification
                className="w-100 mb-18 confirm-modal-text"
                actionElement={1}
                dataTestId="delete-new-warning-id"
                escapeExits
                id="delete-new-warning-id"
                hideCloseButton
                status={NotificationStatus.WARNING}
                title={t("supplier.payeeBrowser.keepChanges")}
              />
            </>
          </Modal>
          <AlertModal
            isOpen={openValidationModal}
            setOpen={setOpenValidationModal}
            title={t("alertMessage.title")}
            notificationType={NotificationStatus.ERROR}
            message={t("common.invalidData")}
          />
          <AlertModal
            isOpen={openInvalidChequeNoErr}
            setOpen={setOpenInvalidChequeNoErr}
            title={t("alertMessage.title")}
            notificationType={NotificationStatus.WARNING}
            message={t("common.invalidChequeNo")}
          />
          <ConfirmModal
            className="unique-cheque-alert"
            isOpen={showOverdrawnErrorModal}
            setOpen={setShowOverdrawnErrorModal}
            title={t("alertMessage.title")}
            message={uniqueChequeErrMsg}
            confirm={() => {
              postReimbursementData(formDataToSave);
            }}
          />
          <AlertModal
            isOpen={showUniqueChequeError}
            setOpen={setShowUniqueChequeError}
            title={t("alertMessage.title")}
            notificationType={NotificationStatus.WARNING}
            message={uniqueChequeErrMsg}
            callback={() => {
              if (formDataToSave && !printButtonClicked) saveReimbursementData(formDataToSave);
            }}
          />
          <ConfirmModal
            className="undu-alert"
            isOpen={isUndoModalOpen}
            setOpen={setIsUndoModalOpen}
            title={t("alertMessage.title")}
            message={t("alertMessage.undoAlert.message")}
            confirm={() => {
              undoChangeAndNavigate();
            }}
          />
        </>
      )}
    </>
  );
};

export default ViewReimbursement;
