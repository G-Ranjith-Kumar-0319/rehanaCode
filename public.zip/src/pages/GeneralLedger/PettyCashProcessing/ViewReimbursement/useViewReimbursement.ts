import "./Style.scss";
import { useHistory, useLocation, useParams } from "react-router-dom";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import React, { ChangeEvent, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { actions as cbActions } from "@/shared/components/SelectChequeBookModal/state/SelectChequeBook.slice";
import { actions as periodActions } from "@/shared/components/PettyCashPeriodBrowse/state/PettyCashPeriodBrowse.slice";
import { getDefaultPaymentPeriod } from "@/store/state/defaultYear.slice";
import { PETTY_CASH_TRANS_STATUS } from "@/types/UseStateType";
import { ISelectedItem, NotificationStatus, ValidationTextLevel } from "@essnextgen/ui-kit";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { usNumberFormat } from "@/utils/getDataSource";
import { getPettyCashList, pettyCashActions } from "../state/PettyCashList.slice";
import {
  actions as reimburAction,
  getFCSourceBalance,
  getReimbursementDetails,
  saveNewReimbursement,
  savePrintChequeReimbursement
} from "../state/ViewReimbursement.slice";

/* eslint-disable camelcase */
type FormData = {
  adj_trans_id: number;
  amount: string;
  bank_statement_no: string;
  book_id: string;
  cheque_book_id: number;
  cheque_no: string;
  date_posted: string;
  det_num: number;
  disp_amount: number;
  foliocount: number;
  narrative: string;
  next_no: string;
  number_range: string;
  orig_journal_id: number;
  orig_trans_id: number;
  payee_name: string;
  pc_account_id: number;
  pc_trans_id: number;
  period_posted: string;
  status: number;
  trans_no: string;
  trans_type: number;
  user_id: number;

  nextChequeNumber: string;
  numberRange: string;
  // paymentPeriod: string;
  paymentDescription: string;
};
const numberFormatter: any = new Intl.NumberFormat("en-US", {
  style: "decimal",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

const useViewReimbursement = () => {
  const [postingPeriodMonth, setPostingPeriodMonth] = useState<string>("");
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { pcAccountId, pcTransId } = useParams<{
    pcAccountId: string;
    pcTransId: string;
  }>();
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch<AppDispatch>();
  const [isChequeBookModalOpen, setIsChequeBookModalOpen] = useState<boolean>(false);
  const [showPostingPeriodModal, setShowPostingPeriodModal] = useState<boolean>(false);
  const [openSaveChangesModal, setOpenSaveChangesModal] = useState<boolean>(false);
  const [openValidationModal, setOpenValidationModal] = useState<boolean>(false);
  const [showUniqueChequeError, setShowUniqueChequeError] = useState<boolean>(false);
  const [printButtonClicked, setPrintButtonClicked] = useState<boolean>(false);
  const [isRequiredPayeeName, setIsRequiredPayeeName] = useState<boolean>(false);
  const [showOverdrawnErrorModal, setShowOverdrawnErrorModal] = useState<boolean>(false);
  const [openInvalidChequeNoErr, setOpenInvalidChequeNoErr] = useState<boolean>(false);
  const [isUndoModalOpen, setIsUndoModalOpen] = useState<boolean>(false);
  const [chequeNoError, setChequeNoError] = useState<boolean>(false);
  const [formDataToSave, SetFormDataToSave] = useState<any>();
  const [chequeNoVal, setChequeNoVal] = useState<any>();
  const [uniqueChequeErrMsg, setUniqueChequeErrMsg] = useState<string>("");
  const {
    selectedPettyCashRow,
    selectedPettyCashAccountBrowse,
    isFocus,
    filterState,
    pettyCashList: { currentPage, totalPages, pageSize }
  } = useAppSelector((state) => state.pettyCashList);
  const pettyCashTransactionList = useAppSelector((state) => state.pettyCashList.pettyCashList?.pettyCashTransaction);
  const { status, selectedChequeBook, chequeBookList, filters } = useAppSelector((state) => state.selectChequeBook);
  const { defaultPeriod } = useAppSelector(({ defaultPeriod }) => defaultPeriod);
  const { pettyCashAccountsHidden, pettyCashTransaction } = useAppSelector(
    (state) => state.ReimbursementDetails.reimbursementDetails
  );
  const { reimbursmentStatus, reimbursmentSaveStatus, printChequeStatus } = useAppSelector(
    (state) => state.ReimbursementDetails
  );
  const { postingPeriodDetails } = useAppSelector((state) => state.pettyCashPeriodBrowse);
  const historyState = { ...(history.location.state as any) };

  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
    getValues
  } = useForm<FormData>({
    shouldFocusError: false
  });

  useEffect(() => {
    reset({
      amount: pettyCashTransaction?.amount,
      cheque_no: pettyCashTransaction?.cheque_no ?? "",
      cheque_book_id: pettyCashTransaction?.cheque_book_id ?? 0,
      next_no: pettyCashTransaction?.next_no ?? "",
      number_range: pettyCashTransaction?.number_range ?? "",
      narrative: pettyCashTransaction?.narrative ?? "",
      period_posted: pettyCashTransaction?.period_posted
    });
  }, [pettyCashTransaction]);

  useEffect(() => {
    if (postingPeriodDetails?.length && pettyCashTransaction) {
      const postingPeriod = postingPeriodDetails?.find(
        (p: any) => Number(p.code) === pettyCashTransaction?.period_posted
      );
      setPostingPeriodMonth(postingPeriod?.description ?? "");
      setValue("period_posted", postingPeriod?.formattedCode ?? "");
    }
    if (historyState?.isAdjust) setValue("narrative", "");
  }, [postingPeriodDetails, pettyCashTransaction]);

  useEffect(() => {
    if (!historyState?.mode || historyState?.isAdjust) {
      dispatch(
        getReimbursementDetails({
          pcTransId,
          pcAccountId
        })
      );
    } else {
      const addReimbursementData = {
        pettyCashAccountsHidden: undefined,
        pettyCashTransaction: undefined
      };
      dispatch(reimburAction.setReimbursementDetails(addReimbursementData));
    }
  }, [pcAccountId, pcTransId]);

  const getCurrentDate = () => {
    const date1 = new Date();
    const day = date1.getDate().toString().padStart(2, "0");
    const month = (date1.getMonth() + 1).toString().padStart(2, "0"); // Months are zero-based, so we add 1
    const year = date1.getFullYear();
    const formattedDate1 = `${day}/${month}/${year}`;
    return formattedDate1;
  };
  const getHeaderValue = (fieldName: string) => {
    if (historyState?.mode) {
      if (historyState?.headerData) return historyState.headerData[fieldName];

      return "";
    }
    return pettyCashAccountsHidden ? pettyCashAccountsHidden[fieldName] : "";
  };

  const handleViewOriginalClick = () => {
    if (pettyCashTransaction?.orig_trans_id) {
      const origTransId = pettyCashTransaction.orig_trans_id;
      history.push({
        pathname: `/general-ledger/petty-cash/view-reimbursement/${pcAccountId}/${origTransId}`
      });
    }
  };

  const handleViewAdjustmentClick = () => {
    if (pettyCashTransaction?.adj_trans_id) {
      const adjTransId = pettyCashTransaction.adj_trans_id;
      history.push({
        pathname: `/general-ledger/petty-cash/view-reimbursement/${pcAccountId}/${adjTransId}`
      });
    }
  };

  const onChequeBookSelection = (selectedItem: ISelectedItem | undefined) => {
    const found = chequeBookList.find((row) => row?.number_range === selectedItem?.text);
    if (selectedItem?.text) {
      dispatch(cbActions.setFilters({ lookingFor: "" }));
      setValue("number_range", found?.number_range);
      setValue("next_no", found?.next_no);
      setValue("cheque_no", found?.next_no);
      setValue("cheque_book_id", found?.book_id);
      trigger("next_no");
      trigger("cheque_no");
      dispatch(cbActions.selectChequeBook(found));
    } else {
      const nextNo = getValues("next_no");
      if (nextNo) {
        const numberRangeData = chequeBookList.find((row) => row?.next_no === nextNo);
        setValue("number_range", numberRangeData?.number_range);
        setValue("cheque_book_id", numberRangeData?.book_id);
        dispatch(cbActions.selectChequeBook(numberRangeData));
      } else {
        dispatch(cbActions.selectChequeBook(undefined));
      }
    }
  };

  const onChequeBookNoSelection = () => {
    setIsChequeBookModalOpen(true);
  };

  const onChequeBookChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    const searchMapItemList = chequeBookList.map((row) => ({
      number_range: row?.number_range,
      next_no: row?.next_no,
      book_id: row?.book_id
    }));
    if (value && searchMapItemList?.length > 0) {
      const len = searchMapItemList.length;
      let i = 0;
      let setDependentValues = false;
      while (i < len) {
        if (searchMapItemList[i].number_range.startsWith(value)) {
          setDependentValues = true;
          break;
        }
        i += 1;
      }
      if (setDependentValues) {
        setValue("next_no", searchMapItemList[i].next_no);
        setValue("cheque_no", searchMapItemList[i].next_no);
        setValue("cheque_book_id", searchMapItemList[i].book_id);
      }
    }
    register("number_range").onChange(e);
    if (!value.trim()) {
      setValue("next_no", "");
      setValue("cheque_no", "");
      setChequeNoVal("");
      dispatch(cbActions.selectChequeBook(undefined));
      dispatch(cbActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(cbActions.setFilters({ lookingFor: value }));
    }
  };

  const setChequeBookDetails = (row: any) => {
    setValue("number_range", row?.number_range);
    setValue("next_no", row?.next_no);
    setValue("cheque_no", row?.next_no);
    setValue("cheque_book_id", row?.book_id);
    trigger("number_range");
    trigger("next_no");
    trigger("cheque_no");
  };

  const onChequeBookSelectedRow = (row: any) => {
    dispatch(cbActions.selectChequeBook(row));
    setChequeBookDetails(row);
  };

  const onSelectRowCheque = (value: string) => {
    if (!value.trim()) {
      dispatch(cbActions.selectChequeBook(undefined));
      dispatch(cbActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(cbActions.setFilters({ lookingFor: value }));
    }
  };

  const setPaymentPeriodDetails = (row: any) => {
    setValue("period_posted", row.formattedCode);
    setPostingPeriodMonth(row.description);
  };

  const onPaymentPeriodSelection = (selectedItem: ISelectedItem | undefined) => {
    const found = postingPeriodDetails.find((s) => s.formattedCode === selectedItem?.text);
    if (selectedItem?.text) {
      dispatch(periodActions.setFilters({ lookingFor: "" }));
      setValue("paymentDescription", found?.description);
      setPostingPeriodMonth(found?.description);
      dispatch(periodActions.selectPostingPeriod(found));
    } else {
      dispatch(periodActions.selectPostingPeriod(undefined));
    }
  };

  const onPaymentPeriodNoSelection = () => {
    setShowPostingPeriodModal(true);
    setValue("period_posted", "");
    setPostingPeriodMonth("");
  };

  const onPaymentPeriodChange = (e: ChangeEvent<HTMLInputElement>) => {
    register("period_posted").onChange(e);
    const { value } = e.target;
    if (!value.trim()) {
      setPostingPeriodMonth("");
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
      const found = postingPeriodDetails.find((s) => s.formattedCode === value);
      if (found) setPostingPeriodMonth(found?.description);
    }
  };

  const onPostingPeriodSelectedRow = (row: any) => {
    dispatch(periodActions.selectPostingPeriod(row));
    setPaymentPeriodDetails(row);
  };
  const onSelectRowDate = (value: any) => {
    if (!value.trim()) {
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
    }
  };

  useEffect(() => {
    dispatch(getDefaultPaymentPeriod({ date: getCurrentDate() }));
  }, []);

  useEffect(() => {
    if (historyState.mode) {
      const found = postingPeriodDetails.find((t) => Number(t.code) === defaultPeriod);
      if (found) {
        setPaymentPeriodDetails(found);
        dispatch(periodActions.selectPostingPeriod(found));
      }
    }
  }, [defaultPeriod]);

  const saveReimbursementData = (formData: any) => {
    SetFormDataToSave("");
    dispatch(
      saveNewReimbursement({
        formData,
        callback: (res) => {
          if (res.validationType !== 0) {
            setShowUniqueChequeError(true);
            setUniqueChequeErrMsg(res.message);
          } else if (isFocus) {
            resetOnFocus();
            dispatch(pettyCashActions.setSelectedPettyCashRow(undefined));
            history.push(`/general-ledger/petty-cash/view-reimbursement/${formData.pc_account_id}/${res?.pc_trans_id}`);
          } else {
            const addReimbursementData = {
              pettyCashAccountsHidden: undefined,
              pettyCashTransaction: undefined
            };
            dispatch(reimburAction.setReimbursementDetails(addReimbursementData));
            history.push("/general-ledger/petty-cash");
          }
        }
      })
    );
  };

  const printChequePostReimbursement = (formData: any) => {
    dispatch(
      savePrintChequeReimbursement({
        formData,
        callback: (res) => {
          if (res.validationType !== 0) {
            setShowUniqueChequeError(true);
            setUniqueChequeErrMsg(res.message);
          } else {
            const pdfData = res?.pc_reimbursement_cheque_file;
            const byteCharacters = atob(pdfData);
            const byteNumbers = new Array(byteCharacters.length);
            let i = 0;
            while (i < byteCharacters.length) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
              i += 1; // Use compound assignment instead of increment operator
            }
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], { type: "application/pdf" });
            const link = document.createElement("a");
            link.href = window.URL.createObjectURL(blob);
            link.download = formData.cheque_no ? `${formData.cheque_no}.pdf` : "file.pdf"; // Set the download attribute with file extension
            link.click();
            history.push("/general-ledger/petty-cash");
          }
        }
      })
    );
  };

  const callSaveAPI = (formData: any) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        message: t("viewReimbursement.postPettyCash"),
        title: t("common.simsFMSModule"),
        type: MODAL_TYPE.CONFIRMV2,
        yesCallback: () => {
          postReimbursementData(formData);
          return null;
        },
        noCallback: () => {}
      })
    );
  };

  const postReimbursementData = (formData: any) => {
    if (formData.cheque_no && formData.reim_number_range) {
      const splitNoRange = formData.reim_number_range.split(" - ");
      const num = Number(formData.cheque_no);
      const min = Number(splitNoRange[0]);
      const max = Number(splitNoRange[1]);
      const isWithinRange = num >= min && num <= max;
      if (!isWithinRange) {
        setOpenInvalidChequeNoErr(true);
        return null;
      }
    }
    if (printButtonClicked) {
      printChequePostReimbursement(formData);
    } else {
      saveReimbursementData(formData);
    }

    return null;
  };
  const isAmountEligible = () => {
    if (Number(getValues("amount")) > 0) return false;
    return true;
  };

  const onPrintCheque = async () => {
    setIsRequiredPayeeName(true);
    await trigger("payee_name");
    onSubmit();
  };

  const onSubmit = handleSubmit(
    (data) => {
      setChequeNoError(false);
      SetFormDataToSave("");
      const formData: any = {};
      formData.pc_account_id = selectedPettyCashAccountBrowse?.pc_account_id;
      formData.pc_trans_id = historyState?.isAdjust ? pettyCashTransaction?.pc_trans_id : 0;
      formData.amount = Number(data.amount);
      formData.period_posted = Number(data.period_posted);
      formData.narrative = data.narrative;
      formData.cheque_book_id = getValues("cheque_book_id") ?? 0;
      formData.cheque_no = data.cheque_no.length > 0 ? data.cheque_no : "";
      formData.payee_name = data.payee_name ?? "";
      formData.isAdjust = historyState?.isAdjust ?? false;
      formData.reim_number_range = data?.number_range;
      dispatch(
        getFCSourceBalance({
          ledDefId: selectedPettyCashAccountBrowse?.source_leddef_id,
          callback: (res) => {
            // Condition 1
            if (historyState?.headerData?.source_type === "FC") {
              const remainingBal = res - formData.amount;
              if (remainingBal < 0) {
                const balanceErrMsg = `${historyState?.headerData?.source_des}${t(
                  "common.appendString"
                )}${numberFormatter.format(Math.abs(remainingBal))}`;
                setShowUniqueChequeError(true);
                setUniqueChequeErrMsg(balanceErrMsg);
                return null;
              }
            }
            // 2nd Conditions
            const totalAmt = Number(historyState?.headerData?.cash_in_hand) + formData.amount;
            if (totalAmt < 0) {
              const balanceErrMsg = `${historyState?.headerData?.source_des}${t(
                "common.appendString"
              )}${numberFormatter.format(Math.abs(totalAmt))}`;
              setShowUniqueChequeError(true);
              setUniqueChequeErrMsg(balanceErrMsg);
              return null;
            }
            // 3rd Contions
            if (historyState?.headerData?.source_type === "BK") {
              if (formData.amount > res) {
                const balanceAmount = Math.abs(res - formData.amount);
                const balanceErrMsg = `${historyState?.headerData?.source_des}${t(
                  "common.appendString"
                )}${usNumberFormat(balanceAmount)}.
                ${t("viewReimbursement.postPettyCash")}`;
                SetFormDataToSave(formData);
                setShowOverdrawnErrorModal(true);
                setUniqueChequeErrMsg(balanceErrMsg);
                return null;
              }
            }

            callSaveAPI(formData);
            return null;
          }
        })
      );
    },
    (error) => {
      if (error.cheque_no?.type === "required") {
        setChequeNoError(true);
      }

      setOpenValidationModal(true);
    }
  );

  const saveChangesModal = () => {
    setPrintButtonClicked(false);
    dispatch(pettyCashActions.setIsFocus(false));
    setOpenSaveChangesModal(true);
  };
  const onFocusClickHandler = () => {
    if (historyState.mode) {
      dispatch(pettyCashActions.setIsFocus(true));
      setOpenSaveChangesModal(true);
    } else {
      dispatch(pettyCashActions.setIsFocus(false));
      dispatch(pettyCashActions.setFilters({ pcTransId: selectedPettyCashRow?.pc_trans_id }));
      history.push(`/general-ledger/petty-cash`);
    }
  };
  const resetOnFocus = () => {
    dispatch(pettyCashActions.setIsFocus(false));
  };

  const undoChangeHandler = () => {
    if (historyState.mode) {
      setIsUndoModalOpen(true);
    } else {
      dispatch(pettyCashActions.setFilters({ pcTransId: selectedPettyCashRow?.pc_trans_id }));
      history.push(`/general-ledger/petty-cash`);
    }
  };
  const undoChangeAndNavigate = () => {
    dispatch(pettyCashActions.setFilters({ pcTransId: selectedPettyCashRow?.pc_trans_id }));
    history.push(`/general-ledger/petty-cash`);
  };

  const resetOnFocusAndNavigate = () => {
    if (isFocus) {
      dispatch(pettyCashActions.setIsFocus(false));
      dispatch(pettyCashActions.setFilters({ pcTransId: selectedPettyCashRow?.pc_trans_id }));
      history.push(`/general-ledger/petty-cash`);
    }
  };

  const goToAdd = () => {
    const addReimbursementData = {
      pettyCashAccountsHidden: undefined,
      pettyCashTransaction: undefined
    };
    dispatch(reimburAction.setReimbursementDetails(addReimbursementData));
    history.push({
      pathname: `/general-ledger/petty-cash/add-reimbursement`,
      state: {
        mode: "add",
        headerData: selectedPettyCashAccountBrowse
      }
    });
  };

  const goToRecord = (row: any) => {
    dispatch(pettyCashActions.setSelectedPettyCashRow(row));
    dispatch(pettyCashActions.setFilters({ highlightPcTransId: row?.id }));
    if (row?.trans_type === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/view-reimbursement/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    }
  };

  const onChangeHandler = (page: number) => {
    dispatch(
      pettyCashActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        highlightPcTransId: undefined,
        pcTransId: 0
      })
    );
    dispatch(
      getPettyCashList({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(pageSize),
        highlightPcTransId: undefined,
        pcTransId: 0,
        pcAccountId: Number(pcAccountId),
        callback: (data) => {
          const row = data?.pettyCashTransaction?.at(0);
          if (row) {
            goToRecord(row);
          }
        }
      })
    );
  };

  const onChangePrevRecord = (page: number) => {
    dispatch(
      pettyCashActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        highlightPcTransId: undefined,
        pcTransId: 0
      })
    );
    dispatch(
      getPettyCashList({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(pageSize),
        highlightPcTransId: undefined,
        pcTransId: 0,
        pcAccountId: Number(pcAccountId),
        callback: (data) => {
          const row = data?.pettyCashTransaction?.at(data?.pettyCashTransaction.length - 1);
          if (row) {
            goToRecord(row);
          }
        }
      })
    );
  };

  const selectPrevRecord = () => {
    if (selectedPettyCashRow && pettyCashTransactionList) {
      const indexNo = pettyCashTransactionList.indexOf(selectedPettyCashRow);
      if (indexNo > 0) {
        const row = pettyCashTransactionList[indexNo - 1];
        dispatch(pettyCashActions.setSelectedPettyCashRow(pettyCashTransactionList[indexNo - 1]));
        goToRecord(row);
      } else if (currentPage > 1) {
        onChangePrevRecord(currentPage - 1);
      }
    }
  };
  const selectNextRecord = () => {
    if (selectedPettyCashRow && pettyCashTransactionList) {
      const indexNo = pettyCashTransactionList.indexOf(selectedPettyCashRow);
      if (indexNo < pettyCashTransactionList.length - 1) {
        const row = pettyCashTransactionList[indexNo + 1];
        dispatch(pettyCashActions.setSelectedPettyCashRow(pettyCashTransactionList[indexNo + 1]));
        goToRecord(row);
      } else if (currentPage < totalPages) {
        onChangeHandler(currentPage + 1);
      }
    }
  };
  const isAllZeros = (str: any) => /^0*$/.test(str);

  const handleCheckNo = () => {
    if (isAllZeros(getValues("cheque_no")) || getValues("cheque_no") === "") {
      setChequeNoVal("");
      setValue("cheque_no", "");
    }
  };
  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChequeNoError(false);
    setChequeNoVal(event.target.value);
    setValue("cheque_no", event.target.value);
    if (event.target.value !== "") {
      const noSpacesValue = event.target.value.replace(/\s+/g, "");
      if (noSpacesValue.length <= 6) {
        setChequeNoVal(noSpacesValue.padEnd(6, "0"));
        setValue("cheque_no", noSpacesValue.padEnd(6, "0"));
      }
    } else {
      setChequeNoVal("");
      setValue("cheque_no", "");
    }
  };

  const isInputClassReq = () => {
    if (historyState?.isAdjust || historyState?.mode) {
      return "";
    }
    if (!historyState?.mode) {
      return "not-in-use";
    }
    return "";
  };
  const getInitialPayeeCheque = () => {
    if (pettyCashTransaction) {
      // either in view or adjust state
      if (historyState?.isAdjust) {
        if (pettyCashAccountsHidden?.source_type === "BK") {
          return pettyCashTransaction.payee_name;
        }
        return "";
      }
      return pettyCashTransaction.payee_name ? pettyCashTransaction.payee_name : "-";
    }
    return getValues("payee_name");
  };
  const adjustTransHandler = () => {
    if (selectedPettyCashRow?.trans_type === 0) {
      const addReimbursementData = {
        pettyCashAccountsHidden: undefined,
        pettyCashTransaction: undefined
      };
      dispatch(reimburAction.setReimbursementDetails(addReimbursementData));
      history.push({
        pathname: `/general-ledger/petty-cash/adjust-reimbursement/${selectedPettyCashRow?.pc_account_id}/${selectedPettyCashRow?.pc_trans_id}`,
        state: {
          selectedRowState: selectedPettyCashRow,
          headerData: selectedPettyCashAccountBrowse,
          isAdjust: true
        }
      });
    }
  };

  const isCancelDisabled = () =>
    !(
      !historyState.mode &&
      !historyState.isAdjust &&
      (pettyCashTransaction?.status === PETTY_CASH_TRANS_STATUS.NORMAL ||
        pettyCashTransaction?.status === PETTY_CASH_TRANS_STATUS.ADJUST ||
        pettyCashTransaction?.status === PETTY_CASH_TRANS_STATUS.ADJUST_OF_ADJUST)
    );

  const isAdjustTransDisabled = () =>
    !(
      !historyState.mode &&
      !historyState.isAdjust &&
      !pettyCashTransaction?.cheque_book_id &&
      (pettyCashTransaction?.status === PETTY_CASH_TRANS_STATUS.NORMAL ||
        pettyCashTransaction?.status === PETTY_CASH_TRANS_STATUS.ADJUST ||
        pettyCashTransaction?.status === PETTY_CASH_TRANS_STATUS.ADJUST_OF_ADJUST)
    );

  return {
    historyState,
    reimbursmentStatus,
    pettyCashAccountsHidden,
    pettyCashTransaction,
    postingPeriodMonth,
    numberFormatter,
    handleViewOriginalClick,
    handleViewAdjustmentClick,
    selectNextRecord,
    selectPrevRecord,
    pcTransId,
    postingPeriodDetails,
    onSelectRowDate,
    onPostingPeriodSelectedRow,
    onPaymentPeriodChange,
    onPaymentPeriodNoSelection,
    onPaymentPeriodSelection,
    onSelectRowCheque,
    onChequeBookSelectedRow,
    onChequeBookNoSelection,
    onChequeBookChange,
    onChequeBookSelection,
    setShowPostingPeriodModal,
    isChequeBookModalOpen,
    showPostingPeriodModal,
    chequeBookList,
    setIsChequeBookModalOpen,
    isAmountEligible,
    getCurrentDate,
    getHeaderValue,
    setValue,
    getValues,
    errors,
    ValidationTextLevel,
    register,
    watch,
    onSubmit,
    setPrintButtonClicked,
    saveChangesModal,
    handleCheckNo,
    openSaveChangesModal,
    setOpenSaveChangesModal,
    handleInputChange,
    setOpenValidationModal,
    openValidationModal,
    chequeNoVal,
    showUniqueChequeError,
    setShowUniqueChequeError,
    uniqueChequeErrMsg,
    reimbursmentSaveStatus,
    onFocusClickHandler,
    resetOnFocus,
    goToAdd,
    undoChangeHandler,
    isUndoModalOpen,
    chequeNoError,
    setIsUndoModalOpen,
    resetOnFocusAndNavigate,
    undoChangeAndNavigate,
    formDataToSave,
    saveReimbursementData,
    printChequePostReimbursement,
    openInvalidChequeNoErr,
    printChequeStatus,
    setOpenInvalidChequeNoErr,
    isInputClassReq,
    getInitialPayeeCheque,
    adjustTransHandler,
    isCancelDisabled,
    isAdjustTransDisabled,
    isRequiredPayeeName,
    printButtonClicked,
    showOverdrawnErrorModal,
    setShowOverdrawnErrorModal,
    postReimbursementData,
    onPrintCheque
  };
};

export default useViewReimbursement;
