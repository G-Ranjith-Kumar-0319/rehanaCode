import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  ISelectedItem,
  Icon,
  IconColor,
  IconSize,
  NotificationStatus,
  TextInput,
  ValidationTextLevel
} from "@essnextgen/ui-kit";

import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import { getDate } from "@/utils/getDataSource";
import PettyCashPeriodBrowseModal from "@/shared/components/PettyCashPeriodBrowse/PettyCashPeriodBrowseModal";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import useAddPostingDetails from "./useAddPostingDetails";

const AddPostingDetails = () => {
  const {
    t,
    postingPeriodDetails,
    onPaymentPeriodNoSelection,
    register,
    getValues,
    errors,
    showPostingPeriodModal,
    setShowPostingPeriodModal,
    onPaymentPeriodChange,
    onPaymentPeriodSelection,
    onPostingPeriodSelectedRow,
    onSelectRowDate,
    postingPeriodMonth,
    onPostHandler,
    openAlertModal,
    setOpenAlertModal,
    alertMessage,
    onCancelHandler,
    periodPosted
  } = useAddPostingDetails();
  return (
    <>
      <Layout
        pageTitle={t("addPostingDetails.pageTitle")}
        className="add-posting-details"
      >
        <div className="mt-10">
          <Grid className="row-gap-8 marginb15">
            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
            >
              <div className="essui-form-label mb-5">{t("addPostingDetails.date")}</div>
              <div>{getDate()}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
            >
              <div>
                <FormLabel
                  className=""
                  forId="txt-payment-period"
                >
                  {t("addPostingDetails.paymentPeriod")}
                </FormLabel>
                <Grid className="">
                  <GridItem>
                    <Input
                      id="txt-payment-period"
                      searchable
                      searchItems={postingPeriodDetails.map((p) => ({ text: p.formattedCode, value: p.description }))}
                      onSelect={(selectedItem: ISelectedItem | undefined) => onPaymentPeriodSelection(selectedItem)}
                      inputWidth={50}
                      maxLength={40}
                      onNoSelection={onPaymentPeriodNoSelection}
                      value={getValues("paymentPeriod")}
                      inputRef={(e) => register("paymentPeriod").ref(e)}
                      name={register("paymentPeriod", { required: true }).name}
                      onChange={onPaymentPeriodChange}
                      validationTextLevel={errors.paymentPeriod ? ValidationTextLevel.Error : undefined}
                      button={
                        <>
                          <TextInput
                            className="read-only"
                            id="txt-payment-description"
                            inputWidth={60}
                            value={String(getValues("paymentPeriod")) === "" ? "" : postingPeriodMonth}
                            name={register("paymentDescription").name}
                            disabled
                          />
                          <Button
                            id="btn-payment-period"
                            color={ButtonColor.Secondary}
                            onClick={() => setShowPostingPeriodModal(true)}
                            size={ButtonSize.Small}
                            className="essui-button-icon-only--small"
                          >
                            <Icon
                              color={IconColor.Primary500}
                              size={IconSize.Medium}
                              name="search"
                            />
                          </Button>
                        </>
                      }
                    />
                  </GridItem>
                </Grid>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={8}
              xl={8}
            >
              <div>
                <FormLabel
                  forId="txt-narrative"
                  className=""
                >
                  {t("addPostingDetails.narrative")}
                </FormLabel>
                <Input
                  id="txt-narrative"
                  value={getValues("narrative")}
                  searchable
                  maxLength={40}
                  inputRef={(e) => register("narrative").ref(e)}
                  onChange={register("narrative").onChange}
                  name={register("narrative", { required: true }).name}
                  validationTextLevel={errors.narrative ? ValidationTextLevel.Error : undefined}
                />
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("addPostingDetails.generalLedgerJournal")}</div>
              <div>-</div>
            </GridItem>
          </Grid>

          <Grid justify="space-between">
            <GridItem
              sm={8}
              lg={6}
              md={4}
            >
              <Button
                id="btn-help"
                size={ButtonSize.Small}
                onClick={() => {}}
                color={ButtonColor.Tertiary}
                iconPosition={ButtonIconPosition.Left}
              >
                {t("common.help")}
              </Button>
            </GridItem>
            <GridItem
              sm={8}
              lg={6}
              md={4}
            >
              <Grid className="dialog-right-button m-0">
                <Button
                  id="btn-cancel"
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  iconPosition={ButtonIconPosition.Left}
                  onClick={onCancelHandler}
                >
                  {t("common.cancel")}
                </Button>
                <Button
                  id="btn-post"
                  size={ButtonSize.Small}
                  color={ButtonColor.Primary}
                  iconPosition={ButtonIconPosition.Left}
                  onClick={onPostHandler}
                >
                  {t("common.post")}
                </Button>
              </Grid>
            </GridItem>
          </Grid>
        </div>
      </Layout>
      <PettyCashPeriodBrowseModal
        isOpen={showPostingPeriodModal}
        setOpen={setShowPostingPeriodModal}
        title={t("common.periodBrowse")}
        selectedRow={onPostingPeriodSelectedRow}
        onSelectRowDate={onSelectRowDate}
        period={periodPosted}
      />
      <AlertModal
        isOpen={openAlertModal}
        setOpen={setOpenAlertModal}
        title={t("alertMessage.title")}
        notificationType={NotificationStatus.WARNING}
        message={alertMessage}
      />
    </>
  );
};

export default AddPostingDetails;
