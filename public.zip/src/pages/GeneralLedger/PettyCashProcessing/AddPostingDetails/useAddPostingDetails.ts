import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import React, { ChangeEvent, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { actions as periodActions } from "@/shared/components/PettyCashPeriodBrowse/state/PettyCashPeriodBrowse.slice";
import { useDispatch } from "react-redux";
import { ISelectedItem } from "@essnextgen/ui-kit";
import { getCurrentDate, getDefaultPaymentPeriod } from "@/store/state/defaultYear.slice";
import { useHistory } from "react-router";
import { getCurrentFinancialYear, METHOD } from "@/types/UseStateType";
import { dateConvertInDDslashMMslashYYYY } from "@/utils/getDataSource";
import { tr } from "date-fns/locale";
import { postExpenditure, ajustExpenditure } from "../state/PostExpenditure.slice";

type FormData = {
  paymentPeriod: string;
  paymentDescription: string;
  narrative: string;
};
const useAddPostingDetails = () => {
  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
    getValues
  } = useForm<FormData>({
    shouldFocusError: false
  });
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const [showPostingPeriodModal, setShowPostingPeriodModal] = useState<boolean>(false);
  const [postingPeriodMonth, setPostingPeriodMonth] = useState<string>("");
  const [openAlertModal, setOpenAlertModal] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<string>("");
  const { postingPeriodDetails } = useAppSelector((state) => state.pettyCashPeriodBrowse);
  const { defaultPeriod } = useAppSelector(({ defaultPeriod }) => defaultPeriod);
  const periodPosted = historyState?.selectedRowState?.period_posted;
  const onPaymentPeriodNoSelection = () => {
    setShowPostingPeriodModal(true);
    setValue("paymentPeriod", "0");
    setPostingPeriodMonth("");
  };

  const onPaymentPeriodChange = (e: ChangeEvent<HTMLInputElement>) => {
    register("paymentPeriod").onChange(e);
    const { value } = e.target;
    if (!value.trim()) {
      setPostingPeriodMonth("");
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
      const found = postingPeriodDetails.find((s) => s.formattedCode === value);
      if (found) setPostingPeriodMonth(found?.description);
    }
  };
  const onPaymentPeriodSelection = (selectedItem: ISelectedItem | undefined) => {
    const found = postingPeriodDetails.find((s) => s.formattedCode === selectedItem?.text);
    if (selectedItem?.text) {
      dispatch(periodActions.setFilters({ lookingFor: "" }));
      setValue("paymentDescription", found?.description);
      setPostingPeriodMonth(found?.description);
      dispatch(periodActions.selectPostingPeriod(found));
    } else {
      dispatch(periodActions.selectPostingPeriod(undefined));
    }
  };

  const onPostingPeriodSelectedRow = (row: any) => {
    dispatch(periodActions.selectPostingPeriod(row));
    setPaymentPeriodDetails(row);
  };
  const setPaymentPeriodDetails = (row: any) => {
    setValue("paymentPeriod", row.formattedCode);
    setPostingPeriodMonth(row.description);
  };
  const onSelectRowDate = (value: any) => {
    if (!value.trim()) {
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
    }
  };
  useEffect(() => {
    dispatch(getDefaultPaymentPeriod({ date: getCurrentDate() }));
  }, []);

  useEffect(() => {
    const found = postingPeriodDetails.find((t) => Number(t.code) === defaultPeriod);
    if (found) {
      setPaymentPeriodDetails(found);
      dispatch(periodActions.selectPostingPeriod(found));
    }
  }, [defaultPeriod]);

  const getFolioData = () => {
    if (!historyState?.expenditureItems) return [];

    return historyState.expenditureItems.map((item: any) => ({
      pc_folio_id: item?.pc_folio_id,
      pc_trans_id: item?.pc_trans_id,
      ledger_id: item?.leddef_id,
      cost_id: item?.cost_id,
      net_amount: String(item?.net_amount),
      vat_amount: String(item?.vat_amount),
      vat_id: item?.vat_id,
      cost_to_establishment: String(item?.cost_to_establishment),
      description: item?.description,
      receipt_date: dateConvertInDDslashMMslashYYYY(item?.receipt_date, true),
      vat_reg_no: item?.vat_reg_no,
      fundId: item?.fund_id,
      ledgersourceid: 0
    }));
  };
  const onAdjustPostHandler = async (data: any) => {
    const formData = {
      pcAccountId: historyState?.selectedRowState?.pc_account_id,
      pc_trans_id: historyState?.selectedRowState?.pc_trans_id,
      book_id: historyState?.selectedRowState?.book_id,
      pettyCashExpenditurePostingDetail: {
        year_id: Number(getCurrentFinancialYear()),
        period_posted: Number(data.paymentPeriod),
        narrative: data.narrative,
        pc_trans_id: Number(historyState?.selectedRowState?.pc_trans_id)
      },
      pettyCashAdjustedFolios: getFolioData()
    };
    dispatch(
      ajustExpenditure({
        formData,
        callback: (data: any) => {
          if (data.validationType === 0) {
            history.push({
              pathname: `/general-ledger/petty-cash`,
              state: {
                ...(history.location.state as any)
              }
            });
          } else {
            setOpenAlertModal(true);
            setAlertMessage(data.message);
          }
        }
      })
    );
  };

  const onExpenditurePostHandler = async (data: any) => {
    const formData = {
      year_id: Number(getCurrentFinancialYear()),
      period_posted: Number(data.paymentPeriod),
      narrative: data.narrative,
      pc_trans_id: Number(historyState?.selectedRowState?.pc_trans_id)
    };
    dispatch(
      postExpenditure({
        formData,
        callback: (data: any) => {
          if (data.validationType === 0) {
            history.push({
              pathname: `/general-ledger/petty-cash`,
              state: {
                ...(history.location.state as any)
              }
            });
          } else {
            setOpenAlertModal(true);
            setAlertMessage(data.message);
          }
        }
      })
    );
  };
  const onPostHandler = async () => {
    const formSumbit = handleSubmit(
      async (data) => {
        if (historyState?.mode === METHOD.ADJUST) {
          onAdjustPostHandler(data);
        } else {
          onExpenditurePostHandler(data);
        }
      },
      () => {
        setOpenAlertModal(true);
        setAlertMessage(t("common.invalidData"));
      }
    );
    await formSumbit();
  };

  const onCancelHandler = () => {
    reset();
    dispatch(periodActions.selectPostingPeriod(undefined));
    dispatch(periodActions.setFilters({ lookingFor: "" }));
    if (historyState.mode === METHOD.ADJUST) {
      history.push({
        pathname: `/general-ledger/petty-cash/adjust-expenditure/${historyState?.selectedRowState?.pc_account_id}/${historyState?.selectedRowState?.pc_trans_id}`,
        state: {
          ...(history.location.state as any)
        }
      });
    } else if (historyState.navigateFrom === "list") {
      history.push({
        pathname: `/general-ledger/petty-cash`,
        state: {
          ...(history.location.state as any)
        }
      });
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/edit-expenditure/${historyState?.selectedRowState?.pc_account_id}/${historyState?.selectedRowState?.pc_trans_id}`,
        state: {
          ...(history.location.state as any)
        }
      });
    }
  };
  return {
    t,
    postingPeriodDetails,
    onPaymentPeriodNoSelection,
    register,
    setValue,
    trigger,
    handleSubmit,
    watch,
    reset,
    getValues,
    errors,
    showPostingPeriodModal,
    setShowPostingPeriodModal,
    onPaymentPeriodChange,
    onPaymentPeriodSelection,
    onPostingPeriodSelectedRow,
    onSelectRowDate,
    postingPeriodMonth,
    onPostHandler,
    openAlertModal,
    setOpenAlertModal,
    alertMessage,
    onCancelHandler,
    periodPosted
  };
};

export default useAddPostingDetails;
