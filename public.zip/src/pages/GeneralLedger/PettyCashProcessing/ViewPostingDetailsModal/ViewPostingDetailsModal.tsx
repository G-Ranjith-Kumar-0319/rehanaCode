import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import Modal from "@/components/Modal/Modal";
import { Grid, GridItem, Loader, LoaderType } from "@essnextgen/ui-kit";
import { getDate } from "@/utils/getDataSource";
import { specialCharacters, STATUS } from "@/types/UseStateType";
import { getPCPostingPeriod } from "@/pages/BankReconciliation/state/PettyCashDetails.slice";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { getPettyCashPostingDetails } from "../state/PettyCashPostingDetails.slice";

type TPostingDetailsModalProp = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  pcTransId: string;
};

const ViewPostingDetailsModal = ({ setOpen, isOpen, pcTransId }: TPostingDetailsModalProp) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { pettyCashPostingDetails, status } = useAppSelector((state) => state.pettyCashPostingDetails);
  const { postingPeriodDetails } = useAppSelector((state) => state.pcDetails);
  const [postingPeriodMonth, setPostingPeriodMonth] = useState<string>("");
  const [periodPosted, setPeriodPosted] = useState<string>("");

  useEffect(() => {
    if (postingPeriodDetails?.length && pettyCashPostingDetails) {
      const postingPeriod = postingPeriodDetails?.find(
        (p: any) => Number(p.code) === pettyCashPostingDetails?.period_posted
      );
      setPostingPeriodMonth(postingPeriod?.description ?? "");
      setPeriodPosted(postingPeriod?.code ? postingPeriod?.code.padStart(2, "0") : "");
    }
  }, [postingPeriodDetails, pettyCashPostingDetails]);

  const getDisplayValue = (code: any, description: any) => {
    if (code || description) {
      return `${code || ""} ${description || ""}`;
    }
    return specialCharacters.HYPHEN;
  };

  useEffect(() => {
    if (pcTransId && isOpen) {
      dispatch(getPettyCashPostingDetails({ pcTransId }));
      dispatch(getPCPostingPeriod(0));
    }
  }, [pcTransId, isOpen]);

  return (
    <Modal
      isOpen={isOpen}
      primaryBtnText={t("common.close")}
      primaryBtnClick={() => {
        setOpen(false);
      }}
      fourthiaryBtnClick={() => {}}
      className="dialog__divider"
      onClose={() => {
        setOpen(false);
      }}
      header={t("pettyCash.viewPostingDetailsModalTitle")}
    >
      {status === STATUS.LOADING ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText={t("common.loading")}
        />
      ) : (
        <div className="overflow-hidden">
          <Grid className="row-gap-16 marginb15">
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("common.date")}</div>
              <div>{getDate(pettyCashPostingDetails?.date_posted)}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={6}
              xl={6}
            >
              <div className="essui-form-label mb-5">{t("pettyCash.period")}</div>
              <div>{getDisplayValue(periodPosted, postingPeriodMonth)}</div>
            </GridItem>

            <GridItem
              sm={4}
              md={12}
              lg={12}
              xl={12}
            >
              <div className="essui-form-label mb-5">{t("common.narrative")}</div>
              <div>{pettyCashPostingDetails?.narrative ?? specialCharacters.HYPHEN}</div>
            </GridItem>
            <GridItem
              sm={4}
              md={12}
              lg={12}
              xl={12}
            >
              <div className="essui-form-label mb-5">{t("viewExpenditure.generalLedgerJournal")}</div>
              <div>{pettyCashPostingDetails?.det_num ?? specialCharacters.HYPHEN}</div>
            </GridItem>
          </Grid>
        </div>
      )}
    </Modal>
  );
};
export default ViewPostingDetailsModal;
