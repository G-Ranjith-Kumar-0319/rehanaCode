import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import {
  getPettyCashAccountBrowse,
  getPettyCashFundingSource,
  getPettyCashList,
  pettyCashActions,
  updatingPettyCashFundingSource
} from "../state/PettyCashList.slice";

/* eslint-disable import/prefer-default-export */
export const usePettyCashAccountBrowse = () => {
  const {
    filterState,
    selectedPettyCashAccountBrowse,
    selectedPersistPettyCashBrowseRow,
    pettyCashAccountBrowse,
    pettyCashFundingStatus,
    pettyCashFundingSource,
    sortedPettyCashAccount,
    pettyCashBrowseStatus,
    isCancel,
    selectedPettyCashFundingSource,
    pettyCashBrowseColumnDef: pettyCashBrowseColDef,
    pettyFundingSourceColumnDef: fundingSourceColDef
  } = useAppSelector((state) => state.pettyCashList);

  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const [selectedRow, setSelectedRow] = useState<any>();
  const [fundingSourceTableEnable, setFundingSourceTableEnable] = useState<any>(false);
  const [pettyCashAccountBrowseClose, setPettyCashAccountBrowseClose] = useState<any>(false);
  const [openFundSourceToPettyCashAccount, setOpenFundSourceToPettyCashAccount] = useState<any>(false);
  const [fundingSourceTableTitle, setFundingSourceTableTitle] = useState<any>();
  const [selectButtonDisabled, setSelectButtonDisabled] = useState<boolean>(true);

  const cancelHandler = () => {
    dispatch(pettyCashActions.setCancelButtonClicked(true));
    setSelectedRow(undefined);
  };

  const checkFundingSource = (row: any) => {
    if (!isCancel) {
      if (!row?.source_des) {
        setFundingSourceTableEnable(true);
        dispatch(getPettyCashFundingSource());
        setFundingSourceTableTitle(row?.pc_acc_des);
      } else {
        setFundingSourceTableEnable(false);
      }
    }
  };
  useEffect(() => {
    const indexOfRow = pettyCashAccountBrowse.findIndex(
      (item) => item.pc_account_id === selectedPersistPettyCashBrowseRow?.pc_account_id
    );
    setTimeout(() => {
      const element = document.getElementById(`rowIndex-pettycash-${indexOfRow}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }, 25);
  }, [pettyCashAccountBrowse, sortedPettyCashAccount]);

  useEffect(() => {
    if (selectedPersistPettyCashBrowseRow) {
      if (!selectedPersistPettyCashBrowseRow?.source_des) {
        setSelectButtonDisabled(true);
      } else {
        setSelectButtonDisabled(false);
      }
    }
  }, [selectedPersistPettyCashBrowseRow]);

  const UpdateFundingSourceData = () => {
    dispatch(
      updatingPettyCashFundingSource({
        pc_account_id: selectedRow?.pc_account_id,
        source_leddef_id: selectedPettyCashFundingSource?.leddef_id,
        callback: (res) => {
          dispatch(getPettyCashAccountBrowse());
          dispatch(pettyCashActions.setSelectedPettyCashBrowseRow(selectedRow));
          setPettyCashAccountBrowseClose(true);
          pettyCashActions.setFilters({
            ...filterState,
            pcAccountId: selectedRow?.pc_account_id,
            pcTransId: 0
          });
          dispatch(pettyCashActions.setSortedPettyCashAccount(selectedRow));
          dispatch(pettyCashActions.setSelectedPettyCashBrowseRow(selectedRow));
        }
      })
    );
  };

  return {
    filterState,
    selectedPettyCashAccountBrowse,
    selectedPersistPettyCashBrowseRow,
    pettyCashAccountBrowse,
    pettyCashFundingStatus,
    pettyCashFundingSource,
    isCancel,
    pettyCashBrowseStatus,
    selectedPettyCashFundingSource,
    pettyCashBrowseColumnDef: pettyCashBrowseColDef,
    pettyFundingSourceColumnDef: fundingSourceColDef,
    fundingSourceTableEnable,
    fundingSourceTableTitle,
    openFundSourceToPettyCashAccount,
    pettyCashAccountBrowseClose,
    setOpenFundSourceToPettyCashAccount,
    checkFundingSource,
    setFundingSourceTableEnable,
    setSelectedRow,
    cancelHandler,
    selectedRow,
    UpdateFundingSourceData,
    selectButtonDisabled,
    t
  };
};
