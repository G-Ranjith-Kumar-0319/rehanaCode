import GridTableNew, { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import { AppDispatch } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  NotificationStatus,
  Notification,
  DialogContent,
  DialogFooter,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import "./PettyCashAccountBrowse.scss";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { usNumberFormat } from "@/utils/getDataSource";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { useEffect } from "react";
import { pettyCashActions } from "../state/PettyCashList.slice";
import { usePettyCashAccountBrowse } from "./usePettyCashAccountBrowse";

type TPettyCashAccountBrowse = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  selectedRows?: (row: { [key: string]: any }) => void;
};

const PettyCashAccountBrowseModal = ({ setOpen, isOpen, selectedRows }: TPettyCashAccountBrowse) => {
  const {
    openFundSourceToPettyCashAccount,
    setOpenFundSourceToPettyCashAccount,
    checkFundingSource,
    setFundingSourceTableEnable,
    setSelectedRow,
    selectedRow,
    isCancel,
    cancelHandler,
    UpdateFundingSourceData,
    fundingSourceTableEnable,
    fundingSourceTableTitle,
    selectedPettyCashAccountBrowse,
    selectedPersistPettyCashBrowseRow,
    pettyCashAccountBrowse,
    pettyCashFundingStatus,
    pettyCashAccountBrowseClose,
    pettyCashFundingSource,
    pettyCashBrowseStatus,
    selectedPettyCashFundingSource,
    pettyCashBrowseColumnDef: pettyCashBrowseColDef,
    pettyFundingSourceColumnDef: fundingSourceColDef,
    selectButtonDisabled,
    t
  } = usePettyCashAccountBrowse();
  const dispatch = useDispatch<AppDispatch>();

  const setSelectedData = () => {
    if (selectedRows) {
      selectedRows(selectedRow);
      dispatch(pettyCashActions.setSelectedPettyCashBrowseRow(selectedRow));
    }
    setOpen(false);
  };
  useEffect(() => {
    if (pettyCashAccountBrowseClose) {
      setOpen(false);
    }
  }, [pettyCashAccountBrowseClose]);

  const CustomCell = ({ field, row }: cellRendererType) => {
    const getContent = () => {
      switch (field) {
        case "actions":
          return (
            <div className="center-button-cell">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Utility}
                onClick={() => setOpenFundSourceToPettyCashAccount(true)}
                className="custom-view-button"
              >
                {t("common.selectButton")}
              </Button>
            </div>
          );
        case "cash_in_hand":
          return <>{usNumberFormat(row?.cash_in_hand)}</>;
        case "unposted_exp":
          return <>{usNumberFormat(row?.unposted_exp)}</>;
        case "balance":
          return <>{usNumberFormat(row?.balance)}</>;
        default: {
          return <div />;
        }
      }
    };
    return getContent();
  };

  return (
    <>
      <Dialog
        dataTestId="test-id"
        escapeExits
        id="element-id"
        isOpen={isOpen}
        onClose={() => {
          setOpen(false);
          cancelHandler();
        }}
        returnFocusOnDeactivate
        title={t("pettyCashList.pettyCashBrowseTitle")}
        className="dialog__divider "
      >
        <DialogContent>
          <div className="pettycash-account">
            <GridTableNew
              onFocus={(e) => {
                const index = e.target?.id?.split("-")[2];
                const selectedRowIndex = pettyCashAccountBrowse.at(Number(index));
                if (!selectedRowIndex?.source_des) {
                  setFundingSourceTableEnable(true);
                  setSelectedRow(selectedRowIndex);
                  dispatch(pettyCashActions.setSelectedPettyCashBrowseRow(selectedRowIndex));
                }
              }}
              dataTestId="pettycash"
              selectedRow={selectedPersistPettyCashBrowseRow}
              dataSource={pettyCashAccountBrowse}
              isLoading={pettyCashBrowseStatus === STATUS.LOADING}
              customCell={CustomCell}
              columnDef={pettyCashBrowseColDef}
              selectedRowHandler={(row) => {
                if (isCancel) {
                  dispatch(pettyCashActions.setCancelButtonClicked(false));
                }
                checkFundingSource(row);
                setSelectedRow(row);
                // dispatch(pettyCashActions.setSelectedPettyCashBrowseRow(row));
                dispatch(pettyCashActions.setPersistPettyCashBrowseRow(row));
              }}
              onEnterKeyPress={() => {
                setOpen(false);
                if (selectedRows) selectedRows(selectedPettyCashAccountBrowse!);
              }}
              isScrollable
              enableScrollIntoView
            />
          </div>

          {fundingSourceTableEnable && (
            <div className="petty-cash-browse">
              <div className="mt-15">
                <Notification
                  actionElement={1}
                  dataTestId="warning-id"
                  escapeExits
                  hideCloseButton
                  status={NotificationStatus.WARNING}
                  title={t("pettyCashList.fundingSourceValidationError")}
                />
              </div>

              <div className="essui-form-label">{t("pettyCashList.fundingSourcePettyCashAccount")}</div>
              <div className="mt-15">{fundingSourceTableTitle}</div>

              <GridTableNew
                selectedRow={selectedPettyCashFundingSource}
                dataSource={pettyCashFundingSource}
                isLoading={pettyCashFundingStatus === STATUS.LOADING}
                customCell={CustomCell}
                columnDef={fundingSourceColDef}
                selectedRowHandler={(row) => {
                  dispatch(pettyCashActions.setSelectedPettyFundingSourceRow(row));
                }}
                isScrollable
              />
            </div>
          )}
        </DialogContent>
        <DialogFooter>
          <Grid
            className="mt-15"
            justify="space-between"
          >
            <GridItem
              sm={8}
              lg={6}
              md={4}
            >
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </GridItem>
            <GridItem
              sm={8}
              lg={6}
              md={4}
            >
              <div className="d-flex justify-end">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={() => {
                    setOpen(false);
                    cancelHandler();
                  }}
                >
                  {t("common.cancel")}
                </Button>
                &nbsp; &nbsp;
                <Button
                  size={ButtonSize.Small}
                  onClick={setSelectedData}
                  disabled={selectButtonDisabled}
                >
                  {t("common.selectButton")}
                </Button>
              </div>
            </GridItem>
          </Grid>
        </DialogFooter>
      </Dialog>
      <ConfirmModal
        className="funding-alert"
        isOpen={openFundSourceToPettyCashAccount}
        setOpen={setOpenFundSourceToPettyCashAccount}
        message={t("pettyCashList.fundingSourcePettyCashAccountModalMsg")}
        title={t("common.simsFMSModule")}
        confirm={UpdateFundingSourceData}
        callback={({ confirm }) => {
          if (!confirm) {
            // setIsSupplierDetailUndo(false);
          }
        }}
      />
    </>
  );
};
PettyCashAccountBrowseModal.defaultProps = {
  selectedRows: undefined
};
export default PettyCashAccountBrowseModal;
