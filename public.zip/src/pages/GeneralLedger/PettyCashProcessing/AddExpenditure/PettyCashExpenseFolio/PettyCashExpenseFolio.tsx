import {
  Button,
  ButtonColor,
  ButtonSize,
  DateInput,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  ISelectedItem,
  Loader,
  LoaderType,
  NotificationStatus,
  Textarea,
  TextInput,
  Tooltip
} from "@essnextgen/ui-kit";

import Input from "@/components/Input/Input";
import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import CostCentersModal from "@/shared/components/CostCenterModal/CostCenterModal";
import LedgerCodesModal from "@/shared/components/LedgerCodesModal/LedgerCodesModal";
import FundCodesModal from "@/shared/components/FundCodesModal/fundCodesModal";
import VatCodesModal from "@/shared/components/VatCodesModal/VatCodesModal";
import InvoiceFundCodesModal from "@/shared/components/FundCodesModal/InvoicefundCodesModal";
import InputDate from "@/shared/components/InputDate/InputDate";
import { dateSeparator } from "@/utils/constants";
import NumberInput from "@/components/NumberInput/NumberInput";
import { isDateInFinancialYear } from "@/utils/getDataSource";
import { ChangeEvent, useState } from "react";
import TextInputMask from "@/components/Input/InputMask";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import { METHOD, STATUS } from "@/types/UseStateType";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import usePettyCashExpenseFolio from "./usePettyCashExpenseFolio";

const PettyCashExpenseFolio = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const {
    expenseFolioDate,
    setValue,
    watch,
    costCenters,
    register,
    getValues,
    setIsOpenCostCenterModal,
    errors,
    ValidationTextLevel,
    onCostCentreChange,
    onCostCentreSelect,
    onCostCentrePending,
    isOpenCostCenterModal,
    FormProvider,
    formMethods,
    costCenterClick,
    ledgerCodeClick,
    isOpenLedgerCodesModal,
    setIsOpenLedgerCodesModal,
    onLedgerCodeSelect,
    ledgerCodes,
    onLedgerCodeChange,
    onLedgerCodePending,
    onFundCodeSelect,
    setIsOpenFundCodesModal,
    isDisabled,
    onFundCodeChange,
    fundCodes,
    onFundCodePending,
    fundCodeClick,
    isOpenFundCodesModal,
    setIsDisabled,
    vatCodes,
    onVatCodeSelect,
    setIsOpenVatCodesModal,
    vatCodeClick,
    onVatCodeChange,
    onVatCodePending,
    isOpenVatCodesModal,
    calculateVatAmount,
    trigger,
    clearErrors,
    setIsInCurrFinYr,
    isInCurrFinYr,
    getVatRegNoInputData,
    vatRegNoBlurEvent,
    isFutureDate,
    isVatAmtErr,
    onVatAmountChange,
    setOpenValidationModal,
    openValidationModal,
    vatRegInputValue,
    onSubmitHandler,
    saveExpenseFolioItemStatus,
    costCenterStatus,
    ledgerCodeStatus,
    navigateBack,
    transId,
    isVatRegNoErr,
    historyState
  } = usePettyCashExpenseFolio();

  return (
    <FormProvider {...formMethods}>
      <Layout
        pageTitle={
          historyState.lineItemMode === METHOD.EDIT
            ? t("pettyCashExpenseFolio.editpageTitle")
            : t("pettyCashExpenseFolio.pageTitle")
        }
        className="add--pety__cash--expense--folio"
      >
        <div className="selection-panel">
          {costCenterStatus === STATUS.LOADING ||
          ledgerCodeStatus === STATUS.LOADING ||
          saveExpenseFolioItemStatus === STATUS.LOADING ? (
            <Loader
              loaderType={LoaderType.Circular}
              loaderText="Loading..."
            />
          ) : null}
          <div className="mt-10">
            <Grid className="row-gap-8">
              <GridItem
                sm={4}
                md={12}
                lg={8}
                xl={8}
              >
                <Grid className="row-gap-8">
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={5}
                    xxl={5}
                  >
                    <div>
                      <div className="essui-form-label mb-5">{t("pettyCashExpenseFolio.folioNo")}</div>
                      <div className="height__equal--input">{getValues("pc_folio_no") ?? "-"}</div>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={5}
                    xxl={5}
                  >
                    <div>
                      <FormLabel
                        forId="txtReceiptDate"
                        className="mb-5"
                      >
                        {t("pettyCashExpenseFolio.receiptDate")}
                      </FormLabel>
                      <InputDate
                        autoFocus
                        id="txtReceiptDate"
                        className="margin-top"
                        searchable={false}
                        dateSeparator={dateSeparator.forwardSlash}
                        value={watch("receipt_date")}
                        inputRef={(e) => register("receipt_date").ref(e)}
                        name={register("receipt_date", { required: true }).name}
                        onChange={(e) => {
                          setValue("receipt_date", e.target.value);
                          trigger("receipt_date");
                          register("receipt_date").onChange(e);
                        }}
                        onDateChange={(date) => {
                          setValue("receipt_date", date);
                          const isInFinancialYear = isDateInFinancialYear(date);
                          const futureDate = isFutureDate(date);
                          setIsInCurrFinYr(!isInFinancialYear || futureDate);
                        }}
                        validationTextLevel={isInCurrFinYr ? ValidationTextLevel.Error : undefined}
                      />
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={5}
                    xxl={5}
                  >
                    <div>
                      <FormLabel
                        className="mb-5"
                        forId="txtCostCentre"
                      >
                        {t("pettyCashExpenseFolio.costCentre")}
                      </FormLabel>
                      <Grid className="">
                        <GridItem
                          sm={1}
                          md={2}
                          lg={3}
                          xl={3}
                          xxl={3}
                          className="pr-8"
                        >
                          <Input
                            isLabel={false}
                            maxLength={100}
                            value={watch("cost_code")}
                            searchable
                            searchItems={costCenters?.map((b) => ({ text: b.code, value: b.code }))}
                            inputRef={(e) => register("cost_code").ref(e)}
                            name={register("cost_code", { required: true }).name}
                            onChange={(e) => onCostCentreChange(e)}
                            onBlur={(e: any) => {
                              register("cost_code").onBlur(e);
                            }}
                            onSelect={(selectedItem: ISelectedItem | undefined) => onCostCentreSelect(selectedItem)}
                            onPending={(selectedItem: ISelectedItem | undefined) => onCostCentrePending(selectedItem)}
                            onNoSelection={() => setIsOpenCostCenterModal(true)}
                            validationTextLevel={errors.cost_code ? ValidationTextLevel.Error : undefined}
                          />
                        </GridItem>
                        <GridItem
                          sm={3}
                          md={10}
                          lg={9}
                          xl={9}
                          xxl={9}
                          className="pl-0"
                        >
                          <div className="d-flex align-center">
                            <Tooltip content={watch("cost_des")}>
                              <div className="essui-textinput essui-textinput--medium read-only mr-8 input__calc--width wrap-input-data">
                                {watch("cost_des")}
                              </div>
                            </Tooltip>

                            <Button
                              color={ButtonColor.Secondary}
                              onClick={costCenterClick}
                              size={ButtonSize.Small}
                              className="essui-button-icon-only--small"
                            >
                              <Icon
                                color={IconColor.Primary500}
                                size={IconSize.Medium}
                                name="search"
                              />
                            </Button>
                          </div>
                        </GridItem>
                      </Grid>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={5}
                    xxl={5}
                  >
                    <div>
                      <FormLabel
                        className="mb-5"
                        forId="txtLedgerCode"
                      >
                        {t("pettyCashExpenseFolio.ledgerCode")}
                      </FormLabel>
                      <Grid className="">
                        <GridItem
                          sm={1}
                          md={2}
                          lg={3}
                          xl={3}
                          xxl={3}
                          className="pr-8"
                        >
                          <Input
                            onSelect={(selectedItem) => {
                              onLedgerCodeSelect(selectedItem);
                            }}
                            onNoSelection={() => setIsOpenLedgerCodesModal(true)}
                            isLabel={false}
                            maxLength={100}
                            value={watch("ledger_code")}
                            searchable
                            searchItems={ledgerCodes.map((b) => ({ text: b.code, value: b.code }))}
                            inputRef={(e) => register("ledger_code").ref(e)}
                            name={register("ledger_code", { required: true }).name}
                            onBlur={(e) => register("ledger_code").onBlur(e)}
                            onChange={(e) => {
                              onLedgerCodeChange(e);
                            }}
                            onPending={(selectedItem: ISelectedItem | undefined) => {
                              onLedgerCodePending(selectedItem);
                            }}
                            validationTextLevel={errors.ledger_code ? ValidationTextLevel.Error : undefined}
                          />
                        </GridItem>
                        <GridItem
                          sm={3}
                          md={10}
                          lg={9}
                          xl={9}
                          xxl={9}
                          className="pl-0"
                        >
                          <div className="d-flex align-center">
                            <Tooltip content={getValues("ledger_des")}>
                              <div className="read-only essui-textinput essui-textinput--medium mr-8 input__calc--width wrap-input-data">
                                {watch("ledger_des")}
                              </div>
                            </Tooltip>

                            <Button
                              color={ButtonColor.Secondary}
                              onClick={ledgerCodeClick}
                              size={ButtonSize.Small}
                              className="essui-button-icon-only--small"
                            >
                              <Icon
                                color={IconColor.Primary500}
                                size={IconSize.Medium}
                                name="search"
                              />
                            </Button>
                          </div>
                        </GridItem>
                      </Grid>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={5}
                    xxl={5}
                  >
                    <div>
                      <FormLabel
                        className="mb-5"
                        forId="txtFund"
                      >
                        {t("pettyCashExpenseFolio.fund")}
                      </FormLabel>
                      <Grid className="">
                        <GridItem
                          sm={1}
                          md={2}
                          lg={3}
                          xl={3}
                          xxl={3}
                          className="pr-8"
                        >
                          <Input
                            onSelect={(selectedItem) => {
                              onFundCodeSelect(selectedItem);
                            }}
                            onNoSelection={() => setIsOpenFundCodesModal(true)}
                            isLabel={false}
                            maxLength={100}
                            value={watch("fund_code")}
                            searchable
                            disabled={isDisabled || watch("ledger_code") === ""}
                            searchItems={fundCodes?.map((b) => ({ text: b.code, value: b.code }))}
                            inputRef={(e) => register("fund_code").ref(e)}
                            name={register("fund_code", { required: true }).name}
                            onBlur={(e) => register("fund_code").onBlur(e)}
                            onChange={(e) => {
                              onFundCodeChange(e);
                            }}
                            onPending={(selectedItem: ISelectedItem | undefined) => {
                              onFundCodePending(selectedItem);
                            }}
                            validationTextLevel={errors.fund_code ? ValidationTextLevel.Error : undefined}
                          />
                        </GridItem>
                        <GridItem
                          sm={3}
                          md={10}
                          lg={9}
                          xl={9}
                          xxl={9}
                          className="pl-0"
                        >
                          <div className="d-flex align-center">
                            <Tooltip content={getValues("fund_des")}>
                              <div
                                className={`${
                                  isDisabled ? "disabled-input" : null
                                } read-only essui-textinput essui-textinput--medium  mr-8 input__calc--width wrap-input-data`}
                              >
                                {watch("fund_des")}
                              </div>
                            </Tooltip>

                            <Button
                              color={ButtonColor.Secondary}
                              onClick={fundCodeClick}
                              size={ButtonSize.Small}
                              className={`essui-button-icon-only--small btnclass ${
                                isDisabled || watch("ledger_code") === "" ? "disabled" : null
                              }`}
                              disabled={isDisabled || watch("ledger_code") === ""}
                            >
                              <Icon
                                color={IconColor.Primary500}
                                size={IconSize.Medium}
                                name="search"
                              />
                            </Button>
                          </div>
                        </GridItem>
                      </Grid>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={4}
                    lg={6}
                    xl={5}
                    xxl={5}
                  >
                    <div className="vat-registration--number">
                      <FormLabel
                        forId="txtVATRegistration"
                        className="mb-5"
                      >
                        {t("pettyCashExpenseFolio.vatRegNo")}
                      </FormLabel>
                      <TextInputMask
                        {...register("vat_reg_no")}
                        className={`essui-textinput essui-textinput--medium ${
                          isVatRegNoErr ? "essui-textinput--error" : ""
                        }`}
                        maskId="vatRegNo"
                        maskType="tel"
                        maskElement="999-9999-99"
                        maskChar=" "
                        value={vatRegInputValue}
                        inputRef={(e) => register("vat_reg_no").ref(e)}
                        onChange={getVatRegNoInputData}
                        onBlur={() => {
                          trigger("vat_reg_no");
                          vatRegNoBlurEvent();
                        }}
                      />
                    </div>
                  </GridItem>
                </Grid>
              </GridItem>
              <GridItem
                sm={4}
                md={12}
                lg={4}
                xl={4}
                className="border-left"
              >
                <Grid>
                  <GridItem
                    sm={4}
                    md={12}
                    lg={12}
                    xl={12}
                  >
                    <FormLabel className="essui-global-typography-default-subtitle">
                      {t("pettyCashExpenseFolio.budgetRemaining")}
                    </FormLabel>
                  </GridItem>
                  <GridItem
                    sm={2}
                    md={4}
                    lg={12}
                    xl={12}
                  >
                    <div className="mt-16">
                      <FormLabel forId="costCentre">{t("pettyCashExpenseFolio.costCentre")}</FormLabel>
                      <div className="mt-8">{watch("cost_budget") ? watch("cost_budget") : "0.00"}</div>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={2}
                    md={4}
                    lg={12}
                    xl={12}
                  >
                    <div className="mt-16">
                      <FormLabel forId="combination">{t("pettyCashExpenseFolio.combination")}</FormLabel>
                      <div className="mt-8">{watch("combination") ? watch("combination") : "0.00"}</div>
                    </div>
                  </GridItem>
                </Grid>
              </GridItem>
            </Grid>
            <Grid className="row-gap-8 mt-8">
              <GridItem
                sm={4}
                md={8}
                lg={8}
                xl={8}
                xxl={8}
              >
                <div className="desc-fullwidth-input">
                  <FormLabel
                    forId="txtDescription"
                    className="mb-5"
                  >
                    {t("pettyCashExpenseFolio.description")}
                  </FormLabel>

                  <Textarea
                    {...register("description", { required: true })}
                    id="txtDescription"
                    rows={6}
                    className="width-100 min-w-100"
                    maxLength={80}
                    value={watch("description")}
                    onChange={(e) => {
                      setValue("description", e.target.value.trim());
                      if (e.target.value.trim()) {
                        clearErrors("description");
                      } else {
                        trigger("description");
                      }
                    }}
                    validationTextLevel={errors.description ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
            </Grid>
            <Grid className="row-gap-8">
              <GridItem
                sm={4}
                md={3}
                lg={3}
                xl={3}
                xxl={3}
              >
                <div>
                  <FormLabel
                    forId="txtTotalIncVat"
                    className="mb-5"
                  >
                    {t("pettyCashExpenseFolio.totalIncVat")}
                  </FormLabel>
                  <NumberInput
                    id="txtTotalIncVat"
                    defaultValue={watch("total_inc_vat") ?? "0.00"}
                    decimals={2}
                    maxLength={6}
                    name={register("total_inc_vat", { required: true }).name}
                    inputRef={(e) => register("total_inc_vat").ref(e)}
                    onChange={(e) => {
                      if (e.target.value !== "0.00") {
                        setValue("total_inc_vat", e.target.value);
                        register("total_inc_vat").onChange(e);
                      } else {
                        setValue("total_inc_vat", "");
                        register("total_inc_vat").onChange(e);
                      }
                    }}
                    onBlur={() => {
                      calculateVatAmount();
                      trigger("total_inc_vat");
                    }}
                    validationTextLevel={errors.total_inc_vat ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={3}
                lg={3}
                xl={3}
                xxl={3}
              >
                <div>
                  <FormLabel
                    className="mb-5"
                    forId="txtVatCode"
                  >
                    {t("pettyCashExpenseFolio.vatCode")}
                  </FormLabel>
                  <Grid className="">
                    <GridItem
                      sm={1}
                      md={2}
                      lg={3}
                      xl={3}
                      xxl={3}
                      className="pr-8"
                    >
                      <Input
                        onSelect={(selectedItem) => {
                          onVatCodeSelect(selectedItem);
                        }}
                        onNoSelection={() => setIsOpenVatCodesModal(true)}
                        isLabel={false}
                        maxLength={100}
                        value={watch("vat_code")}
                        searchable
                        searchItems={vatCodes.map((b) => ({ text: b.vat_code, value: b.vat_code }))}
                        inputRef={(e) => {
                          register("vat_code").ref(e);
                        }}
                        name={register("vat_code", { required: true }).name}
                        onBlur={(e) => register("vat_code").onBlur(e)}
                        validationTextLevel={errors.vat_code ? ValidationTextLevel.Error : undefined}
                        onChange={(e) => onVatCodeChange(e)}
                        onPending={(selectedItem) => {
                          onVatCodePending(selectedItem);
                        }}
                      />
                    </GridItem>
                    <GridItem
                      sm={3}
                      md={10}
                      lg={9}
                      xl={9}
                      xxl={9}
                      className="pl-0"
                    >
                      <div className="d-flex align-center">
                        <Tooltip content={getValues("vat_des")}>
                          <div className="read-only essui-textinput essui-textinput--medium  mr-8 input__calc--width wrap-input-data">
                            {getValues("vat_des")}
                          </div>
                        </Tooltip>
                        <Button
                          color={ButtonColor.Secondary}
                          onClick={vatCodeClick}
                          size={ButtonSize.Small}
                          className="essui-button-icon-only--small btncls"
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="search"
                          />
                        </Button>
                      </div>
                    </GridItem>
                  </Grid>
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
                xxl={2}
              >
                <div>
                  <FormLabel
                    forId="txtAmountVat"
                    className="mb-5"
                  >
                    {t("pettyCashExpenseFolio.amountOfVat")}
                  </FormLabel>
                  <NumberInput
                    className="w-100"
                    defaultValue={watch("vat_amount") ?? "0.00"}
                    decimals={2}
                    maxLength={6}
                    id="txtAmountVat"
                    name={register("vat_amount").name}
                    inputRef={(e) => register("vat_amount").ref(e)}
                    onChange={(e) => {
                      setValue("vat_amount", e.target.value);
                      register("vat_amount").onChange(e);
                      trigger("vat_amount");
                    }}
                    onBlur={onVatAmountChange}
                    validationTextLevel={isVatAmtErr ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
                xxl={2}
              >
                <div>
                  <div className="essui-form-label mb-5">{t("pettyCashExpenseFolio.totalExcvat")}</div>
                  <div className="height__equal--input">{getValues("total_exc_vat") ?? "0.00"}</div>
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
                xxl={2}
              >
                <div>
                  <div className="essui-form-label mb-5">{t("pettyCashExpenseFolio.costToEstd")}</div>
                  <div className="height__equal--input">{getValues("cost_to_establishment") ?? "0.00"}</div>
                </div>
              </GridItem>
            </Grid>
            <Grid>
              <GridItem
                sm={2}
                md={4}
                lg={6}
                xl={6}
              >
                <div>
                  <HelpButton
                    identifier="testIdentifier"
                    labelName={t("common.help")}
                  />
                </div>
              </GridItem>
              <GridItem
                sm={2}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="rightbtn">
                  <Button
                    id="add-expense-folio-btn-save"
                    size={ButtonSize.Small}
                    color={ButtonColor.Primary}
                    onClick={() => onSubmitHandler()}
                  >
                    {t("common.save")}
                  </Button>
                  <Button
                    id="add-expense-folio-btn-cancel"
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    onClick={() => {
                      navigateBack(Number(transId));
                    }}
                  >
                    {t("common.cancel")}
                  </Button>
                </div>
              </GridItem>
            </Grid>
          </div>
        </div>
      </Layout>
      {/* )} */}
      <CostCentersModal
        isOpen={isOpenCostCenterModal}
        setOpen={setIsOpenCostCenterModal}
        headerTitle={t("pettyCashExpenseFolio.costCentreModalHeader")}
      />
      <LedgerCodesModal
        isOpen={isOpenLedgerCodesModal}
        setOpen={setIsOpenLedgerCodesModal}
        headerTitle={t("pettyCashExpenseFolio.ledgerCodeModalHeader")}
      />
      <FundCodesModal
        isOpen={isOpenFundCodesModal}
        setOpen={setIsOpenFundCodesModal}
        setIsDisabled={setIsDisabled}
        headerTitle={t("pettyCashExpenseFolio.fundCodeModalHeader")}
      />
      <VatCodesModal
        isOpen={isOpenVatCodesModal}
        setOpen={setIsOpenVatCodesModal}
        headerTitle={t("pettyCashExpenseFolio.vatCodeModalHeader")}
      />
      <AlertModal
        isOpen={openValidationModal}
        setOpen={setOpenValidationModal}
        title={t("alertMessage.title")}
        notificationType={NotificationStatus.ERROR}
        message={t("common.invalidData")}
      />
    </FormProvider>
  );
};

export default PettyCashExpenseFolio;
