import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  TextInput
} from "@essnextgen/ui-kit";

const AddExpenditure = () => (
  <>
    <Layout
      pageTitle="Add Expenditure"
      className=""
      isBreadcrumbRequired
    >
      <Grid className="row-gap-16">
        <GridItem
          lg={3}
          xl={3}
          md={4}
          sm={4}
        >
          <div>
            <div className="essui-form-label">Petty Cash Account</div>
            <div className="mt-8">Petty Cash</div>
          </div>
        </GridItem>
        <GridItem
          lg={3}
          xl={3}
          md={4}
          sm={4}
        >
          <div>
            <div className="essui-form-label">Cash In Hand</div>
            <div className="mt-8">220.00</div>
          </div>
        </GridItem>
        <GridItem
          lg={3}
          xl={3}
          md={4}
          sm={4}
        >
          <div>
            <div className="essui-form-label">Unposted Expenditure</div>
            <div className="mt-8">1.00</div>
          </div>
        </GridItem>
      </Grid>
    </Layout>

    <Layout
      className=""
      isBreadcrumbRequired={false}
    >
      <Grid className="row-gap-16">
        <GridItem
          lg={2}
          xl={2}
          sm={4}
        >
          <div>
            <div className="essui-form-label">Transaction Number</div>
            <div className="mt-8">#0002475</div>
          </div>
        </GridItem>
        <GridItem
          lg={4}
          xl={4}
          sm={4}
        >
          <div>
            <FormLabel forId="txtPettyCash">Petty Cash Book</FormLabel>
            <Grid className="">
              <GridItem
                lg={4}
                md={2}
                sm={1}
                xl={4}
                xxl={4}
                className="pr-8"
              >
                <Input
                  value="PC22"
                  searchable
                  id="txtPettyCash"
                />
              </GridItem>
              <GridItem
                lg={8}
                md={6}
                sm={3}
                xl={8}
                xxl={8}
                className="pl-0"
              >
                <Input
                  value="1 to 500"
                  className="read-only"
                  button={
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      aria-label="search"
                      className="essui-button-icon-only--small"
                    >
                      <Icon
                        color={IconColor.Primary500}
                        size={IconSize.Medium}
                        name="search"
                      />
                    </Button>
                  }
                  searchable
                  readOnly
                />
              </GridItem>
            </Grid>
          </div>
        </GridItem>
      </Grid>
    </Layout>

    <Layout
      className=""
      isBreadcrumbRequired={false}
    >
      <Grid className="row-gap-16">
        <GridItem
          lg={4}
          xl={4}
          md={4}
          sm={4}
        >
          <div>
            <div className="essui-form-label">Cost Centre</div>
            <div className="mt-8">190 Staff Development</div>
          </div>
        </GridItem>
        <GridItem
          lg={4}
          xl={4}
          md={4}
          sm={4}
        >
          <div>
            <div className="essui-form-label">Ledger Code</div>
            <div className="mt-8">134 01 Staff Travel</div>
          </div>
        </GridItem>
        <GridItem
          lg={2}
          xl={2}
          md={4}
          sm={4}
        >
          <div>
            <FormLabel forId="txtFolio">1 folio(s)</FormLabel>
            <TextInput
              id="txtFolio"
              value="View Posting Details"
              disabled
            />
          </div>
        </GridItem>
      </Grid>
    </Layout>

    <Layout
      className=""
      isBreadcrumbRequired={false}
    >
      <Grid className="mb-8">
        <GridItem sm={4}>
          <div className="essui-global-typography-default-subtitle">Transaction Totals</div>
        </GridItem>
      </Grid>
      <Grid className="row-gap-16">
        <GridItem
          lg={4}
          xl={4}
          md={4}
          sm={4}
        >
          <div>
            <div className="essui-form-label">Exc. VAT</div>
            <div className="mt-8">0.83</div>
          </div>
        </GridItem>
        <GridItem
          lg={4}
          xl={4}
          md={4}
          sm={4}
        >
          <div>
            <div className="essui-form-label">VAT</div>
            <div className="mt-8">0.00</div>
          </div>
        </GridItem>
        <GridItem
          lg={2}
          xl={2}
          md={4}
          sm={4}
        >
          <div>
            <div className="essui-form-label">Inc. VAT</div>
            <div className="mt-8">1.00</div>
          </div>
        </GridItem>
      </Grid>
    </Layout>

    <Layout
      isBreadcrumbRequired={false}
      className=""
    >
      <Grid>
        <GridItem
          sm={6}
          md={{
            offset: 2,
            span: 6
          }}
          lg={{
            offset: 6,
            span: 6
          }}
          xl={{
            offset: 6,
            span: 6
          }}
        >
          <div className="d-flex gap-8 justify-end flex-wrap">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              disabled
            >
              View Original
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
              disabled
            >
              View Adjustment
            </Button>
          </div>
        </GridItem>
      </Grid>
    </Layout>
  </>
);

export default AddExpenditure;
