import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  IPaginationProps,
  Icon,
  IconColor,
  IconSize,
  Loader,
  LoaderType,
  NotificationStatus,
  Pagination
} from "@essnextgen/ui-kit";
import Layout from "@/components/Layout/Layout";

import Input from "@/components/Input/Input";
import "./Style.scss";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import {
  getCurrentFinancialYear,
  METHOD,
  PC_TRANSACTION_TYPE,
  PETTY_CASH_TRANS_STATUS,
  STATUS
} from "@/types/UseStateType";
import { usNumberFormat } from "@/utils/getDataSource";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useHistory } from "react-router-dom";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import CustomCell from "./Grid/CustomCell";
import {
  deletePettyCashTranscation,
  getPettyCashAccountBrowse,
  getPettyCashList,
  pettyCashActions,
  printPettyCashTranscation
} from "../state/PettyCashList.slice";
import PettyCashFilters from "./Grid/PettyCashFilters";
import PettyCashAccountBrowseModal1 from "../PettyCashAccountBrowse/PettyCashAccountBrowse";
import PettyCashToolbar from "../PettyCashToolbar";
import PettyCashPageToolbar from "../PettyCashPageToolbar";
import SelectTransactionTypeModal from "../SelectTransactionTypeModal/SelectTransactionTypeModal";
import { getUnpostedTransId, expenditureActions } from "../state/ViewExpenditure.slice";
import { actions as pettyCashOpenBookActions } from "../state/PettyCashOpenBook.slice";
import { actions as reimburAction } from "../state/ViewReimbursement.slice";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];

const PettyCashList = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [lookingFor, setLookingFor] = useState<string | undefined>(undefined);
  const [openPettyCashBrowse, setOpenPettyCashBrowse] = useState<boolean>(false);
  const [selectPettyCash, setSelectPettyCash] = useState<boolean>(false);
  const [onChangePrevRecord, setOnChangePrevRecord] = useState<boolean>(false);
  const [pettyCashBrowseRowData, setPettyCashBrowseRowData] = useState<any>();
  const [cashInHand, setCashInHand] = useState<any>();
  const [unpostExp, setUnpostExp] = useState<any>();
  const [pettyCashAccount, setPettyCashAccount] = useState<any>();
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<string>("");
  const [openAlertModal, setOpenAlertModal] = useState<boolean>(false);
  const dispatch = useDispatch<AppDispatch>();
  const pDataTestId = "pettyCashListGrid";
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;
  const {
    selectedPettyCashRow,
    selectedPettyCashUndoRow,
    filterState,
    pettyCashApiStatus,
    selectedPettyCashAccountBrowse,
    conlumnDef: pCColumnDef,
    pettyCashList,
    sortedPettyCashAccount,
    printPettyCashStatus,
    deletePettyCashStatus,
    pettyCashList: { pageSize, currentPage, totalPages, pettyCashTransaction },
    isFocus
  } = useAppSelector((state) => state.pettyCashList);
  const history = useHistory();
  const { pCashViewSelected } = useAppSelector((state) => state.pettyCashList);
  const [isSelectModalOpen, setIsSelectModalOpen] = useState<boolean>(false);
  const [isLoaderOn, setIsLoaderOn] = useState<boolean>(false);

  const selectPettyCashBrowseModal = (row: any) => {
    dispatch(pettyCashActions.setSelectedPettyCashUndoRow(undefined));
    setPettyCashBrowseRowData(row);
    setSelectPettyCash(true);
    dispatch(
      pettyCashActions.setFilters({
        pageNumber: 1,
        pcTransId: 0
      })
    );
  };
  const UNPOSTED = {
    Unposted_Exp: "Unposted Expenditure"
  };
  useEffect(() => {
    dispatch(getPettyCashAccountBrowse());
    dispatch(
      pettyCashActions.setFilters({
        pageNumber: 1
      })
    );
  }, []);

  useEffect(() => {
    setCashInHand(usNumberFormat(sortedPettyCashAccount?.cash_in_hand));
    setUnpostExp(usNumberFormat(sortedPettyCashAccount?.unposted_exp));
    setPettyCashAccount(sortedPettyCashAccount?.pc_acc_des);
  }, [sortedPettyCashAccount]);

  useEffect(() => {
    setCashInHand(usNumberFormat(selectedPettyCashAccountBrowse?.cash_in_hand));
    setUnpostExp(usNumberFormat(selectedPettyCashAccountBrowse?.unposted_exp));
  }, [selectedPettyCashAccountBrowse]);

  const onChangeHandler = (page: number) => {
    dispatch(
      pettyCashActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(pageSize),
        highlightPcTransId: undefined,
        pcTransId: 0
      })
    );
  };

  useEffect(() => {
    if (onChangePrevRecord) {
      dispatch(
        pettyCashActions.setFilters({
          ...filterState,
          lookingFor: "",
          pageNumber: currentPage - 1,
          pageSize: String(pageSize),
          highlightPcTransId: undefined,
          pcTransId: 0
        })
      );
    }
  }, [onChangePrevRecord]);

  useEffect(() => {
    if (pettyCashBrowseRowData?.pc_account_id || sortedPettyCashAccount) {
      clearHistoryState();
      dispatch(
        getPettyCashList({
          ...filterState,
          pcAccountId: pettyCashBrowseRowData?.pc_account_id ?? selectedPettyCashAccountBrowse?.pc_account_id,
          callback: (data) => {
            if (data && (selectPettyCash || onChangePrevRecord)) {
              setSelectPettyCash(false);
              setOnChangePrevRecord(false);
              const row = (data?.pettyCashTransaction as { [key: string]: any }[])?.at(
                data?.pettyCashTransaction.length - 1
              ); // at is not a function}
              dispatch(pettyCashActions.setSelectedPettyCashRow(row));
              dispatch(pettyCashOpenBookActions.resetSelectedRow());
              dispatch(expenditureActions.resetExpenditureDetails());
            }
          }
        })
      );
      setCashInHand(usNumberFormat(selectedPettyCashAccountBrowse?.cash_in_hand));
      setUnpostExp(usNumberFormat(selectedPettyCashAccountBrowse?.unposted_exp));
      setPettyCashAccount(selectedPettyCashAccountBrowse?.pc_acc_des);
    }
  }, [filterState, sortedPettyCashAccount]);

  useEffect(() => {
    if (lookingFor !== filterState?.lookingFor && lookingFor !== undefined) {
      dispatch(pettyCashActions.setFilters({ lookingFor, highlightPcTransId: undefined }));
    }
  }, [lookingFor, filterState?.lookingFor]);

  const goToRecord = (row: any) => {
    dispatch(pettyCashActions.setSelectedPettyCashRow(row));
    dispatch(pettyCashActions.setSelectedPettyCashUndoRow(row));
    dispatch(pettyCashActions.setFilters({ highlightPcTransId: row?.id }));
    if (row?.trans_type === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/view-reimbursement/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    } else if (row?.status === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/edit-expenditure/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          mode: METHOD.EDIT,
          selectedRowState: row,
          headerData: pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse,
          isDirty: false
        }
      });
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    }
  };

  const onRowSelect: (row?: RowType | undefined) => void = (row) => {
    if (pettyCashApiStatus === STATUS.SUCCESS) {
      dispatch(pettyCashActions.setSelectedPettyCashRow(row));
    }
  };

  const clearHistoryState = () => {
    history.replace({ ...history.location, state: undefined });
  };

  const getSelectedTransType = () => {
    if (filterState?.view === "A" && selectedPettyCashRow) {
      return selectedPettyCashRow?.trans_type
        ? t("pettyCashList.expenditureHighlighted")
        : t("pettyCashList.reimbursementHighlighted");
    }
    return "";
  };

  const goToAdd = () => {
    dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(undefined));
    if (pCashViewSelected?.value === PC_TRANSACTION_TYPE.REIMBURSEMENT) {
      const addReimbursementData = {
        pettyCashAccountsHidden: undefined,
        pettyCashTransaction: undefined
      };
      dispatch(reimburAction.setReimbursementDetails(addReimbursementData));
      history.push({
        pathname: `/general-ledger/petty-cash/add-reimbursement`,
        state: {
          mode: "add",
          headerData: pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse
        }
      });
    } else if (pCashViewSelected?.value === PC_TRANSACTION_TYPE.EXPENDITURE) {
      checkForUnpostedExp();
    } else {
      setIsSelectModalOpen(true);
    }
  };
  const checkForUnpostedExp = () => {
    dispatch(expenditureActions.resetExpenditureDetails());
    setIsLoaderOn(true);
    const pAccountData = pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse;
    dispatch(
      getUnpostedTransId({
        pcAccountId: selectedPettyCashAccountBrowse?.pc_account_id,
        callback: (data) => {
          setIsLoaderOn(false);
          if (data?.at_pc_trans_id > 0) {
            history.push({
              pathname: `/general-ledger/petty-cash/edit-expenditure/${pAccountData?.pc_account_id}/${data?.at_pc_trans_id}`,
              state: {
                mode: METHOD.EDIT,
                headerData: pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse
              }
            });
          } else {
            history.push({
              pathname: `/general-ledger/petty-cash/add-expenditure/${pAccountData?.pc_account_id}/${data?.at_pc_trans_id}`,
              state: {
                mode: METHOD.ADD,
                headerData: pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse
              }
            });
          }
        }
      })
    );
  };
  const selectPrevRecord = () => {
    if (selectedPettyCashRow && pettyCashTransaction) {
      const indexNo = pettyCashTransaction.indexOf(selectedPettyCashRow);
      const index = indexNo !== 0 ? indexNo - 1 : 0;
      document.getElementById(getIndex(pDataTestId, index))?.focus();
      if (indexNo > 0) {
        dispatch(pettyCashActions.setSelectedPettyCashRow(pettyCashTransaction[indexNo - 1]));
      } else if (currentPage > 1) {
        setOnChangePrevRecord(true);
      }
    }
  };

  const selectNextRecord = () => {
    if (selectedPettyCashRow && pettyCashTransaction) {
      const indexNo = pettyCashTransaction.indexOf(selectedPettyCashRow);
      const index = pettyCashTransaction.length - 1 > indexNo ? indexNo + 1 : pettyCashTransaction.length - 1;
      document.getElementById(getIndex(pDataTestId, index))?.focus();
      if (indexNo < pettyCashTransaction.length - 1) {
        dispatch(pettyCashActions.setSelectedPettyCashRow(pettyCashTransaction[indexNo + 1]));
      } else if (currentPage < totalPages) {
        onChangeHandler(currentPage + 1);
      }
    }
  };

  const navigateToViewPage = () => {
    if (selectedPettyCashRow?.trans_type === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/view-reimbursement/${selectedPettyCashRow?.pc_account_id}/${selectedPettyCashRow?.pc_trans_id}`,
        state: {
          selectedRowState: selectedPettyCashRow,
          isDirty: false
        }
      });
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${selectedPettyCashRow?.pc_account_id}/${selectedPettyCashRow?.pc_trans_id}`,
        state: {
          selectedRowState: selectedPettyCashRow,
          isDirty: false
        }
      });
    }
  };
  const onFocusClickHandler = () => {
    dispatch(pettyCashActions.setSelectedPettyCashUndoRow(selectedPettyCashRow));
    dispatch(pettyCashActions.setIsFocus(true));
    navigateToViewPage();
  };
  const onDelete = () => {
    setIsDeleteModalOpen(true);
  };
  const deleteRecord = () => {
    dispatch(
      deletePettyCashTranscation({
        pcTransId: selectedPettyCashRow?.pc_trans_id ?? 0,
        callback: () => {
          dispatch(
            pettyCashActions.setFilters({
              pageNumber: 1,
              pcAccountId: selectedPettyCashAccountBrowse?.pc_account_id,
              pcTransId: 0
            })
          );
          dispatch(getPettyCashAccountBrowse());
          setCashInHand(usNumberFormat(selectedPettyCashAccountBrowse?.cash_in_hand));
          setUnpostExp(usNumberFormat(selectedPettyCashAccountBrowse?.unposted_exp));
        }
      })
    );
  };
  const undoChangeHandler = () => {
    let row;
    if (selectedPettyCashUndoRow) {
      row = ((pettyCashList?.pettyCashTransaction as { [key: string]: any }[]) || [])
        ?.filter((p) => p.pc_trans_id === selectedPettyCashUndoRow?.pc_trans_id)
        .at(0);
    } else {
      row = pettyCashList?.pettyCashTransaction[0];
    }

    dispatch(pettyCashActions.setSelectedPettyCashRow(row));
  };

  const printButtonHandler = async () => {
    const { payload } = await dispatch(
      printPettyCashTranscation({
        accountid: selectedPettyCashRow?.pc_account_id ?? 0,
        transno: selectedPettyCashRow?.trans_no,
        yearId: getCurrentFinancialYear()
      })
    );
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName || t("pettyCash.fileName");
    link.click();
  };
  const adjustTransHandler = () => {
    if (selectedPettyCashRow?.trans_type === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/adjust-reimbursement/${selectedPettyCashRow?.pc_account_id}/${selectedPettyCashRow?.pc_trans_id}`,
        state: {
          headerData: pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse,
          selectedRowState: selectedPettyCashRow,
          isAdjust: true
        }
      });
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/adjust-expenditure/${selectedPettyCashRow?.pc_account_id}/${selectedPettyCashRow?.pc_trans_id}`,
        state: {
          headerData: pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse,
          selectedRowState: selectedPettyCashRow,
          mode: METHOD.ADJUST
        }
      });
    }
  };

  const isPostDisabled = () => {
    if (
      selectedPettyCashRow?.trans_type !== 0 &&
      selectedPettyCashRow?.status === PETTY_CASH_TRANS_STATUS.UNPOSTED &&
      selectedPettyCashRow?.foliocount > 0
    ) {
      return false;
    }
    return true;
  };

  const isCancelDisabled = () =>
    !(
      selectedPettyCashRow?.status === PETTY_CASH_TRANS_STATUS.NORMAL ||
      selectedPettyCashRow?.status === PETTY_CASH_TRANS_STATUS.ADJUST ||
      selectedPettyCashRow?.status === PETTY_CASH_TRANS_STATUS.ADJUST_OF_ADJUST
    );

  const isAdjustTransDisabled = () => {
    if (selectedPettyCashRow?.trans_type === 0) {
      return !(
        !selectedPettyCashRow?.cheque_book_id &&
        (selectedPettyCashRow.status === PETTY_CASH_TRANS_STATUS.NORMAL ||
          selectedPettyCashRow.status === PETTY_CASH_TRANS_STATUS.ADJUST ||
          selectedPettyCashRow.status === PETTY_CASH_TRANS_STATUS.ADJUST_OF_ADJUST)
      );
    }
    return !(
      selectedPettyCashRow?.status === PETTY_CASH_TRANS_STATUS.NORMAL ||
      selectedPettyCashRow?.status === PETTY_CASH_TRANS_STATUS.ADJUST ||
      selectedPettyCashRow?.status === PETTY_CASH_TRANS_STATUS.ADJUST_OF_ADJUST
    );
  };

  const postTransHandler = () => {
    if (selectedPettyCashRow?.trans_type !== 0 && selectedPettyCashRow?.status === PETTY_CASH_TRANS_STATUS.UNPOSTED) {
      const overDrawn =
        Number(selectedPettyCashAccountBrowse?.unposted_exp) - Number(selectedPettyCashAccountBrowse?.cash_in_hand);
      if (overDrawn > 0) {
        setOpenAlertModal(true);
        const message = `${selectedPettyCashAccountBrowse?.pc_acc_des} ${t(
          "viewExpenditure.overDrawnError"
        )} ${usNumberFormat(overDrawn)}`;
        setAlertMessage(message);
      } else {
        history.push({
          pathname: `/general-ledger/petty-cash/add-posting-details/${selectedPettyCashRow?.pc_account_id}/${selectedPettyCashRow?.pc_trans_id}`,
          state: {
            ...(history.location.state as any),
            headerData: pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse,
            selectedRowState: selectedPettyCashRow,
            isAdjust: false,
            navigateFrom: "list"
          }
        });
      }
    }
  };

  return (
    <>
      {isLoaderOn || deletePettyCashStatus === STATUS.LOADING || printPettyCashStatus === STATUS.LOADING ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText={t("common.loading")}
        />
      ) : (
        <>
          <Layout
            pageTitle={t("pettyCashList.pageTitle")}
            isBreadcrumbRequired
            className="petty-cash-processing wrapper__radius--0"
            rightContent={
              <PettyCashToolbar
                goToAdd={goToAdd}
                goToPrevRecord={selectPrevRecord}
                goToNextRecord={selectNextRecord}
                onFocusClickHandler={onFocusClickHandler}
                undoChangeHandler={undoChangeHandler}
                onDelete={onDelete}
                isDeleteDisable={selectedPettyCashRow?.narrative !== UNPOSTED.Unposted_Exp}
                isPrintDisable={selectedPettyCashRow?.trans_type !== 1}
                printButtonHandler={printButtonHandler}
              />
            }
            toolbar={
              <PettyCashPageToolbar
                adjustTransHandler={adjustTransHandler}
                isPostDisabled={isPostDisabled()}
                onSubmit={postTransHandler}
                isCancelDisabled={isCancelDisabled()}
                isAdjustTransDisabled={isAdjustTransDisabled()}
                pcTransId={selectedPettyCashRow?.pc_trans_id}
              />
            }
          >
            <Grid className="mt-2">
              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={4}
                className="input-set-gap8"
              >
                <Input
                  id="pettyCenter"
                  labelText="Petty Cash Account"
                  searchable
                  disabled
                  value={pettyCashBrowseRowData?.pc_acc_des ?? pettyCashAccount}
                  button={
                    <>
                      <Button
                        color={ButtonColor.Secondary}
                        size={ButtonSize.Small}
                        className="essui-button-icon-only--small"
                        aria-label="petty-btn"
                        onClick={() => {
                          setOpenPettyCashBrowse(true);
                        }}
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </>
                  }
                />
              </GridItem>
              <GridItem
                sm={3}
                md={3}
                lg={3}
                xl={3}
              >
                <div>
                  <FormLabel className="mb-5">{t("pettyCashList.cashInHand")}</FormLabel>
                  <div className="input-value">
                    {cashInHand ?? usNumberFormat(pettyCashBrowseRowData?.cash_in_hand)}
                  </div>
                </div>
              </GridItem>

              <GridItem
                sm={3}
                md={3}
                lg={3}
                xl={3}
              >
                <div>
                  <FormLabel className="mb-5">{t("pettyCashList.unpostedExpenditure")}</FormLabel>
                  <div className="input-value">
                    {pettyCashBrowseRowData?.unposted_exp
                      ? usNumberFormat(pettyCashBrowseRowData?.unposted_exp)
                      : unpostExp}
                  </div>
                </div>
              </GridItem>
            </Grid>
          </Layout>
          <Layout
            isBreadcrumbRequired={false}
            className="petty-cash-list-grid"
          >
            <GridTableNew
              filters={<PettyCashFilters />}
              dataTestId={pDataTestId}
              dataSource={pettyCashList?.pettyCashTransaction || []}
              isLoading={pettyCashApiStatus === STATUS.LOADING}
              columnDef={pCColumnDef}
              customCell={CustomCell}
              selectedRow={selectedPettyCashRow}
              onEnterKeyPress={() => {
                goToRecord(selectedPettyCashRow);
              }}
              selectedRowHandler={onRowSelect}
              className="petty-cash-list-grid"
              footer={
                (totalPages > 1 || filterState?.view === "A") && (
                  <div className="petty-cash-footer-container">
                    <div className="left essui-form-label">{getSelectedTransType()}</div>
                    <div className="right">
                      <Pagination
                        count={totalPages}
                        page={currentPage}
                        onChange={(e, page) => {
                          onChangeHandler(page);
                        }}
                      />
                    </div>
                  </div>
                )
              }
            />
          </Layout>
          {openPettyCashBrowse && (
            <PettyCashAccountBrowseModal1
              isOpen={openPettyCashBrowse}
              setOpen={setOpenPettyCashBrowse}
              selectedRows={(row) => {
                selectPettyCashBrowseModal(row);
              }}
            />
          )}
          <SelectTransactionTypeModal
            isOpen={isSelectModalOpen}
            setOpen={setIsSelectModalOpen}
            checkForUnpostedExp={checkForUnpostedExp}
            pettyCashBrowseRowData={pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse}
          />
        </>
      )}
      <SelectTransactionTypeModal
        isOpen={isSelectModalOpen}
        setOpen={setIsSelectModalOpen}
        checkForUnpostedExp={checkForUnpostedExp}
        pettyCashBrowseRowData={pettyCashBrowseRowData ?? selectedPettyCashAccountBrowse}
      />
      <ConfirmModal
        className="delete-alert"
        isOpen={isDeleteModalOpen}
        setOpen={setIsDeleteModalOpen}
        title={t("alertMessage.title")}
        message={t("alertMessage.deleteAlert.message")}
        confirm={() => {
          deleteRecord();
        }}
      />
      <AlertModal
        isOpen={openAlertModal}
        setOpen={setOpenAlertModal}
        title={t("alertMessage.title")}
        notificationType={NotificationStatus.WARNING}
        message={alertMessage}
      />
    </>
  );
};
export default PettyCashList;
