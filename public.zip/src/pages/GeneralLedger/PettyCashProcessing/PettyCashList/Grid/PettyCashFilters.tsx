import React from "react";
import {
  Dropdown,
  DropdownItem,
  FormLabel,
  RadioButton,
  RadioLabelPosition,
  TextInputSize,
  ISelectedItem
} from "@essnextgen/ui-kit";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { STATUS } from "@/types/UseStateType";
import columnDef from "./columnDef";
import usePettyCashFilters from "./usePettyCashFilters";

const PettyCashFilters = () => {
  const {
    t,
    pettyCashViews,
    filterState,
    pettyCashApiStatus,
    pCashViewSelected,
    lookingForChangehandler,
    lookingForCallback,
    onSequenceChange,
    onViewSelection,
    onDescendingSort,
    onAscendingSort
  } = usePettyCashFilters();

  return (
    <div className="filters">
      <LookingFor
        initialValue={filterState?.lookingFor}
        callback={lookingForCallback}
        changeHandler={lookingForChangehandler}
        hasDatePicker
        disableDatePicker={filterState?.sequenceValue !== "date_posted"}
        isInputReadOnly={pettyCashApiStatus === STATUS.LOADING}
        className="essui-global-typography-default-h2 looking-for-container"
      />
      <div className="essui-global-typography-default-h2 sequence-container">
        <FormLabel>{t("pettyCashList.sequence")}</FormLabel>
        <div className="sequence">
          <div className="essui-textinput sequence-fields">
            {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
              const sequenceId = `sequence=${index + 1}`;
              return (
                <RadioButton
                  label={column.sequenceName ? column.sequenceName : column.headerName}
                  labelPosition={RadioLabelPosition.Right}
                  value={column.field}
                  onChange={() => {
                    onSequenceChange(column, index);
                  }}
                  isSelected={filterState?.sequenceValue === column.field}
                  key={sequenceId}
                  name={column.field}
                />
              );
            })}
          </div>
          <div className="essui-textinput sequence-order">
            <RadioButton
              label={t("common.ascending")}
              labelPosition={RadioLabelPosition.Right}
              value={0}
              onChange={onAscendingSort}
              isSelected={filterState?.order === 0}
            />
            <RadioButton
              label={t("common.descending")}
              labelPosition={RadioLabelPosition.Right}
              value={1}
              onChange={onDescendingSort}
              isSelected={filterState?.order === 1}
            />
          </div>
        </div>
      </div>
      <div className="view-filter">
        <FormLabel forId="view">{t("pettyCashList.view")}</FormLabel>
        <Dropdown
          size={TextInputSize.Medium}
          searchable
          selectedItem={pCashViewSelected}
          isScrollbarVisible
          onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => onViewSelection(item)}
        >
          {(pettyCashViews || []).map((view: any, i: any) => {
            const id = `dropdown-${i}`;
            return (
              <DropdownItem
                key={id}
                id={id}
                text={view.text}
                value={view.value}
              >
                {view.text}
              </DropdownItem>
            );
          })}
        </Dropdown>
      </div>
    </div>
  );
};

export default PettyCashFilters;
