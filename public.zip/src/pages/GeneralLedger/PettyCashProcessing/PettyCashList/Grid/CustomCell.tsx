import { cellRendererType } from "@/components/GridTable/GridTable";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import { usNumberFormat } from "@/utils/getDataSource";
import { useHistory } from "react-router-dom";
import { RootContext, useAppContext } from "@/routes/Routes";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { METHOD } from "@/types/UseStateType";
import { pettyCashActions } from "../../state/PettyCashList.slice";

const CustomCell = ({ field, row }: cellRendererType) => {
  const dispatch = useDispatch<AppDispatch>();

  const history = useHistory();
  const state = history.location.state as any;
  const { filterState, selectedPettyCashAccountBrowse } = useAppSelector((state) => state.pettyCashList);

  const handleButtonClick = () => {
    dispatch(pettyCashActions.setSelectedPettyCashRow(row));
    dispatch(pettyCashActions.setSelectedPettyCashUndoRow(row));
    dispatch(pettyCashActions.setFilters({ highlightPcTransId: row?.id }));
    if (row?.trans_type === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/view-reimbursement/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    } else if (row?.status === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/edit-expenditure/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          mode: METHOD.EDIT,
          selectedRowState: row,
          headerData: selectedPettyCashAccountBrowse,
          isDirty: false
        }
      });
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    }
  };

  const getContent = () => {
    switch (field) {
      case "detailLink":
        return (
          <Button
            className="grid-actions__button m-auto"
            size={ButtonSize.Small}
            color={ButtonColor.Tertiary}
            iconName="chevron--right"
            onClick={handleButtonClick}
          />
        );
      case "date_posted":
        return (
          <>
            {new Date(row?.date_posted).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })}
          </>
        );
      case "disp_amount":
        return <>{usNumberFormat(row?.disp_amount)}</>;
      default: {
        return <div />;
      }
    }
  };
  return getContent();
};

export default CustomCell;
