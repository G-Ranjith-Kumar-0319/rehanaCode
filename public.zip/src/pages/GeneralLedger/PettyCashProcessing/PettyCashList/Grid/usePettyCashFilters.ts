import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { ISelectedItem } from "@essnextgen/ui-kit";
import { pettyCashActions } from "../../state/PettyCashList.slice";
import columnDef from "./columnDef";

const usePettyCashFilters = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const [lookingFor, setLookingFor] = useState<string>("");
  const [lookingForSearch, setLookingForSearch] = useState<boolean>(false);
  const dispatch = useDispatch<AppDispatch>();
  const { filterState, pettyCashApiStatus, pCashViewSelected, selectedPettyCashRow } = useAppSelector(
    (state) => state.pettyCashList
  );
  const pettyCashViews = [
    {
      value: "A",
      text: "All transactions"
    },
    {
      value: "E",
      text: "Expenditure only"
    },
    {
      value: "R",
      text: "Reimbursement only"
    }
  ];
  const handleSequenceChange = (value: React.SetStateAction<string>, sequenceNewIndex: number) => {
    const getRow = columns.find((row) => row.field === value);
    columns.splice(columns.indexOf(getRow!), 1);
    columns.splice(0, 0, getRow!);
    setColumn([...columnDef]);
    dispatch(pettyCashActions.setColumnDef(columns));
    dispatch(
      pettyCashActions.setFilters({
        lookingFor: "",
        sequence: sequenceNewIndex,
        sequenceValue: String(value),
        pcTransId: selectedPettyCashRow?.pc_trans_id
      })
    );
  };
  const lookingForChangehandler = (value: string) => {
    setLookingForSearch(true);
    setLookingFor(value);
  };

  const lookingForCallback = () => {
    if (lookingForSearch) {
      dispatch(pettyCashActions.setFilters({ lookingFor, pcTransId: 0, highlightPcTransId: undefined }));
      setLookingForSearch(false);
    }
  };
  const onAscendingSort = () => {
    lookingForChangehandler("");
    dispatch(
      pettyCashActions.setFilters({
        lookingFor: "",
        order: 0,
        pcTransId: selectedPettyCashRow?.pc_trans_id
      })
    );
  };

  const onDescendingSort = () => {
    lookingForChangehandler("");
    dispatch(
      pettyCashActions.setFilters({
        lookingFor: "",
        order: 1,
        pcTransId: selectedPettyCashRow?.pc_trans_id
      })
    );
  };

  const onViewSelection = (item: ISelectedItem) => {
    lookingForChangehandler("");
    dispatch(pettyCashActions.setPCashViewSelected(item));
    dispatch(
      pettyCashActions.setFilters({
        lookingFor: "",
        view: item.value,
        pageNumber: 1,
        pcTransId: selectedPettyCashRow?.pc_trans_id
      })
    );
  };

  const onSequenceChange = (column: any, index: number) => {
    lookingForChangehandler("");
    handleSequenceChange(column.field, index);
  };
  return {
    t,
    pettyCashViews,
    columns,
    setColumn,
    handleSequenceChange,
    filterState,
    pettyCashApiStatus,
    pCashViewSelected,
    lookingForChangehandler,
    lookingForCallback,
    onSequenceChange,
    onViewSelection,
    onDescendingSort,
    onAscendingSort
  };
};

export default usePettyCashFilters;
