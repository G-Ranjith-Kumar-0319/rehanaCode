import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useHistory, useParams } from "react-router-dom";
import { RowType } from "@/components/GridTableNew/GridTableNew";
import {
  METHOD,
  PETTY_CASH_TRANS_STATUS,
  STATUS,
  getCurrentFinancialYear,
  specialCharacters
} from "@/types/UseStateType";
import { isEmptyObject } from "@/utils/constants";
import { useForm } from "react-hook-form";
import { usNumberFormat } from "@/utils/getDataSource";
import {
  getExpenditureDetails,
  expenditureActions,
  getUnpostedTransId,
  saveExpenditure
} from "../state/ViewExpenditure.slice";
import {
  deletePettyCashTranscation,
  getPettyCashList,
  pettyCashActions,
  printPettyCashTranscation
} from "../state/PettyCashList.slice";
import { getPettyCashOpenBooks, actions as pettyCashOpenBookActions } from "../state/PettyCashOpenBook.slice";
import { expenseFolioActions } from "../state/PettyCashExpenseFolio.slice";

type expenditureFormData = {
  prefix?: string;
  range: string;
};

const useViewExpenditure = () => {
  const formMethods = useForm<expenditureFormData>({
    mode: "all",
    shouldFocusError: false,
    defaultValues: {
      prefix: "",
      range: ""
    }
  });
  const { handleSubmit, reset, setValue } = formMethods;

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const { pcAccountId, transId } = useParams<{
    pcAccountId: string;
    transId: string;
  }>();
  const [loading, setLoading] = useState<boolean>(false);
  const [isViewPostingDetailsModalOpen, setIsViewPostingDetailsModalOpen] = useState<boolean>(false);
  const [openAlertModal, setOpenAlertModal] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<string>("");
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [isUndoModalOpen, setIsUndoModalOpen] = useState<boolean>(false);
  const [openSaveChangesModal, setOpenSaveChangesModal] = useState<boolean>(false);
  const [reRender, setRerender] = useState<boolean>(false);
  const dispatch = useDispatch<AppDispatch>();
  const {
    selectedPettyCashRow,
    filterState,
    deletePettyCashStatus,
    printPettyCashStatus,
    selectedPettyCashAccountBrowse,
    pettyCashList: { currentPage, totalPages, pageSize }
  } = useAppSelector((state) => state.pettyCashList);
  const pettyCashTransactionList = useAppSelector((state) => state.pettyCashList.pettyCashList?.pettyCashTransaction);
  const { expenditureApiStatus, selectedExpenditureRow, isDirty } = useAppSelector((state) => state.expenditureDetails);
  const { expenditureHeader, expenditureItems } = useAppSelector(
    (state) => state.expenditureDetails.expenditureDetails
  );
  const { pettyCashOpenBooks, pettyCashOpenBooksApiStatus, selectedPettyCashOpenBook } = useAppSelector(
    (state) => state.pettyCashOpenBooks
  );
  const historyState = { ...(history.location.state as any) };
  const { isAdjustDeleteTriggered, isAdjustEditTriggered, adjustedData } = useAppSelector(
    (state) => state.PettyCashExpenseFolio
  );
  useEffect(() => {
    if (pcAccountId !== "0" && transId !== "0") {
      setLoading(true);
      dispatch(
        getExpenditureDetails({
          pcAccountId,
          transId,
          callback: (data) => {
            dispatch(getPettyCashOpenBooks(0));
            setLoading(false);
          }
        })
      );
    } else {
      dispatch(expenditureActions.resetExpenditureDetails());
    }
  }, [pcAccountId, transId]);

  useEffect(() => {
    if (
      !isEmptyObject(expenditureHeader) &&
      pettyCashOpenBooks?.length &&
      expenditureApiStatus === STATUS.SUCCESS &&
      historyState?.mode !== METHOD.ADD
    ) {
      const selectedPCashOpenBook = pettyCashOpenBooks.filter((s) => s.prefix === expenditureHeader?.prefix)[0];
      dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(selectedPCashOpenBook));
    } else if (
      pettyCashOpenBooksApiStatus === STATUS.SUCCESS &&
      historyState?.mode === METHOD.ADD &&
      pettyCashOpenBooks?.length === 1
    ) {
      dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(pettyCashOpenBooks[0]));
    }
  }, [expenditureHeader, pettyCashOpenBooks, expenditureApiStatus]);

  const onRowSelect: (row?: RowType | undefined) => void = (row) => {
    if (expenditureApiStatus === STATUS.SUCCESS) {
      dispatch(expenditureActions.setSelectedExpenditureRow(row));
    }
  };
  const onDelete = () => {
    setIsDeleteModalOpen(true);
  };
  const deleteRecord = () => {
    dispatch(
      deletePettyCashTranscation({
        pcTransId: selectedPettyCashRow?.pc_trans_id ?? 0,
        callback: () => {
          history.push({
            pathname: `/general-ledger/petty-cash`
          });
          dispatch(
            pettyCashActions.setFilters({
              pageNumber: 1,
              pcTransId: 0,
              pcAccountId: selectedPettyCashAccountBrowse?.pc_account_id
            })
          );
        }
      })
    );
  };

  const updateHistoryState = (expenditureLineItems: any) => {
    history.replace({
      ...history.location,
      state: {
        ...historyState,
        expenditureItems: expenditureLineItems
      }
    });
  };

  useEffect(() => {
    if (historyState?.mode !== METHOD.ADJUST) {
      updateHistoryState(expenditureItems);
      if (expenditureItems.length) onRowSelect(expenditureItems?.[0]);
    } else if (
      expenditureItems.length &&
      historyState?.mode === METHOD.ADJUST &&
      !historyState?.expenditureItems?.length
    ) {
      updateHistoryState(expenditureItems);
      onRowSelect(expenditureItems?.[0]);
    }
  }, [historyState?.mode, expenditureItems]);

  const deleteItem = (index: number) => {
    const filteredItems = historyState?.expenditureItems.filter((_: any, itemIndex: any) => itemIndex !== index);
    updateHistoryState(filteredItems);
  };
  useEffect(() => {
    if (isAdjustDeleteTriggered) {
      const index = historyState?.expenditureItems.findIndex(
        (item: any) => item?.pc_folio_id === selectedExpenditureRow?.pc_folio_id
      );
      deleteItem(index);
      dispatch(expenseFolioActions.setIsAdjustDeleteTriggered(false));
    }
  }, [isAdjustDeleteTriggered]);

  const updateAdjustedItem = (index: number, updatedItem: any) => {};
  const handleItemEdit = (index: number, updatedItem: any) => {
    updateAdjustedItem(index, updatedItem);
  };
  useEffect(() => {
    if (isAdjustEditTriggered) {
      const index = historyState?.expenditureItems?.findIndex(
        (item: any) => item?.pc_folio_id === adjustedData?.pc_folio_id
      );
      handleItemEdit(index, adjustedData);
      dispatch(expenseFolioActions.setIsAdjustEditTriggered(false));
    }
  }, [isAdjustEditTriggered, adjustedData]);

  useEffect(() => {
    if (expenditureApiStatus === STATUS.FAILED) {
      setLoading(false);
    }
  }, [expenditureApiStatus]);

  const onFocusClickHandler = () => {
    if (historyState?.mode === METHOD.ADJUST || historyState?.mode === METHOD.ADD || isDirty) {
      setOpenSaveChangesModal(true);
    } else {
      dispatch(pettyCashActions.setIsFocus(false));
      dispatch(pettyCashActions.setFilters({ pcTransId: selectedPettyCashRow?.pc_trans_id }));
      history.push(`/general-ledger/petty-cash`);
    }
  };

  const undoChangeHandler = () => {
    if (historyState?.mode === METHOD.ADD || historyState?.mode === METHOD.ADJUST) {
      setIsUndoModalOpen(true);
    } else {
      dispatch(pettyCashActions.setFilters({ pcTransId: selectedPettyCashRow?.pc_trans_id }));
      history.push(`/general-ledger/petty-cash`);
    }
  };

  const onFocusNoButton = () => {
    if (historyState?.mode === METHOD.ADJUST) {
      updateHistoryState(expenditureItems);
    } else {
      history.push(`/general-ledger/petty-cash`);
      dispatch(expenditureActions.setPettyCashBookDirty(false));
    }
    setOpenSaveChangesModal(false);
  };
  const onFocusYesButton = () => {
    setOpenSaveChangesModal(false);
    onSubmitHandler();
  };
  const undoChangeAndNavigate = () => {
    dispatch(pettyCashActions.setFilters({ pcTransId: selectedPettyCashRow?.pc_trans_id }));
    history.push(`/general-ledger/petty-cash`);
  };
  const goToRecord = (row: any) => {
    dispatch(pettyCashActions.setSelectedPettyCashRow(row));
    dispatch(pettyCashActions.setSelectedPettyCashUndoRow(row));
    dispatch(pettyCashActions.setFilters({ highlightPcTransId: row?.id }));
    if (row?.trans_type === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/view-reimbursement/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    } else if (row?.status === 0) {
      history.push({
        pathname: `/general-ledger/petty-cash/edit-expenditure/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          mode: METHOD.EDIT,
          selectedRowState: row,
          headerData: selectedPettyCashAccountBrowse,
          isDirty: false
        }
      });
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${row?.pc_account_id}/${row?.pc_trans_id}`,
        state: {
          selectedRowState: row,
          isDirty: false
        }
      });
    }
  };

  const onChangeHandler = (page: number) => {
    dispatch(
      pettyCashActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        highlightPcTransId: undefined,
        pcTransId: 0
      })
    );
    dispatch(
      getPettyCashList({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(pageSize),
        highlightPcTransId: undefined,
        pcTransId: 0,
        pcAccountId: Number(pcAccountId),
        callback: (data) => {
          const row = data?.pettyCashTransaction?.at(0);
          if (row) {
            goToRecord(row);
          }
        }
      })
    );
  };

  const onChangePrevRecord = (page: number) => {
    dispatch(
      pettyCashActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        highlightPcTransId: undefined,
        pcTransId: 0
      })
    );
    dispatch(
      getPettyCashList({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(pageSize),
        highlightPcTransId: undefined,
        pcTransId: 0,
        pcAccountId: Number(pcAccountId),
        callback: (data) => {
          const row = data?.pettyCashTransaction?.at(data?.pettyCashTransaction.length - 1);
          if (row) {
            goToRecord(row);
          }
        }
      })
    );
  };

  const selectPrevRecord = () => {
    if (selectedPettyCashRow && pettyCashTransactionList) {
      const indexNo = pettyCashTransactionList.indexOf(selectedPettyCashRow);
      if (indexNo > 0) {
        const row = pettyCashTransactionList[indexNo - 1];
        dispatch(pettyCashActions.setSelectedPettyCashRow(pettyCashTransactionList[indexNo - 1]));
        goToRecord(row);
      } else if (currentPage > 1) {
        onChangePrevRecord(currentPage - 1);
      }
    }
  };
  const selectNextRecord = () => {
    if (selectedPettyCashRow && pettyCashTransactionList) {
      const indexNo = pettyCashTransactionList.indexOf(selectedPettyCashRow);
      if (indexNo < pettyCashTransactionList.length - 1) {
        const row = pettyCashTransactionList[indexNo + 1];
        dispatch(pettyCashActions.setSelectedPettyCashRow(pettyCashTransactionList[indexNo + 1]));
        goToRecord(row);
      } else if (currentPage < totalPages) {
        onChangeHandler(currentPage + 1);
      }
    }
  };

  const getPageTitle = () => {
    switch (historyState?.mode) {
      case METHOD.EDIT:
        return t("viewExpenditure.editExpenditureTitle");
      case METHOD.ADD:
      case METHOD.ADJUST:
        return t("viewExpenditure.addExpenditureTitle");
      default:
        return t("viewExpenditure.viewExpenditureTitle");
    }
  };

  const getUnpostedExpenditure = () => {
    let unpostedExp = 0;
    historyState?.expenditureItems?.forEach((item: any) => {
      unpostedExp += item.line_cost;
    });
    return unpostedExp;
  };
  const getVatAmount = () => {
    let vatAmount = 0;
    historyState?.expenditureItems?.forEach((item: any) => {
      vatAmount += item.vat_amount;
    });
    return vatAmount;
  };
  const getNetAmount = () => {
    let netAmount = 0;
    historyState?.expenditureItems?.forEach((item: any) => {
      netAmount += item.line_cost;
    });
    return netAmount;
  };
  const getPettyCashAccountValue = (fieldName: string) => {
    if (historyState?.mode === METHOD.ADD && isEmptyObject(expenditureHeader)) {
      return historyState?.headerData?.[fieldName] ?? "";
    }

    if (historyState?.mode === METHOD.ADJUST && !isEmptyObject(expenditureHeader)) {
      if (["cash_in_hand", "unposted_exp", "vat_amount", "net_amount"].includes(fieldName)) {
        switch (fieldName) {
          case "cash_in_hand":
            return expenditureHeader[fieldName] + expenditureHeader.line_cost;
          case "unposted_exp":
            return expenditureHeader[fieldName] + getUnpostedExpenditure();
          case "vat_amount":
            return getVatAmount();
          case "net_amount":
            return getNetAmount();
          default:
            return expenditureHeader[fieldName];
        }
      }
    }

    return expenditureHeader?.[fieldName] ?? "";
  };

  const isToolbarAddDisabled = () => {
    if (historyState?.mode === METHOD.ADD) {
      return true;
    }
    if (historyState?.mode === METHOD.EDIT) {
      return true;
    }
    return false;
  };
  const printButtonHandler = async () => {
    const { payload } = await dispatch(
      printPettyCashTranscation({
        accountid: selectedPettyCashRow?.pc_account_id ?? 0,
        transno: selectedPettyCashRow?.trans_no,
        yearId: getCurrentFinancialYear()
      })
    );
    const { data, fileName } = payload as any;
    const blob = new Blob([data], { type: "application/pdf" });
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName || t("pettyCash.fileName");
    link.click();
  };
  const isToolbarDeleteDisabled = () => {
    if (historyState?.mode === METHOD.EDIT) {
      return false;
    }
    return true;
  };
  const isToolbarPrintDisabled = () => {
    if (historyState?.mode === METHOD.ADD) {
      return true;
    }
    if (historyState?.mode === METHOD.EDIT) {
      return false;
    }
    return false;
  };

  const isViewPostingDetailsDisabled = () => {
    if (!historyState?.mode) {
      return false;
    }
    return true;
  };
  const goToAdd = () => {
    dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(undefined));
    checkForUnpostedExp();
  };

  const checkForUnpostedExp = () => {
    dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(undefined));
    setLoading(true);
    dispatch(
      getUnpostedTransId({
        pcAccountId: expenditureHeader?.pc_account_id,
        callback: (data) => {
          setValue("prefix", specialCharacters.BLANKVALUE);
          setValue("range", specialCharacters.BLANKVALUE);
          reset();

          setLoading(false);
          if (data?.at_pc_trans_id > 0) {
            history.push({
              pathname: `/general-ledger/petty-cash/edit-expenditure/${expenditureHeader?.pc_account_id}/${data?.at_pc_trans_id}`,
              state: {
                mode: METHOD.EDIT,
                headerData: expenditureHeader
              }
            });
          } else {
            history.push({
              pathname: `/general-ledger/petty-cash/add-expenditure`,
              state: {
                mode: METHOD.ADD,
                headerData: expenditureHeader
              }
            });
          }
        }
      })
    );
  };

  const isPostDisabled = () => {
    if (
      (expenditureHeader?.trans_type !== 0 &&
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.UNPOSTED &&
        expenditureHeader?.foliocount > 0) ||
      historyState?.mode === METHOD.ADJUST
    ) {
      return false;
    }
    return true;
  };
  const onSubmitHandler = async () => {
    const formSumbit = handleSubmit(
      async (data) => {
        if (data.prefix === selectedPettyCashOpenBook?.prefix) {
          if (historyState?.mode === METHOD.ADD || historyState?.mode === METHOD.EDIT) {
            setLoading(true);
            await saveExpenditureHandler();
            dispatch(expenditureActions.setPettyCashBookDirty(false));
          }
        }
      },
      () => {
        setOpenAlertModal(true);
        setAlertMessage(t("common.invalidData"));
      }
    );
    if (historyState?.mode === METHOD.ADJUST) {
      postTransHandler();
    } else {
      await formSumbit();
    }
  };

  const saveExpenditureHandler = async () => {
    const formData = {
      pcAccountId,
      pc_trans_id: transId || 0,
      book_id: selectedPettyCashOpenBook?.book_id
    };
    dispatch(
      saveExpenditure({
        formData,
        callback: (data) => {
          setLoading(false);
          if (data?.pc_trans_id && historyState?.mode === METHOD.ADD) {
            history.push({
              pathname: `/general-ledger/petty-cash/edit-expenditure/${formData?.pcAccountId}/${data?.pc_trans_id}`,
              state: {
                mode: METHOD.EDIT
              }
            });
          } else {
            dispatch(getExpenditureDetails({ pcAccountId, transId }));
          }
        }
      })
    );
  };

  const postTransHandler = () => {
    const overDrawn =
      Number(getPettyCashAccountValue("unposted_exp")) - Number(getPettyCashAccountValue("cash_in_hand"));
    if (overDrawn > 0) {
      setOpenAlertModal(true);
      const message = `${expenditureHeader?.pc_acc_des} ${t("viewExpenditure.overDrawnError")} ${usNumberFormat(
        overDrawn
      )}`;
      setAlertMessage(message);
    } else {
      history.push({
        pathname: `/general-ledger/petty-cash/add-posting-details/${expenditureHeader?.pc_account_id}/${expenditureHeader?.pc_trans_id}`,
        state: {
          ...(history.location.state as any),
          selectedRowState: expenditureHeader,
          navigateFrom: "detail"
        }
      });
    }
  };
  const handleViewOriginalClick = () => {
    if (expenditureHeader?.orig_trans_id) {
      const origTransId = expenditureHeader.orig_trans_id;
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${pcAccountId}/${origTransId}`
      });
    }
  };

  const handleViewAdjustmentClick = () => {
    if (expenditureHeader?.adj_trans_id) {
      const adjTransId = expenditureHeader.adj_trans_id;
      history.push({
        pathname: `/general-ledger/petty-cash/view-expenditure/${pcAccountId}/${adjTransId}`
      });
    }
  };

  const isCancelDisabled = () =>
    !(
      !historyState.mode &&
      (expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.NORMAL ||
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.ADJUST ||
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.ADJUST_OF_ADJUST)
    );

  const isAdjustTransDisabled = () =>
    !(
      !historyState.mode &&
      (expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.NORMAL ||
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.ADJUST ||
        expenditureHeader?.status === PETTY_CASH_TRANS_STATUS.ADJUST_OF_ADJUST)
    );

  const adjustTransHandler = () => {
    history.push({
      pathname: `/general-ledger/petty-cash/adjust-expenditure/${expenditureHeader?.pc_account_id}/${expenditureHeader?.pc_trans_id}`,
      state: {
        headerData: expenditureHeader,
        selectedRowState: selectedPettyCashRow,
        mode: METHOD.ADJUST
      }
    });
  };

  return {
    t,
    loading,
    expenditureApiStatus,
    onRowSelect,
    selectedExpenditureRow,
    selectedPettyCashRow,
    isUndoModalOpen,
    setIsUndoModalOpen,
    selectNextRecord,
    selectPrevRecord,
    isCancelDisabled,
    isAdjustTransDisabled,
    handleViewAdjustmentClick,
    handleViewOriginalClick,
    onFocusClickHandler,
    undoChangeHandler,
    expenditureHeader,
    expenditureItems,
    historyState,
    getPageTitle,
    onDelete,
    setIsDeleteModalOpen,
    isDeleteModalOpen,
    getPettyCashAccountValue,
    isToolbarAddDisabled,
    isToolbarDeleteDisabled,
    isToolbarPrintDisabled,
    isViewPostingDetailsDisabled,
    isViewPostingDetailsModalOpen,
    setIsViewPostingDetailsModalOpen,
    printButtonHandler,
    transId,
    goToAdd,
    isPostDisabled,
    deleteRecord,
    onSubmitHandler,
    undoChangeAndNavigate,
    setOpenSaveChangesModal,
    onFocusNoButton,
    onFocusYesButton,
    openSaveChangesModal,
    formMethods,
    openAlertModal,
    setOpenAlertModal,
    alertMessage,
    postTransHandler,
    deletePettyCashStatus,
    printPettyCashStatus,
    adjustTransHandler
  };
};

export default useViewExpenditure;
