import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { actions as pettyCashOpenBookActions } from "@/pages/GeneralLedger/PettyCashProcessing/state/PettyCashOpenBook.slice";
import { useFormContext } from "react-hook-form";
import { METHOD, specialCharacters } from "@/types/UseStateType";
import { useHistory } from "react-router-dom";
import { isEmptyObject } from "@/utils/constants";
import { getNoOfPagesLeft } from "../../state/PettyCashExpenseFolio.slice";
import { expenditureActions } from "../../state/ViewExpenditure.slice";

const useExpenditureFilters = () => {
  const { register, setValue, trigger, watch } = useFormContext();
  const nameInputRef = useRef<HTMLInputElement | null>(null);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = { ...(history.location.state as any) };
  const { expenditureHeader, expenditureItems } = useAppSelector(
    (state) => state.expenditureDetails.expenditureDetails
  );
  const { selectedExpenditureRow } = useAppSelector((state) => state.expenditureDetails);
  const { pettyCashOpenBooks, selectedPettyCashOpenBook, filters } = useAppSelector(
    (state) => state.pettyCashOpenBooks
  );
  const [pettyCashBookModalOpen, setPettyCashBookModalOpen] = useState<boolean>(false);
  const [isAddButtonDisabled, setIsAddButtonDisabled] = useState<boolean>(true);
  const handleSelectedPettyCashBook = (selectedItem: any) => {
    const pCSelectedRow = pettyCashOpenBooks.filter((s) => s.prefix === selectedItem?.text)[0];
    if (selectedItem?.text) {
      setValue("prefix", selectedItem.text);
      setValue("range", selectedItem.value);
      dispatch(pettyCashOpenBookActions.setFilters({ lookingFor: "" }));
    } else {
      setValue("prefix", "");
      setValue("range", "");
    }
    dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(pCSelectedRow));
  };

  const onSelectPettyCashBook = (selectedItem: { [key: string]: any }) => {
    dispatch(expenditureActions.setPettyCashBookDirty(true));
    dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(selectedItem));
  };

  const handleOnChangePettyCashBook = (e: React.ChangeEvent<HTMLInputElement>) => {
    setValue("prefix", e.target.value);
    dispatch(pettyCashOpenBookActions.setFilters({ lookingFor: e.target.value.toUpperCase() }));
    register("prefix").onChange(e);
    if (!e.target.value) {
      dispatch(pettyCashOpenBookActions.selectPettyCashOpenBook(undefined));
      setValue("range", specialCharacters.BLANKVALUE);
    }
  };
  const handlePettyCashOpenBookPendingState = useCallback(
    (suggested: any) => {
      if (suggested) {
        const found = pettyCashOpenBooks?.find((t) => t?.prefix === suggested?.text);
        if (found) {
          setIsAddButtonDisabled(false);
        }
        setValue("range", found?.range);
        trigger("range");
      }
    },
    [pettyCashOpenBooks]
  );

  // Check whether the selected Cash Book has any pages left or not
  const checkBookPagesLeft = () => {
    if (historyState?.mode === "ADD") {
      dispatch(
        getNoOfPagesLeft({
          bookId: selectedPettyCashOpenBook?.book_id,
          callback: (res) => {
            // disable add expense folio button if api have less than zero count
            if (res <= 0) setIsAddButtonDisabled(true);
          }
        })
      );
    }
  };

  useEffect(() => {
    if (selectedPettyCashOpenBook !== undefined) {
      checkBookPagesLeft();
      const selectedPCashOpenBook = pettyCashOpenBooks.filter((s) => s.prefix === selectedPettyCashOpenBook?.prefix)[0];
      setValue("prefix", selectedPCashOpenBook?.prefix);
      setValue("range", selectedPCashOpenBook?.range);
      trigger("prefix");
      nameInputRef?.current?.blur(); // Trigger the blur event to remove the focus from the input field
    } else {
      setValue("prefix", specialCharacters.BLANKVALUE);
      setValue("range", specialCharacters.BLANKVALUE);
      setTimeout(() => {
        nameInputRef?.current?.focus();
      }, 0);
    }
    isAddLineItemBtnDisabled();
  }, [selectedPettyCashOpenBook]);

  const isPettyCashBookSearchDisabled = () => !historyState.mode || expenditureItems.length > 0;

  const isAddLineItemBtnDisabled = () => {
    if (!historyState.mode || historyState.mode === METHOD.ADJUST) {
      setIsAddButtonDisabled(true);
    } else {
      if (watch("range") === specialCharacters.BLANKVALUE) {
        setIsAddButtonDisabled(true);
        return;
      }
      setIsAddButtonDisabled(false);
    }
  };

  const watchedRange = watch("range");
  useEffect(() => {
    isAddLineItemBtnDisabled();
  }, [watchedRange]);

  const addExpenseFolioItem = () => {
    history.push({
      pathname: `${history.location.pathname}/expense-folio`,
      state: {
        mode: historyState.mode,
        lineItemMode: METHOD.ADD,
        headerData: isEmptyObject(expenditureHeader) ? historyState.headerData : expenditureHeader,
        selectedBook: selectedPettyCashOpenBook
      }
    });
  };

  const openBookModalOpen = () => {
    dispatch(pettyCashOpenBookActions.setFilters({ ...filters, sequenceIndex: "0" }));
    setPettyCashBookModalOpen(true);
  };
  return {
    t,
    expenditureHeader,
    pettyCashOpenBooks,
    handleSelectedPettyCashBook,
    pettyCashBookModalOpen,
    setPettyCashBookModalOpen,
    onSelectPettyCashBook,
    handleOnChangePettyCashBook,
    handlePettyCashOpenBookPendingState,
    isPettyCashBookSearchDisabled,
    isAddButtonDisabled,
    isAddLineItemBtnDisabled,
    selectedExpenditureRow,
    addExpenseFolioItem,
    nameInputRef,
    openBookModalOpen
  };
};

export default useExpenditureFilters;
