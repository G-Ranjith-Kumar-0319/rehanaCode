import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";

import { ISelectedItem } from "@essnextgen/ui-kit";
import { NumberLiteralType } from "typescript";
import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import pettyCashColDef from "../PettyCashList/Grid/columnDef";
import { fundingSourceColDef, pettyCashBrowseColDef } from "../PettyCashList/Grid/coulmnAccountBrowseDef";

export type TPettyCashList = { [key: string]: any }[];

export type PettyCashType = {
  pettyCashTransaction: TPettyCashList;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: string;
  pcAccountId: number;
  highlightPcTransId: number;
  pcTransId: number;
};

type TpettyCashPayload = {
  pageNumber?: number;
  pageSize?: string;
  view?: string;
  sequence?: number;
  sequenceValue?: string;
  lookingFor?: string | undefined;
  pcAccountId?: number;
  pcTransId?: number;
  order?: number;
  index?: number;
  highlightPcTransId?: number;
};

type TupdatePettyCashFundingSourcePayload = {
  /* eslint-disable camelcase */
  pc_account_id?: number;
  source_leddef_id?: number;
};

type TCancelPettyCashTransactionPayload = {
  pcTransId?: string;
};

type PettyCashStateType = {
  pettyCashAccountBrowse: { [key: string]: any }[];
  pettyCashFundingSource: { [key: string]: any }[];
  filterState?: TpettyCashPayload;
  selectedPettyCashRow?: { [key: string]: any };
  selectedPettyCashAccountBrowse?: { [key: string]: any };
  selectedPersistPettyCashBrowseRow?: { [key: string]: any };
  sortedPettyCashAccount?: { [key: string]: any };
  selectedPettyCashFundingSource?: { [key: string]: any };
  pettyCashList: PettyCashType;
  conlumnDef: TColumnDef;
  pettyCashBrowseColumnDef: TColumnDef;
  pettyFundingSourceColumnDef: TColumnDef;
  error: string | undefined;
  pettyCashApiStatus?: STATUS;
  deletePettyCashStatus?: STATUS;
  printPettyCashStatus?: STATUS;
  pettyCashBrowseStatus?: STATUS;
  pettyCashFundingStatus?: STATUS;
  isFocus?: boolean;
  pCashViewSelected?: ISelectedItem;
  selectedPettyCashUndoRow?: { [key: string]: any };
  isCancel: boolean;
};

const initialState: PettyCashStateType = {
  pettyCashAccountBrowse: [],
  pettyCashFundingSource: [],
  filterState: {
    pageNumber: 1,
    pageSize: "10",
    order: 1,
    sequence: 0,
    sequenceValue: pettyCashColDef.filter((col) => !!col.sequence)[0].field,
    view: "A",
    lookingFor: "",
    highlightPcTransId: 0,
    pcTransId: 0,
    pcAccountId: 0
  },
  conlumnDef: pettyCashColDef,
  pettyCashBrowseColumnDef: pettyCashBrowseColDef,
  pettyFundingSourceColumnDef: fundingSourceColDef,
  pettyCashList: {
    pettyCashTransaction: [],
    currentPage: 1,
    totalCount: "",
    pageSize: 10,
    totalPages: 0,
    highlightPcTransId: 0,
    pcTransId: 0,
    pcAccountId: 0
  },
  error: "",
  isFocus: false,
  isCancel: false,
  pCashViewSelected: {
    text: "All transactions",
    value: "A"
  }
};

/** Thunks */
export const getPettyCashList = createAsyncThunk(
  "pettyCash/list",
  async (
    {
      pageSize,
      pageNumber,
      view,
      order,
      sequence,
      lookingFor,
      highlightPcTransId,
      pcTransId,
      pcAccountId,
      callback
    }: TpettyCashPayload & { callback?: (data: any, selectedRow?: any) => void },
    thunkAPI
  ) => {
    try {
      const { dispatch } = thunkAPI;
      const { data }: { data: { [key: string]: any } } = await client.post(`${apiRoot}/petty-cash`, {
        pageNumber,
        pageSize: 10,
        sequence,
        view,
        order,
        lookingFor,
        highlightPcTransId,
        pcTransId,
        pcAccountId
      });
      if (data) {
        const row = ((data?.pettyCashTransaction as { [key: string]: any }[]) || [])
          ?.filter((p) => p.pc_trans_id === data?.highlightPcTransId)
          .at(0);
        dispatch(pettyCashActions.setSelectedPettyCashRow(row));
        if (callback) {
          callback(data);
        }
      }

      return data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const getPettyCashAccountBrowse = createAsyncThunk("petty-cash/petty-cash-accounts", async () => {
  const response = await client.get(`${apiRoot}/petty-cash/petty-cash-accounts`);

  return response.data;
});

export const getPettyCashFundingSource = createAsyncThunk("petty-cash/petty-funding-source", async () => {
  const response = await client.get(`${apiRoot}/petty-cash/petty-funding-source`);

  return response.data;
});

export const updatingPettyCashFundingSource = createAsyncThunk(
  "petty-cash/update-petty-cash-funding-source",
  /* eslint-disable camelcase */
  async (
    {
      pc_account_id,
      source_leddef_id,
      callback
    }: TupdatePettyCashFundingSourcePayload & { callback?: (data: any) => void },
    thunkAPI
  ) => {
    try {
      const response = await client.post(`${apiRoot}/petty-cash/update-petty-cash-funding-source`, {
        pc_account_id,
        source_leddef_id,
        callback
      });
      if (callback) {
        callback(response.data);
      }
      return response.data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const cancelPettyCashTransaction = createAsyncThunk(
  "pettyCash/cancelTransaction",
  async ({ pcTransId }: TCancelPettyCashTransactionPayload, thunkAPI) => {
    try {
      const response = await client.post(`${apiRoot}/petty-cash/cancel-petty-cash-transaction?pcTransId=${pcTransId}`);
      return response.data;
    } catch (e) {
      return thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const deletePettyCashTranscation = createAsyncThunk(
  "/petty-cash/petty-cash-trans-no",
  async ({ pcTransId, callback }: any) => {
    const response = await client.delete(`${apiRoot}/petty-cash/petty-cash-trans-no?pcTransId=${pcTransId}`);
    if (response.status === 200) {
      callback();
    }
    return response.data;
  }
);

export const printPettyCashTranscation = createAsyncThunk(
  "/document/petty-cash-expense-trans-print-pdf",
  async ({ accountid, transno, yearId }: { accountid: number; transno: string; yearId: any }) => {
    try {
      const response = await client.get(`${apiRoot}/document/petty-cash-expense-trans-print-pdf`, {
        params: { accountid, transno, yearId },
        responseType: "blob"
      });

      const fileName = (response.headers["content-disposition"] as any)
        .split(";")
        .find((n: any) => n.includes("filename="))
        .replace("filename=", "")
        .trim()
        .replace(/['"]+/g, "");

      return { data: response.data, fileName };
    } catch (e) {
      console.log(e);
      return { data: null, fileName: "" };
    }
  }
);

/**
 * # Petty Cash Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  initialState,
  name: "pettyCashList",
  extraReducers: (builder) => {
    /** Petty Cash List */
    builder
      .addCase(getPettyCashList.pending, (state) => {
        state.pettyCashApiStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getPettyCashList.fulfilled, (state, action: PayloadAction<any>) => {
        state.pettyCashList = action.payload;
        state.pettyCashApiStatus = STATUS.SUCCESS;
      })
      .addCase(getPettyCashList.rejected, (state) => {
        state.pettyCashApiStatus = STATUS.FAILED;
        state.pettyCashList = initialState.pettyCashList;
      });

    builder
      .addCase(getPettyCashAccountBrowse.pending, (state) => {
        state.pettyCashBrowseStatus = STATUS.LOADING;
      })
      .addCase(getPettyCashAccountBrowse.fulfilled, (state, action: PayloadAction<any>) => {
        state.pettyCashAccountBrowse = action.payload;
        if (!state.selectedPettyCashAccountBrowse) {
          const filteredData = action.payload.filter((e: any) => e.source_des !== "" && e.source_des !== null);
          const found = [...filteredData];
          const sortedPettyCashAccountBrowse = found.sort((a, b) => a.pc_acc_des.localeCompare(b.pc_acc_des));
          const [firstSortedAccount] = sortedPettyCashAccountBrowse;
          state.sortedPettyCashAccount = firstSortedAccount;
          state.selectedPettyCashAccountBrowse = firstSortedAccount;
          state.selectedPersistPettyCashBrowseRow = firstSortedAccount;
        } else {
          const filteredRow = action.payload.find(
            (e: any) => e.pc_account_id === state.selectedPettyCashAccountBrowse?.pc_account_id
          );
          state.selectedPettyCashAccountBrowse = filteredRow;
          state.selectedPersistPettyCashBrowseRow = filteredRow;
        }
        state.pettyCashBrowseStatus = STATUS.SUCCESS;
      })
      .addCase(getPettyCashAccountBrowse.rejected, (state, action: PayloadAction<any>) => {
        state.pettyCashBrowseStatus = STATUS.FAILED;
        state.error = action.payload.error.message;
      });

    builder
      .addCase(getPettyCashFundingSource.pending, (state) => {
        state.pettyCashFundingStatus = STATUS.LOADING;
      })
      .addCase(getPettyCashFundingSource.fulfilled, (state, action: PayloadAction<any>) => {
        state.pettyCashFundingSource = action.payload;
        // eslint-disable-next-line
        state.selectedPettyCashFundingSource = action.payload[0];
        state.pettyCashFundingStatus = STATUS.SUCCESS;
      })
      .addCase(getPettyCashFundingSource.rejected, (state, action: PayloadAction<any>) => {
        state.pettyCashFundingStatus = STATUS.FAILED;
        state.error = action.payload.error.message;
      });

    builder
      .addCase(cancelPettyCashTransaction.pending, (state) => {
        state.pettyCashApiStatus = STATUS.LOADING;
      })
      .addCase(cancelPettyCashTransaction.fulfilled, (state, action: PayloadAction<any>) => {
        state.pettyCashApiStatus = STATUS.SUCCESS;
        state.pettyCashList.pettyCashTransaction = state.pettyCashList.pettyCashTransaction.filter(
          (transaction) => transaction.pc_trans_id !== action.payload.pc_trans_id
        );
      })
      .addCase(cancelPettyCashTransaction.rejected, (state, action: PayloadAction<any>) => {
        state.pettyCashApiStatus = STATUS.FAILED;
        state.error = action.payload.error.message;
      });

    builder
      .addCase(deletePettyCashTranscation.pending, (state) => {
        state.deletePettyCashStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(deletePettyCashTranscation.fulfilled, (state, action: PayloadAction<any>) => {
        state.deletePettyCashStatus = STATUS.SUCCESS;
      })
      .addCase(deletePettyCashTranscation.rejected, (state, action: PayloadAction<any>) => {
        state.deletePettyCashStatus = STATUS.FAILED;
        state.error = action?.payload?.error.message;
      });
    builder
      .addCase(printPettyCashTranscation.pending, (state) => {
        state.printPettyCashStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(printPettyCashTranscation.fulfilled, (state, action: PayloadAction<any>) => {
        state.printPettyCashStatus = STATUS.SUCCESS;
      })
      .addCase(printPettyCashTranscation.rejected, (state, action: PayloadAction<any>) => {
        state.printPettyCashStatus = STATUS.FAILED;
        state.error = action?.payload?.error.message;
      });
  },
  reducers: {
    initialState: (state) => {
      state.filterState = { ...initialState.filterState };
    },
    setSelectedPettyCashRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedPettyCashRow = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.conlumnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TpettyCashPayload>) => {
      state.filterState = {
        ...state.filterState,
        ...action.payload
      };
    },
    setPCashViewSelected: (state, action: PayloadAction<any>) => {
      state.pCashViewSelected = action.payload;
    },
    setSelectedPettyCashBrowseRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedPettyCashAccountBrowse = action.payload;
    },
    setPersistPettyCashBrowseRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedPersistPettyCashBrowseRow = action.payload;
    },
    setSelectedPettyFundingSourceRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedPettyCashFundingSource = action.payload;
    },
    setSortedPettyCashAccount: (state, action: PayloadAction<any>) => {
      state.sortedPettyCashAccount = action.payload;
    },
    setIsFocus: (state, action: PayloadAction<any>) => {
      state.isFocus = action.payload;
    },
    setSelectedPettyCashUndoRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedPettyCashUndoRow = action.payload;
    },
    setCancelButtonClicked: (state, action: PayloadAction<any>) => {
      state.isCancel = action.payload;
    }
  }
});

export const { actions: pettyCashActions, reducer } = slice;
export default reducer;
