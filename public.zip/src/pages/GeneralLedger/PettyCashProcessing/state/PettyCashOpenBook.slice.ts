import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import pettyCashBookColumnDef from "@/shared/components/PettyCashOpenBookModal/Grid/columnDef";
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type pettyCashOpenBookState = {
  pettyCashOpenBooks: { [key: string]: any }[];
  selectedPettyCashOpenBook?: { [key: string]: any };
  columnDef: TColumnDef;
  error?: string;
  pettyCashOpenBooksApiStatus?: STATUS;
  filters?: TFilters;
};

const initialState: pettyCashOpenBookState = {
  columnDef: pettyCashBookColumnDef,
  pettyCashOpenBooks: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined
  }
};

/** Thunks */
export const getPettyCashOpenBooks = createAsyncThunk("pettyCash/getPettyCashOpenBooks", async (sequence?: any) => {
  const response = await client.get(`${apiRoot}/petty-cash/petty-cash-open-books?sequence=${sequence || 0}`);
  return response.data;
});

const slice = createSlice({
  extraReducers: (builder) => {
    /** Invoice Posting period Slice */
    builder
      .addCase(getPettyCashOpenBooks.pending, (state) => {
        state.pettyCashOpenBooksApiStatus = STATUS.LOADING;
      })
      .addCase(getPettyCashOpenBooks.fulfilled, (state, action: PayloadAction<any>) => {
        state.pettyCashOpenBooks = action.payload;
        state.pettyCashOpenBooksApiStatus = STATUS.SUCCESS;
      })
      .addCase(getPettyCashOpenBooks.rejected, (state, action: PayloadAction<any>) => {
        state.pettyCashOpenBooksApiStatus = STATUS.FAILED;
        state.error = action.payload?.error.message;
      });
  },
  initialState,
  name: "pettyCashOpenBooks",
  reducers: {
    selectPettyCashOpenBook: (state, action: PayloadAction<any>) => {
      state.selectedPettyCashOpenBook = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (pettyCashBookColumnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    },
    resetSelectedRow: (state) => {
      state.selectedPettyCashOpenBook = undefined;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
