import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { OrderType, STATUS } from "@/types/UseStateType";

type TPettyCashData = {
  pettyCashAccountsHidden: { [key: string]: any } | undefined;
  pettyCashTransaction: { [key: string]: any } | undefined;
};
type TPettyCashDetailsState = {
  error: string | undefined;
  status?: STATUS;
  reimbursmentStatus?: STATUS;
  printChequeStatus?: STATUS;
  printChequeData: { [key: string]: any } | undefined;
  reimbursmentSaveStatus?: STATUS;
  fcSourceBalanceStatus?: STATUS;
  reimbursementDetails: TPettyCashData;
};
const initialState: TPettyCashDetailsState = {
  error: "",
  printChequeData: [],
  reimbursementDetails: {
    pettyCashAccountsHidden: undefined,
    pettyCashTransaction: undefined
  }
};

/** Thunks */
export const getReimbursementDetails = createAsyncThunk(
  "pettyCash/reimbursementDetails",
  async ({
    pcAccountId,
    pcTransId,
    callback
  }: {
    pcAccountId: string;
    pcTransId: string;
    callback?: (data: any) => void;
  }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-reimb-transno`, {
      params: { pcAccountId, pcTransId }
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const saveNewReimbursement = createAsyncThunk(
  "petty-cash/petty-cash-reimbursement",
  async ({ formData, callback }: { formData: any; callback?: (data: any) => void }) => {
    const response = await client.post(`${apiRoot}/petty-cash/petty-cash-reimbusment`, {
      ...formData
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const savePrintChequeReimbursement = createAsyncThunk(
  "petty-cash/petty-cash-reimbusment-save-print-cheque",
  async ({ formData, callback }: { formData: any; callback?: (data: any) => void }) => {
    const response = await client.post(`${apiRoot}/petty-cash/petty-cash-reimbusment-save-print-cheque`, {
      ...formData
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const getFCSourceBalance = createAsyncThunk(
  "/petty-cash/petty-cash-source-bal",
  async ({ ledDefId, callback }: { ledDefId: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/petty-cash/petty-cash-source-bal`, {
      params: {
        ledDefId
      }
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * This slice of state is responsible for storing PCView details state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** PCView details state */
    builder
      .addCase(getReimbursementDetails.pending, (state) => {
        state.reimbursmentStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getReimbursementDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.reimbursementDetails = action.payload;
        state.error = undefined;
        state.reimbursmentStatus = STATUS.SUCCESS;
      })
      .addCase(getReimbursementDetails.rejected, (state, action: PayloadAction<any>) => {
        state.reimbursmentStatus = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      })
      .addCase(saveNewReimbursement.pending, (state) => {
        state.reimbursmentSaveStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(saveNewReimbursement.fulfilled, (state, action: PayloadAction<any>) => {
        state.error = undefined;
        state.reimbursmentSaveStatus = STATUS.SUCCESS;
      })
      .addCase(saveNewReimbursement.rejected, (state, action: PayloadAction<any>) => {
        state.reimbursmentSaveStatus = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      })
      .addCase(getFCSourceBalance.pending, (state) => {
        state.fcSourceBalanceStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getFCSourceBalance.fulfilled, (state, action: PayloadAction<any>) => {
        state.error = undefined;
        state.fcSourceBalanceStatus = STATUS.SUCCESS;
      })
      .addCase(getFCSourceBalance.rejected, (state, action: PayloadAction<any>) => {
        state.fcSourceBalanceStatus = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      })

      .addCase(savePrintChequeReimbursement.pending, (state) => {
        state.printChequeStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(savePrintChequeReimbursement.fulfilled, (state, action: PayloadAction<any>) => {
        state.printChequeData = action.payload;
        state.error = undefined;
        state.printChequeStatus = STATUS.SUCCESS;
      })
      .addCase(savePrintChequeReimbursement.rejected, (state, action: PayloadAction<any>) => {
        state.printChequeStatus = STATUS.FAILED;
        // state.error = action.error.message ?? "Unknown error";
      });
  },
  initialState,
  name: "ReimbursementDetails",
  reducers: {
    setReimbursementDetails: (state, action: PayloadAction<any>) => {
      state.reimbursementDetails = {
        pettyCashAccountsHidden: action.payload.pettyCashAccountsHidden,
        pettyCashTransaction: action.payload.pettyCashTransaction
      };
    }
  }
});
export const { actions, reducer } = slice;
export default reducer;
