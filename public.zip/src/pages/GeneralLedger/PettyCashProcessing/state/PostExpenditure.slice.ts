import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";

const initialState = {
  error: ""
};

/** Thunks */

export const postExpenditure = createAsyncThunk(
  "petty-cash/post-expenditure",
  async ({ formData, callback }: { formData: any; callback?: (data: any) => void }) => {
    const response = await client.post(`${apiRoot}/petty-cash/petty-cash-posting-details`, {
      ...formData
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const ajustExpenditure = createAsyncThunk(
  "petty-cash/ajust-expenditure",
  async ({ formData, callback }: { formData: any; callback?: (data: any) => void }) => {
    const response = await client.post(`${apiRoot}/petty-cash/petty-cash-trans-adjustment`, {
      ...formData
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * This slice of state is responsible for storing expenditure details state
 */
const slice = createSlice({
  extraReducers: (builder) => {},
  initialState,
  name: "PostExpenditure",
  reducers: {}
});
export const { actions: postExpenditureActions, reducer } = slice;
export default reducer;
