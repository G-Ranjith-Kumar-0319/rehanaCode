import { useState } from "react";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  RadioButton,
  RadioLabelPosition
} from "@essnextgen/ui-kit";
import { useHistory } from "react-router-dom";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import { PC_TRANSACTION_TYPE } from "@/types/UseStateType";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import BodyUtil from "@/shared/utils/NoScroll";
import "./Style.scss";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/store/store";
import { actions as reimburAction } from "../state/ViewReimbursement.slice";

const SelectTransactionTypeModal = ({
  isOpen,
  setOpen,
  pettyCashBrowseRowData,
  checkForUnpostedExp
}: {
  isOpen: boolean;
  setOpen: (flag: boolean) => void;
  pettyCashBrowseRowData: any;
  checkForUnpostedExp: () => void;
}) => {
  const [selected, setSelected] = useState<PC_TRANSACTION_TYPE>(PC_TRANSACTION_TYPE.EXPENDITURE);
  const history = useHistory();
  const closeHandler = () => {
    setOpen(false);
  };
  const dispatch = useDispatch<AppDispatch>();
  const onSelect = () => {
    setOpen(false);
    BodyUtil.NoScroll.remove();
    if (selected === PC_TRANSACTION_TYPE.REIMBURSEMENT) {
      const addReimbursementData = {
        pettyCashAccountsHidden: undefined,
        pettyCashTransaction: undefined
      };
      dispatch(reimburAction.setReimbursementDetails(addReimbursementData));
      history.push({
        pathname: `/general-ledger/petty-cash/add-reimbursement`,
        state: {
          mode: "add",
          headerData: pettyCashBrowseRowData
        }
      });
    } else {
      checkForUnpostedExp();
    }
  };

  const secondaryButton = (
    <Button
      size={ButtonSize.Small}
      color={ButtonColor.Secondary}
      onClick={closeHandler}
    >
      Cancel
    </Button>
  );

  const primaryButton = (
    <Button
      size={ButtonSize.Small}
      onClick={onSelect}
    >
      Select
    </Button>
  );

  return (
    <Modalv2
      isOpen={isOpen}
      onClose={closeHandler}
      header="Select Transaction Type"
      className="select-transaction-type-modal"
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
    >
      <div className="multiple__radio--btnfield row-gap-8">
        <div className="d-flex align-center">
          <RadioButton
            label="Expenditure"
            labelPosition={RadioLabelPosition.Right}
            value={PC_TRANSACTION_TYPE.EXPENDITURE}
            isSelected={selected === PC_TRANSACTION_TYPE.EXPENDITURE}
            onChange={() => setSelected(PC_TRANSACTION_TYPE.EXPENDITURE)}
          />
        </div>
        <div className="d-flex align-center">
          <RadioButton
            label="Reimbursement"
            labelPosition={RadioLabelPosition.Right}
            value={PC_TRANSACTION_TYPE.REIMBURSEMENT}
            isSelected={selected === PC_TRANSACTION_TYPE.REIMBURSEMENT}
            onChange={() => setSelected(PC_TRANSACTION_TYPE.REIMBURSEMENT)}
          />
        </div>
      </div>
    </Modalv2>
  );
};

export default SelectTransactionTypeModal;
