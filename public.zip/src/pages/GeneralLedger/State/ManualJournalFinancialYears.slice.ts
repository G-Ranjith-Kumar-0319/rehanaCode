import { RowType } from "@/components/GridTableNew/GridTableNew";
import { apiRoot } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { ISelectedItem } from "@essnextgen/ui-kit";
import { createSlice, PayloadAction, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

// Define the initial state interface
type initialStateType = {
  data?: RowType[];
  status: STATUS;
  error: string | null;
  selectedView?: ISelectedItem;
};

// Define the initial state
const initialState: initialStateType = {
  error: null,
  status: STATUS.IDLE
};

export const fetchManualJournalFinancialYear = createAsyncThunk("manualJournalFinancialYear", async () => {
  try {
    // Make your axios API call here
    const response = await axios.get(`${apiRoot}/Manual-Journal/manual-journal-financial-year`);
    return response.data;
  } catch (error) {
    // Handle any errors that occur during the API call
    throw new Error("Failed to fetch manual journal details");
  }
});

// Add the async thunk function to the reducers
const slice = createSlice({
  name: "manualJournalFinancialYears",
  initialState,
  reducers: {
    // Define your actions and their corresponding reducers here
    setSelectedView: (state, action: PayloadAction<ISelectedItem | undefined>) => {
      state.selectedView = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder.addCase(fetchManualJournalFinancialYear.fulfilled, (state, action) => {
      // Handle the successful API response and update the state accordingly
      state.data = action.payload as any;
      state.status = STATUS.SUCCESS;
      state.error = null;
    });
    builder.addCase(fetchManualJournalFinancialYear.pending, (state) => {
      // Handle the pending state while the API call is in progress
      state.status = STATUS.LOADING;
      state.error = null;
    });
    builder.addCase(fetchManualJournalFinancialYear.rejected, (state, action) => {
      // Handle any errors that occur during the API call
      state.status = STATUS.FAILED;
      state.error = action.error.message || null;
    });
  }
});

// Export the actions and reducer
export const { actions: mjFinancialYearActions, reducer } = slice;
export default reducer;
