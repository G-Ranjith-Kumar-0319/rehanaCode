import { KeyValueType, RowType } from "@/components/GridTableNew/GridTableNew";
import { apiRoot } from "@/config";
import { RootState } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { createSlice, PayloadAction, createAsyncThunk, current } from "@reduxjs/toolkit";
import axios from "axios";
import { fetchPeriods } from "./ManualJournalPeriods.slice";
import { fetchManualJournalFinancialYear } from "./ManualJournalFinancialYears.slice";

// Define the initial state interface
export type JournalDetailsType = {
  journalHeader?: KeyValueType;
  journalLines: KeyValueType[];
  voucherJournal?: KeyValueType;
  [key: string]: any;
};
type initialStateType = {
  data: JournalDetailsType;
  status: STATUS;
  error: string | null;
  selectedRow?: RowType;
};

// Define the initial state
const initialState: initialStateType = {
  data: {
    journalHeader: undefined,
    journalLines: [],
    voucherJournal: undefined
  },
  error: null,
  status: STATUS.IDLE
};

// Define your async thunk function
export const fetchManualJournalDetails = createAsyncThunk(
  "manualJournalDetails/fetch",
  async (
    {
      voucherId,
      templateVoucherId,
      callback
    }: { voucherId: string; templateVoucherId: string | undefined; callback?: (data?: KeyValueType) => void },
    thunkAPI
  ) => {
    const { dispatch, getState } = thunkAPI;
    const { manualJournalPeriods } = getState() as RootState;
    try {
      // Make your axios API call here
      const response = await axios.get(`${apiRoot}/Manual-Journal/journal-details`, {
        params: { voucherId, templateVoucherId: templateVoucherId !== "" ? templateVoucherId : undefined }
      });

      if (!manualJournalPeriods?.periods?.length) {
        await dispatch(fetchPeriods());
      }

      if ((response?.data as { [key: string]: any })?.journalHeader?.reverse === "T") {
        await dispatch(fetchManualJournalFinancialYear());
      }

      if (callback) callback();

      return response.data;
    } catch (error) {
      // Handle any errors that occur during the API call
      throw new Error("Failed to fetch manual journal details");
    }
  }
);

// Create an async thunk function to update the manual journal details
export const saveJournalDetails = createAsyncThunk(
  "manualJournalDetails/save",
  async ({ data, callback }: { data: KeyValueType; callback?: (data?: KeyValueType) => void }, thunkAPI) => {
    const { dispatch, getState } = thunkAPI;
    const state = getState() as RootState;
    const { manualJournalDetails } = state;
    const payloadData = {
      header: {
        ...manualJournalDetails.data?.journalHeader,
        bank_id: 0,
        period: data?.period_no,
        narrative: data?.narrative,
        bank_reference: undefined,
        reverse_year_id: 0,
        reverse_period_no: -1
      },
      journalLine: manualJournalDetails.data?.journalLines
    };

    try {
      // Make your axios API call here to update the manual journal details
      const response = await axios.post(`${apiRoot}/Manual-Journal/manual-journal-line-save`, payloadData);

      await dispatch(fetchPeriods());

      if ((response?.data as { [key: string]: any })?.journalHeader?.reverse === "T") {
        await dispatch(fetchManualJournalFinancialYear());
      }

      if (response.data && callback) {
        callback(response.data);
      }

      return response.data;
    } catch (error) {
      // Handle any errors that occur during the API call
      throw new Error("Failed to update manual journal details");
    }
  }
);

// Add the async thunk function to the reducers
const slice = createSlice({
  name: "manualJournalDetails",
  initialState,
  reducers: {
    // Define your actions and their corresponding reducers here
    setSelectedRow: (state, action: PayloadAction<RowType | undefined>) => {
      state.selectedRow = action.payload;
    },
    addJournalLine: (state, action: PayloadAction<any>) => {
      state.data.journalLines.push(action.payload);
      state.selectedRow = action.payload;
    },
    resetDetails: (state) => {
      state.data = initialState.data;
    }
  },
  extraReducers: (builder) => {
    builder.addCase(fetchManualJournalDetails.fulfilled, (state, action) => {
      // Handle the successful API response and update the state accordingly
      state.data = action.payload as any;
      state.status = STATUS.SUCCESS;
      state.error = null;
    });
    builder.addCase(fetchManualJournalDetails.pending, (state) => {
      // Handle the pending state while the API call is in progress
      state.status = STATUS.LOADING;
      state.error = null;
    });
    builder.addCase(fetchManualJournalDetails.rejected, (state, action) => {
      // Handle any errors that occur during the API call
      state.status = STATUS.FAILED;
      state.error = action.error.message || null;
    });
  }
});

// Export the actions and reducer
export const { actions: mjDetailsActions, reducer } = slice;
export default reducer;
