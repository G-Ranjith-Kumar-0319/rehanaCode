import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { AppDispatch, RootState } from "@/store/store"; // Adjust the import based on your project structure
import { apiRoot, client } from "@/config";
import { STATUS } from "@/types/UseStateType";
import { RowType } from "@/components/GridTableNew/GridTableNew";
/* eslint-disable camelcase */
export type PeriodRowType = {
  period_no: number;
  description: string;
  startDate: string;
};

type PeriodsState = {
  periods: PeriodRowType[];
  status: STATUS;
  error: string | null;
  selectedRow?: PeriodRowType;
  reversalPeriodRow?: PeriodRowType;
};

const initialState: PeriodsState = {
  periods: [],
  status: STATUS.IDLE,
  error: null
};

export const fetchPeriods = createAsyncThunk<PeriodRowType[], void, { rejectValue: string }>(
  "periods/fetchPeriods",
  async (_, thunkAPI) => {
    try {
      const response = await client.get(`${apiRoot}/Manual-Journal/open-periods`); // Adjust the API endpoint as necessary

      const data = response.data as PeriodRowType[];
      return data;
    } catch (error) {
      return thunkAPI.rejectWithValue("Network error");
    }
  }
);

const periodsSlice = createSlice({
  name: "manualJournalPeriods",
  initialState,
  reducers: {
    setSelectedRow: (state, actions: PayloadAction<PeriodRowType | undefined>) => {
      state.selectedRow = actions.payload;
    },
    setReversalPeriodRow: (state, actions: PayloadAction<PeriodRowType | undefined>) => {
      state.reversalPeriodRow = actions.payload;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchPeriods.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = null;
      })
      .addCase(fetchPeriods.fulfilled, (state, action: PayloadAction<PeriodRowType[]>) => {
        state.status = STATUS.SUCCESS;
        state.periods = action.payload;
      })
      .addCase(fetchPeriods.rejected, (state, action: PayloadAction<string | undefined>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload || "Failed to fetch periods";
      });
  }
});

export const { actions: mjPeriodssActions, reducer } = periodsSlice;
export default reducer;
