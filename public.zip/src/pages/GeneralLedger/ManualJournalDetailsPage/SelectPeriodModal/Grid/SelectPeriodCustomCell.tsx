import { cellRendererType } from "@/components/GridTable/GridTable";

const SelectPeriodCustomCell = ({ field, row }: cellRendererType) => {
  const getContent = () => {
    switch (field) {
      case "start_date":
        return (
          <>
            {new Date(row?.start_date).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })}
          </>
        );
      default: {
        return <div />;
      }
    }
  };
  return getContent();
};

export default SelectPeriodCustomCell;
