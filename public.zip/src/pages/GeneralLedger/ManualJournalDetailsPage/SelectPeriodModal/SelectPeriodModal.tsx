import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { actions } from "@/shared/components/LedgerCodesModal/state/LedgerCodes.slice";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import React, { useEffect, useState } from "react";
import { useFormContext } from "react-hook-form";
import { useDispatch } from "react-redux";
import BodyUtil from "@/shared/utils/NoScroll";
import SelectPeriodsColumnDef from "./Grid/SelectPeriodsColumnDef";
import { fetchPeriods, mjPeriodssActions, PeriodRowType } from "../../State/ManualJournalPeriods.slice";
import SelectPeriodsFilters from "./Grid/SelectPeriodsFilters";
import SelectPeriodCustomCell from "./Grid/SelectPeriodCustomCell";
import { periodsType } from "../ManualJournalDetailsPage";

type Period = {
  period: number;
  description: string;
  startDate: string;
};

type PropsType = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  id?: periodsType;
};

const SelectPeriodModal = ({ setOpen, isOpen, id }: PropsType) => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { periods, status, selectedRow, reversalPeriodRow } = useAppSelector((state) => state.manualJournalPeriods);
  const { data } = useAppSelector((state) => state.manualJournalDetails);
  const { setValue } = useFormContext();
  const [row, setRow] = useState<PeriodRowType | undefined>(
    id === periodsType.NORMAL ? selectedRow : reversalPeriodRow
  );
  const dataSource =
    id === periodsType.REVERSAL && selectedRow ? periods.filter((p) => p.period_no > selectedRow?.period_no!) : periods;

  const closeHandler = () => {
    setOpen(false);
  };

  useEffect(
    () => () => {
      BodyUtil.NoScroll.remove();
    },
    []
  );

  const selectHandler = () => {
    if (id === periodsType.NORMAL) {
      setValue("period_no", row?.period_no);
      dispatch(mjPeriodssActions.setSelectedRow(row));
    } else {
      setValue("period_no", row?.period_no);
      dispatch(mjPeriodssActions.setReversalPeriodRow(row));
    }
  };

  const tertiaryButton = (
    <HelpButton
      identifier="testIdentifier"
      labelName={t("common.help")}
    />
  );

  const secondaryButton = (
    <Button
      size={ButtonSize.Small}
      color={ButtonColor.Secondary}
      id="cancel-periods-button"
      onClick={closeHandler}
    >
      {t("common.cancel")}
    </Button>
  );

  const primaryButton = (
    <Button
      size={ButtonSize.Small}
      id="select-periods-button"
      onClick={() => {
        selectHandler();
        setOpen(false);
      }}
    >
      {t("common.select")}
    </Button>
  );

  return (
    <Modalv2
      header={
        id === periodsType.NORMAL ? t("manualJournalPage.selectPeriod") : t("manualJournalPage.selectReversalPeriod")
      }
      isOpen={isOpen}
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
      tertiaryButton={tertiaryButton}
      onClose={closeHandler}
    >
      <div>
        <GridTableNew
          dataTestId="selectPeriodsGrid"
          filters={
            <SelectPeriodsFilters
              selectRow={row}
              setSelectRow={setRow}
            />
          }
          customCell={SelectPeriodCustomCell}
          isScrollable
          enableScrollIntoView
          dataSource={dataSource}
          selectedRow={row}
          isLoading={status === STATUS.LOADING}
          columnDef={SelectPeriodsColumnDef}
          selectedRowHandler={(row) => setRow(row as any)}
          onEnterKeyPress={() => {
            selectHandler();
            setOpen(false);
          }}
        />
      </div>
    </Modalv2>
  );
};

SelectPeriodModal.defaultProps = {
  id: undefined
};

export default SelectPeriodModal;
