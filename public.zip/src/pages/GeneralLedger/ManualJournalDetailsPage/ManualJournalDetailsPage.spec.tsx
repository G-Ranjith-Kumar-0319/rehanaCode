import { PropsWithChildren } from "react";
import { render, queryByAttribute, act } from "@testing-library/react";
import ManualJournalDetailsPage from "@/pages/GeneralLedger/ManualJournalDetailsPage/ManualJournalDetailsPage";
import { Provider } from "react-redux";
import RouterProvider, { Router } from "react-router-dom";
import * as AppContext from "@/routes/Routes";
import axios from "axios";
import { createMemoryHistory } from "history";
import { setupStore } from "@/store/store";
import mocks from "@/shared/utils/test/fileMock";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn(),
  useLocation: () => ({
    pathname: "localhost:3002/UI/general-ledger/manual-journal-list/edit/3794",
    search: "",
    hash: "",
    state: {},
    key: "5nvxpbdafa"
  }),
  useHistory: () => ({
    push: jest.fn()
  })
}));

describe("ManualJournalDetailsPage", () => {
  beforeEach(() => {
    const contextValue = {
      resolve: jest.fn(),
      setPromise: jest.fn(),
      redirectToPurchaseOrderLink: jest.fn(),
      redirectToInvoiceDetailsLink: jest.fn(),
      redirectToBankReconciledDetails: jest.fn(),
      redirectToManualJournalDetails: jest.fn(),
      globalPaths: [],
      setGlobalPaths: jest.fn(),
      translate: jest.fn(),
      setTitle: jest.fn(),
      title: "test"
    };

    jest.spyOn(RouterProvider, "useParams").mockReturnValue({ voucherId: "1" });
    jest.spyOn(AppContext, "useAppContext").mockReturnValue(contextValue);
  });
  const getById: any = queryByAttribute.bind(null, "id");

  it("should render the component", async () => {
    const preloadedState = {};
    const store = setupStore(preloadedState);
    jest.spyOn(axios, "get").mockResolvedValueOnce({
      data: mocks.manualJournalDetailsResponse,
      status: 200
    });

    const Wrapper = ({ children }: PropsWithChildren) => <Provider store={store}>{children}</Provider>;
    const history = createMemoryHistory({ initialEntries: ["/"] });

    const { getByTestId } = render(
      <Wrapper>
        <Router history={history}>
          <ManualJournalDetailsPage />
        </Router>
      </Wrapper>
    );
    await act(
      () =>
        new Promise((resolve) => {
          setTimeout(resolve, 20);
        })
    );
    expect(axios.get).toHaveBeenCalledWith("/api/v1/Manual-Journal/journal-details", { params: { voucherId: "1" } });
    expect(axios.get).toHaveBeenCalledWith("/api/v1/Manual-Journal/open-periods");
  });
});
