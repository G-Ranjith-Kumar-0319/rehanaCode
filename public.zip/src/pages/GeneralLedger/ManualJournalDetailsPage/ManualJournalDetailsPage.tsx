import React, { useState, useEffect } from "react";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import {
  Grid,
  GridItem,
  FormLabel,
  Button,
  ButtonColor,
  ButtonSize,
  Icon,
  IconColor,
  IconSize,
  Divider,
  Loader,
  LoaderType,
  Dropdown,
  DropdownItem,
  TextInputSize,
  ISelectedItem
} from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useParams } from "react-router-dom";
import { AppDispatch, useAppSelector } from "@/store/store";
import { specialCharacters, STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { usNumberFormat } from "@/utils/getDataSource";
import ManualJournalPageToolbar from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalPageToolbar";
import ManualJournalToolbar from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalToolbar";
import { actions as mjTypeActions } from "@/pages/ManualJournalProcessing/SelectManualJournalType/JournalType/ManualJournalTypeStatus.slice";
import { useAppContext } from "@/routes/Routes";
import SelectPeriodModal from "./SelectPeriodModal/SelectPeriodModal";
import CustomCell from "./Grid/CustomCell";
import { fetchManualJournalDetails, mjDetailsActions, saveJournalDetails } from "../State/ManualJournalDetails.slice";
import ManualJournalFilters from "./Grid/ManualJournalFilters";
import manualJournalColumnDef from "./Grid/manualJournalColumnDef";
import { mjPeriodssActions } from "../State/ManualJournalPeriods.slice";
import { mjFinancialYearActions } from "../State/ManualJournalFinancialYears.slice";
import "./ManualJournalDetailsPage.style.scss";

export enum periodsType {
  NORMAL = "NORMAL",
  REVERSAL = "REVERSAL"
}

const ManualJournalDetailsPage = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { voucherId } = useParams<{ voucherId: string }>();
  const status = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.status);
  const pStatus = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.status);
  const data = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.data);
  const selectedRow = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.selectedRow);
  const periodRow = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.selectedRow);
  const periods = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.periods);
  const reversalPeriodRow = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.reversalPeriodRow);
  const { selectedView: templateView } = useAppSelector((state) => state.manualJournalType);
  const [title, setTitle] = useState<string>();
  const [isFinYearEnabled, setIsFinYearEnabled] = useState<boolean>(false);
  const { data: financialYears, selectedView } = useAppSelector((state) => state.manualJournalFinancialYears);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [id, setId] = useState<periodsType>();
  const difference = Math.abs(
    (data?.journalLines ?? []).reduce((acc: any, curr: any) => acc + curr.debit - curr.credit, 0)
  );
  const formattedDifference = usNumberFormat(difference);
  const credit = (data?.journalLines ?? []).reduce((acc: any, curr: any) => acc + Number(curr.credit), 0);
  const debit = (data?.journalLines ?? []).reduce((acc: any, curr: any) => acc + Number(curr.debit), 0);
  const getBalance = () => {
    let balance;

    if (formattedDifference !== "0.00") {
      balance = formattedDifference;
    } else if (credit !== 0 && debit !== 0 && credit === debit && data?.journalLines?.length) {
      balance = t("manualJournalPage.balanced");
    } else {
      balance = t("manualJournalPage.noValues");
    }

    return balance;
  };

  const formMethods = useForm({
    defaultValues: {
      narrative: "",
      period_no: "",
      period_description: "",
      reversal_year: ""
    },
    values: {
      narrative: data?.journalHeader?.narrative,
      period_no: selectedRow?.period_no,
      period_description: selectedRow?.description,
      reversal_period_no: reversalPeriodRow?.period_no,
      reversal_description: reversalPeriodRow?.description,
      reversal_year: data?.reversalYear,
      year: data?.year
    }
  });

  const {
    control,
    handleSubmit,
    setValue,
    formState: { isDirty },
    reset
  } = formMethods;

  const periodOnClickHandler = () => {
    setIsOpen(true);
    setId(periodsType.NORMAL);
  };

  useEffect(() => {
    if (pStatus === STATUS.SUCCESS && status === STATUS.SUCCESS) {
      if (data?.journalHeader?.template === "F") {
        const normalPeriod = periods.find((period) => period.period_no === data?.journalHeader?.period);
        dispatch(mjPeriodssActions.setSelectedRow(normalPeriod));
        setValue("period_no", normalPeriod?.period_no);
        setValue("period_description", normalPeriod?.description);
        const newYear = (financialYears || []).find((year) => year.year_des === data?.reversalYear);
        dispatch(
          mjFinancialYearActions.setSelectedView({
            text: newYear?.year_des,
            value: newYear?.year_id
          })
        );
      }

      if (templateView.value !== "") {
        setValue("narrative", data?.journalHeader?.narrative, { shouldDirty: true });
        dispatch(
          mjTypeActions.setManualJournalTypeView({
            text: "",
            value: ""
          })
        );
      }

      setTitle(
        data?.journalHeader?.reverse === "T"
          ? t("manualJournalPage.reversingJournal")
          : t("manualJournalPage.normalTemplate")
      );
    }
  }, [pStatus, status]);

  useEffect(() => {
    const reversalPeriods = periods.filter((p) => p.period_no > periodRow?.period_no!);
    if (data?.journalHeader?.reverse === "T" && periodRow && reversalPeriods.indexOf(reversalPeriodRow!) === -1) {
      const reversalPeriod = periods.at(periods.indexOf(periodRow) + 1);
      dispatch(mjPeriodssActions.setReversalPeriodRow(reversalPeriod));
    }
  }, [periodRow]);

  useEffect(
    () => () => {
      dispatch(mjDetailsActions.setSelectedRow(undefined));
      // dispatch(mjDetailsActions.resetDetails());
    },
    []
  );

  useEffect(() => {
    if (financialYears?.length) {
      const selectedFinancialYear = financialYears.find(
        (f) => f?.sequence === Number(getCurrentFinancialYear() ?? "0") + 1
      );
      const isDisabled = !(
        selectedFinancialYear?.year_des !== "" &&
        selectedFinancialYear?.year_state === "S" &&
        selectedFinancialYear?.lowest_gl < selectedFinancialYear?.no_periods
      );
      setIsFinYearEnabled(isDisabled);
    }
  }, [financialYears]);

  const onSubmit = async (isRedirect?: boolean) => {
    let isError = false;
    const submit = handleSubmit(async (data) => {
      const result = await dispatch(saveJournalDetails({ data }));
      if (result?.type !== "manualJournalDetails/save/fulfilled") {
        isError = true;
      }
    });

    await submit();

    if (!isError) {
      reset();
    }

    if (!isRedirect) {
      await dispatch(fetchManualJournalDetails({ voucherId, templateVoucherId: templateView?.value }));
    }

    return isError;
  };

  return (
    <>
      {pStatus === STATUS.LOADING || status === STATUS.LOADING ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        <FormProvider {...formMethods}>
          <Layout
            className="manual-journal-details"
            pageTitle={title}
            rightContent={
              <ManualJournalToolbar
                onSubmit={onSubmit}
                isDirty={isDirty}
              />
            }
            toolbar={<ManualJournalPageToolbar />}
            dataTestId="manaalJournalDetails-page"
          >
            <Grid className="row-gap-16">
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
              >
                <div>
                  <div className="essui-form-label">{t("manualJournalPage.year")}</div>
                  <div className="height__equal--input">{data?.year}</div>
                </div>
              </GridItem>

              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
              >
                <div>
                  <Grid>
                    <GridItem>
                      <Input
                        id="period-no-input"
                        labelText={t("manualJournalPage.period")}
                        inputWidth={45}
                        searchable
                        searchItems={periods.map((period) => ({
                          value: String(period.description),
                          text: String(period.period_no)
                        }))}
                        value={String(periodRow?.period_no || "")}
                        disabled={data?.journalHeader?.temp_no !== null || data?.journalHeader?.template !== "F"}
                        onPending={(selectedItem, index) => {
                          if (index !== undefined) {
                            setValue("period_no", periods.at(index!)?.period_no, { shouldDirty: true });
                            setValue("period_description", periods.at(index!)?.description, { shouldDirty: true });
                            dispatch(mjPeriodssActions.setSelectedRow(periods.at(index!)));
                          } else {
                            setValue("period_no", "", { shouldDirty: true });
                            setValue("period_description", "", { shouldDirty: true });
                            dispatch(mjPeriodssActions.setSelectedRow(undefined));
                          }
                        }}
                        onNoSelection={() => {
                          setId(periodsType.NORMAL);
                          setIsOpen(true);
                        }}
                        button={
                          <>
                            <Input
                              readOnly
                              disabled
                              id="period-description-input"
                              inputWidth={55}
                              value={periodRow?.description ?? ""}
                              className="read-only"
                            />
                            <Button
                              color={ButtonColor.Secondary}
                              onClick={periodOnClickHandler}
                              className="essui-button-icon-only--small"
                              id="period-no-button"
                              size={ButtonSize.Small}
                              aria-label="search"
                              disabled={data?.journalHeader?.temp_no !== null || data?.journalHeader?.template === "T"}
                            >
                              <Icon
                                color={IconColor.Primary500}
                                size={IconSize.Medium}
                                name="search"
                              />
                            </Button>
                          </>
                        }
                      />
                    </GridItem>
                  </Grid>
                </div>
              </GridItem>
              {data?.journalHeader?.temp_no ? (
                <GridItem
                  sm={4}
                  md={2}
                  lg={2}
                  xl={2}
                >
                  <div>
                    <div className="essui-form-label">{t("manualJournalPage.number")}</div>
                    <div className="height__equal--input">{data?.journalHeader?.temp_no}</div>
                  </div>
                </GridItem>
              ) : null}

              <GridItem
                sm={4}
                md={data?.journalHeader?.temp_no !== null ? 6 : 8}
                lg={data?.journalHeader?.temp_no !== null ? 6 : 8}
                xl={data?.journalHeader?.temp_no !== null ? 6 : 8}
              >
                <div>
                  <Controller
                    render={({ field }) => (
                      <Input
                        id="narrative-input"
                        labelText={t("manualJournalPage.narrative")}
                        maxLength={60}
                        isViewOnly={data?.journalHeader?.temp_no !== null}
                        {...field}
                      />
                    )}
                    name="narrative"
                    control={control}
                  />
                </div>
              </GridItem>
              {data?.journalHeader?.reverse === "T" ? (
                <>
                  <GridItem
                    sm={4}
                    md={2}
                    lg={2}
                    xl={2}
                  >
                    <div>
                      <FormLabel forId="reversal-year-dropdown">{t("manualJournalPage.reversalYear")}</FormLabel>
                      <Dropdown
                        id="reversal-year-dropdown"
                        className="manual-journal-details__dropdown"
                        size={TextInputSize.Medium}
                        searchable
                        selectedItem={selectedView}
                        isScrollbarVisible
                        onSelect={(e: React.SyntheticEvent, item: ISelectedItem) =>
                          dispatch(mjFinancialYearActions.setSelectedView(item))
                        }
                        scrollbarHeight={Number(data?.journalLines || 0) <= 3 ? 120 : undefined}
                        disabled={data?.journalHeader?.temp_no !== null || isFinYearEnabled}
                      >
                        {(financialYears || []).map((view: { [key: string]: string }, i: any) => {
                          const id = `dropdown-${i}`;
                          return (
                            <DropdownItem
                              key={id}
                              id={id}
                              text={view.year_des}
                              value={view.year_id}
                            >
                              {view.year_des}
                            </DropdownItem>
                          );
                        })}
                      </Dropdown>
                    </div>
                  </GridItem>
                  <GridItem
                    sm={4}
                    md={2}
                    lg={2}
                    xl={2}
                  >
                    <div>
                      <Grid>
                        <GridItem>
                          <Input
                            id="reversal-period-no-input"
                            searchable
                            searchItems={periods.map((period) => ({
                              value: String(period.description),
                              text: String(period.period_no)
                            }))}
                            labelText={t("manualJournalPage.period")}
                            inputWidth={45}
                            value={String(reversalPeriodRow?.period_no || "")}
                            disabled={data?.journalHeader?.temp_no !== null}
                            onPending={(selectedItem, index) => {
                              if (index !== undefined) {
                                dispatch(mjPeriodssActions.setReversalPeriodRow(periods.at(index!)));
                              } else {
                                dispatch(mjPeriodssActions.setReversalPeriodRow(undefined));
                              }
                            }}
                            button={
                              <>
                                <Input
                                  readOnly
                                  disabled
                                  id="reversal-period-description-input"
                                  searchable={false}
                                  inputWidth={55}
                                  value={reversalPeriodRow?.description}
                                  className="read-only"
                                />
                                <Button
                                  color={ButtonColor.Secondary}
                                  onClick={() => {
                                    setId(periodsType.REVERSAL);
                                    setIsOpen(true);
                                  }}
                                  id="reversal-period-no-button"
                                  className="essui-button-icon-only--small"
                                  size={ButtonSize.Small}
                                  aria-label="search"
                                  disabled={data?.journalHeader?.temp_no !== null}
                                >
                                  <Icon
                                    color={IconColor.Primary500}
                                    size={IconSize.Medium}
                                    name="search"
                                  />
                                </Button>
                              </>
                            }
                          />
                        </GridItem>
                      </Grid>
                    </div>
                  </GridItem>
                  {data?.contra_no ? (
                    <GridItem
                      sm={4}
                      md={2}
                      lg={2}
                      xl={2}
                    >
                      <div>
                        <div className="essui-form-label">{t("manualJournalPage.contraNo")}</div>
                        <div className="height__equal--input">
                          {data?.contra_no ? data?.contra_no : specialCharacters.HYPHEN}
                        </div>
                      </div>
                    </GridItem>
                  ) : null}
                </>
              ) : null}
            </Grid>
          </Layout>

          <Layout
            isBreadcrumbRequired={false}
            type="transparent"
            className="manual-journal-details__grid"
          >
            <GridTableNew
              id="journalLinesGrid"
              dataTestId="journalLinesGrid"
              customCell={CustomCell}
              filters={<ManualJournalFilters />}
              columnDef={manualJournalColumnDef}
              dataSource={data?.journalLines ?? []}
              isLoading={false}
              selectedRow={selectedRow}
              isScrollable
              selectedRowHandler={(row) => {
                dispatch(mjDetailsActions.setSelectedRow(row));
              }}
            />
          </Layout>

          <Layout isBreadcrumbRequired={false}>
            <div className="container">
              <Grid className="row-gap-16">
                <GridItem
                  lg={12}
                  md={12}
                  sm={4}
                  xl={12}
                  xxl={12}
                >
                  <div>
                    <div className="essui-form-label mb-5">{t("manualJournalPage.narrative")}</div>
                    <div>{selectedRow?.narrative ? selectedRow?.narrative : specialCharacters.HYPHEN}</div>
                  </div>
                </GridItem>
              </Grid>
              <div className="mb-16 mt-16">
                <Divider />
              </div>
              <Grid className="row-gap-16">
                <GridItem
                  lg={3}
                  md={3}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div>
                    <div className="essui-form-label mb-5">{t("manualJournalPage.balance")}</div>
                    <div>{getBalance()}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={3}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div>
                    <div className="essui-form-label mb-5">{t("manualJournalPage.totalDebits")}</div>
                    <div>{usNumberFormat(debit ?? specialCharacters.zero)}</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={3}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div>
                    <div className="essui-form-label mb-5">{t("manualJournalPage.totalCredits")}</div>
                    <div>{usNumberFormat(credit ?? specialCharacters.zero)}</div>
                  </div>
                </GridItem>
              </Grid>
            </div>
            {isOpen && (
              <SelectPeriodModal
                isOpen={isOpen}
                setOpen={(flag) => {
                  setIsOpen(flag);
                  if (!flag) {
                    setId(undefined);
                  }
                }}
                id={id}
              />
            )}
          </Layout>
        </FormProvider>
      )}
    </>
  );
};

export default ManualJournalDetailsPage;
