import { useAppSelector } from "@/store/store";
import { AddLarge } from "@carbon/icons-react";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { Grid, GridItem, Button, ButtonSize, NotificationStatus, FormLabel, ButtonColor } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";

const ManualJournalFilters = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { data } = useAppSelector((state) => state.manualJournalDetails);

  return (
    <Grid justify="space-between">
      <GridItem>
        <h2 className="essui-global-typography-default-subtitle">{t("manualJournalPage.journalLines")}</h2>
      </GridItem>
      <GridItem>
        <Button
          // className="essui-button essui-button--utility essui-button--small br-0"
          className="br-0"
          id="manual-journal-addNewLine"
          size={ButtonSize.Small}
          color={ButtonColor.Utility}
          title={t("purchaseOrder.addNewLine")}
          aria-label={t("purchaseOrder.addNewLineAriaText")}
          onClick={() => {
            history.push({
              pathname: `${history.location.pathname}/journal-line/add`,
              state: { ...historyState, voucherType: data?.journalHeader?.voucher_type }
            });
          }}
          disabled={data?.journalHeader?.temp_no !== null}
        >
          <AddLarge
            size="18"
            // color="black"
          />
        </Button>
      </GridItem>
    </Grid>
  );
};

export default ManualJournalFilters;
