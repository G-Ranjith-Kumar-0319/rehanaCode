import GridRowActions, { OptionsType } from "@/components/GridRowActions/GridRowActions";
import { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import { usNumberFormat } from "@/utils/getDataSource";
import { Icon, IconSize, ISelectedItem } from "@essnextgen/ui-kit";
import React, { ReactNode, SyntheticEvent, useState } from "react";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { useHistory } from "react-router-dom";

type clickHandlerType = (e: SyntheticEvent, selectedItem: ISelectedItem) => void;

const CustomCell: React.FC<cellRendererType> = ({ field, row }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { data } = useAppSelector((state) => state.manualJournalDetails);
  const history = useHistory();

  const options = [
    {
      text: "editLine",
      value: "editLine",
      disabled: data?.journalHeader?.temp_no !== null,
      children: <RowAction optionName={t("manualJournalPage.editLine")} />
    },
    {
      text: "deleteLine",
      value: "deleteLine",
      disabled: data?.journalHeader?.temp_no !== null,
      children: <RowAction optionName={t("manualJournalPage.deleteLine")} />
    }
  ];

  const orderLineActionHandler: clickHandlerType = async (e, selectedItem) => {
    switch (selectedItem.value) {
      case "editLine":
        history.push(`/general-ledger/manual-journal-list/edit/${row?.voucher_id}/line/${row?.voucher_line_id}`);
        break;
      case "deleteLine":
        // TODO: Implement delete line
        break;
      default:
        break;
    }
  };

  const getContent = () => {
    switch (field) {
      case "debit":
        return <>{usNumberFormat(row?.debit)}</>;
      case "credit":
        return <>{usNumberFormat(row?.credit)}</>;
      case "actions":
        return (
          <GridRowActions
            name={
              <Icon
                size={IconSize.Medium}
                name="overflow-menu--horizontal"
              />
            }
            options={options}
            onClick={orderLineActionHandler}
            selectedRow={row}
          />
        );
      default:
        return null;
    }
  };
  return getContent();
};

export default CustomCell;

type OptionProps = {
  iconName?: string;
  optionName: string;
  children?: ReactNode;
};
const RowAction = ({ iconName, optionName, children }: OptionProps) => (
  <div className="option">
    {iconName ? (
      <Icon
        size={IconSize.Medium}
        name={iconName}
      />
    ) : (
      children
    )}
    {optionName}
  </div>
);

RowAction.defaultProps = {
  iconName: undefined,
  children: undefined
};
