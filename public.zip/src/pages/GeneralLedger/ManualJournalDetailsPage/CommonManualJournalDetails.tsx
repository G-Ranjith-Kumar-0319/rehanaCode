import { useEffect } from "react";
import { useHistory, useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { JournalEditorMode } from "@/pages/ManualJournalProcessing/SelectManualJournalType/ManualJournalPageToolbar";
import { Loader, LoaderType } from "@essnextgen/ui-kit";
import { specialCharacters, STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import ManualJournalDetailsPage from "./ManualJournalDetailsPage";
import { fetchManualJournalDetails, mjDetailsActions } from "../State/ManualJournalDetails.slice";

const CommonManualJournalDetails = () => {
  const { voucherId } = useParams<{ voucherId: string }>();
  const dispatch = useDispatch();
  const { data } = useAppSelector((state) => state.manualJournalDetails);
  const { selectedView: templateView } = useAppSelector((state) => state.manualJournalType);
  const status = useAppSelector(({ manualJournalDetails }) => manualJournalDetails.status);
  const pStatus = useAppSelector(({ manualJournalPeriods }) => manualJournalPeriods.status);

  useEffect(() => {
    if (!data.journalHeader) {
      dispatch(fetchManualJournalDetails({ voucherId, templateVoucherId: templateView?.value }));
    }
  }, []);

  const getPage = () => {
    switch (data?.journalHeader?.voucher_type) {
      case JournalEditorMode.jvNormal:
        return <ManualJournalDetailsPage />;
      case JournalEditorMode.jvCashBook:
        return <>Cash book</>;

      default:
        return <>NO Page</>;
    }
  };

  return (
    <>
      {pStatus === STATUS.LOADING || status === STATUS.LOADING ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        getPage()
      )}
    </>
  );
};

export default CommonManualJournalDetails;
