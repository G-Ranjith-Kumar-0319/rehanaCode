import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  Dialog,
  DialogContent,
  DialogFooter,
  FormLabel,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import Input from "@/components/Input/Input";

const DeliveryLineDetailsModal = () => (
  <Dialog
    dataTestId="test-id"
    escapeExits
    id="element-id"
    returnFocusOnDeactivate
    title="Delivery Line Details"
    className="dialog__divider modal__align--set"
  >
    <DialogContent>
      <div className="overflow-hidden">
        <Grid
          container
          className="row-gap-16"
        >
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="essui-form-label mb-5">Part Number</div>
            <div>001</div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="essui-form-label mb-5">Item Description</div>
            <div>Test Description</div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="essui-form-label mb-5">Quantity Ordered</div>
            <div>250</div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="essui-form-label mb-5">Quantity Outstanding</div>
            <div>50</div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="essui-form-label mb-5">Quantity Delivered</div>
            <div>200</div>
          </GridItem>
        </Grid>
      </div>
    </DialogContent>
    <DialogFooter>
      <Grid container>
        <GridItem
          sm={2}
          md={4}
          lg={6}
          xl={6}
        >
          <HelpButton
            identifier="testIdentifier"
            labelName="Help"
          />
        </GridItem>
        <GridItem
          sm={2}
          md={4}
          lg={6}
          xl={6}
          className="d-flex justify-end"
        >
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Primary}
          >
            Close
          </Button>
        </GridItem>
      </Grid>
    </DialogFooter>
  </Dialog>
);

export default DeliveryLineDetailsModal;
