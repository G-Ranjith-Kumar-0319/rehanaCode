import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  Orientation,
  Tag,
  TagColor,
  TagSize,
  Textarea
} from "@essnextgen/ui-kit";
import "./Style.scss";

const AddDelivery = () => (
  <>
    <Layout
      pageTitle="Add Delivery"
      className="add__delivery"
      isBreadcrumbRequired
    >
      <Grid className="row-gap-16">
        <GridItem
          sm={4}
          md={3}
          lg={3}
          xl={3}
          className="border-right"
        >
          <Grid className="row-gap-8">
            <GridItem
              sm={4}
              md={8}
              lg={12}
              xl={12}
            >
              <FormLabel forId="txtsupplier">Supplier</FormLabel>
              <Input
                id="txtsupplier"
                searchable
                value="British Gas"
                button={
                  <Button
                    color={ButtonColor.Secondary}
                    size={ButtonSize.Small}
                    className="essui-button-icon-only--small"
                    ariaLabel="search"
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                }
              />
            </GridItem>
            <GridItem
              lg={12}
              xl={12}
            >
              <div className="essui-form-label mb-5">Tower Point</div>
              <div>
                <p className="m-0">Enfield</p>
                <p className="m-0">London</p>
              </div>
            </GridItem>
          </Grid>
        </GridItem>
        <GridItem
          sm={4}
          md={5}
          lg={9}
          xl={9}
        >
          <Grid className="row-gap-8">
            <GridItem
              sm={4}
              md={8}
              lg={4}
              xl={4}
            >
              <FormLabel forId="txtDeliveryDate">Delivery Date</FormLabel>
              <Input
                id="txtDeliveryDate"
                button={
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    className="essui-button-icon-only--small"
                    ariaLabel="search"
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="calendar"
                    />
                  </Button>
                }
                searchable
                value="20/04/2024"
                className="w-100"
              />
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={4}
              xl={4}
            >
              <FormLabel forId="txtDeliveryNoteDate">Delivery Note Date</FormLabel>
              <Input
                id="txtDeliveryNoteDate"
                button={
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    className="essui-button-icon-only--small"
                    ariaLabel="search"
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="calendar"
                    />
                  </Button>
                }
                searchable
                value="29/01/2024"
                className="w-100"
              />
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={4}
              xl={4}
            >
              <div className="essui-form-label mb-5">Delivery Note ID</div>
              <div className="input-value">-</div>
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={4}
              xl={4}
            >
              <FormLabel forId="txtDeliveryNoteNumber">Delivery Note Number</FormLabel>
              <Input
                id="txtDeliveryNoteNumber"
                searchable
                value="123"
                className="w-100"
              />
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={4}
              xl={4}
            >
              <FormLabel forId="txtOrderNumber">Order Number</FormLabel>
              <Input
                id="txtOrderNumber"
                searchable
                value="BANK012166"
                button={
                  <Button
                    color={ButtonColor.Secondary}
                    size={ButtonSize.Small}
                    className="essui-button-icon-only--small"
                    ariaLabel="search"
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                }
              />
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={12}
              xl={12}
            >
              <FormLabel forId="txtNotes">Notes</FormLabel>
              <Input
                id="txtNotes"
                className="w-100 read-only"
                readOnly
                button={
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    className="essui-button-icon-only--small"
                    ariaLabel="editAlt"
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="edit--alt"
                    />
                  </Button>
                }
                searchable
                value="Test Note"
              />
            </GridItem>
          </Grid>
        </GridItem>
      </Grid>
    </Layout>
  </>
);

export default AddDelivery;
