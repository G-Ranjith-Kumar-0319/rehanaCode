import GridTableNew from "@/components/GridTableNew/GridTableNew";
import "../FundDefinition/FundCodeStyle.scss";
import { Grid, GridItem, Icon, IconSize } from "@essnextgen/ui-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import {
  generalLedgerFuncCodeAction,
  generalLedgerFundCodeAddEdit,
  getFundCodeListingData,
  getNextYear,
  getPrevState,
  getPreviousYear
} from "@/pages/GeneralLedgerSetup/State/GeneralLedgerFundCodeListing.slice";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { CARBON_ICON, METHOD, STATUS } from "@/types/UseStateType";
import { useHistory } from "react-router-dom";
import CustomCell from "./FundCodeCustomCell";
import FundCodeListingColumnDef from "../Grid/ColumnDefs";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import FundCodeFilter from "./FundCodeFilter";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import useLedgerGrpPopup from "../../hooks/useLedgerGrpPopup";

const FundCodeListing = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { fundCodeList, status, newFundList, selectedRow, finalFundCodeList, previousYear, nextYear, previousState } =
    useAppSelector((state: any) => state.generalLedgerFundCode);
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [newFundCodeList, setNewFundCodeList] = useState(fundCodeList);
  const { setSelectedRow, emptyNewFundList, setFinalFundCodeList } = generalLedgerFuncCodeAction;
  const history = useHistory();
  const { setTabData } = useLedgerGrpPopup();
  const {
    location: { pathname: historyPathname }
  } = history;

  useEffect(() => {
    dispatch(
      getFundCodeListingData({
        callback: (res: any) => {}
      })
    );
  }, []);

  const mergeArr = (arrOne: any, arrTwo: any) => {
    if (arrTwo.length > 0) {
      /** This line will check the duplicate into arrTwo then replace the arrOne
       * record if existing fund_code will be found, after that it will merge
       * the new record and remvoe the existing fund_code record from the arrOne */
      const newArrayLookup = arrTwo.reduce((acc: any, obj: any) => {
        acc[obj.fund_code] = obj;
        return acc;
      }, {});
      /* eslint-disable camelcase */
      const updatedArray = arrOne.map((oldObj: { fund_code: string | number }) => {
        const newObj = newArrayLookup[oldObj.fund_code];
        if (newObj) {
          delete newArrayLookup[oldObj.fund_code]; // Remove the object from lookup once used
          return newObj;
        }
        return oldObj;
      });

      const remainingNewArray = Object.values(newArrayLookup);
      const newArr = updatedArray.concat(remainingNewArray);
      setNewFundCodeList([...newArr]);
      dispatch(setFinalFundCodeList(newArr));
    } else {
      setNewFundCodeList([...arrOne]);
      dispatch(setFinalFundCodeList(arrOne));
    }
  };

  useEffect(() => {
    if (newFundList?.length > 0) {
      mergeArr(newFundCodeList, newFundList);
    }
  }, [newFundList]);

  useEffect(() => {
    if (fundCodeList?.length > 0) {
      mergeArr(fundCodeList, newFundList);
    }
  }, [fundCodeList]);

  useEffect(() => {
    if (selectedRow === undefined) {
      dispatch(setSelectedRow(newFundCodeList.at(0)));
    } else {
      const found = newFundList.filter(
        (t: any) => t.ledger_des.toLowerCase() === selectedRow?.ledger_des.toLowerCase()
      )[0];
      dispatch(
        setSelectedRow(
          found === undefined
            ? finalFundCodeList.find((t: any) => t.ledger_des.toLowerCase() === selectedRow?.ledger_des.toLowerCase())
            : found
        )
      );
      setTimeout(() => {
        const element = document.getElementById(
          `rowIndex-generalLedgerFundCodeList-${newFundCodeList.findIndex(
            (val: any) => val.fund_code === found?.fund_code!
          )}`
        );
        element?.scrollIntoView({ block: "center", behavior: "smooth" });
      }, 1000);
    }
  }, [newFundCodeList, newFundList, finalFundCodeList]);

  const submitHandler = () => {
    dispatch(
      generalLedgerFundCodeAddEdit({
        callback: (res: any) => {
          if (res?.validationType === 0) {
            dispatch(emptyNewFundList());
          }
        }
      })
    );
  };

  // Get "Next Year/Prev Year/Prev State" on load
  useEffect(() => {
    if (!previousState) dispatch(getPrevState());
    if (!nextYear) dispatch(getNextYear());
    if (!previousYear) dispatch(getPreviousYear());
  }, []);
  //

  const handleCancel = () => {
    setTabData("/");
  };

  return (
    <>
      <GeneralLedgerSetup>
        <div className="general-ledger-listing-container general-ledger-scroll-height">
          <Grid container>
            <GridItem
              sm={12}
              md={12}
              lg={12}
              xl={12}
            >
              <GridTableNew
                dataTestId="generalLedgerFundCodeList"
                filters={<FundCodeFilter />}
                dataSource={finalFundCodeList || []}
                isLoading={status === STATUS.LOADING}
                columnDef={FundCodeListingColumnDef}
                selectedRow={selectedRow}
                isRowSelectionEnabled
                isScrollable
                customCell={CustomCell}
                selectedRowHandler={(row) => {}}
              />
            </GridItem>
          </Grid>
        </div>
        <GenralLedgerFooter
          cancelCallback={handleCancel}
          onSubmit={submitHandler}
        />
      </GeneralLedgerSetup>
    </>
  );
};
export default FundCodeListing;
