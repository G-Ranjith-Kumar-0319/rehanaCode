import GridRowActions, { OptionsType } from "@/components/GridRowActions/GridRowActions";
import { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import { useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { Icon, IconSize } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { generalLedgerFuncCodeAction } from "../../State/GeneralLedgerFundCodeListing.slice";

const FundCodeCustomCell = ({ field, row }: cellRendererType) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { setSelectedRow } = generalLedgerFuncCodeAction;

  const onActionHandler = (e: any, action: any) => {
    if (action?.text === "edit") {
      dispatch(setSelectedRow(row));
      history.push(`/tools/fund-codes/edit/${row?.fund_id}`);
    }
  };
  const options: OptionsType[] = [
    {
      text: "edit",
      value: "edit",
      children: <div className="option">{t("generalLedgerSetup.edit")}</div>
    },
    {
      text: "delete",
      value: "delete",
      disabled: true,
      children: <div className="option">{t("generalLedgerSetup.delete")}</div>
    }
  ];

  const getContent = () => (
    <GridRowActions
      name={
        <Icon
          size={IconSize.Medium}
          name="overflow-menu--horizontal"
        />
      }
      options={options}
      onClick={onActionHandler}
    />
  );

  return getContent();
};

export default FundCodeCustomCell;
