import { Grid, GridItem, ButtonSize, Button } from "@essnextgen/ui-kit";
import { AddLarge } from "@carbon/icons-react";
import { CARBON_ICON } from "@/types/UseStateType";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useHistory } from "react-router-dom";
import { useEffect } from "react";

const FundCodeFilter = () => {
  const history = useHistory();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();

  const handleAddEditFundCode = () => {
    history.push("/tools/fund-codes/add");
  };
  useEffect(() => {
    setTimeout(() => {
      document.getElementById("glfc-add-btn")?.focus();
    }, 100);
  }, []);
  return (
    <Grid>
      <GridItem
        md={12}
        lg={12}
        xl={12}
        className="btn-container"
      >
        <Button
          onClick={() => handleAddEditFundCode()}
          size={ButtonSize.Small}
          title={t("generalLedgerSetup.fundCode.title")}
          id="glfc-add-btn"
          className="essui-button essui-button--utility essui-button--small br-0 focus-active"
        >
          <AddLarge
            size={CARBON_ICON.SIZE}
            color={CARBON_ICON.COLOR_BLACK}
          />
        </Button>
      </GridItem>
    </Grid>
  );
};

export default FundCodeFilter;
