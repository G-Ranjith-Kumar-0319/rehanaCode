import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import { Button, ButtonColor, ButtonSize, CheckBox, FormLabel, Grid, GridItem } from "@essnextgen/ui-kit";

const FundDefinition = () => (
  <Layout pageTitle="Fund Codes">
    <Grid className="mb-16">
      <GridItem sm={4}>
        <div className="essui-global-typography-default-subtitle">Fund Definition</div>
      </GridItem>
    </Grid>

    <Grid className="mb-8">
      <GridItem
        sm={4}
        md={1}
        lg={1}
        xl={1}
      >
        <div>
          <FormLabel forId="txtFundCode">Fund Code</FormLabel>
          <Input
            value=""
            searchable
            id="txtFundCode"
          />
        </div>
      </GridItem>
    </Grid>

    <Grid className="mb-8">
      <GridItem
        sm={4}
        md={3}
        lg={3}
        xl={3}
      >
        <div>
          <FormLabel forId="txtDescription">Description</FormLabel>
          <Input
            value=""
            searchable
            id="txtDescription"
          />
        </div>
      </GridItem>
    </Grid>

    <Grid className="mb-8">
      <GridItem
        sm={4}
        md={2}
        lg={2}
        xl={2}
      >
        <div>
          <FormLabel forId="txtLaCode">LA Code</FormLabel>
          <Input
            value=""
            searchable
            id="txtLaCode"
          />
        </div>
      </GridItem>
    </Grid>

    <Grid className="mb-8">
      <GridItem
        sm={4}
        md={3}
        lg={3}
        xl={3}
      >
        <div className="midchkbox">
          <CheckBox
            label="Exclude Fund from CFR"
            id="txtCheck"
          />
        </div>
      </GridItem>
    </Grid>

    <Grid>
      <GridItem
        sm={2}
        md={4}
        lg={6}
        xl={6}
      >
        <div>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Tertiary}
          >
            Help
          </Button>
        </div>
      </GridItem>
      <GridItem
        sm={2}
        md={4}
        lg={6}
        xl={6}
      >
        <div className="rightbtn">
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Primary}
          >
            Save
          </Button>
        </div>
      </GridItem>
    </Grid>
  </Layout>
);
export default FundDefinition;
