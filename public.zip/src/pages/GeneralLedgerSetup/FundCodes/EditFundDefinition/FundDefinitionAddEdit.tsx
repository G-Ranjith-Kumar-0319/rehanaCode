import Input from "@/components/Input/Input";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  FormLabel,
  Grid,
  GridItem,
  Loader,
  LoaderType,
  NotificationStatus,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useForm } from "react-hook-form";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { BOOLEAN_DATA, STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import { localRoutes } from "@/utils/constants";
import {
  getFundCodeListingData,
  getGeneralLedgerExcludeFundCFR,
  getGeneralLedgerFundCodeNext,
  getGeneralLedgerExcludeFundCFRVisibility,
  generalLedgerFuncCodeAction,
  generalLedgerFundCodeAddEdit,
  getGeneralLedgerFundDataBrowse,
  getGeneralLedgerValidateFundDesc,
  getGeneralLedgerValidateFundCode
} from "../../State/GeneralLedgerFundCodeListing.slice";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import useLedgerGrpPopup from "../../hooks/useLedgerGrpPopup";
import GenralLedgerFooter from "../../GeneralLedgerFooter";

type FormData = {
  /* eslint-disable camelcase */
  fund_id: number;
  fund_code: string;
  ledger_code: any;
  ledger_des: string;
  mffund: string;
  ledgers_attached: any;
  private_fund: string;
  cfr_excluded: string;
};

const FundDefinitionAddEdit = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { setTabData } = useLedgerGrpPopup();
  const history = useHistory();
  const {
    location: { pathname: historyPathname }
  } = history;
  const [excludeFundCFRVisibility, setExcludeFundCFRVisibility] = useState(false);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    newFundList,
    fundCodeDirty,
    finalFundCodeList,
    selectedRow,
    previousYear,
    nextYear,
    previousState,
    funcDescValidStatus
  } = useAppSelector((state: any) => state.generalLedgerFundCode);
  const { fundId } = useParams<{ fundId: any }>();
  let flag = false;
  const isLoading = funcDescValidStatus === STATUS.LOADING;
  /* eslint-disable camelcase */
  const formMethods = useForm<FormData>({
    mode: "all",
    shouldFocusError: false,
    defaultValues: {
      fund_id: 0,
      fund_code: "",
      ledger_code: null,
      ledger_des: "",
      mffund: "",
      ledgers_attached: null,
      private_fund: "F",
      cfr_excluded: "F"
    }
  });

  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    reset,
    watch,
    formState: { errors, isDirty }
  } = formMethods;

  const findFromLocalAndShow = () => {
    const found = newFundList
      .map((fund: any) => {
        if (Number(fund.fund_code) === Number(selectedRow?.fund_code)) {
          return fund;
        }
        return undefined;
      })
      .filter((t: any) => t);
    if (found && found.length > 0 && history.location.pathname.includes("/edit")) {
      setValue("fund_id", found?.at(-1)?.fund_id || 0);
      setValue("fund_code", found?.at(-1)?.fund_code);
      setValue("ledger_des", found?.at(-1)?.ledger_des);
      setValue("mffund", found?.at(-1)?.mffund);
      setValue("cfr_excluded", found?.at(-1)?.cfr_excluded);
      return true;
    }
    return false;
  };
  const getFundCodeData = () => {
    if (findFromLocalAndShow()) return;
    if (fundId && fundId !== "0") {
      dispatch(getGeneralLedgerFundDataBrowse({ fundId })).then((res: any) => {
        if (res && res.payload) {
          setValue("fund_id", res.payload.fund_id);
          setValue("fund_code", res.payload.fund_code);
          setValue("ledger_des", res.payload.ledger_des);
          setValue("mffund", res.payload.mffund);
          setValue("cfr_excluded", res.payload.cfr_excluded);
        }
      });
    }
    if (fundId === "0" && finalFundCodeList?.length > 0) {
      finalFundCodeList.forEach((item: any) => {
        if (item.fund_code === selectedRow?.fund_code) {
          reset({
            fund_id: item.fund_id,
            fund_code: item.fund_code,
            ledger_code: item.ledger_code,
            ledger_des: item.ledger_des,
            mffund: item.mffund,
            ledgers_attached: item.ledgers_attached,
            cfr_excluded: item.cfr_excluded,
            private_fund: item.private_fund
          });
        }
      });
    }
  };

  useEffect(() => {
    dispatch(
      getGeneralLedgerExcludeFundCFRVisibility({
        callback: (res: any) => {
          if (res) {
            if (res.cfr_invalid_year === BOOLEAN_DATA.False && res.cfr_functionality === BOOLEAN_DATA.True) {
              setExcludeFundCFRVisibility(true);
            } else {
              setExcludeFundCFRVisibility(false);
            }
          }
        }
      })
    );
  }, []);

  useEffect(() => {
    if (finalFundCodeList?.length === 0)
      dispatch(
        getFundCodeListingData({
          callback: (res: any) => {
            if (res?.length > 0) {
              dispatch(generalLedgerFuncCodeAction.setFinalFundCodeList(res));
              setTimeout(() => {
                getFundCodeData();
              }, 500);
            }
          }
        })
      );
  }, []);

  useEffect(() => {
    if (finalFundCodeList?.length > 0 && !fundId) {
      const temFundCode = Number(finalFundCodeList[finalFundCodeList.length - 1]?.fund_code) + 1;
      setValue("fund_code", String(temFundCode), { shouldDirty: true });
    }
  }, [finalFundCodeList]);

  useEffect(() => {
    if (!fundId && newFundList?.length === 0) {
      dispatch(
        getGeneralLedgerFundCodeNext({
          callback: (res: any) => {
            if (res) {
              setValue("fund_code", String(res), { shouldDirty: true });
            }
          }
        })
      );
    }
  }, []);

  useEffect(() => {
    getFundCodeData();
  }, [fundId]);

  useEffect(() => {
    dispatch(generalLedgerFuncCodeAction.setFuncCodeDirtyData(isDirty));
  }, [isDirty]);

  const getGeneralLedgerUniqueCode = async (val: any, onSubmitCheck?: boolean) => {
    if (finalFundCodeList?.length > 0 && !fundId) {
      const result = finalFundCodeList.some((item: { fund_code: any }) => item.fund_code === val);

      if (result) {
        if (onSubmitCheck) {
          dispatch(
            uiActions.alertPopup({
              enable: true,
              type: MODAL_TYPE?.ALERT,
              message: t("generalLedgerSetup.fundCode.uniqueFundCode"),
              title: t("common.simsFMSModule"),
              notificationType: NotificationStatus?.ERROR,
              className: "primary-focus"
            })
          );
        }
        setToSession("setisBtn", false);
        return false;
      }
      if ((previousYear !== 0 && previousState !== BOOLEAN_DATA.False) || nextYear !== 0) {
        const isValid = await new Promise((resolve) => {
          dispatch(
            getGeneralLedgerValidateFundCode({
              yearId: getValidateYearValue(),
              ledgerCode: `FD${val}`,
              linkValue: fundId !== "0" && fundId ? fundId : null,
              callback: (res: any) => {
                if (res && res === BOOLEAN_DATA.True) {
                  if (onSubmitCheck) {
                    dispatch(
                      uiActions.alertPopup({
                        enable: true,
                        type: MODAL_TYPE?.ALERT,
                        message: getValidateYearMsgForFundCode(),
                        title: t("common.simsFMSModule"),
                        notificationType: NotificationStatus?.ERROR,
                        className: "primary-focus"
                      })
                    );
                  }
                  setToSession("setisBtn", false);
                  resolve(false);
                } else {
                  resolve(true);
                }
              }
            })
          );
        });

        if (!isValid) {
          return false;
        }
      }
    }
    return true;
  };

  const getValidateYearValue = () => {
    if (previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
      return previousYear;
    }
    if (nextYear !== 0) {
      return nextYear;
    }
    return getCurrentFinancialYear();
  };

  const getValidateYearMsgForFundDesc = () => {
    if (nextYear !== 0) {
      return t("generalLedgerSetup.fundCode.uniqueFundDescFinYearNext");
    }
    if (previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
      return t("generalLedgerSetup.fundCode.uniqueFundDescFinYearPre");
    }
    return "";
  };

  const getValidateYearMsgForFundCode = () => {
    if (nextYear !== 0) {
      return t("generalLedgerSetup.fundCode.uniqueFundCodeFinYearNext");
    }
    if (previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
      return t("generalLedgerSetup.fundCode.uniqueFundCodeFinYearPre");
    }
    return "";
  };

  const getGeneralLedgerUniqueDesc = async (val: any, onSubmitCheck?: boolean) => {
    let uniqueRes;
    if (finalFundCodeList?.length > 0) {
      if (fundId || fundId === 0) {
        uniqueRes = finalFundCodeList.some(
          (item: any) =>
            item.ledger_des?.toLowerCase().trim() === val.toLowerCase().trim() &&
            item.fund_code !== selectedRow?.fund_code
        );
      } else {
        uniqueRes = finalFundCodeList.some(
          (item: { ledger_des: any }) => item.ledger_des?.toLowerCase().trim() === val.toLowerCase().trim()
        );
      }

      if (val !== "" && (nextYear !== 0 || (previousYear !== 0 && previousState !== BOOLEAN_DATA.False))) {
        const isValid = await new Promise((resolve) => {
          dispatch(
            getGeneralLedgerValidateFundDesc({
              yearId: getValidateYearValue(),
              fundDesc: val,
              linkValue: fundId !== "0" && fundId ? fundId : null,
              callback: (res: any) => {
                if (res && res === BOOLEAN_DATA.True) {
                  if (onSubmitCheck) {
                    dispatch(
                      uiActions.alertPopup({
                        enable: true,
                        type: MODAL_TYPE?.ALERT,
                        message: getValidateYearMsgForFundDesc(),
                        title: t("common.simsFMSModule"),
                        notificationType: NotificationStatus?.ERROR,
                        className: "primary-focus"
                      })
                    );
                  }
                  setToSession("setisBtn", false);
                  resolve(false);
                } else {
                  resolve(true);
                }
              }
            })
          );
        });

        if (!isValid) {
          return false;
        }
      }
      if (uniqueRes) {
        if (onSubmitCheck) {
          dispatch(
            uiActions.alertPopup({
              enable: true,
              type: MODAL_TYPE?.ALERT,
              message: t("generalLedgerSetup.fundCode.uniqueFundDesc"),
              title: t("common.simsFMSModule"),
              notificationType: NotificationStatus?.ERROR,
              className: "primary-focus"
            })
          );
        }
        setToSession("setisBtn", false);
        return false;
      }
    }
    return true;
  };

  const handleCheckBox = (val: any) => {
    if (fundId && val) {
      dispatch(
        getGeneralLedgerExcludeFundCFR({
          fundId,
          callback: (res: any) => {
            if (res === BOOLEAN_DATA.True) {
              dispatch(
                uiActions.confirmPopup({
                  enable: true,
                  type: MODAL_TYPE.CONFIRMV2,
                  message: t("generalLedgerSetup.fundCode.fundCFR"),
                  title: t("common.simsFMSModule"),
                  notificationType: NotificationStatus.HIGHLIGHT,
                  yesCallback: async () => {
                    setValue("cfr_excluded", BOOLEAN_DATA.True, {
                      shouldDirty: true
                    });
                  },
                  noCallback: () => {
                    setValue("cfr_excluded", BOOLEAN_DATA.False, {
                      shouldDirty: true
                    });
                  },
                  isCancelBtnEnable: false
                })
              );
            }
          }
        })
      );
    }
    setValue("cfr_excluded", val ? BOOLEAN_DATA.True : BOOLEAN_DATA.False);
  };

  const onSubmit = async () => {
    let isError = false;
    setToSession("setisBtn", true);
    const chkUniqueFundDesc = await getGeneralLedgerUniqueDesc(watch("ledger_des"), true);
    const chkUniqueFundCode = await getGeneralLedgerUniqueCode(watch("fund_code"), true);
    const formSumbit = handleSubmit(
      async (data) => {
        if (chkUniqueFundDesc && chkUniqueFundCode) {
          data.ledger_code = `FD${data.fund_code}`;
          if (fundId < 0 || fundId === undefined) {
            setToSession("setisBtn", true);
            dispatch(generalLedgerFuncCodeAction.addNewFundList(data));
            dispatch(generalLedgerFuncCodeAction.setSelectedRow(data));
          } else if (finalFundCodeList?.length > 0) {
            dispatch(generalLedgerFuncCodeAction.addNewFundList(data));
            dispatch(generalLedgerFuncCodeAction.setSelectedRow(data));
            const updatedFinalFundCodeList = finalFundCodeList.map((item: any) => {
              if (item.fund_code === data.fund_code) {
                return {
                  ...item,
                  ledger_des: data.ledger_des,
                  mffund: data.mffund,
                  cfr_excluded: data.cfr_excluded,
                  ledger_code: data.ledger_code
                };
              }
              return item;
            });
            dispatch(generalLedgerFuncCodeAction.updateFinalFundCodeList(updatedFinalFundCodeList));
          }
          history.push("/tools/general-ledger-setup/fund-codes");
        }
      },
      (error) => {
        isError = true;
        setToSession("setisBtn", false);
      }
    );
    await formSumbit();
    return isError;
  };

  useEffect(() => {
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      if (
        location.pathname !== "/tools" &&
        (historyPathname === "/tools/fund-codes/add" || historyPathname.includes("/tools/fund-codes/edit")) &&
        fundCodeDirty &&
        !getSessionItem("setisBtn")
      ) {
        dispatch(
          uiActions.confirmPopup({
            enable: true,
            message: t("common.keepChangesWishMsg"),
            title: t("common.simsFMSModule"),
            type: MODAL_TYPE.CONFIRMV2,
            yesCallback: async () => {
              const result = await onSubmit();
              if (result) {
                flag = false;
              }
              if (result === false) {
                flag = true;
                setToSession("setisBtn", true);
                dispatch(
                  generalLedgerFundCodeAddEdit({
                    callback: () => {}
                  })
                );
                history.push(location.pathname);
              }
            },
            noCallback: () => {
              flag = true;
              setToSession("setisBtn", true);
              history.push(location.pathname);
            },
            isCancelBtnEnable: true,
            cancelCallback: () => {
              setTabData("");
            }
          })
        );
        if (!flag) {
          return false;
        }
      }
    });

    return () => {
      unblock();
    };
  }, [history, getSessionItem("setisBtn"), fundCodeDirty]);

  useEffect(() => {
    document.getElementById("txtDescription")?.focus();
  }, []);

  const handleCancelCallback = () => {
    const goToBack = localRoutes.generalLedgerSetup.fundCodeList;
    setToSession("setisBtn", true);
    history.push(goToBack);
  };

  return (
    <>
      <GeneralLedgerSetup>
        <div className="tab-container">
          <GridItem>
            <Grid className="mb-16">
              <GridItem sm={4}>
                <div className="essui-global-typography-default-subtitle">
                  {t("generalLedgerSetup.fundCode.fundDefinition")}
                </div>
              </GridItem>
            </Grid>

            <Grid className="mb-8">
              <GridItem
                sm={4}
                md={1}
                lg={1}
                xl={1}
              >
                <div>
                  <FormLabel forId="txtFundCode">{t("generalLedgerSetup.fundCode.fundCode")}</FormLabel>
                  <Input
                    id="txtFundCode"
                    value={watch("fund_code")}
                    inputRef={(e) => register("fund_code").ref(e)}
                    name={
                      register("fund_code", {
                        required: true,
                        pattern: /^\d+$/,
                        validate: (val) => getGeneralLedgerUniqueCode(val, false)
                      }).name
                    }
                    onChange={(e) =>
                      setValue("fund_code", e.target.value, {
                        shouldDirty: true
                      })
                    }
                    searchable={false}
                    disabled={!!(fundId === 0 || fundId)}
                    maxLength={2}
                    onBlur={() => trigger("fund_code")}
                    validationTextLevel={errors.fund_code ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
            </Grid>

            <Grid className="mb-8">
              <GridItem
                sm={4}
                md={3}
                lg={3}
                xl={3}
              >
                <div>
                  <FormLabel forId="txtDescription">{t("generalLedgerSetup.fundCode.desc")}</FormLabel>
                  <Input
                    id="txtDescription"
                    value={watch("ledger_des")}
                    inputRef={(e) => register("ledger_des").ref(e)}
                    name={
                      register("ledger_des", {
                        required: true,
                        validate: (val) => getGeneralLedgerUniqueDesc(val, false)
                      }).name
                    }
                    onChange={(e) =>
                      setValue("ledger_des", e.target.value, {
                        shouldDirty: true
                      })
                    }
                    searchable={false}
                    onBlur={() => trigger("ledger_des")}
                    disabled={false}
                    maxLength={22}
                    validationTextLevel={errors.ledger_des ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </GridItem>
            </Grid>

            <Grid className="mb-8">
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
              >
                <div>
                  <FormLabel forId="txtLaCode">{t("generalLedgerSetup.fundCode.laCode")}</FormLabel>
                  <Input
                    id="txtLaCode"
                    value={watch("mffund")}
                    inputRef={(e) => register("mffund").ref(e)}
                    name={register("mffund").name}
                    onChange={(e) =>
                      setValue("mffund", e.target.value, {
                        shouldDirty: true
                      })
                    }
                    searchable={false}
                    disabled={false}
                    maxLength={9}
                  />
                </div>
              </GridItem>
            </Grid>

            {excludeFundCFRVisibility ? (
              <Grid className="mb-8">
                <GridItem
                  sm={4}
                  md={3}
                  lg={3}
                  xl={3}
                >
                  <div className="midchkbox">
                    <CheckBox
                      label={t("generalLedgerSetup.fundCode.excFundCfr")}
                      id="txtCheck"
                      value={watch("cfr_excluded")}
                      onChange={(e: any) => {
                        const val = e.target.checked;
                        handleCheckBox(val);
                      }}
                      isSelected={watch("cfr_excluded") === BOOLEAN_DATA.True}
                    />
                  </div>
                </GridItem>
              </Grid>
            ) : null}
          </GridItem>
          <GenralLedgerFooter
            cancelCallback={handleCancelCallback}
            onSubmit={onSubmit}
          />
        </div>
      </GeneralLedgerSetup>
    </>
  );
};

export default FundDefinitionAddEdit;
