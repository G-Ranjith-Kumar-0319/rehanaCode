import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const FundCodeListingColumnDef: TColumnDef = [
  {
    headerName: "Code",
    field: "fund_code"
  },
  {
    headerName: "Ledger",
    field: "ledger_code"
  },
  {
    headerName: "Description",
    field: "ledger_des"
  },
  {
    headerName: "LA Code",
    field: "mffund"
  },

  {
    headerName: "",
    field: "action",
    cellRenderer: "GridCellLink",
    columnWidth: 10
  }
];

export default FundCodeListingColumnDef;
