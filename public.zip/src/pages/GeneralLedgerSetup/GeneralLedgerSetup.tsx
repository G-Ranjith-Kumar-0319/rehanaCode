import Layout from "@/components/Layout/Layout";
import { TabGroup } from "@essnextgen/ui-kit";
import React, { useEffect, useState } from "react";
import { deleteSessionItem, getSessionItem, setToSession } from "@/utils/getDataSource";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import "./Style.scss";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { warnBudgetCheck } from "./State/glLedgerCodes.slice";
import GeneralLedgerHeader from "./GeneralLedgerHeader";

interface GeneralLedgerSetupProps {
  children: React.ReactNode; // Can be any React element
}

const GeneralLedgerSetup = ({ children }: GeneralLedgerSetupProps) => {
  const dispatch = useDispatch();
  const { isWarnBudgetCheck } = useAppSelector((state) => state.glLedgerCodes);
  const [currtitle, setCurrTitle] = useState("");
  const isWarnFlag = getSessionItem("glWarnBudget");
  const getTitle = (title: string) => {
    setCurrTitle(title);
  };
  useEffect(() => {
    if (!isWarnFlag) {
      if (isWarnBudgetCheck === undefined) {
        dispatch(warnBudgetCheck());
      }
      if (isWarnBudgetCheck > 0) {
        setToSession("glWarnBudget", false);
      }
    }
  }, [isWarnBudgetCheck]);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <>
      <Layout
        className="save-bank-statement gl-codes-list"
        pageTitle={t("generalLedgerSetup.generalLedgerSetupTitle")}
        type="transparent"
      >
        <TabGroup dataTestId="TabGroup">
          <GeneralLedgerHeader getTitle={getTitle} />
          {children}
        </TabGroup>
      </Layout>
    </>
  );
};

export default GeneralLedgerSetup;
