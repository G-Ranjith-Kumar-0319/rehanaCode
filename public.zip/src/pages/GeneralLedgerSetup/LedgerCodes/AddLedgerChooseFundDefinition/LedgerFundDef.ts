import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const LedgerFundModalDef: TColumnDef = [
  {
    headerName: "Code",
    field: "fund_code",
    sequence: true
  },
  {
    headerName: "Description",
    field: "fund_des",
    sequence: true
  }
];

export default LedgerFundModalDef;
