import useDebounce from "@/hooks/useDebounce";
import { AppDispatch, useAppSelector } from "@/store/store";
import findNearest from "@/utils/nearestSearch";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  FormLabel,
  Grid,
  GridItem,
  RadioButton,
  RadioLabelPosition,
  TextInput,
  TextInputSize
} from "@essnextgen/ui-kit";
import React, { Dispatch, useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { KEYBOARD_STRING, LG_FUND_CODE } from "@/types/UseStateType";
import { useParams } from "react-router-dom";
import LedgerFundModalDef from "./LedgerFundDef";
import { ledgerFundDefinitionAction } from "../../State/glLedgerFundDefinition.slice";
import "./Style.scss";

const LedgerFundDefinitionFilter = ({ setSelectOtherFundRow }: { setSelectOtherFundRow: Dispatch<any> }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...LedgerFundModalDef]);
  const dispatch = useDispatch<AppDispatch>();
  const { ledgefId }: any = useParams();
  const { status, filters, linkedFundList, otherFundList, otherFundSelectedRow, linkFundSelectedRow } = useAppSelector(
    (state) => state.glLedgerFundDefinition
  );
  const debouncedValue = useDebounce(filters?.lookingFor!, 300);
  const inputRef: React.Ref<HTMLInputElement> = useRef(null);

  useEffect(() => {
    setTimeout(() => {
      document?.getElementById("lookingForFundDef")?.focus();
    }, 100);
  }, []);

  useEffect(() => {
    if (debouncedValue !== "" && otherFundList && otherFundList?.length) {
      let found;
      found = [...otherFundList]
        .filter((element) =>
          debouncedValue
            ? element[filters?.sequenceValue!].toString()?.toUpperCase()?.startsWith(debouncedValue!)
            : false
        )
        .at(0);

      if (found && found !== undefined && ledgefId) setSelectOtherFundRow(found);
      if (!ledgefId) dispatch(ledgerFundDefinitionAction.setOtherFundSelectedRow(found));

      if (found === undefined) {
        found = findNearest(
          [...otherFundList],
          [{ fieldName: filters?.sequenceValue!, searchValue: debouncedValue }],
          true
        );
        setSelectOtherFundRow(found);
      }
      const element = document.getElementById(`rowIndex-glOtherFundDefList-${otherFundList.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [debouncedValue]);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(ledgerFundDefinitionAction.setFilters({ lookingFor: value.toUpperCase() }));
  };

  const handleSequenceChange = (value?: string) => {
    LedgerFundModalDef?.map((col, index) => {
      if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });
    setColumn([...LedgerFundModalDef]);
    dispatch(ledgerFundDefinitionAction.setColumnDef(columns));
    dispatch(ledgerFundDefinitionAction.setLinkedFundList([...linkedFundList]));
    dispatch(ledgerFundDefinitionAction.setOtherFundList([...otherFundList]));
  };

  useEffect(() => {
    handleSequenceChange(filters?.sequenceValue);
  }, [filters?.sequenceValue]);

  const handleSequenceFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey = e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp;
    if (isArrowKey) {
      e.preventDefault();
      const nextSequenceValue =
        filters?.sequenceValue === LG_FUND_CODE.FUND_CODE ? LG_FUND_CODE.FUND_DES : LG_FUND_CODE.FUND_CODE;
      const index = nextSequenceValue === LG_FUND_CODE.FUND_DES ? 1 : 0;
      dispatch(
        ledgerFundDefinitionAction.setFilters({
          sequenceValue: String(nextSequenceValue),
          sequenceIndex: String(index),
          lookingFor: ""
        })
      );
    }
  };

  return (
    <>
      <div className="choose__fund--modal pl-12">
        <div className="choose__fund--table essui-global-typography-default-h2 ml-0 mr-16">
          <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              inputRef={inputRef}
              id="lookingForFundDef"
              value={filters?.lookingFor}
              onChange={(e) => handleLookingForChange(e)}
              size={TextInputSize.Medium}
            />
          </div>
        </div>

        <div className="essui-global-typography-default-h2">
          <FormLabel>{t("purchaseOrder.sequence")}</FormLabel>
          <div
            className="essui-textinput sequence justify-sequence"
            onKeyDown={handleSequenceFieldKeyDown}
          >
            {(LedgerFundModalDef.filter((col) => !!col.sequence) || []).map((column, index) => {
              const sequenceId = `sequence=${index + 1}`;
              return (
                <RadioButton
                  label={column.headerName}
                  name={column.headerName}
                  labelPosition={RadioLabelPosition.Right}
                  value={column.field}
                  onChange={() => {
                    dispatch(
                      ledgerFundDefinitionAction.setFilters({
                        sequenceValue: String(column.field),
                        sequenceIndex: String(index),
                        lookingFor: ""
                      })
                    );
                  }}
                  isSelected={filters?.sequenceValue === column.field}
                  key={sequenceId}
                  id={`ledger-code-${index}`}
                />
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
};

export default LedgerFundDefinitionFilter;
