import GridTableNew, { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  Grid,
  GridItem,
  NotificationStatus
} from "@essnextgen/ui-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useParams } from "react-router-dom";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import LedgerFundModalDef from "./LedgerFundDef";
import {
  getFundDefinitionListingData,
  getValidateBeforeRemoveLinkData,
  ledgerFundDefinitionAction
} from "../../State/glLedgerFundDefinition.slice";
import LedgerFundDefinitionFilter from "./LedgerFundDefinitionFilter";
import { isArrayLength } from "../../ProfileModels/utils";
import { ledgerCodesAction } from "../../State/glLedgerCodes.slice";
import "./Style.scss";

type TChooseFundProp = {
  setSpreadModel: (flag: boolean) => void;
  spreadModel: boolean;
};

const ChooseFundsModal = ({ setSpreadModel, spreadModel }: TChooseFundProp) => {
  const dispatch = useDispatch<AppDispatch>();
  const { ledgefId }: any = useParams();
  const [selectedRow, setSelectedRow] = useState<{ [key: string]: any } | undefined>();
  const [otherFundIndex, setOtherFundIndex] = useState<any>(0);
  const [linkFundIndex, setLinkFundIndex] = useState<any>(0);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    ledgerCodeForm: { formData }
  } = useAppSelector((state) => state.glLedgerCodes);
  const {
    status,
    filters,
    columnDef,
    linkedFundList,
    otherFundList,
    otherFundSelectedRow,
    linkFundSelectedRow,
    isOtherLinkFund
  } = useAppSelector((state) => state.glLedgerFundDefinition);
  const { ledgerCodeFundCodes } = useAppSelector((state) => state.glLedgerCodeFundCode);
  const { setLedgerFormData } = ledgerCodesAction;
  let tempLinkedArr: any[] = [];
  const tempOtherArr: any[] = [];

  const handleClose = () => {
    setSpreadModel(false);
    if (otherFundSelectedRow) setSelectedRow(otherFundSelectedRow);
    dispatch(ledgerFundDefinitionAction.resetSelectedRows());
    dispatch(ledgerFundDefinitionAction.setFilters({ lookingFor: "" }));
  };

  useEffect(() => {
    const { field } = LedgerFundModalDef.filter((col) => !!col.sequence)[0];
    dispatch(ledgerFundDefinitionAction.setFilters({ ...filters, sequenceValue: field }));
  }, []);

  const selectPeriods = () => {
    if (linkedFundList && linkedFundList.length > 0) {
      const updatedPayload = linkedFundList.map((item: any) => ({
        fund_id: item?.fund_id,
        fund_code: item?.fund_code,
        fund_des: item?.fund_des,
        cfr_code: item?.cfr_code ? item?.cfr_code : item?.fund_cfr_code
      }));
      dispatch(
        setLedgerFormData({
          ...formData,
          funds: updatedPayload
        })
      );
    }
    handleClose();
  };

  useEffect(() => {
    const { field } = LedgerFundModalDef.filter((col) => !!col.sequence)[0];
    dispatch(ledgerFundDefinitionAction.setFilters({ ...filters, sequenceValue: field }));
    if (spreadModel && !ledgefId) {
      dispatch(ledgerFundDefinitionAction.setLinkedFundList([...(formData?.funds || [])]));
      /** This will call when the add screen will open */
      if (isArrayLength(ledgerCodeFundCodes) && isArrayLength(formData?.funds) && !ledgefId) {
        const filterOtherFund = ledgerCodeFundCodes.filter((item1) =>
          formData?.funds?.every((item2) => item2.fund_code !== item1.fund_code)
        );
        dispatch(ledgerFundDefinitionAction.setOtherFundList([...(filterOtherFund || [])]));
      }
    }
  }, [spreadModel]);

  useEffect(() => {
    if (ledgefId && spreadModel && !isOtherLinkFund) {
      dispatch(
        getFundDefinitionListingData({
          leddefId: ledgefId,
          callback: (res: any) => {
            if (res?.otherFunds?.length) {
              dispatch(ledgerFundDefinitionAction.setOtherFundList([...res?.otherFunds]));
            }
            if (res?.linkedFunds?.length) {
              dispatch(ledgerFundDefinitionAction.setLinkedFundList([...res?.linkedFunds]));
            }
          }
        })
      );
    }
  }, [ledgefId, spreadModel]);

  useEffect(() => {
    if (linkedFundList && linkedFundList.length > 0) {
      dispatch(ledgerFundDefinitionAction.setLinkFundSelectedRow(linkedFundList[0]));
    }
  }, [linkedFundList]);

  useEffect(() => {
    if (ledgefId) dispatch(ledgerFundDefinitionAction.setOtherFundSelectedRow(selectedRow));
  }, [selectedRow]);

  const handleRemoveDisable = () => linkedFundList.length <= 1;

  const handleChooseDisable = () => otherFundList.length === 0;

  const chooseOtherFund = () => {
    const newObj = { ...otherFundSelectedRow };
    if (linkedFundList && linkedFundList.length > 0) {
      tempLinkedArr.push(newObj);
    }
    const indexNo = otherFundList?.findIndex(
      (row: { [key: string]: any }) => row?.fund_code === otherFundSelectedRow?.fund_code
    );
    const updatedOtherFundList = otherFundList.filter((fund) => fund !== otherFundSelectedRow);
    dispatch(ledgerFundDefinitionAction.setOtherFundList(updatedOtherFundList));
    if (tempLinkedArr && tempLinkedArr.length > 0) {
      dispatch(ledgerFundDefinitionAction.setLinkedFundList([...linkedFundList, ...tempLinkedArr]));
    }
    setOtherFundIndex(indexNo);
  };

  useEffect(() => {
    if (otherFundIndex === otherFundList?.length) {
      dispatch(ledgerFundDefinitionAction.setOtherFundSelectedRow(otherFundList[otherFundIndex - 1]));
    } else {
      dispatch(ledgerFundDefinitionAction.setOtherFundSelectedRow(otherFundList[otherFundIndex]));
    }
  }, [otherFundIndex, otherFundList]);

  const chooseAllFund = () => {
    tempLinkedArr = [];
    const tempArr = [...otherFundList];
    tempArr.forEach((item) => {
      const newObj = { ...item };
      tempLinkedArr.push(newObj);
    });
    dispatch(ledgerFundDefinitionAction.setLinkedFundList([...linkedFundList, ...tempLinkedArr]));
    dispatch(ledgerFundDefinitionAction.setOtherFundList([]));
    dispatch(ledgerFundDefinitionAction.setOtherFundSelectedRow(null));
  };

  const removeLinkedFund = async () => {
    if (ledgefId && linkFundSelectedRow) {
      await dispatch(
        getValidateBeforeRemoveLinkData({
          leddefId: ledgefId,
          fundId: linkFundSelectedRow?.fund_id,
          callback: (res: any) => {
            if (res === 1) {
              dispatch(
                uiActions.alertPopup({
                  enable: true,
                  type: MODAL_TYPE.ALERT,
                  message: t(`generalLedgerSetup.fundCode.checkRemoveLinkedFund`, {
                    fundCode: linkFundSelectedRow?.fund_code
                  }),
                  title: t("common.simsFMSModule"),
                  notificationType: NotificationStatus.ERROR,
                  className: "primary-focus"
                })
              );
              return;
            }
            updateOtherFund();
          }
        })
      );
    }
    if (!ledgefId) {
      updateOtherFund();
    }
  };

  const updateOtherFund = () => {
    const indexNo = linkedFundList?.findIndex(
      (row: { [key: string]: any }) => row?.fund_code === linkFundSelectedRow?.fund_code
    );
    const updatedLinkedFundList = linkedFundList.filter((fund) => fund !== linkFundSelectedRow);
    dispatch(ledgerFundDefinitionAction.setLinkedFundList(updatedLinkedFundList));
    const tempObj = { ...linkFundSelectedRow };
    if (linkedFundList && linkedFundList.length > 0) {
      tempOtherArr.push(tempObj);
    }
    if (tempOtherArr && tempOtherArr.length > 0) {
      dispatch(ledgerFundDefinitionAction.setOtherFundList([...otherFundList, ...tempOtherArr]));
    }
    setLinkFundIndex(indexNo);
  };

  useEffect(() => {
    if (linkFundIndex === linkedFundList?.length) {
      dispatch(ledgerFundDefinitionAction.setLinkFundSelectedRow(linkedFundList[linkFundIndex - 1]));
    } else {
      dispatch(ledgerFundDefinitionAction.setLinkFundSelectedRow(linkedFundList[linkFundIndex]));
    }
  }, [linkFundIndex, linkedFundList]);

  useEffect(() => {
    const debouncedValue = filters?.lookingFor!;
    if (!debouncedValue && spreadModel) {
      const found = [...otherFundList].at(0);
      if (!ledgefId) dispatch(ledgerFundDefinitionAction.setOtherFundSelectedRow(found));
      setSelectedRow(found);
      const element = document.getElementById(`rowIndex-glOtherFundDefList-0`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [filters?.lookingFor]);

  return (
    <Dialog
      escapeExits
      id="element-id"
      returnFocusOnDeactivate
      title={t("generalLedgerSetup.fundCode.fundModalTitle")}
      className="dialog__divider modal__align--set ledger__choose--funds choose__fund--modal--width"
      onClose={handleClose}
      isOpen={spreadModel}
    >
      <DialogContent>
        <LedgerFundDefinitionFilter setSelectOtherFundRow={setSelectedRow} />
        <div className="overflow-hidden ">
          <div className="choose__fund--modal mt-8 pl-12 pr-12 row-gap-16">
            <div className="choose__fund--table grid-table-scrool">
              <GridTableNew
                filters={
                  <div className="essui-global-typography-default-subtitle">
                    {t("generalLedgerSetup.fundCode.otherFunds")}
                  </div>
                }
                dataTestId="glOtherFundDefList"
                columnDef={columnDef}
                isLoading={status === STATUS.LOADING}
                dataSource={otherFundList.length ? otherFundList : []}
                selectedRow={otherFundSelectedRow}
                selectedRowHandler={(row) => {
                  dispatch(ledgerFundDefinitionAction.setOtherFundSelectedRow(row));
                }}
                isScrollable
                className="spread-table"
              />
            </div>
            <div className="choose__fund--button pl-16 pr-16">
              <div className="d-flex justify-end flex-wrap row-gap-8">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="w-100 justify-start"
                  iconName="arrow--right"
                  onClick={chooseOtherFund}
                  disabled={handleChooseDisable()}
                  id="chooseFund"
                >
                  Choose
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="w-100 justify-start"
                  iconName="arrow--right"
                  onClick={chooseAllFund}
                  disabled={handleChooseDisable()}
                  id="chooseFundAll"
                >
                  Choose All
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="w-100 justify-start"
                  iconName="arrow--left"
                  id="fund-def-remove"
                  onClick={removeLinkedFund}
                  disabled={handleRemoveDisable()}
                >
                  Remove
                </Button>
              </div>
            </div>
            <div className="choose__fund--table grid-table-scrool">
              <GridTableNew
                filters={
                  <div className="essui-global-typography-default-subtitle">
                    {t("generalLedgerSetup.fundCode.linkedFunds")}
                  </div>
                }
                selectedRow={linkFundSelectedRow}
                selectedRowHandler={(row) => {
                  if (ledgefId) dispatch(ledgerFundDefinitionAction.setLinkFundSelectedRow(row));
                }}
                dataSource={linkedFundList.length ? linkedFundList : []}
                columnDef={columnDef}
                isLoading={false}
                isScrollable
                className="spread-table"
              />
            </div>
          </div>
        </div>
      </DialogContent>
      <DialogFooter>
        <Grid container>
          <GridItem
            sm={2}
            md={4}
            lg={6}
            xl={6}
          >
            <div>
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </div>
          </GridItem>
          <GridItem
            sm={2}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="d-flex justify-end">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                className="ml-4 mr-4"
                onClick={handleClose}
                id="fundCancel"
              >
                Cancel
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
                className="ml-4"
                onClick={selectPeriods}
                id="fundSelect"
              >
                Select
              </Button>
            </div>
          </GridItem>
        </Grid>
      </DialogFooter>
    </Dialog>
  );
};

export default ChooseFundsModal;
