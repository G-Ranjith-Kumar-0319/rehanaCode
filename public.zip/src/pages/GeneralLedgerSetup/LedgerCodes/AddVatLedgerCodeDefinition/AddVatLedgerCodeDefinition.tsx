import React, { useEffect } from "react";
import Input from "@/components/Input/Input";
import { FormLabel, Grid, GridItem, ValidationTextLevel } from "@essnextgen/ui-kit";
import NumberInput from "@/components/NumberInput/NumberInput";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { getVatCodesList, ledgerCodesAction, TledgeCodeDetails } from "../../State/glLedgerCodes.slice";
import useLedgerCodesForm from "../hooks/useLedgerCodesForm";

const AddVatLedgerCodeDefinition = () => {
  const {
    fieldsStatus,
    watch,
    register,
    validateVatCode,
    setValue,
    getValues,
    errors,
    validateVatConsolidationCode,
    isEditPage
  } = useLedgerCodesForm();
  const validVatConsolidationCode = ["1", "2", "4", "6", "7", "8", "9"];
  const handleKeyPress = (e: React.KeyboardEvent<Element>) => {
    const isValid = /[A-Za-z0-9]/.test(e.key);
    if (!isValid) {
      e.preventDefault();
    }
  };
  const handleVatConsolidationCodeKeyPress = (e: React.KeyboardEvent<Element>) => {
    const isValid = [...validVatConsolidationCode, "Backspace", "Tab", "Enter"].includes(e.key);
    if (!isValid) {
      e.preventDefault();
    }
  };
  const dispatch = useDispatch();

  const { ledgerCodeForm, errorState, callVatCodeApi } = useAppSelector((state) => state.glLedgerCodes);
  const { formData } = ledgerCodeForm;
  const { setLedgerFormData } = ledgerCodesAction;

  useEffect(() => {
    if (callVatCodeApi) {
      dispatch(getVatCodesList());
    }
  }, [callVatCodeApi]);

  return (
    <>
      <Grid className="mb-16" />
      <Grid className="row-gap-16 mb-8">
        <GridItem
          sm={4}
          md={3}
          lg={3}
          xl={3}
        >
          <Grid>
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={5}
              xxl={4}
            >
              <div>
                <FormLabel forId="vat_code">VAT Code</FormLabel>
                {isEditPage ? (
                  <div className="height__equal--input">{formData.vat?.vat_code}</div>
                ) : (
                  <Input
                    maxLength={1}
                    className="vat-code"
                    id="vat_code"
                    value={formData.vat?.vat_code?.toLocaleUpperCase() || ""}
                    name={
                      register("vat.vat_code", {
                        required: true
                      }).name
                    }
                    onKeyDown={(e) => handleKeyPress(e)}
                    onChange={(e) => {
                      const newVal = e.target.value.toLocaleUpperCase();
                      if (/^[A-Za-z0-9]*$/.test(newVal)) {
                        setValue("vat.vat_code", newVal, {
                          shouldDirty: true
                        });
                      }
                      validateVatCode(newVal, false);
                    }}
                    validationTextLevel={errorState.vatCode ? ValidationTextLevel.Error : undefined}
                  />
                )}
              </div>
            </GridItem>
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={5}
              xxl={4}
            >
              <div>
                <FormLabel forId="rate">VAT Rate (%)</FormLabel>
                {isEditPage ? (
                  <div className="height__equal--input">{formData.vat?.rate || "0.00"}</div>
                ) : (
                  <NumberInput
                    className="vat-input"
                    decimals={2}
                    maxLength={2}
                    id="rate"
                    defaultValue={(formData.vat?.rate as any) || "0.00"}
                    value={(formData.vat?.rate as any) || "0.00"}
                    name={
                      register("vat.rate", {
                        required: true
                      }).name
                    }
                    onChange={(e) => {
                      const value = parseFloat(e.target.value).toFixed(2);
                      setValue("vat.rate", value, {
                        shouldDirty: true
                      });

                      dispatch(setLedgerFormData({ ...formData, vat: { ...formData.vat, rate: value } }));
                    }}
                  />
                )}
              </div>
            </GridItem>
          </Grid>
        </GridItem>

        <GridItem
          sm={4}
          md={3}
          lg={3}
          xl={2}
        >
          <div>
            <FormLabel forId="txtVatConsolidationCode">VAT Consolidation Code</FormLabel>
            <Input
              maxLength={1}
              id="txtVatConsolidationCode"
              value={formData.vat?.vat_consolidation_code || ""}
              name={
                register("vat.vat_consolidation_code", {
                  required: true
                }).name
              }
              onChange={(e) => {
                const newVal = e.target.value;

                setValue("vat.vat_consolidation_code", newVal, {
                  shouldDirty: true
                });
                dispatch(setLedgerFormData({ ...formData, vat: { ...formData.vat, vat_consolidation_code: newVal } }));
                validateVatConsolidationCode(newVal, false);
              }}
              onKeyDown={(e) => handleVatConsolidationCodeKeyPress(e)}
              validationTextLevel={errorState?.vatConsolidationCode ? ValidationTextLevel.Error : undefined}
            />
          </div>
        </GridItem>
      </Grid>
    </>
  );
};

export default AddVatLedgerCodeDefinition;
