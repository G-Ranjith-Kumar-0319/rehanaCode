import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useAppSelector } from "@/store/store";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useHistory, useParams, useLocation } from "react-router-dom";
import { BOOLEAN_DATA, ledgerCodeType } from "@/types/UseStateType";
import { useForm } from "react-hook-form";
import { isBankType, isChargeCardType, isExpType, isSalaryType, isVatType } from "../utils";
import {
  ledgerCodesAction,
  postLedgerCodes,
  TledgeCodeDetails as FromData,
  validatenewLedgerDescYear,
  validateGLVatCodeYear
} from "../../State/glLedgerCodes.slice";
import { deepSome } from "../../utils";
import { isTextEqual } from "../../ProfileModels/utils";

type TConfirmationPopup = {
  yesFunc?: () => void;
  noFunc?: () => void;
  cancelFunc?: () => void;
  changeTab: () => void;
  inputValidation?: boolean;
};

const useLedgerCodesForm = () => {
  const history = useHistory();
  const location = useLocation();
  const isEditPage = location.pathname.includes("edit-ledger-code");
  const {
    ledgerCodeForm,
    newLedgerCodesList,
    deleteLCIds,
    errorState,
    tableLedgerCodeList,
    vatCodeList,
    tempEditDetail,
    selectedRowGlCodes
  } = useAppSelector((state) => state.glLedgerCodes);
  const { previousYear, nextYear, previousState } = useAppSelector((state: any) => state.generalLedgerFundCode);
  const {
    resetLedgerCodesState,
    setLedgerFormData,
    updateErrorState,
    setNewLCData,
    setFromSubmitting,
    selectGlListSelectedRow,
    resetForm
  } = ledgerCodesAction;
  /* eslint-disable camelcase */
  const {
    formData: { ledger_des, ledger_type }
  } = ledgerCodeForm;
  const dispatch = useDispatch();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { ledgefId } = useParams<any>();
  const isEditMode = !!ledgefId; // Check if it is edit mode
  const {
    register,
    getFieldState,
    formState: { errors, isDirty },
    getValues,
    setError,
    setValue,
    trigger,
    watch,
    handleSubmit,
    clearErrors,
    reset,
    setFocus
  } = useForm<FromData>({
    defaultValues: {
      ledger_des,
      vat: {
        vat_id: 0,
        rate: "0.00",
        vat_code: ""
      }
    }
  });

  const getAlertMessage = (message: string, msgOption = {}) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE?.ALERT,
        message: t(message, { ...msgOption }),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus?.ERROR,
        className: "primary-focus"
      })
    );
  };

  const getConfirmPopup = (
    message: string,
    msgOption = {},
    yesFunc: () => void,
    isCancelBtnEnable: boolean,
    noCallback: any,
    yesText = "Yes"
  ) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        type: MODAL_TYPE?.CONFIRMV2,
        message: t(message, { ...msgOption }),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus?.WARNING,
        className: "primary-focus",
        yesCallback: async () => {
          yesFunc();
        },
        noCallback,
        isCancelBtnEnable,
        yesButtonText: yesText
      })
    );
  };

  const findDescInPreNextYear = async (year: string) =>
    dispatch(
      validatenewLedgerDescYear({
        linkValue: 0,
        ledgerDesc: watch("ledger_des") || ledgerCodeForm.formData.ledger_des,
        yearId: year
      })
    );
  const setErrorState = (field: keyof FromData, message: string, showPopup = false, msgOption = {}) => {
    setError(field, { type: "required" });
    dispatch(updateErrorState({ ...errorState, [field]: true }));
    if (showPopup) {
      getAlertMessage(message, msgOption);
    }
  };

  const clearErrorState = (field: keyof FromData) => {
    clearErrors(field);
    dispatch(updateErrorState({ ...errorState, [field]: false }));
  };

  const updateFormState = (data: Partial<FromData>) => {
    dispatch(setLedgerFormData({ ...ledgerCodeForm.formData, ...data }));
  };

  // Description validation function
  const validateDescription = async (value: string, showPopup: boolean) => {
    const dontCallAPI = isTextEqual(tempEditDetail?.ledger_des || "", value); // Get the old value of ledger description and not call API
    updateFormState({ ledger_des: value });
    let errorMessage = "";
    const excludeItemToMatch = isEditMode ? selectedRowGlCodes?.ledger_des : null;
    const isNotUnique = deepSome(tableLedgerCodeList, value, "ledger_des", excludeItemToMatch);
    if (!value) {
      errorMessage = "common.invalidData";
    } else {
      if (!dontCallAPI && previousYear && previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
        const res: any = await findDescInPreNextYear(previousYear);
        if (res.payload === BOOLEAN_DATA.True) {
          errorMessage = "generalLedgerSetup.ledgerCode.newLedgerDescExistInPrevYear";
        } else if (res.payload === BOOLEAN_DATA.False && value && !isNotUnique) {
          clearErrorState("ledger_des");
        }
      }
      if (!dontCallAPI && !errorMessage && nextYear && nextYear !== 0) {
        const res: any = await findDescInPreNextYear(nextYear);
        if (res.payload === BOOLEAN_DATA.True) {
          errorMessage = "generalLedgerSetup.ledgerCode.newLedgerDescExistInNextYear";
        } else if (res.payload === BOOLEAN_DATA.False && value && !isNotUnique) {
          clearErrorState("ledger_des");
        }
      }
      if (isNotUnique && errorMessage === "") {
        errorMessage = "generalLedgerSetup.ledgerCode.newLedgerDescExist";
      }
    }
    if (errorMessage) {
      setErrorState("ledger_des", errorMessage, showPopup);
      return false;
    }
    clearErrorState("ledger_des");
    return true;
  };

  // eslint-disable-next-line
  const isVatConCodeValid = async (vatConCode: string, showPopup: boolean) => {
    const isVatConsolidationCodeValid = await validateVatConsolidationCode(vatConCode || "", showPopup);
    if (!isVatConsolidationCodeValid) {
      return false;
    }
  };

  // eslint-disable-next-line
  const isLedgerDescValid = async (des: string, showPopup: boolean) => {
    const isLedgerDescValid = await validateDescription(des, showPopup);
    if (!isLedgerDescValid) {
      return false;
    }
  };

  // Form validation function
  const isFormValid = async (showPopup: boolean) => {
    const values = ledgerCodeForm.formData;
    const ledgerDes = values.ledger_des;
    const vatConsolidationCode = values?.vat?.vat_consolidation_code;
    const vatCode = values?.vat?.vat_code;

    if ((!errorState.vatCode || vatCode?.length === 0) && !errorState.vatConsolidationCode) {
      const isValid = await isLedgerDescValid(ledgerDes, showPopup);
      if (isValid === false) {
        return false;
      }
    }

    if (isVatType(ledger_type)) {
      if (!vatCode || vatCode?.length === 0) {
        const isValid = await isVatConCodeValid(vatConsolidationCode || "", showPopup);
        if (isValid === false) {
          return false;
        }
      }

      if (!isEditMode) {
        const isVatCodeValid = await validateVatCode(vatCode || "", showPopup);
        if (!isVatCodeValid) {
          return false;
        }
      }

      if (!errorState.vatCode || !errorState.ledger_des) {
        const isValid = await isVatConCodeValid(vatConsolidationCode || "", showPopup);
        if (isValid === false) {
          return false;
        }
      }

      if (!errorState.vatCode || !errorState.vatConsolidationCode) {
        const isValid = await isLedgerDescValid(ledgerDes, showPopup);
        if (isValid === false) {
          return false;
        }
      }
    }

    // if (isVatType(ledger_type)) {
    //   return false;
    // }

    // if (isExpType(ledger_type) && !isSalaryType(ledger_type)) {
    //   return false;
    // }

    // if (isBankType(ledger_type)) {
    //   return false;
    // }

    // if (isChargeCardType(ledger_type)) {
    //   return false;
    // }
    // if (ledger_des.trim().length === 0) {
    //   getAlertMessage("common.invalidData");
    //   return false;
    // }
    return true;
  };

  const fieldsStatus = {
    ledgerType: false,
    code: false,
    description: false,
    ledgerGroup: false,
    shortCode: false,
    normalVat: false,
    funds: false,
    vat: false,
    bank: false,
    cardsDetail: false,
    vatCode: false
  };

  // -----Below conditions is refers delphi-------
  const fieldVisibleOnInitiate = () => {
    const updateStatus = { ...fieldsStatus };
    // Start SetupLeddef============
    if (ledger_type === ledgerCodeType.EX) {
      // dbcbServices.Visible := True;
    } else {
      // dbcbServices.Visible := false;
    }
    if (isBankType(ledger_type) || isChargeCardType(ledger_type)) {
      updateStatus.bank = true;
    }
    // End SetupLeddef============

    // Start SetupPageForType ============
    if (isExpType(ledger_type)) {
      if (ledger_type === ledgerCodeType.IN) {
        // lsVatCodes.TableName := 'v_current_year_vat_out_codes'
      } else {
        // lsVatCodes.TableName := 'v_current_year_vat_in_codes';
      }
      fieldsStatus.vat = true;
      // if (tLeddefmodel_id.asInteger === 0) {
      //   tLeddefmodel_id.asInteger = manualProfileId;
      // }
    } else if (isBankType(ledger_type) || isChargeCardType(ledger_type)) {
      fieldsStatus.bank = true;
    } else if (isVatType(ledger_type)) {
      fieldsStatus.vat = true;
      if (ledger_type === ledgerCodeType.VO) {
        // dbcbRecoverable.Visible := False;
      }
    }

    if (isSalaryType(ledger_type)) {
      updateStatus.shortCode = true;
      updateStatus.funds = true;
    } else if (isExpType(ledger_type)) {
      updateStatus.shortCode = true;
      updateStatus.funds = true;

      updateStatus.normalVat = true;
    } else if (isVatType(ledger_type)) {
      updateStatus.vat = true;
    } else if (isBankType(ledger_type) || isChargeCardType(ledger_type)) {
      fieldsStatus.bank = true;
      if (isBankType(ledger_type)) {
        // fieldsStatus.accountCode = true
      }
    }
    // End SetupPageForType ============

    // p_setupCFR
    if (isBankType(ledger_type) || isChargeCardType(ledger_type)) {
      // p_displayDebitCards;
    }

    return updateStatus;
  };
  // -----Above conditions is refers delphi-------

  const confirmationPopupLC = ({
    yesFunc,
    noFunc,
    cancelFunc,
    changeTab,
    inputValidation = false
  }: TConfirmationPopup) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        message: t("common.keepChangesWishMsg"),
        title: t("common.simsFMSModule"),
        type: MODAL_TYPE.CONFIRMV2,
        yesCallback: async () => {
          if (inputValidation) {
            // Tab switch on form validation will come here
          } else {
            // Logic for Listing ledger codes
            dispatch(postLedgerCodes());
            if (typeof yesFunc === "function") yesFunc();
          }
        },
        noCallback: () => {
          dispatch(resetLedgerCodesState());
          if (typeof noFunc === "function") noFunc();
        },
        isCancelBtnEnable: true,
        cancelCallback: () => {
          if (typeof cancelFunc === "function") cancelFunc();
        }
      })
    );
  };

  const isPaylodValidLC = () => newLedgerCodesList.length > 0 || deleteLCIds.length > 0;
  const cancelWarningPopupLC = () => {
    if (isPaylodValidLC()) {
      dispatch(
        uiActions.confirmPopup({
          enable: true,
          message: t("generalLedgerSetup.cancelWarningMsg"),
          title: t("common.simsFMSModule"),
          type: MODAL_TYPE.CONFIRMV2,
          yesCallback: async () => {
            dispatch(resetLedgerCodesState());
            history.push("/");
          },
          noCallback: () => {
            history.push("/tools/general-ledger-setup/ledger-codes");
          }
        })
      );
    } else {
      history.push("/");
    }
  };

  const saveAndRedirect = () => {
    const selectedRow = setselectedRowData(ledgerCodeForm.formData);
    dispatch(setNewLCData({ ...ledgerCodeForm.formData, isUpdated: true }));
    dispatch(resetForm());
    history.push("/tools/general-ledger-setup/ledger-codes");
  };

  // Validate VAT Code function

  const findVatCodeInPreNextYear = async (year: string, value: string) =>
    dispatch(
      validateGLVatCodeYear({
        linkValue: 0,
        vatCode: value,
        yearId: year
      })
    );

  const validateVatCode = async (value: string, showPopup: boolean) => {
    let errorMessage = "";
    let msgOption = {};
    const vatCode = value;
    const vatRate = ledgerCodeForm.formData.vat?.rate;
    const vatConsolidationCode = ledgerCodeForm.formData.vat?.vat_consolidation_code;
    updateFormState({
      vat: {
        ...ledgerCodeForm.formData.vat,
        vat_code: vatCode,
        vat_id: 0,
        vat_consolidation_code: vatConsolidationCode,
        rate: vatRate || "0.00",
        in_use: "T",
        out_of_scope: "F",
        recoverable: "T"
      }
    });

    const vatAlreadyExists =
      newLedgerCodesList.some((item) => item?.vat?.vat_code === vatCode) ||
      vatCodeList.some((item) => item?.vat_code === vatCode);

    if (vatCode?.trim().length === 0) {
      errorMessage = "common.invalidData";
      setErrorState("vatCode" as any, errorMessage, showPopup, msgOption);
      return false;
    }

    if (vatAlreadyExists && errorMessage === "") {
      errorMessage = "generalLedgerSetup.ledgerCode.newLedgerVatCodeExistInCurrentYear";
      msgOption = { vatCode };
    }

    if (nextYear && nextYear !== 0) {
      const res: any = await findVatCodeInPreNextYear(nextYear, vatCode);
      if (res.payload === BOOLEAN_DATA.True) {
        errorMessage = "generalLedgerSetup.ledgerCode.newLedgerVatCodeExistInNextYear";
      } else {
        clearErrorState("vatCode" as any);
      }
    }

    if (previousYear && previousYear !== 0) {
      const res: any = await findVatCodeInPreNextYear(previousYear, vatCode);
      if (res.payload === BOOLEAN_DATA.True) {
        errorMessage = "generalLedgerSetup.ledgerCode.newLedgerVatCodeExistInPrevYear";
      } else {
        clearErrorState("vatCode" as any);
      }
    }

    if (errorMessage) {
      setErrorState("vatCode" as any, errorMessage, showPopup, msgOption);
      return false;
    }
    clearErrorState("vatCode" as any);
    return true;
  };

  const validateVatConsolidationCode = async (value: string, showPopup: boolean) => {
    let errorMessage = "";
    const validVatConsolidationCode = ["1", "2", "4", "6", "7", "8", "9"];
    const vatConsolidationCode = value;

    if (vatConsolidationCode !== undefined && vatConsolidationCode?.trim().length !== 0) {
      if (!validVatConsolidationCode.includes(vatConsolidationCode as string)) {
        errorMessage = "generalLedgerSetup.ledgerCode.newLedgerVatConsolidation";
        setErrorState("vatConsolidationCode" as any, errorMessage, showPopup, { vatConsolidationCode });
        return false;
      }
    }

    clearErrorState("vatConsolidationCode" as any);
    return true;
  };

  const setselectedRowData = (data: any) => {
    const selectedRow = {
      leddef_id: data.leddef_id,
      ledger_code: data.ledger_code,
      ledger_des: data.ledger_des,
      ledger_type: data.ledger_type,
      previous_year_leddef_id: data.previous_year_leddef_id,
      next_year_leddef_id: data.next_year_leddef_id
    };
    return selectedRow;
  };

  const isNoError = Object.values(errors).every((val) => !val);
  const onSubmit = async () => {
    const values = ledgerCodeForm.formData;
    dispatch(setFromSubmitting(true));
    const isValid = await isFormValid(true);
    if (isValid) {
      if (isVatType(ledger_type) && !isEditMode) {
        getConfirmPopup(
          "generalLedgerSetup.ledgerCode.newLedgerValidVatCode",
          {
            vatCode: values.vat?.vat_code,
            rate: values.vat?.rate
          },
          saveAndRedirect,
          true,
          undefined,
          "OK"
        );
      } else {
        saveAndRedirect();
      }
    }
    dispatch(setFromSubmitting(false));
  };
  return {
    isFormValid,
    confirmationPopupLC,
    cancelWarningPopupLC,
    isPaylodValidLC,
    fieldsStatus: fieldVisibleOnInitiate(),
    register,
    getFieldState,
    getValues,
    setError,
    setValue,
    trigger,
    watch,
    handleSubmit,
    onSubmit,
    clearErrorState,
    reset,
    setFocus,
    validateDescription,
    errors,
    validateVatCode,
    validateVatConsolidationCode,
    updateFormState,
    isEditPage
  };
};

export default useLedgerCodesForm;
