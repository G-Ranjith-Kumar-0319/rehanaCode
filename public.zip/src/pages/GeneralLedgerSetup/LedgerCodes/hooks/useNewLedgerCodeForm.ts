import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useForm } from "react-hook-form";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { BOOLEAN_DATA, ledgerCodeType, STATUS } from "@/types/UseStateType";
import { useHistory, useParams } from "react-router-dom";
import { useAppContext } from "@/routes/Routes";
import { localRoutes } from "@/utils/constants";
import { isArrayLength, isTextEqual } from "../../ProfileModels/utils";
import { deepSome } from "../../utils";
import {
  ledgerCodesAction,
  validateNewLedgerCodeYear,
  validatenewLedgerDescYear
} from "../../State/glLedgerCodes.slice";

/* eslint-disable camelcase */
export type FormData = {
  ledger_code: string;
  ledger_des: string;
};
/* eslint-enable camelcase */
const useNewLedgerForm = () => {
  const {
    register,
    formState: { errors, isDirty },
    getValues,
    setValue,
    trigger,
    watch,
    handleSubmit,
    clearErrors,
    reset,
    setFocus
  } = useForm<FormData>({
    defaultValues: {
      ledger_code: "",
      ledger_des: ""
    }
  });

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const { resolve, setPromise } = useAppContext();
  const { index }: { index: string } = useParams();
  const { previousYear, nextYear, previousState } = useAppSelector((state: any) => state.generalLedgerFundCode);
  const [isClicked, setIsClicked] = useState(false);
  const {
    ledgerCodesList,
    status: fundCodeDesc,
    ledgerCodeForm: { formData, isFormDirty },
    newLedgerErrorState,
    isCodeExist,
    isDescExist,
    tableLedgerCodeList
  } = useAppSelector((state) => state.glLedgerCodes);
  const { resetForm, setNewLedgerErrorState, setLedgerFormData, setNewLedgerSubmitting } = ledgerCodesAction;
  const findCodeInPreNextYear = async (year: string) =>
    dispatch(
      validateNewLedgerCodeYear({
        linkValue: 0,
        ledgerCode: watch("ledger_code"),
        yearId: year
      })
    );
  const findDescInPreNextYear = async (year: string) =>
    dispatch(
      validatenewLedgerDescYear({
        linkValue: 0,
        ledgerDesc: watch("ledger_des"),
        yearId: year
      })
    );

  const getAlertMessage = async (message: any, resolve?: any) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        message: t(`generalLedgerSetup.ledgerCode.${message}`),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus.ERROR,
        className: "primary-focus",
        callback: () => {
          if (resolve) resolve(true);
        }
      })
    );
  };

  const clearErrorState = (field: keyof FormData) => {
    dispatch(setNewLedgerErrorState({ ...newLedgerErrorState, [field]: false }));
    clearErrors(field);
  };

  // update errors if focus out and Response from endpoint change
  useEffect(() => {
    const updatedErrors = {
      ...newLedgerErrorState,
      ...(isCodeExist && { ledger_code: isCodeExist === BOOLEAN_DATA?.True }),
      ...(isDescExist && { ledger_des: isDescExist === BOOLEAN_DATA?.True })
    };
  }, [isCodeExist, isDescExist]);
  //
  const handleErrorByField = (field: keyof FormData, error: string, showPopup = false) => {
    dispatch(setNewLedgerErrorState({ ...newLedgerErrorState, [field]: true }));
    if (showPopup) {
      getAlertMessage(error);
    }
  };

  const validateCode = async (value: string, showPopup = true) => {
    let errorMessage = "";
    setIsClicked(false);
    // Check if the cost code is unique in the current list
    const found = deepSome(tableLedgerCodeList, value, "ledger_code");

    // Validate cost code
    if (!value) {
      errorMessage = "ledgerCodeRequired";
      handleErrorByField("ledger_code", errorMessage, false);
      return false;
    }
    if (found) {
      errorMessage = "ledgerCodeNotUnique";
      dispatch(setNewLedgerErrorState({ ...newLedgerErrorState, ledger_code: true }));
      await setPromise((resolve: any) => getAlertMessage(errorMessage, resolve));
      return false;
    }
    if (previousYear && previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
      const res: any = await findCodeInPreNextYear(previousYear);
      if (res?.payload === BOOLEAN_DATA.True) {
        errorMessage = "ledgerCodeExistInPrevYear";
        dispatch(setNewLedgerErrorState({ ...newLedgerErrorState, ledger_code: true }));
        await setPromise((resolve: any) => getAlertMessage(errorMessage, resolve));
      } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
        clearErrorState("ledger_code");
      }
    }
    if (nextYear && nextYear !== 0) {
      const res: any = await findCodeInPreNextYear(nextYear);
      if (res?.payload === BOOLEAN_DATA.True) {
        errorMessage = "ledgerCodeExistInNextYear";
        dispatch(setNewLedgerErrorState({ ...newLedgerErrorState, ledger_code: true }));
        await setPromise((resolve: any) => getAlertMessage(errorMessage, resolve));
      } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
        clearErrorState("ledger_code");
      }
    }

    if (errorMessage === "") clearErrorState("ledger_code");
    return true;
  };

  const validateDescription = async (value: string, showPopup = false) => {
    setIsClicked(false);
    let errorMessage = "";
    let result: boolean | undefined;
    const found = value && deepSome(tableLedgerCodeList, value, "ledger_des");
    // Validate description
    if (!value) {
      errorMessage = "newLedgerDescRequired";
      handleErrorByField("ledger_des", errorMessage, false);
      return false;
    }
    if (found) {
      errorMessage = "newLedgerDescExist";
      dispatch(setNewLedgerErrorState({ ...newLedgerErrorState, ledger_des: true }));
      await setPromise((resolve: any) => getAlertMessage(errorMessage, resolve));
    }
    if (nextYear && nextYear !== 0) {
      const res: any = await findDescInPreNextYear(nextYear);
      if (res.payload === BOOLEAN_DATA.True) {
        errorMessage = "newLedgerDescExistInNextYear";
        dispatch(setNewLedgerErrorState({ ...newLedgerErrorState, ledger_des: true }));
        await setPromise((resolve: any) => getAlertMessage(errorMessage, resolve));
      } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
        clearErrorState("ledger_des");
      }
    }
    if (previousYear && previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
      const res: any = await findDescInPreNextYear(previousYear);
      if (res.payload === BOOLEAN_DATA.True) {
        errorMessage = "newLedgerDescExistInPrevYear";
        dispatch(setNewLedgerErrorState({ ...newLedgerErrorState, ledger_des: true }));
        result = await setPromise((resolve: any) => getAlertMessage(errorMessage, resolve));
      } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
        clearErrorState("ledger_des");
      }
    }
    // Clear error
    if (errorMessage === "") clearErrorState("ledger_des");
    return true;
  };

  const validateFields = async (showPopup = false) => {
    const values = formData || getValues();
    if (
      (await validateCode(values.ledger_code, showPopup)) &&
      (await validateDescription(values.ledger_des, showPopup))
    ) {
      return true;
    }
    return false;
  };

  const clearForm = () => {
    setValue("ledger_code", "");
    setValue("ledger_des", "");
    setFocus("ledger_code"); // Focus after save and continue...
  };

  const isLocalValid = () => Object.values(newLedgerErrorState ?? {}).every((t) => t === false);

  const saveAsRedirect = () => {
    const ledgerShort =
      formData.ledger_short !== ledgerCodeType.BK && formData.ledger_short !== ledgerCodeType.CL
        ? formData.ledger_code
        : "";
    dispatch(
      setLedgerFormData({
        ...formData,
        ledger_code: formData.ledger_code,
        ledger_des: formData.ledger_des,
        ledger_short: ledgerShort
      })
    );
    history.push(localRoutes.generalLedgerSetup.ledgerCodeSave);
    setIsClicked(false);
    clearForm();
  };

  const onSubmit = async () => {
    setIsClicked(true);
    // const isValid = fundCodeDesc === STATUS.SUCCESS
    const isValid = await validateFields(false);
    if (isValid) {
      saveAsRedirect();
    }
  };
  return {
    register,
    errors,
    setValue,
    watch,
    handleSubmit,
    validateFields,
    validateCode,
    validateDescription,
    trigger,
    reset,
    getValues,
    setFocus,
    clearForm,
    clearErrorState,
    handleErrorByField,
    isDirty,
    onSubmit,
    isLocalValid,
    setIsClicked,
    isClicked
  };
};

export default useNewLedgerForm;
