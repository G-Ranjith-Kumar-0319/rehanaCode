import { useEffect } from "react";
import { useHistory } from "react-router-dom";

const useRedirectOnRefresh = (redirectPath: string) => {
  const history = useHistory();

  useEffect(() => {
    // Check if the page was refreshed
    if (localStorage.getItem("isPageRefreshed") === "true") {
      localStorage.removeItem("isPageRefreshed");
      history.replace(redirectPath);
    }

    // Set the flag when the component unmounts (i.e., on page refresh)
    const handleBeforeUnload = () => {
      localStorage.setItem("isPageRefreshed", "true");
    };

    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [history, redirectPath]);
};

export default useRedirectOnRefresh;
