import React, { useEffect } from "react";
import Layout from "@/components/Layout/Layout";
import { useHistory, useParams } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { Loader, LoaderType } from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import AddLedgerCodesDefinition from "../AddLedgerCodesDefinition/AddLedgerCodesDefinition";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import { getLedgerCodeDetails, ledgerCodesAction, postLedgerCodes } from "../../State/glLedgerCodes.slice";
import useLedgerCodesForm from "../hooks/useLedgerCodesForm";
import AddExpenditureLedgerCodes from "../AddExpenditureLedgerCodes/AddExpenditureLedgerCodes";
import AddVatLedgerCodeDefinition from "../AddVatLedgerCodeDefinition/AddVatLedgerCodeDefinition";
import { isVatType } from "../utils";
import useRedirectOnRefresh from "../hooks/useRedirectOnRefresh";

const LedgerCodeSaveForm = () => {
  useRedirectOnRefresh("/tools/general-ledger-setup/ledger-codes"); // Will redirect if page is refreshed
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const { ledgefId }: any = useParams();
  const {
    ledgerCodeForm: { formData },
    errorState,
    isFormSubmitting,
    newLedgerCodesList,
    ledgerCodesList,
    selectedRowGlCodes,
    tableLedgerCodeList
  } = useAppSelector((state) => state.glLedgerCodes);
  const { setNewLCData, updateErrorState, resetForm, setLedgerFormData, selectGlListSelectedRow } = ledgerCodesAction;

  const { onSubmit, errors, reset, watch, setValue } = useLedgerCodesForm();

  const dispatch = useDispatch();

  useEffect(
    () => () => {
      const resetErrorState = Object.keys(errorState).reduce((acc: any, key: string) => {
        acc[key] = false;
        return acc;
      }, {});
      dispatch(updateErrorState(resetErrorState));
    },
    []
  );

  useEffect(() => {
    const newLedgefId = parseInt(ledgefId, 10);
    const data = tableLedgerCodeList.find((item: any) => item.leddef_id === newLedgefId);
    if (newLedgefId && newLedgefId !== 0 && !data?.isUpdated) {
      dispatch(getLedgerCodeDetails(ledgefId));
    } else if (newLedgefId && newLedgefId !== 0) {
      dispatch(setLedgerFormData({ ...formData, ...data }));
    }
  }, [ledgefId]);

  const handleCancel = () => {
    dispatch(resetForm());
    dispatch(selectGlListSelectedRow(selectedRowGlCodes));
    history.replace("/tools/general-ledger-setup/ledger-codes");
  };

  return (
    <>
      <GeneralLedgerSetup>
        <Layout
          className="p-0 glc-form"
          isBreadcrumbRequired={false}
        >
          <div className="essui-global-typography-default-subtitle form-heading">
            {t("generalLedgerSetup.ledgerCode.ledgerCodeDefinition")}
          </div>
          {isFormSubmitting ? (
            <>
              <Loader
                loaderType={LoaderType.Circular}
                loaderText="Please wait"
              />
            </>
          ) : (
            <>
              <AddLedgerCodesDefinition />

              {/* <AddExpenditureLedgerCodes /> */}

              {isVatType(formData.ledger_type) && <AddVatLedgerCodeDefinition />}

              <GenralLedgerFooter
                cancelCallback={handleCancel}
                onSubmit={onSubmit}
              />
            </>
          )}
        </Layout>
      </GeneralLedgerSetup>
    </>
  );
};

export default LedgerCodeSaveForm;
