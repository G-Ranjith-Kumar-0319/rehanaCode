import {
  Dropdown,
  DropdownItem,
  FormLabel,
  Grid,
  GridItem,
  ISelectedItem,
  Loader,
  LoaderType,
  TextInputSize
} from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import "./Style.scss";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import React, { useEffect, useRef } from "react";
import { useHistory } from "react-router-dom";
import { CUR_PAGE_WIZARD, ledgerCodeType, STATUS } from "@/types/UseStateType";
import { localRoutes } from "@/utils/constants";
import { getLedgerGroupsList, ledgerCodesAction, TLedgerGrp } from "../../State/glLedgerCodes.slice";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import { checkGlLedgerType } from "../../utils";
import useSortedData from "../../hooks/useSortedData";

const LedgerCodeDefinitionWizardStepTwo = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const {
    status,
    stepFormData: { ledgerGrpSelected, selectedLedgerCodeType },
    callLedgergrpApi,
    ledgerGrpList,
    ledgerCodeForm: { formData }
  } = useAppSelector((state) => state.glLedgerCodes);
  const { resetForm, setLedgerFormData } = ledgerCodesAction;
  const isGlLedgerCodeType = checkGlLedgerType({ value: formData.ledger_type } as any);
  const ledgerGrpListSorted = useSortedData(ledgerGrpList, "group_des", "asc");

  useEffect(() => {
    if (callLedgergrpApi) {
      dispatch(getLedgerGroupsList());
    }
  }, [callLedgergrpApi]);

  const handleCancel = () => {
    dispatch(resetForm());
    history.replace("/tools/general-ledger-setup/ledger-codes");
  };

  useEffect(() => {
    const inputElement = document.getElementById("ledgerGrpInput") as HTMLInputElement;
    if (inputElement) {
      setTimeout(() => {
        inputElement.focus();
      }, 0);
    }
  }, [ledgerGrpListSorted]);

  return (
    <GeneralLedgerSetup>
      <div className="wizard-container">
        {status === STATUS.LOADING ? (
          <Loader
            loaderType={LoaderType.Circular}
            loaderText="Please wait"
            isLoaderModal={false}
          />
        ) : (
          <>
            <Grid className="mb-16">
              <GridItem
                sm={4}
                className="mb-16"
              >
                <div className="essui-global-typography-default-subtitle">
                  {t("generalLedgerSetup.ledgerCode.ledgerCodeSteps", {
                    currentStep: isGlLedgerCodeType ? CUR_PAGE_WIZARD.TWO_BY_FOUR : CUR_PAGE_WIZARD.TWO_BY_THREE
                  })}
                </div>
              </GridItem>
              <GridItem sm={4}>
                <div className="sub-heading">{t("generalLedgerSetup.ledgerCode.screen3FundCodeSubHeading")}</div>
              </GridItem>
            </Grid>
            <Grid className="mt-8">
              <GridItem
                sm={4}
                md={3}
                lg={4}
                xl={4}
                xxl={4}
              >
                <div className="ledger__codes--belongs form-container">
                  <FormLabel
                    forId="txtEnterNewDescription"
                    className=""
                  >
                    {t("generalLedgerSetup.ledgerCode.selectLedgerGrp")}
                  </FormLabel>
                  <Dropdown
                    id="ledgerGrpInput"
                    selectedItem={{
                      text: formData?.group_des,
                      value: `dropdown-${formData?.group_id.toString()}`
                    }}
                    placeholderText="Search"
                    size={TextInputSize.Medium}
                    searchable
                    isScrollbarVisible
                    onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => {
                      const id = item?.value!.split("-")[1];
                      dispatch(
                        setLedgerFormData({
                          ...formData,
                          group_id: parseInt(id, 10),
                          group_des: item.text!
                        })
                      );
                    }}
                  >
                    {(ledgerGrpListSorted || []).map((data: TLedgerGrp, i: any) => {
                      const id = `dropdown-${data.group_id}`;
                      return (
                        <DropdownItem
                          key={id}
                          id={id}
                          text={data.group_des}
                          value={id}
                        >
                          {data.group_des}
                        </DropdownItem>
                      );
                    })}
                  </Dropdown>
                </div>
              </GridItem>
            </Grid>
          </>
        )}

        <GenralLedgerFooter
          cancelCallback={handleCancel}
          backCtaCallback={{ backCta: () => history.replace("/tools/ledger-codes/add"), isDisabled: false }}
          nextCtaCallback={{
            nextCta: () => {
              if (isGlLedgerCodeType) {
                history.push(localRoutes.generalLedgerSetup.ledgerCodeWizadThree);
              } else {
                history.push(localRoutes.generalLedgerSetup.ledgerCodeWizadFour);
              }
            },
            isDisabled: !formData?.group_id && !formData?.group_des
          }}
        />
      </div>
    </GeneralLedgerSetup>
  );
};
export default LedgerCodeDefinitionWizardStepTwo;
