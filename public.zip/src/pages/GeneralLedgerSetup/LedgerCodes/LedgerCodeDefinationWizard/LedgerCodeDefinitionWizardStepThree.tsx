import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  TextInput,
  Tooltip
} from "@essnextgen/ui-kit";
import Input from "@/components/Input/Input";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { localRoutes } from "@/utils/constants";
import { CUR_PAGE_WIZARD } from "@/types/UseStateType";
import LedgerCodeFundCodeModal from "../Modals/LedgerCodeFundCodeModal";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import { glLedgerFundCodeAction } from "../../State/glLedgerCodeFundCode.slice";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import { ledgerCodesAction } from "../../State/glLedgerCodes.slice";
import "./Style.scss";

/* eslint-disable camelcase */
type FormData = {
  fund_code: string;
  ledger_des: string;
};

const LedgerCodeDefinitionWizardStepThree = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const [isFundCode, setIsFundCode] = useState<boolean>(false);
  const { ledgerCodeFundCodes, selectedLedgerFundCode } = useAppSelector((state) => state.glLedgerCodeFundCode);
  const { resetForm, setLedgerFormData } = ledgerCodesAction;
  const formMethods = useForm<FormData>({
    mode: "all",
    shouldFocusError: false,
    defaultValues: {
      fund_code: "",
      ledger_des: ""
    }
  });
  const {
    ledgerCodeForm: { formData },
    newLedgerErrorState
  } = useAppSelector((state) => state.glLedgerCodes);
  const {
    register,
    setValue,
    watch,
    formState: { errors, isDirty }
  } = formMethods;

  const handleCancel = () => {
    dispatch(glLedgerFundCodeAction.reset());
    dispatch(resetForm());
    history.replace(localRoutes.generalLedgerSetup.ledgerCodeList);
  };

  useEffect(() => {
    if (selectedLedgerFundCode) {
      setValue("fund_code", selectedLedgerFundCode.fund_code);
      setValue("ledger_des", selectedLedgerFundCode.ledger_des);
    }
  }, [selectedLedgerFundCode]);

  return (
    <>
      <FormProvider {...formMethods}>
        <GeneralLedgerSetup>
          <div className="wizard-container">
            <Grid className="mb-16">
              <GridItem
                sm={4}
                className="mb-16"
              >
                <div className="essui-global-typography-default-subtitle">
                  {t("generalLedgerSetup.ledgerCode.ledgerCodeSteps", { currentStep: CUR_PAGE_WIZARD.THREE_BY_FOUR })}
                </div>
              </GridItem>
              <GridItem sm={4}>
                <div className="sub-heading">{t("generalLedgerSetup.ledgerCode.screen3FundCodeSubHeading")}</div>
              </GridItem>
            </Grid>
            <Grid className="mt-8">
              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={3}
                className="input--width80 "
              >
                <div className="normal__vat--field">
                  <FormLabel forId="ledgerFundCode">
                    {t("generalLedgerSetup.ledgerCode.screen3FundCodeHeading")}{" "}
                  </FormLabel>

                  <Input
                    autoFocus
                    id="ledgerFundCode"
                    labelText=""
                    className="gl-fund-code-width55"
                    searchable
                    button={
                      <>
                        <Tooltip
                          content={watch("ledger_des")}
                          id="txtBacsDescription"
                        >
                          <div className="essui-textinput essui-textinput--medium read-only invoice-line-tooltip-class">
                            {watch("ledger_des")}
                          </div>
                        </Tooltip>
                        <Button
                          color={ButtonColor.Secondary}
                          onClick={() => {
                            setIsFundCode(true);
                          }}
                          size={ButtonSize.Small}
                          className="essui-button-icon-only--small"
                          ariaLabel="search"
                          id="glSelectFundCodeSearch"
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="search"
                          />
                        </Button>
                      </>
                    }
                    onSelect={(selectedItem) => {
                      const fundDetails = ledgerCodeFundCodes.filter((s) => s.fund_code === selectedItem?.value).at(0);
                      if (selectedItem?.text) {
                        setValue("fund_code", fundDetails?.fund_code, { shouldDirty: true, shouldValidate: true });
                      }
                      dispatch(glLedgerFundCodeAction.selectRow(fundDetails));
                    }}
                    onNoSelection={() => {
                      setIsFundCode(true);
                      setValue("fund_code", "");
                      setValue("ledger_des", "");
                    }}
                    value={watch("fund_code")}
                    searchItems={ledgerCodeFundCodes.map((b) => ({ text: b.fund_code, value: b.fund_code }))}
                    inputRef={register("fund_code").ref}
                    name={
                      register("fund_code", {
                        required: true
                      }).name
                    }
                    onChange={(e) => {
                      setValue("fund_code", e.target.value);
                      register("fund_code").onChange(e);
                      if (!e.target.value) {
                        dispatch(glLedgerFundCodeAction.selectRow(undefined));
                        setValue("ledger_des", "");
                      }
                    }}
                    onPending={(selectedValue) => {
                      if (selectedValue?.text) {
                        const ledgerFundCodeVal = ledgerCodeFundCodes.filter(
                          (s: any) => s.fund_code === selectedValue?.value
                        )[0];
                        dispatch(
                          setLedgerFormData({
                            ...formData,
                            funds: [
                              {
                                fund_id: ledgerFundCodeVal?.fund_id as any,
                                fund_code: ledgerFundCodeVal?.fund_code,
                                fund_des: ledgerFundCodeVal?.ledger_des
                                  ? ledgerFundCodeVal?.ledger_des
                                  : ledgerFundCodeVal?.fund_des,
                                cfr_code: ledgerFundCodeVal?.cfr_code
                              }
                            ]
                          })
                        );
                        setValue("ledger_des", ledgerFundCodeVal?.ledger_des);
                      }
                    }}
                    onBlur={(e) => {
                      if (!isFundCode) {
                        register("fund_code").onBlur(e);
                      }
                    }}
                  />
                </div>
              </GridItem>
            </Grid>
            <GenralLedgerFooter
              cancelCallback={handleCancel}
              backCtaCallback={{
                backCta: () => history.replace(localRoutes.generalLedgerSetup.ledgerCodeWizadTwo),
                isDisabled: false
              }}
              nextCtaCallback={{
                nextCta: () => {
                  history.push(localRoutes.generalLedgerSetup.ledgerCodeWizadFour);
                },
                isDisabled: !selectedLedgerFundCode
              }}
            />
          </div>
        </GeneralLedgerSetup>
        <LedgerCodeFundCodeModal
          isOpen={isFundCode}
          setOpen={setIsFundCode}
        />
      </FormProvider>
    </>
  );
};
export default LedgerCodeDefinitionWizardStepThree;
