import { FormLabel, Grid, GridItem, ValidationTextLevel } from "@essnextgen/ui-kit";
import Input from "@/components/Input/Input";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useHistory } from "react-router-dom";

import { CUR_PAGE_WIZARD } from "@/types/UseStateType";
import { localRoutes } from "@/utils/constants";
import { useEffect } from "react";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import { checkGlLedgerType, handleKeyPress } from "../../utils";
import { ledgerCodesAction } from "../../State/glLedgerCodes.slice";
import { glLedgerFundCodeAction } from "../../State/glLedgerCodeFundCode.slice";
import useNewLedgerForm from "../hooks/useNewLedgerCodeForm";

const LedgerCodeDefinitionWizardStepFour = () => {
  const {
    register,
    setValue,
    watch,
    validateCode,
    validateDescription,
    onSubmit,
    clearErrorState,
    handleErrorByField
  } = useNewLedgerForm();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    ledgerCodeForm: { formData },
    newLedgerErrorState
  } = useAppSelector((state) => state.glLedgerCodes);
  const { resetForm, setNewLedgerErrorState, setLedgerFormData } = ledgerCodesAction;

  useEffect(() => {
    if (formData?.ledger_code || formData?.ledger_des) {
      setValue("ledger_code", formData?.ledger_code);
      setValue("ledger_des", formData?.ledger_des);
    }
  }, [formData?.ledger_code]);

  const handleCancel = () => {
    dispatch(glLedgerFundCodeAction.reset());
    dispatch(resetForm());
    history.replace(localRoutes.generalLedgerSetup.ledgerCodeList);
  };

  const isGlLedgerCodeType = checkGlLedgerType({ value: formData.ledger_type } as any);

  // Clear error on change event
  const clearError = (field: string) => {
    dispatch(setNewLedgerErrorState({ ...newLedgerErrorState, [field]: false }));
  };

  const handleDisable = () => {
    if (watch("ledger_code") === "" || watch("ledger_des") === "") {
      return true;
    }
    if (newLedgerErrorState && (newLedgerErrorState.ledger_code || newLedgerErrorState.ledger_des)) {
      return true;
    }
    return false;
  };

  return (
    <>
      <GeneralLedgerSetup>
        <div className="wizard-container">
          <Grid className="mb-16">
            <GridItem
              sm={4}
              className="mb-16"
            >
              <div className="essui-global-typography-default-subtitle">
                {t("generalLedgerSetup.ledgerCode.ledgerCodeSteps", {
                  currentStep: isGlLedgerCodeType ? CUR_PAGE_WIZARD.FOUR_BY_FOUR : CUR_PAGE_WIZARD.THREE_BY_THREE
                })}
              </div>
            </GridItem>
            <GridItem sm={4}>
              <div className="sub-heading">{t("generalLedgerSetup.ledgerCode.screen4SubHeading")}</div>
            </GridItem>
          </Grid>
          <Grid>
            <GridItem
              sm={4}
              md={2}
              lg={2}
              xl={2}
              xxl={2}
            >
              <div>
                <FormLabel forId="txtEnterNewCode">{t("generalLedgerSetup.ledgerCode.screen4Code")}</FormLabel>
                <Input
                  autoFocus
                  id="txtEnterNewCode"
                  className="gl-input-uppercase"
                  value={watch("ledger_code").toUpperCase()}
                  inputRef={(e) => register("ledger_code").ref(e)}
                  name={
                    register("ledger_code", {
                      required: true
                    }).name
                  }
                  onChange={(e) => {
                    clearError("ledger_code");
                    setValue("ledger_code", e.target.value.toUpperCase(), {
                      shouldDirty: true
                    });
                    dispatch(
                      setLedgerFormData({
                        ...formData,
                        ledger_code: e.target.value.toUpperCase()
                      })
                    );
                  }}
                  onKeyDown={(e: any) => handleKeyPress(e, /[a-zA-Z0-9]/)}
                  maxLength={8} // This ensures the input box itself restricts input to 8 characters
                  onBlur={(e: any) => validateCode(e.target.value)}
                  validationTextLevel={newLedgerErrorState?.ledger_code ? ValidationTextLevel.Error : undefined}
                />
              </div>
            </GridItem>
          </Grid>
          <Grid className="mt-8">
            <GridItem
              sm={4}
              md={3}
              lg={3}
              xl={3}
              xxl={3}
            >
              <div>
                <FormLabel
                  forId="txtEnterNewDescription"
                  className=""
                >
                  {t("generalLedgerSetup.ledgerCode.screen4Desc")}
                </FormLabel>
                <Input
                  id="txtEnterNewDescription"
                  value={watch("ledger_des")}
                  inputRef={(e) => register("ledger_des").ref(e)}
                  name={
                    register("ledger_des", {
                      required: true
                    }).name
                  }
                  onChange={(e) => {
                    clearErrorState("ledger_des");
                    setValue("ledger_des", e.target.value, {
                      shouldDirty: true
                    });
                    dispatch(
                      setLedgerFormData({
                        ...formData,
                        ledger_des: e.target.value
                      })
                    );
                  }}
                  maxLength={32} // This ensures the input box itself restricts input to 32 characters
                  onBlur={(e: any) => validateDescription(e.target.value)}
                  validationTextLevel={newLedgerErrorState?.ledger_des ? ValidationTextLevel.Error : undefined}
                />
              </div>
            </GridItem>
          </Grid>
          <GenralLedgerFooter
            cancelCallback={handleCancel}
            backCtaCallback={{
              backCta: () => {
                if (isGlLedgerCodeType) {
                  history.replace(localRoutes.generalLedgerSetup.ledgerCodeWizadThree);
                } else {
                  history.replace(localRoutes.generalLedgerSetup.ledgerCodeWizadTwo);
                }
              },
              isDisabled: false
            }}
            finishCtaCallback={{
              finishCta: () => {
                onSubmit();
                // Redirect to final save page
              },
              isDisabled: handleDisable()
            }}
          />
        </div>
      </GeneralLedgerSetup>
    </>
  );
};
export default LedgerCodeDefinitionWizardStepFour;
