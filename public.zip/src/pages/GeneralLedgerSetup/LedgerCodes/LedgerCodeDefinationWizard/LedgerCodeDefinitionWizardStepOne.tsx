import {
  Button,
  ButtonColor,
  ButtonSize,
  Dropdown,
  DropdownItem,
  FormLabel,
  Grid,
  GridItem,
  ISelectedItem,
  Loader,
  LoaderType,
  NotificationStatus,
  TextInputSize
} from "@essnextgen/ui-kit";
import React, { useEffect, useLayoutEffect, useState } from "react";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { useHistory } from "react-router-dom";
import Layout from "@/components/Layout/Layout";
import { BOOLEAN_DATA, CUR_PAGE_WIZARD, ledgerCodeType, STATUS, yearState } from "@/types/UseStateType";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import { text } from "stream/consumers";
import {
  creditorExist,
  debtorExist,
  earningChecks,
  getfinancialYearData,
  getWizardDropDown,
  ledgerCodesAction,
  ledgerDescExist,
  lowestUnfinalizedYear
} from "../../State/glLedgerCodes.slice";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import { isArrayLength, isTextEqual } from "../../ProfileModels/utils";
import { checkGlLedgerType } from "../../utils";

const LedgerCodeDefinitionWizardStepOne = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    wizardList,
    isWizardLoaded,
    status,
    CCCodeExist,
    CCDodeExist,
    isEarningChecks,
    isLowestUnfinalizedYr,
    financialYearData,
    ledgerCodeForm: { formData },
    stepFormData: { selectedLedgerCodeType }
  } = useAppSelector((state) => state.glLedgerCodes);
  const { previousYear, nextYear, previousState } = useAppSelector((state: any) => state.generalLedgerFundCode);
  const { resetForm, setLedgerFormData } = ledgerCodesAction;
  const [isNextBtnActive, setNextBtnActive] = useState(false);
  const isGlLedgerCodeType = checkGlLedgerType({ value: formData.ledger_type } as any);
  useLayoutEffect(() => {
    if (!isWizardLoaded) dispatch(getWizardDropDown());
  }, []);

  const handleCancel = () => {
    dispatch(resetForm());
    history.replace("/tools/general-ledger-setup/ledger-codes");
  };

  const getAlertMessage = (message: string) => {
    const alertMessage = isTextEqual(message, isEarningChecks)
      ? isEarningChecks
      : t(`generalLedgerSetup.ledgerCode.${message}`);
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        message: alertMessage,
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus.WARNING,
        callback: () => setToSession("glWarnBudget", true)
      })
    );
  };

  const getConfirmMsg = (message: string) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        message: t(`generalLedgerSetup.ledgerCode.${message}`),
        title: t("common.simsFMSModule"),
        type: MODAL_TYPE.CONFIRMV2,
        yesCallback: () => {},
        noCallback: () => {
          handleCancel();
        }
      })
    );
  };

  // Initially handle first item selecte
  useEffect(() => {
    if (isArrayLength(wizardList) && !formData.ledger_type) {
      const intialItem = { ledger_type: wizardList[0]?.code, ledger_type_des: wizardList[0].description };
      dispatch(setLedgerFormData({ ...formData, ...intialItem }));
    }
  }, [wizardList]);
  const getOnChangeValidateReq = () => {
    if (CCCodeExist && CCDodeExist && isEarningChecks && isLowestUnfinalizedYr) return;
    if (CCCodeExist === undefined) dispatch(creditorExist());
    if (CCDodeExist === undefined) dispatch(debtorExist());
    if (isEarningChecks === undefined) dispatch(lowestUnfinalizedYear());
    if (isLowestUnfinalizedYr === undefined) dispatch(earningChecks());
    if (financialYearData === undefined) dispatch(getfinancialYearData());
  };
  useEffect(() => {
    getOnChangeValidateReq();
  }, []);

  const handleOnSelect = (item: ISelectedItem) => {
    const ledgerType = item?.value;
    dispatch(setLedgerFormData({ ...formData, ledger_type: ledgerType as string, ledger_type_des: item?.text }));

    let errorMsg = "";
    if (ledgerType === ledgerCodeType.BK && CCCodeExist === BOOLEAN_DATA.False && CCDodeExist === BOOLEAN_DATA.True) {
      errorMsg = "creditorAlertMsg";
    } else if (
      ledgerType === ledgerCodeType.BK &&
      previousYear !== 0 &&
      !(previousState !== yearState.S && financialYearData?.year_state === yearState.S)
    ) {
      errorMsg = "bankAccountAlertMsg";
    } else if (ledgerType === ledgerCodeType.CC && CCCodeExist) {
      errorMsg = "controlAlertMsg";
    } else if (ledgerType === ledgerCodeType.DC && CCDodeExist) {
      errorMsg = "debtorAlertMsg";
    } else if (
      (ledgerType === ledgerCodeType.CC || ledgerType === ledgerCodeType.DC) &&
      isLowestUnfinalizedYr === BOOLEAN_DATA.False
    ) {
      getConfirmMsg("lowestFinalizedConfrimMSg");
    } else if (ledgerType === ledgerCodeType.RE && isEarningChecks !== "") {
      errorMsg = isEarningChecks;
    } else {
      setNextBtnActive(false);
    }
    if (errorMsg) {
      getAlertMessage(errorMsg);
      setNextBtnActive(true);
    }
  };

  useEffect(() => {
    setTimeout(() => {
      document.getElementById("ledgerCodeTypeDrop")?.focus();
    }, 0);
  }, [wizardList]);
  return (
    <>
      <GeneralLedgerSetup>
        <Layout
          isBreadcrumbRequired={false}
          className="p-0"
        >
          {status === STATUS.LOADING ? (
            <Loader
              loaderType={LoaderType.Circular}
              loaderText="Please wait"
              isLoaderModal={false}
            />
          ) : (
            <>
              <Grid className="mb-16">
                <GridItem
                  sm={4}
                  className="mb-16"
                >
                  <div className="essui-global-typography-default-subtitle">
                    {t("generalLedgerSetup.ledgerCode.ledgerCodeSteps", {
                      currentStep: isGlLedgerCodeType ? CUR_PAGE_WIZARD.ONE_BY_FOUR : CUR_PAGE_WIZARD.ONE_BY_THREE
                    })}
                  </div>
                </GridItem>
                <GridItem sm={4}>
                  <div className="sub-heading">{t("generalLedgerSetup.ledgerCode.stepOneMessage")}:</div>
                </GridItem>
              </Grid>
              <Grid className="mt-8">
                <GridItem
                  sm={4}
                  md={3}
                  lg={3}
                  xl={3}
                  xxl={3}
                >
                  <div>
                    <FormLabel
                      forId="ledgerCodeTypeDrop"
                      className=""
                    >
                      {t("generalLedgerSetup.ledgerCode.selectLedgerCodeTypeMsg")}
                    </FormLabel>
                    <Dropdown
                      id="ledgerCodeTypeDrop"
                      size={TextInputSize.Medium}
                      selectedItem={{
                        text: formData.ledger_type_des,
                        value: formData?.ledger_type
                      }}
                      searchable
                      isScrollbarVisible
                      onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => {
                        handleOnSelect(item);
                      }}
                    >
                      {(wizardList || [])?.map((item: { [key: string]: string }) => (
                        <DropdownItem
                          value={item?.code}
                          text={item?.description}
                          key={item?.code}
                        >
                          {item.description}
                        </DropdownItem>
                      ))}
                    </Dropdown>
                  </div>
                </GridItem>
              </Grid>
            </>
          )}
          <GenralLedgerFooter
            backCtaCallback={{
              backCta: () => {},
              isDisabled: true
            }}
            nextCtaCallback={{
              nextCta: () => {
                history.push("/tools/ledger-codes/ledger-group");
              },
              isDisabled: isNextBtnActive
            }}
            cancelCallback={handleCancel}
          />
        </Layout>
      </GeneralLedgerSetup>
    </>
  );
};
export default LedgerCodeDefinitionWizardStepOne;
