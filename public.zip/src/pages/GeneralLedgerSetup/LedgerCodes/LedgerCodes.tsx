import React, { useEffect, useState } from "react";
import { Grid, GridItem, Loader, LoaderType, NotificationStatus } from "@essnextgen/ui-kit";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useHistory } from "react-router-dom";
import { getLedgerCodeList, ledgerCodesAction, postLedgerCodes } from "../State/glLedgerCodes.slice";
import LedgerCodesFilter from "./Grid/LedgerCodesFilter";
import GenralLedgerFooter from "../GeneralLedgerFooter";
import GeneralLedgerSetup from "../GeneralLedgerSetup";
import CustomCell from "./Grid/CustomCell";
import useLedgerGrpPopup from "../hooks/useLedgerGrpPopup";
import { ledgerGrpAction } from "../State/LedgerGroupsList.slice";

import { getNextYear, getPreviousYear, getPrevState } from "../State/GeneralLedgerFundCodeListing.slice";
import useLedgerCodesForm from "./hooks/useLedgerCodesForm";
import { glLedgerFundCodeAction } from "../State/glLedgerCodeFundCode.slice";
import { isArrayLength } from "../ProfileModels/utils";
import { ledgerFundDefinitionAction } from "../State/glLedgerFundDefinition.slice";

const LedgerCodes = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const { setTabData } = useLedgerGrpPopup();
  const { setSelectedRow, setCancelBtnClick } = ledgerGrpAction;
  const {
    ledgerCodesList,
    status,
    filters,
    columnDef,
    selectedRowGlCodes,
    isFormSubmitting,
    newLedgerCodesList,
    tableLedgerCodeList,
    ledgerCodeForm
  } = useAppSelector((state) => state.glLedgerCodes);
  const { selectGlListSelectedRow, setTableList, setFilters, setFromSubmitting } = ledgerCodesAction;
  const { previousYear, nextYear, previousState } = useAppSelector((state: any) => state.generalLedgerFundCode);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const isWarnBudget = getSessionItem("glWarnBudget");
  const { cancelWarningPopupLC, isPaylodValidLC } = useLedgerCodesForm();
  const [selectRow, setSelectRow] = useState<any>();
  const getAlertMessage = (message: string) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        message: t(`generalLedgerSetup.ledgerCode.${message}`),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus.WARNING,
        callback: () => {
          setToSession("glWarnBudget", true);
          dispatch(ledgerCodesAction.resetForm());
          dispatch(glLedgerFundCodeAction.reset());
          history.push("/tools/ledger-codes/add");
        }
      })
    );
  };

  useEffect(() => {
    if (ledgerCodesList.length !== 0 || newLedgerCodesList.length !== 0) {
      dispatch(setTableList([...ledgerCodesList, ...newLedgerCodesList]));
    }
  }, [newLedgerCodesList, ledgerCodesList, filters?.sequenceValue]);

  useEffect(() => {
    if (!isArrayLength(tableLedgerCodeList)) {
      dispatch(
        getLedgerCodeList({
          sequence: filters?.sequenceIndex,
          callback: (response: any) => {
            if (response.length > 0) {
              dispatch(selectGlListSelectedRow(response?.data?.data[0]));
            }
          }
        })
      );
    }
  }, [tableLedgerCodeList]);

  // Display a temporary loader to prevent UI flicker during row selection
  useEffect(() => {
    const initializeData = async () => {
      dispatch(setFilters({ lookingFor: "" }));
      await new Promise((resolve) => setTimeout(resolve, 0));
      if (selectedRowGlCodes === undefined) {
        dispatch(selectGlListSelectedRow(tableLedgerCodeList.at(0)));
      }
      dispatch(setFromSubmitting(true));
      await new Promise((resolve) => setTimeout(resolve, 600));
      dispatch(setFromSubmitting(false));
      const element = document.getElementById(
        `rowIndex-generalLedgerGrpList-${tableLedgerCodeList.indexOf(selectedRowGlCodes!)}`
      );
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    };
    initializeData();
  }, [filters?.sequenceValue, tableLedgerCodeList]);

  const handleCancelCallBack = () => {
    dispatch(setCancelBtnClick(true));
    cancelWarningPopupLC();
  };

  const handleAddClick = () => {
    if (isWarnBudget === false) {
      getAlertMessage("warnBudgetAlertMsg");
    } else {
      dispatch(ledgerCodesAction.resetForm());
      dispatch(glLedgerFundCodeAction.reset());
      dispatch(ledgerCodesAction.resetNewLedgerErrorState());
      dispatch(ledgerFundDefinitionAction.resetFundData());
      dispatch(ledgerFundDefinitionAction.resetSelectedRows());
      history.push("/tools/ledger-codes/add");
    }
  };

  // Get "Next Year/Prev Year/Prev State" on load
  useEffect(() => {
    if (!previousState) dispatch(getPrevState());
    if (!nextYear) dispatch(getNextYear());
    if (!previousYear) dispatch(getPreviousYear());
  }, []);

  const submitHandler = () => {
    if (isPaylodValidLC()) {
      dispatch(postLedgerCodes());
    }
  };

  return (
    <>
      <GeneralLedgerSetup>
        <div className="general-ledger-listing-container general-ledger-scroll-height">
          {isFormSubmitting || status === STATUS.LOADING ? (
            <>
              <Loader
                loaderType={LoaderType.Circular}
                loaderText="Please wait"
              />
            </>
          ) : (
            <Grid container>
              <GridItem
                sm={12}
                md={12}
                lg={12}
                xl={12}
              >
                <GridTableNew
                  dataTestId="generalLedgerGrpList"
                  filters={
                    <LedgerCodesFilter
                      handleAddClick={handleAddClick}
                      setSelectRow={selectGlListSelectedRow}
                    />
                  }
                  columnDef={columnDef}
                  isLoading={false}
                  dataSource={tableLedgerCodeList}
                  isRowSelectionEnabled
                  isScrollable
                  customCell={CustomCell}
                  selectedRow={selectedRowGlCodes}
                  selectedRowHandler={(row) => {
                    dispatch(selectGlListSelectedRow(row));
                  }}
                />
              </GridItem>
            </Grid>
          )}
        </div>
        <GenralLedgerFooter
          onSubmit={submitHandler}
          cancelCallback={handleCancelCallBack}
        />
      </GeneralLedgerSetup>
    </>
  );
};

export default LedgerCodes;
