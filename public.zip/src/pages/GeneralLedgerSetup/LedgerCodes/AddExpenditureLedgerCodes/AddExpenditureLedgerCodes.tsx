import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import InputButton from "@/pages/ChartOfAccountsReview/SidePanels/SelectPeriod/Grid/InputButton";
import "./Style.scss";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  TextInput,
  Tooltip
} from "@essnextgen/ui-kit";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import FundCodeFilter from "../../FundCodes/FundCodeListing/FundCodeFilter";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import FundCodeListingColumnDef from "../../FundCodes/Grid/ColumnDefs";
import CustomCell from "../Grid/CustomCell";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import FundCodeListing from "../../FundCodes/FundCodeListing/FundCodeListing";

const AddExpenditureLedgerCodes = () => (
  <>
    <Grid className="mb-16">
      <GridItem
        sm={4}
        md={4}
        lg={3}
        xl={3}
      >
        <div>
          <div className="essui-form-label">Ledger Type</div>
          <div className="height__equal--input">Expenditure</div>
        </div>
      </GridItem>
      <GridItem
        sm={4}
        md={4}
        lg={1}
        xl={1}
      >
        <div>
          <div className="essui-form-label">Code</div>
          <div className="height__equal--input">223</div>
        </div>
      </GridItem>
      <GridItem
        sm={4}
        md={4}
        lg={3}
        xl={3}
      >
        <div>
          <FormLabel forId="txtDescription">Description</FormLabel>
          <Input
            value=""
            searchable
            id="txtDescription"
          />
        </div>
      </GridItem>
      <GridItem
        sm={4}
        md={4}
        lg={3}
        xl={3}
      >
        <div>
          <FormLabel forId="txtLedgerGroup">Ledger Group</FormLabel>
          <Input
            value="Assets"
            searchable
            id="txtLedgerGroup"
          />
        </div>
      </GridItem>
    </Grid>
    <Grid>
      <GridItem
        sm={4}
        md={4}
        lg={4}
        xl={4}
      >
        <Grid className="row-gap-8">
          <GridItem
            sm={4}
            md={2}
            lg={4}
            xl={4}
            xxl={3}
          >
            <div>
              <FormLabel forId="txtShortCode">Short Code</FormLabel>
              <Input
                value=""
                searchable
                id="txtShortCode"
              />
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={6}
            lg={8}
            xl={8}
            xxl={9}
          >
            <div>
              <FormLabel forId="txtNormalProfile">Normal Profile</FormLabel>
              <Input
                value=""
                searchable
                id="txtNormalProfile"
              />
            </div>
          </GridItem>
        </Grid>
      </GridItem>
      <GridItem
        sm={4}
        md={4}
        lg={3}
        xl={3}
        className="input--width80"
      >
        <div className="normal__vat--field">
          <FormLabel forId="txtAccountNumber">Normal VAT</FormLabel>
          <Input
            id="costCenter"
            labelText=""
            className="width160"
            onChange={(e) => {}}
            onBlur={(e) => {}}
            onSelect={(selectedItem) => {}}
            onPending={(selectedItem) => {}}
            onNoSelection={() => {}}
            button={
              <>
                <Tooltip content="">
                  <div className="essui-textinput essui-textinput--medium read-only" />
                </Tooltip>
                <Button
                  color={ButtonColor.Secondary}
                  size={ButtonSize.Small}
                  onClick={() => {}}
                  className="essui-button-icon-only--small"
                >
                  <Icon
                    color={IconColor.Primary500}
                    size={IconSize.Medium}
                    name="search"
                  />
                </Button>
              </>
            }
          />
        </div>
      </GridItem>
      <GridItem>
        <div className="essui-global-typography-default-h2 mr-t20">
          <CheckBox
            label="Services"
            value=""
            id="txtServices"
          />
        </div>
      </GridItem>
    </Grid>
  </>
);
export default AddExpenditureLedgerCodes;
