import GridRowActions, { OptionsType } from "@/components/GridRowActions/GridRowActions";
import { cellRendererType } from "@/components/GridTable/GridTable";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { Icon, IconSize, NotificationStatus } from "@essnextgen/ui-kit";
import { ReactNode } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import { ledgerCodesAction, TledgeCodeDetails } from "../../State/glLedgerCodes.slice";
import { glLedgerFundCodeAction } from "../../State/glLedgerCodeFundCode.slice";
import { ledgerFundDefinitionAction } from "../../State/glLedgerFundDefinition.slice";

const CustomCell = ({ field, row }: cellRendererType) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const isWarnBudget = getSessionItem("glWarnBudget");
  const history = useHistory();
  const dispatch = useDispatch();
  const { setLedgerFormData } = ledgerCodesAction;
  const { selectedRowGlCodes } = useAppSelector((state) => state.glLedgerCodes);

  const options: OptionsType[] = [
    {
      text: "Edit this ledger code",
      value: "Edit",
      children: <RowAction optionName={t("generalLedgerSetup.editLedgerCode")} />
    },
    {
      text: "Delete this ledger code",
      value: "Delete",
      disabled: true,
      children: <RowAction optionName={t("generalLedgerSetup.deleteLedgerCode")} />
    }
  ];

  const getAlertMessage = (message: string) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        message: t(`generalLedgerSetup.ledgerCode.${message}`),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus.WARNING,
        callback: () => {
          setToSession("glWarnBudget", true);
          redirectCallBack();
        }
      })
    );
  };

  const redirectCallBack = () => {
    dispatch(ledgerCodesAction.resetForm());
    dispatch(glLedgerFundCodeAction.reset());
    dispatch(ledgerCodesAction.resetNewLedgerErrorState());
    dispatch(ledgerFundDefinitionAction.resetFundData());
    dispatch(ledgerFundDefinitionAction.resetSelectedRows());
    history.push(`/tools/ledger-codes/edit-ledger-code/${row?.leddef_id}`);
    if (row?.leddef_id === 0) {
      dispatch(setLedgerFormData({ ...(selectedRowGlCodes as TledgeCodeDetails) }));
    }

    history.push(`/tools/ledger-codes/edit-ledger-code/${row?.leddef_id}`);
  };

  const handleEdit = () => {
    if (isWarnBudget === false) {
      getAlertMessage("warnBudgetAlertMsg");
    } else {
      redirectCallBack();
    }
  };

  const handleDelete = () => {
    // Delete conditions will be there..
  };

  const handleActionClick = (e: any, action: OptionsType) => {
    if (action.value === "Edit") {
      handleEdit();
    } else {
      handleDelete();
    }
  };

  const getContent = () => {
    if (field === "actions") {
      return (
        <GridRowActions
          name={
            <Icon
              size={IconSize.Medium}
              name="overflow-menu--horizontal"
            />
          }
          options={options}
          onClick={handleActionClick}
        />
      );
    }
    return "";
  };
  return getContent();
};

export default CustomCell;

type OptionProps = {
  iconName?: string;
  optionName: string;
  children?: ReactNode;
};
const RowAction = ({ iconName, optionName, children }: OptionProps) => (
  <div className="option">
    {iconName ? (
      <Icon
        size={IconSize.Medium}
        name={iconName}
      />
    ) : (
      children
    )}
    {optionName}
  </div>
);

RowAction.defaultProps = {
  iconName: undefined,
  children: undefined
};
