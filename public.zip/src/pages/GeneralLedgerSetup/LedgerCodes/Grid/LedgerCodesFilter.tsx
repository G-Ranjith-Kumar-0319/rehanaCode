import {
  Grid,
  GridItem,
  ButtonSize,
  Button,
  FormLabel,
  TextInput,
  RadioButton,
  RadioLabelPosition
} from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { AddLarge } from "@carbon/icons-react";
import { CARBON_ICON, KEYBOARD_STRING, ledgerCodeSequence } from "@/types/UseStateType";
import { useHistory } from "react-router-dom";
import { setToSession } from "@/utils/getDataSource";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import React, { useEffect, useState } from "react";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { useAppSelector } from "@/store/store";
import useDebounce from "@/hooks/useDebounce";
import findNearest from "@/utils/nearestSearch";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { getLedgerCodeList, ledgerCodesAction } from "../../State/glLedgerCodes.slice";
import LedgerCodesColumnDef from "./columnDef";
import { ledgerGrpAction } from "../../State/LedgerGroupsList.slice";

const LedgerCodesFilter = ({ handleAddClick, setSelectRow }: any) => {
  const { setLadgerGrpData, setIsBtnClick } = ledgerGrpAction;
  const history = useHistory();
  const dispatch = useDispatch();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { setFilters, setColumnDef, selectGlListSelectedRow } = ledgerCodesAction;
  const [columns, setColumn] = useState<TColumnDef>([...LedgerCodesColumnDef]);
  const { filters, columnDef, ledgerCodesList, tableLedgerCodeList } = useAppSelector((state) => state.glLedgerCodes);
  const debouncedValue = useDebounce(filters?.lookingFor!, 600);
  useEffect(() => {
    if (debouncedValue !== "" && tableLedgerCodeList && tableLedgerCodeList?.length) {
      let found;
      found = [...tableLedgerCodeList]
        .filter((element) =>
          debouncedValue
            ? element[filters?.sequenceValue!].toString()?.toUpperCase()?.startsWith(debouncedValue!)
            : false
        )
        .at(0);

      if (found && found !== undefined) setSelectRow(found);

      if (found === undefined) {
        found = findNearest(
          [...tableLedgerCodeList],
          [{ fieldName: filters?.sequenceValue!, searchValue: debouncedValue }],
          true
        );
        setSelectRow(found);
      }
      const element = document.getElementById(`rowIndex-generalLedgerGrpList-${tableLedgerCodeList.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
      dispatch(selectGlListSelectedRow(found));
    }
  }, [debouncedValue]);

  useEffect(() => {
    setTimeout(() => {
      document.getElementById("looking-for")?.focus();
    }, 100);
  }, []);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(setFilters({ lookingFor: value.toUpperCase() }));
  };

  const handleSequenceChange = (value?: string) => {
    LedgerCodesColumnDef.map((col, index) => {
      if (value === "ledger_type") {
        [columns[0], columns[1], columns[2]] = [columns[2], columns[0], columns[1]];
      } else if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });
    setColumn([...LedgerCodesColumnDef]);
    dispatch(setColumnDef(columns));
  };

  useEffect(() => {
    handleSequenceChange(filters?.sequenceValue);
    dispatch(selectGlListSelectedRow(undefined));
  }, [filters?.sequenceValue]);

  const handleSequenceFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey = e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp;

    if (e.key === KEYBOARD_STRING.ArrowDown) {
      e.preventDefault();
      const nextSequenceValue = (() => {
        if (filters?.sequenceValue === ledgerCodeSequence.LEDGERCODE) {
          return ledgerCodeSequence.DESCRIPTION;
        }
        if (filters?.sequenceValue === ledgerCodeSequence.DESCRIPTION) {
          return ledgerCodeSequence.LEDGERTYPE;
        }
        if (filters?.sequenceValue === ledgerCodeSequence.LEDGERTYPE) {
          return ledgerCodeSequence.LEDGERCODE;
        }
        return "";
      })();

      const index = (() => {
        if (nextSequenceValue === ledgerCodeSequence.LEDGERTYPE) {
          return "2";
        }
        if (nextSequenceValue === ledgerCodeSequence.DESCRIPTION) {
          return "1";
        }
        if (nextSequenceValue === ledgerCodeSequence.LEDGERCODE) {
          return "0";
        }
        return "";
      })();

      dispatch(
        setFilters({
          sequenceValue: nextSequenceValue,
          sequenceIndex: index
        })
      );
    } else if (e.key === KEYBOARD_STRING.ArrowUp) {
      e.preventDefault();
      const nextSequenceValue = (() => {
        if (filters?.sequenceValue === ledgerCodeSequence.LEDGERCODE) {
          return ledgerCodeSequence.LEDGERTYPE;
        }
        if (filters?.sequenceValue === ledgerCodeSequence.DESCRIPTION) {
          return ledgerCodeSequence.LEDGERCODE;
        }
        if (filters?.sequenceValue === ledgerCodeSequence.LEDGERTYPE) {
          return ledgerCodeSequence.DESCRIPTION;
        }
        return "";
      })();

      const index = (() => {
        if (nextSequenceValue === ledgerCodeSequence.LEDGERTYPE) {
          return "2";
        }
        if (nextSequenceValue === ledgerCodeSequence.DESCRIPTION) {
          return "1";
        }
        if (nextSequenceValue === ledgerCodeSequence.LEDGERCODE) {
          return "0";
        }
        return "";
      })();
      dispatch(
        setFilters({
          sequenceValue: nextSequenceValue,
          sequenceIndex: index
        })
      );
    }
  };

  return (
    <Grid>
      <GridItem
        sm={3}
        md={3}
        xl={3}
      >
        <div className="essui-global-typography-default-h2  ">
          <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
          <div className="looking-for">
            <TextInput
              value={filters?.lookingFor}
              onKeyDown={(event) => {
                // eslint-disable-next-line
                if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                  event.preventDefault();
                }
              }}
              onChange={(e) => handleLookingForChange(e)}
              id="looking-for"
              autoComplete={false}
            />
          </div>
        </div>
      </GridItem>
      <GridItem
        md={4}
        lg={4}
        xl={4}
      >
        <div className="filters align-center justify__content--between">
          <div className="essui-global-typography-default-h2 sequence-container">
            <FormLabel>{t("bankReconciliation.sequence")}</FormLabel>
            <div className="sequence">
              <div
                className="essui-textinput sequence-fields sequence-order"
                onKeyDown={handleSequenceFieldKeyDown}
              >
                {(LedgerCodesColumnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                  const sequenceId = `sequence=${index + 1}`;
                  const sequence = column.sequenceIndex
                    ? LedgerCodesColumnDef.find((s) => s.sequenceIndex === index && s.sequence && s.sequenceIndex)
                    : column;
                  return (
                    <RadioButton
                      label={column.sequenceName ? column.sequenceName : column.headerName}
                      labelPosition={RadioLabelPosition.Right}
                      value={column.field}
                      key={sequenceId}
                      name={column.field}
                      onChange={() => {
                        dispatch(
                          setFilters({
                            sequenceValue: String(column.field),
                            sequenceIndex: String(index),
                            lookingFor: ""
                          })
                        );
                      }}
                      isSelected={filters?.sequenceValue === column.field}
                    />
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </GridItem>
      <GridItem
        md={5}
        lg={5}
        xl={5}
        className="btn-container"
      >
        <Button
          size={ButtonSize.Small}
          onClick={() => handleAddClick()}
          title={t("generalLedgerSetup.addLedgerCodes")}
          id="gllg-add-btn"
          className="essui-button essui-button--utility essui-button--small br-0 focus-active add-button"
        >
          <AddLarge
            size={CARBON_ICON.SIZE}
            color={CARBON_ICON.COLOR_BLACK}
          />
        </Button>
      </GridItem>
    </Grid>
  );
};

export default LedgerCodesFilter;
