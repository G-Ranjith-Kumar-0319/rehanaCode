import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const GlLcFundColumnDef: TColumnDef = [
  {
    headerName: "Fund",
    field: "fund_code",
    columnWidth: 30
  },
  {
    headerName: "Description",
    field: "fund_des",
    columnWidth: 30
  },
  {
    headerName: "CFR Code",
    field: "cfr_code",
    columnWidth: 30
  }
];

export const GlLcFundTwoColumnDef: TColumnDef = [
  {
    headerName: "Fund",
    field: "fund_code",
    columnWidth: 30
  },
  {
    headerName: "Description",
    field: "fund_des",
    columnWidth: 70
  }
];

export default GlLcFundColumnDef;
