import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const LedgerCodesColumnDef: TColumnDef = [
  {
    headerName: "Code",
    field: "ledger_code",
    sequence: true,
    sequenceName: "Ledger Code",
    columnWidth: 10
  },
  {
    headerName: "Description",
    field: "ledger_des",
    columnWidth: 70,
    sequence: true
  },
  {
    headerName: "Type",
    field: "ledger_type",
    columnWidth: 10,
    sequence: true,
    sequenceName: "Ledger Type"
  },
  {
    headerName: "",
    field: "actions",
    cellRenderer: "GridCellLink",
    columnWidth: 10
  }
];

export default LedgerCodesColumnDef;
