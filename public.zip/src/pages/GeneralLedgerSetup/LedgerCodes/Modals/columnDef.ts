import { TColumnDef } from "@/components/GridTable/GridTable";

const ledgerCodeFundCodecolumnDef: TColumnDef = [
  {
    headerName: "Fund Code",
    field: "fund_code",
    align: "left",
    sequence: true
  },
  {
    headerName: "Fund Description",
    field: "ledger_des",
    align: "left",
    sequence: true
  }
];
export default ledgerCodeFundCodecolumnDef;
