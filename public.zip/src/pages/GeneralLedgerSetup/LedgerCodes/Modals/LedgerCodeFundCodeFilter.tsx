import useDebounce from "@/hooks/useDebounce";
import { AppDispatch, useAppSelector } from "@/store/store";
import findNearest from "@/utils/nearestSearch";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import {
  FormLabel,
  Grid,
  GridItem,
  RadioButton,
  RadioLabelPosition,
  TextInput,
  TextInputSize
} from "@essnextgen/ui-kit";
import React, { Dispatch, useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { glLedgerFundCodeAction as glLedgerCodeActions } from "@/pages/GeneralLedgerSetup/State/glLedgerCodeFundCode.slice";
import { KEYBOARD_STRING, LG_FUND_CODE } from "@/types/UseStateType";
import columnDef from "./columnDef";

const LedgerCodeFundCodeFilter = ({ setSelectFundCodeRow }: { setSelectFundCodeRow: Dispatch<any> }) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const dispatch = useDispatch<AppDispatch>();
  const { ledgerCodeFundCodes, filters } = useAppSelector((state) => state.glLedgerCodeFundCode);
  const { selectedSupplier } = useAppSelector((state) => state.selectedSupplier);
  const debouncedValue = useDebounce(filters?.lookingFor!, 300);
  const inputRef: React.Ref<HTMLInputElement> = useRef(null);

  useEffect(() => {
    if (debouncedValue !== "" && ledgerCodeFundCodes && ledgerCodeFundCodes?.length) {
      let found;
      found = [...ledgerCodeFundCodes]
        .filter((element) =>
          debouncedValue
            ? element[filters?.sequenceValue!].toString()?.toUpperCase()?.startsWith(debouncedValue!)
            : false
        )
        .at(0);

      if (found && found !== undefined) setSelectFundCodeRow(found);

      if (found === undefined) {
        found = findNearest(
          [...ledgerCodeFundCodes],
          [{ fieldName: filters?.sequenceValue!, searchValue: debouncedValue }],
          true
        );
        setSelectFundCodeRow(found);
      }
      const element = document.getElementById(`rowIndex-LedgerfundCodesModal-${ledgerCodeFundCodes.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [debouncedValue]);

  const handleLookingForChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    dispatch(glLedgerCodeActions.setFilters({ lookingFor: value.toUpperCase() }));
  };

  const handleSequenceChange = (value?: string) => {
    columnDef?.map((col, index) => {
      if (col.field === value) {
        const temp = columns[0];
        columns[0] = columns[index];
        columns[index] = temp;
      }
      return col;
    });
    setColumn([...columnDef]);
    dispatch(glLedgerCodeActions.setColumnDef(columns));
  };

  useEffect(() => {
    handleSequenceChange(filters?.sequenceValue);
  }, [filters?.sequenceValue]);

  const handleSequenceFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey = e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp;
    if (isArrowKey) {
      e.preventDefault();
      const nextSequenceValue =
        filters?.sequenceValue === LG_FUND_CODE.FUND_CODE ? LG_FUND_CODE.LEDGER_DES : LG_FUND_CODE.FUND_CODE;
      const index = nextSequenceValue === LG_FUND_CODE.LEDGER_DES ? 1 : 0;
      dispatch(
        glLedgerCodeActions.setFilters({
          sequenceValue: String(nextSequenceValue),
          sequenceIndex: String(index),
          lookingFor: ""
        })
      );
    }
  };

  return (
    <>
      <Grid
        className="custom-table ledger-code-fund-code-modal"
        align="center"
      >
        <GridItem
          sm={4}
          md={4}
          xl={4}
        >
          <div className="essui-global-typography-default-h2 ml-4">
            <FormLabel forId="looking-for">{t("purchaseOrder.lookingFor")}</FormLabel>
            <div className="looking-for">
              <TextInput
                onKeyDown={(event) => {
                  // eslint-disable-next-line
                  if (/^[a-zA-Z0-9\s]*$/.test(event.key) === false) {
                    event.preventDefault();
                  }
                }}
                inputRef={inputRef}
                id="looking-for-ledger-code"
                value={filters?.lookingFor}
                onChange={(e) => handleLookingForChange(e)}
                size={TextInputSize.Medium}
              />
            </div>
          </div>
        </GridItem>

        <GridItem
          sm={5}
          md={5}
          xl={6}
        >
          <div className="essui-global-typography-default-h2">
            <FormLabel>{t("purchaseOrder.sequence")}</FormLabel>
            <div
              className="essui-textinput sequence justify-sequence"
              onKeyDown={handleSequenceFieldKeyDown}
            >
              {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
                const sequenceId = `sequence=${index + 1}`;
                return (
                  <RadioButton
                    label={column.sequenceName ? column.sequenceName : column.headerName}
                    name={column.sequenceName ? column.sequenceName : column.headerName}
                    labelPosition={RadioLabelPosition.Right}
                    value={column.field}
                    onChange={() => {
                      dispatch(
                        glLedgerCodeActions.setFilters({
                          sequenceValue: String(column.field),
                          sequenceIndex: String(index),
                          lookingFor: ""
                        })
                      );
                    }}
                    isSelected={filters?.sequenceValue === column.field}
                    key={sequenceId}
                    id={`ledger-code-${index}`}
                  />
                );
              })}
            </div>
          </div>
        </GridItem>
      </Grid>
    </>
  );
};

export default LedgerCodeFundCodeFilter;
