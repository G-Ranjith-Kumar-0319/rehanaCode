import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useTranslation } from "@essnextgen/ui-intl-kit";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useFormContext } from "react-hook-form";
import LedgerCodeFundCodeFilter from "./LedgerCodeFundCodeFilter";
import { ledgerCodesAction } from "../../State/glLedgerCodes.slice";
import { glLedgerFundCodeAction, getLedgerCodeFundCodes } from "../../State/glLedgerCodeFundCode.slice";

interface FundCodeModalProps {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
}

const LedgerCodeFundCodeModal: React.FC<FundCodeModalProps> = ({ setOpen, isOpen }) => {
  const { t } = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { setValue } = useFormContext();
  const [selectedRow, setSelectedRow] = useState<{ [key: string]: any } | undefined>();
  const { status, ledgerCodeFundCodes, columnDef, filters, selectedLedgerFundCode } = useAppSelector(
    (state) => state.glLedgerCodeFundCode
  );
  const { resetForm, setLedgerFormData } = ledgerCodesAction;
  const {
    ledgerCodeForm: { formData },
    newLedgerErrorState
  } = useAppSelector((state) => state.glLedgerCodes);
  useEffect(() => {
    const { field } = columnDef.filter((col) => !!col.sequence)[0];
    dispatch(glLedgerFundCodeAction.setFilters({ ...filters, sequenceValue: field }));
  }, []);

  useEffect(() => {
    const { field } = columnDef.filter((col) => !!col.sequence)[0];
    dispatch(glLedgerFundCodeAction.setFilters({ ...filters, sequenceValue: field }));
    dispatch(glLedgerFundCodeAction.resetFilters());
  }, [isOpen]);

  useEffect(() => {
    dispatch(getLedgerCodeFundCodes({ sequence: Number(filters?.sequenceIndex) }));
  }, [filters?.sequenceIndex]);

  useEffect(() => {
    setSelectedRow(selectedLedgerFundCode ?? undefined);
    dispatch(
      setLedgerFormData({
        ...formData,
        funds: [
          {
            fund_id: selectedLedgerFundCode?.fund_id as any,
            fund_code: selectedLedgerFundCode?.fund_code,
            fund_des: selectedLedgerFundCode?.ledger_des,
            cfr_code: selectedLedgerFundCode?.cfr_code
          }
        ]
      })
    );
  }, [selectedLedgerFundCode]);

  const closeHandler = (e: React.SyntheticEvent) => {
    e.preventDefault();
    setOpen(false);
    if (selectedLedgerFundCode) setSelectedRow(selectedLedgerFundCode);
    dispatch(glLedgerFundCodeAction.setFilters({ lookingFor: "" }));
  };

  useEffect(() => {
    const debouncedValue = filters?.lookingFor!;
    if (!debouncedValue && isOpen) {
      const found = [...ledgerCodeFundCodes].at(0);
      setSelectedRow(found);
      const element = document.getElementById(`rowIndex-LedgerfundCodesModal-0`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [filters?.lookingFor]);

  const onSelectHandler = () => {
    dispatch(glLedgerFundCodeAction.selectRow(selectedRow));
    setValue("fund_code", selectedRow?.fund_code, {
      shouldValidate: true,
      shouldDirty: true
    });
    setValue("ledger_des", selectedRow?.ledger_des, {
      shouldValidate: true,
      shouldDirty: true
    });
    setOpen(false);
  };

  const primaryButton = (
    <Button
      id="ledger-code-fund-code-select"
      size={ButtonSize.Small}
      onClick={onSelectHandler}
    >
      {t("common.select")}
    </Button>
  );

  const secondaryButton = (
    <Button
      id="ledger-code-fund-code-cancel"
      size={ButtonSize.Small}
      color={ButtonColor.Secondary}
      onClick={closeHandler}
    >
      {t("common.cancel")}
    </Button>
  );

  const tertiaryButton = (
    <HelpButton
      id="ledger-code-fund-code-help"
      identifier="testIdentifier"
      labelName={t("common.help")}
    />
  );

  return (
    <Modalv2
      header={t("generalLedgerSetup.ledgerCode.ledgerCodeFundCodeTitle")}
      isOpen={isOpen}
      primaryButton={primaryButton}
      secondaryButton={secondaryButton}
      tertiaryButton={tertiaryButton}
      onClose={closeHandler}
      escapeExits
    >
      <GridTableNew
        dataTestId="LedgerfundCodesModal"
        filters={<LedgerCodeFundCodeFilter setSelectFundCodeRow={setSelectedRow} />}
        isScrollable
        enableScrollIntoView
        dataSource={ledgerCodeFundCodes || []}
        selectedRow={selectedRow}
        isLoading={status === "LOADING"}
        columnDef={columnDef}
        selectedRowHandler={(row) => setSelectedRow(row)}
        onEnterKeyPress={onSelectHandler}
      />
    </Modalv2>
  );
};

export default LedgerCodeFundCodeModal;
