import React, { useEffect, useState } from "react";
import Input from "@/components/Input/Input";
import { useAppSelector } from "@/store/store";
import {
  Button,
  ButtonSize,
  Dropdown,
  DropdownItem,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  ISelectedItem,
  Loader,
  LoaderType,
  TextInputSize,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import GridTableNew, { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import useLedgerCodesForm from "../hooks/useLedgerCodesForm";
import {
  getCFRValid,
  getLedgerGroupsList,
  getNormalProfileList,
  ledgerCodesAction,
  TLedgerGrp
} from "../../State/glLedgerCodes.slice";
import { isArrayLength } from "../../ProfileModels/utils";
import GlLcFundColumnDef, { GlLcFundTwoColumnDef } from "../Grid/glLcFundColumnDef";
import useSortedData from "../../hooks/useSortedData";
import ChooseFundsModal from "../AddLedgerChooseFundDefinition/ChooseFundsModal";

const AddLedgerCodesDefinition = () => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    fieldsStatus,
    watch,
    register,
    validateDescription,
    setValue,
    errors,
    clearErrorState,
    updateFormState,
    isEditPage
  } = useLedgerCodesForm();
  const { setLedgerFormData } = ledgerCodesAction;
  const [openLedgerDefinitionFundModal, setOpenLedgerDefinitionFundModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState({ text: "", value: "" });
  const [columnDef, setcolumnDef] = useState<TColumnDef>();
  const [isCFRValid, setIsCFRValid] = useState<boolean>();
  const dispatch = useDispatch();
  const {
    ledgerCodeForm: { formData },
    normalProfileList,
    status,
    errorState,
    ledgerGrpList,
    callLedgergrpApi
  } = useAppSelector((state) => state.glLedgerCodes);

  const ledgerGrpListSorted = useSortedData(ledgerGrpList, "group_des", "asc");
  useEffect(() => {
    if (!isArrayLength(normalProfileList)) {
      dispatch(getNormalProfileList());
    }
  }, []);

  useEffect(() => {
    if (fieldsStatus.shortCode || fieldsStatus.funds) {
      const filteredItems = normalProfileList.filter((val) => val.model_des === "Manual Entry");
      if (filteredItems.length > 0 && formData?.model_id === null) {
        setSelectedItem({
          text: filteredItems[0].model_des,
          value: filteredItems[0].model_id
        });
        dispatch(
          setLedgerFormData({
            ...formData,
            model_id: Number(filteredItems[0].model_id),
            model_des: filteredItems[0].model_des
          })
        );
      } else if (formData?.model_id) {
        setSelectedItem({
          text: formData?.model_des ?? "",
          value: String(formData.model_id) ?? ""
        });
      }
    }
  }, [normalProfileList, formData]);

  useEffect(() => {
    checkCFRValid();
  }, [normalProfileList]);

  const checkCFRValid = () => {
    dispatch(
      getCFRValid({
        callback: (res) => {
          if (res.cfr_functionality === "T" && res.cfr_invalid_year === "F") {
            setIsCFRValid(true);
          } else {
            setIsCFRValid(false);
          }
        }
      })
    );
  };

  useEffect(() => {
    if (isCFRValid === true) {
      setcolumnDef([...GlLcFundColumnDef]);
    } else {
      setcolumnDef([...GlLcFundTwoColumnDef]);
    }
  }, [isCFRValid]);

  useEffect(() => {
    if (callLedgergrpApi && isEditPage) {
      dispatch(getLedgerGroupsList());
    }
  }, [callLedgergrpApi]);

  return (
    <>
      <Grid />
      <Grid className="row-gap-16">
        <GridItem
          sm={4}
          md={3}
          lg={3}
          xl={3}
        >
          <div>
            <div className="essui-form-label mb-5">Ledger Type</div>
            <div>{formData.ledger_type_des}</div>
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={3}
          lg={3}
          xl={3}
        >
          <div>
            <div className="essui-form-label mb-5">Code</div>
            <div>{formData.ledger_code}</div>
          </div>
        </GridItem>
      </Grid>

      <Grid className="row-gap-16 mt-16 mb-8">
        <GridItem
          sm={4}
          md={3}
          lg={3}
          xl={3}
        >
          <div>
            <FormLabel
              forId="txtDescription"
              className="mb-5"
            >
              Description
            </FormLabel>
            <Input
              autoFocus
              searchable
              id="description"
              value={formData.ledger_des}
              inputRef={(e) => register("ledger_des").ref(e)}
              name={
                register("ledger_des", {
                  required: true
                }).name
              }
              onChange={(e) => {
                clearErrorState("ledger_des");
                setValue("ledger_des", e.target.value, {
                  shouldDirty: true
                });
              }}
              onBlur={(e: any) => validateDescription(e.target.value, false)}
              maxLength={32}
              validationTextLevel={errorState.ledger_des || errors.ledger_des ? ValidationTextLevel.Error : undefined}
            />
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={3}
          lg={3}
          xl={3}
        >
          <div className="gl-lc-dropdown-container">
            <FormLabel
              forId="txtLedgerGroup"
              className="mb-5"
            >
              Ledger Group
            </FormLabel>
            <Dropdown
              className="w-100"
              id="ledgerGrpInput"
              selectedItem={{
                text: formData?.group_des,
                value: `dropdown-${formData?.group_id.toString()}`
              }}
              placeholderText="Search"
              size={TextInputSize.Medium}
              searchable
              isScrollbarVisible
              onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => {
                setValue("group_des", item?.text || "");
                const id = item?.value!.split("-")[1];
                dispatch(
                  setLedgerFormData({
                    ...formData,
                    group_id: parseInt(id, 10),
                    group_des: item.text!
                  })
                );
              }}
              validationTextLevel={errors.group_des ? ValidationTextLevel.Error : undefined}
            >
              {(ledgerGrpListSorted || []).map((data: TLedgerGrp, i: any) => {
                const id = `dropdown-${data.group_id}`;
                return (
                  <DropdownItem
                    key={id}
                    id={id}
                    text={data.group_des}
                    value={id}
                  >
                    {data.group_des}
                  </DropdownItem>
                );
              })}
            </Dropdown>
          </div>
        </GridItem>
        {fieldsStatus.shortCode && (
          <>
            <GridItem
              sm={4}
              md={2}
              lg={2}
              xl={2}
            >
              <div>
                <FormLabel
                  forId="txtShortCode"
                  className="mb-5"
                >
                  {t("generalLedgerSetup.shortCode")}
                </FormLabel>
                <Input
                  value={formData.ledger_short}
                  searchable
                  id="txtShortCode"
                  maxLength={8}
                  inputRef={(e) => register("ledger_short").ref(e)}
                  name={
                    register("ledger_short", {
                      required: true
                    }).name
                  }
                  onChange={(e) => {
                    clearErrorState("ledger_short");
                    setValue("ledger_short", e.target.value, {
                      shouldDirty: true
                    });
                  }}
                  onBlur={(e: any) => updateFormState({ ledger_short: e.target.value })}
                />
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={3}
              lg={3}
              xl={3}
            >
              <div>
                <FormLabel
                  forId="txtNormalProfile"
                  className="mb-5"
                >
                  {t("generalLedgerSetup.normalProfile")}
                </FormLabel>
                <Dropdown
                  selectedItem={selectedItem}
                  size={TextInputSize.Medium}
                  searchable
                  isScrollbarVisible
                  onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => {
                    setValue("model_des", item?.text || "");
                    const id = item?.value;
                    dispatch(
                      setLedgerFormData({
                        ...formData,
                        model_id: Number(item.value),
                        model_des: item.text!
                      })
                    );
                  }}
                >
                  {(normalProfileList || []).map((data: any, i: any) => (
                    <DropdownItem
                      key={data.model_id}
                      id={data.model_id}
                      text={data.model_des}
                      value={data.model_id}
                    >
                      {data.model_des}
                    </DropdownItem>
                  ))}
                </Dropdown>
              </div>
            </GridItem>
          </>
        )}
        {fieldsStatus.funds && (
          <GridItem
            sm={12}
            md={12}
            lg={12}
            xl={12}
            className="gl-lc-form-fund-grid"
          >
            {status === STATUS.LOADING && (
              <Grid className="gl-lc-form-fund-loader">
                <Loader
                  loaderType={LoaderType.Circular}
                  loaderText="Loading..."
                />
              </Grid>
            )}
            <GridTableNew
              dataTestId="generalLedgerFundCodeList"
              isLoading={false}
              filters={
                <Grid>
                  <GridItem
                    lg={10}
                    className="d-flex align-center"
                  >
                    <div className="essui-global-typography-default-subtitle">{t("generalLedgerSetup.funds")}</div>
                  </GridItem>
                  <GridItem lg={2}>
                    <div className="d-flex justify-end">
                      <Button
                        size={ButtonSize.Small}
                        title={t("generalLedgerSetup.fundCode.linkFunds")}
                        id="glfc-add-btn"
                        className="essui-button essui-button--utility essui-button--small br-0 focus-active"
                        onClick={() => setOpenLedgerDefinitionFundModal(true)}
                      >
                        <Icon
                          color={IconColor.Neutral}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    </div>
                  </GridItem>
                </Grid>
              }
              dataSource={[...(formData?.funds || [])]}
              columnDef={columnDef || []}
              selectedRow={undefined}
              isRowSelectionEnabled
              isScrollable
              selectedRowHandler={(row) => {}}
            />
          </GridItem>
        )}
        <ChooseFundsModal
          spreadModel={openLedgerDefinitionFundModal}
          setSpreadModel={setOpenLedgerDefinitionFundModal}
        />
      </Grid>
    </>
  );
};
export default AddLedgerCodesDefinition;
