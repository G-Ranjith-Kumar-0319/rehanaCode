import { ledgerCodeType } from "@/types/UseStateType";

// Test for type BK (Bank types)
export const isBankType = (code: string) => code === ledgerCodeType.BK;

// Test for type EX, ES, IN or AF (budgetable types)
export const isExpType = (code: string) =>
  code === ledgerCodeType.EX || code === ledgerCodeType.ES || code === ledgerCodeType.IN || code === ledgerCodeType.AF;

// Test for type ES (budgetable types)
export const isSalaryType = (code: string) => code === ledgerCodeType.ES;

// Test for type VI or VO (VAT input/output)
export const isVatType = (code: string) => code === ledgerCodeType.VI || code === ledgerCodeType.VO;

// Test for type CL (Charge card type)
export const isChargeCardType = (code: string) => code === ledgerCodeType.CL;

// Test for remaining type AO, CP, RE, PC, DE, CC, DC, PY
export const isOtherType = (code: string) =>
  code === ledgerCodeType.AO ||
  code === ledgerCodeType.CP ||
  code === ledgerCodeType.RE ||
  code === ledgerCodeType.PC ||
  code === ledgerCodeType.DE ||
  code === ledgerCodeType.CC ||
  code === ledgerCodeType.DC ||
  code === ledgerCodeType.PY;
