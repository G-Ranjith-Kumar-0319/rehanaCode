import { useState, useEffect } from "react";

type DataItem = { [key: string]: any };

// Define the sorting order type
type SortOrder = "asc" | "desc";

const useSortedData = <T extends DataItem>(data: T[], key: keyof T, order: SortOrder = "asc"): T[] => {
  const [sortedData, setSortedData] = useState<T[]>([]);

  useEffect(() => {
    if (data && key) {
      const sortedArray = [...data].sort((a, b) => {
        const aValue = a[key];
        const bValue = b[key];

        // Ensure the comparison is case-insensitive for strings
        if (typeof aValue === "string" && typeof bValue === "string") {
          const aValueLower = aValue.toLowerCase();
          const bValueLower = bValue.toLowerCase();
          if (aValueLower < bValueLower) return order === "asc" ? -1 : 1;
          if (aValueLower > bValueLower) return order === "asc" ? 1 : -1;
        } else {
          // Generic comparison for other types
          if (aValue < bValue) return order === "asc" ? -1 : 1;
          if (aValue > bValue) return order === "asc" ? 1 : -1;
        }

        return 0;
      });
      setSortedData(sortedArray);
    } else {
      setSortedData([...data]);
    }
  }, [data, key, order]);

  return sortedData;
};

export default useSortedData;
