import { useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { useHistory, useLocation } from "react-router-dom";
import { getSessionItem } from "@/utils/getDataSource";
import { localRoutes } from "@/utils/constants";
import { ledgerGrpAction, postLedgerData } from "../State/LedgerGroupsList.slice";
import { generalLedgerFuncCodeAction, generalLedgerFundCodeAddEdit } from "../State/GeneralLedgerFundCodeListing.slice";
import useProfileModelForm from "../ProfileModels/hook/useProfileModelForm";
import useCostCentrePopup from "../CostCentres/hook/useCostCentrePopup";
import useCostCentreForm from "../CostCentres/hook/useCostCentreForm";
import { costCentreActions } from "../State/CostCentresTab.slice";
import useLedgerCodesForm from "../LedgerCodes/hooks/useLedgerCodesForm";

const useLedgerGrpPopup = () => {
  const location = useLocation();

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    addNewGrpsList,
    setLadgerGrpData,
    changeNewGrpList,
    resetSlice,
    setCancelBtnClick,
    setFormError,
    setSelectedRow
  } = ledgerGrpAction;
  const [tabData, setTabData] = useState("");
  const { newFundList } = useAppSelector((state: any) => state.generalLedgerFundCode);
  const { emptyNewFundList } = generalLedgerFuncCodeAction;
  const history = useHistory();
  const dispatch = useDispatch();
  const { validateFields } = useCostCentreForm();

  const { ledgerGroupsList, ladgerGrpData, isBtnClick, newGrpsList, newCreatedEditItem, deletedIds, isCancelClicked } =
    useAppSelector((state) => state.ledgerGroupsList);
  const { inputText, isFormDirty, id: itemId } = ladgerGrpData;
  const {
    location: { pathname: historyPathname }
  } = history;
  let flag = false;

  const { confirmationPopup, isRemaining } = useProfileModelForm();
  const { inputDetails: profileFormInput, newProfileModalData } = useAppSelector(
    (state) => state.generalLedgerProfileModel
  );
  const { isFormDirty: isProfileFormDirty } = profileFormInput;
  const {
    grpInputDetails: { isFormDirty: isCCGInputDirty },
    ccdInputDetail
  } = useAppSelector((state) => state.glCostCentre);
  const { confirmationPopupCCG, isPaylodValid } = useCostCentrePopup();

  const { confirmationPopupLC, isPaylodValidLC } = useLedgerCodesForm();

  const getEditText = (id: number) => {
    let editText;

    if (id !== 0) {
      editText = newGrpsList.find((data) => data.id === id) || ledgerGroupsList.find((data) => data.id === id);
      return editText;
    }
    editText = newCreatedEditItem;
    return editText;
  };

  const blankMsgPopup = () => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE?.ALERT,
        message: t("generalLedgerSetup.blankErrorMessage"),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus?.ERROR
      })
    );
    dispatch(setFormError(true));
  };

  const uniqueMsgPopup = () => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE?.ALERT,
        message: t("generalLedgerSetup.uniqueMessage"),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus?.ERROR
      })
    );
    dispatch(setFormError(true));
  };

  const yesFunc = () => {
    history.push(tabData);
  };

  const noFunc = () => {
    history.push(tabData);
  };
  const changeTab = () => {
    setTabData("");
  };
  const cancelFunc = () => {
    setTabData("");
  };

  useEffect(() => {
    if (location.pathname.includes("/ledger-groups/create") && tabData.length !== 0) {
      if (isFormDirty) {
        dispatch(
          uiActions.confirmPopup({
            enable: true,
            message: t("common.keepChangesWishMsg"),
            title: t("common.simsFMSModule"),
            type: MODAL_TYPE.CONFIRMV2,
            yesCallback: async () => {
              if (inputText.trim().length === 0) {
                blankMsgPopup();
                setTabData("");
              } else {
                const isDuplicated = [...ledgerGroupsList, ...newGrpsList].some(
                  (data) => data.description.toLocaleLowerCase().trim() === inputText.toLocaleLowerCase().trim()
                );

                if (isDuplicated) {
                  uniqueMsgPopup();
                  setTabData("");
                } else {
                  dispatch(
                    setLadgerGrpData({
                      id: 0,
                      inputText: "",
                      isFormDirty: false
                    })
                  );
                  dispatch(addNewGrpsList({ description: inputText, id: 0 }));
                  dispatch(postLedgerData());
                  history.push(tabData);
                }
              }
            },
            noCallback: () => {
              dispatch(
                setLadgerGrpData({
                  id: 0,
                  inputText: "",
                  isFormDirty: false
                })
              );
              dispatch(resetSlice());
              history.push(tabData);
            },
            isCancelBtnEnable: true,
            cancelCallback: () => {
              setTabData("");
            }
          })
        );
      } else if (!tabData.includes("create") && tabData.length !== 0) {
        history.push(tabData);
      }
    } else if (location.pathname.includes("/ledger-groups/edit") && tabData.length !== 0) {
      if (isFormDirty) {
        dispatch(
          uiActions.confirmPopup({
            enable: true,
            message: t("common.keepChangesWishMsg"),
            title: t("common.simsFMSModule"),
            type: MODAL_TYPE.CONFIRMV2,
            yesCallback: async () => {
              if (inputText.trim().length === 0) {
                blankMsgPopup();
                setTabData("");
              } else {
                const editText = getEditText(itemId);
                if (editText?.description === inputText) {
                  history.push(tabData);
                } else {
                  let isDuplicated = false;
                  if (editText?.id === 0) {
                    isDuplicated = [...ledgerGroupsList, ...newGrpsList].some(
                      (data) =>
                        data.description.toLocaleLowerCase().trim() === inputText.toLocaleLowerCase().trim() &&
                        editText?.description !== data.description
                    );
                  } else {
                    isDuplicated = [...ledgerGroupsList, ...newGrpsList].some(
                      (data) =>
                        data.description.toLocaleLowerCase().trim() === inputText.toLocaleLowerCase().trim() &&
                        editText?.id !== data.id
                    );
                  }

                  if (isDuplicated) {
                    dispatch(
                      uiActions.alertPopup({
                        enable: true,
                        type: MODAL_TYPE?.ALERT,
                        message: t("generalLedgerSetup.uniqueMessage"),
                        title: t("common.simsFMSModule"),
                        notificationType: NotificationStatus?.ERROR
                      })
                    );
                    flag = false;
                    setTabData("");
                  } else {
                    dispatch(
                      setLadgerGrpData({
                        id: 0,
                        inputText: "",
                        isFormDirty: false
                      })
                    );
                    dispatch(addNewGrpsList({ description: inputText, id: itemId }));
                    if (itemId === 0 && newCreatedEditItem) {
                      dispatch(changeNewGrpList(newCreatedEditItem));
                    }
                    dispatch(postLedgerData());
                    history.push(tabData);
                  }
                }
              }
            },
            noCallback: () => {
              dispatch(
                setLadgerGrpData({
                  id: 0,
                  inputText: "",
                  isFormDirty: false
                })
              );
              dispatch(resetSlice());

              if (itemId === 0 && newCreatedEditItem) {
                dispatch(changeNewGrpList(newCreatedEditItem));
              }
              history.push(tabData);
            },
            isCancelBtnEnable: true,
            cancelCallback: () => {
              setTabData("");
            }
          })
        );
      } else if (!tabData.includes("create") && tabData.length !== 0) {
        history.push(tabData);
      }
    } else if (
      location.pathname === "/tools/general-ledger-setup/ledger-groups" &&
      tabData !== "/tools/general-ledger-setup/ledger-groups" &&
      tabData.length !== 0 &&
      (newGrpsList.length > 0 || deletedIds.length > 0) &&
      !getSessionItem("setisBtn")
    ) {
      dispatch(
        uiActions.confirmPopup({
          enable: true,
          message: tabData === "/" ? t("generalLedgerSetup.glGoToHomeConfirmMsg") : t("common.keepChangesWishMsg"),
          title: t("common.simsFMSModule"),
          type: MODAL_TYPE.CONFIRMV2,
          yesCallback: async () => {
            if (!isCancelClicked) {
              dispatch(postLedgerData());
            }
            if (isCancelClicked) {
              dispatch(resetSlice());
              dispatch(setCancelBtnClick(false));
            }
            history.push(tabData);
          },
          noCallback: () => {
            if (isCancelClicked) {
              dispatch(setCancelBtnClick(false));
              setTabData("");
            }
            if (!isCancelClicked) {
              dispatch(resetSlice());
              history.push(tabData);
            }
          },
          isCancelBtnEnable: !isCancelClicked && true,
          cancelCallback: () => {
            setTabData("");
          }
        })
      );
    } else if (
      tabData !== "/tools/general-ledger-setup/fund-codes" &&
      location.pathname === "/tools/general-ledger-setup/fund-codes" &&
      tabData.length !== 0 &&
      newFundList?.length > 0 &&
      !getSessionItem("setisBtn")
    ) {
      dispatch(
        uiActions.confirmPopup({
          enable: true,
          message:
            tabData === localRoutes.home
              ? t("generalLedgerSetup.glGoToHomeConfirmMsg")
              : t("common.keepChangesWishMsg"),
          title: t("common.simsFMSModule"),
          type: MODAL_TYPE.CONFIRMV2,
          yesCallback: async () => {
            if (tabData !== localRoutes.home) {
              dispatch(
                generalLedgerFundCodeAddEdit({
                  callback: (res: any) => {
                    if (res?.validationType === 0) {
                      dispatch(emptyNewFundList());
                    }
                  }
                })
              );
            } else {
              dispatch(emptyNewFundList());
            }
            history.push(tabData);
          },
          noCallback: () => {
            if (tabData !== localRoutes.home) {
              dispatch(emptyNewFundList());
              history.push(tabData);
            } else {
              setTabData("");
            }
          },
          isCancelBtnEnable: tabData !== localRoutes.home && true,
          cancelCallback: () => {
            setTabData("");
          }
        })
      );
    } else if (location.pathname.includes("/profile-models/add") && tabData.length !== 0) {
      if (isProfileFormDirty) {
        confirmationPopup({
          inputValidation: true,
          yesFunc,
          changeTab,
          noFunc,
          cancelFunc
        });
      } else if (!tabData.includes("/profile-models/add") && tabData.length !== 0) {
        history.push(tabData);
      }
    } else if (location.pathname.includes("/profile-models/edit") && tabData.length !== 0) {
      if (isProfileFormDirty) {
        confirmationPopup({
          inputValidation: true,
          yesFunc,
          changeTab,
          noFunc,
          cancelFunc
        });
      } else if (!tabData.includes("/profile-models/edit") && tabData.length !== 0) {
        history.push(tabData);
      }
    } else if (
      tabData !== "/tools/general-ledger-setup/profile-models" &&
      location.pathname === "/tools/general-ledger-setup/profile-models" &&
      tabData.length !== 0 &&
      (newProfileModalData?.length > 0 || isRemaining)
    ) {
      confirmationPopup({
        inputValidation: false,
        yesFunc,
        changeTab,
        noFunc,
        cancelFunc
      });
    } else if (
      (location.pathname.includes("/cost-centres/add-cost-group") ||
        location.pathname.includes("/cost-centres/edit-cost-group/")) &&
      tabData.length !== 0
    ) {
      if (isCCGInputDirty) {
        confirmationPopupCCG({
          inputValidation: true,
          yesFunc,
          changeTab,
          noFunc,
          cancelFunc
        });
      } else if (
        (!tabData.includes("/cost-centres/add-cost-group") || !tabData.includes("/cost-centres/edit-cost-group/")) &&
        tabData.length !== 0
      ) {
        history.push(tabData);
      }
    } else if (
      (location.pathname.includes("/cost-centres/add-file") ||
        location.pathname.includes("/cost-centres/edit-file/")) &&
      tabData.length !== 0
    ) {
      if (ccdInputDetail?.isFormDirty) {
        confirmationPopupCCG({
          inputDetailValidation: true,
          yesFunc,
          changeTab,
          noFunc,
          cancelFunc
        });
      } else if (
        (!tabData.includes("/cost-centres/add-file") || !tabData.includes("/cost-centres/edit-file/")) &&
        tabData.length !== 0
      ) {
        history.push(tabData);
      }
    } else if (
      tabData !== "/tools/general-ledger-setup/cost-centres" &&
      location.pathname === "/tools/general-ledger-setup/cost-centres" &&
      tabData.length !== 0 &&
      isPaylodValid()
    ) {
      confirmationPopupCCG({
        inputValidation: false,
        yesFunc,
        changeTab,
        noFunc,
        cancelFunc
      });
    } else if (
      tabData !== "/tools/general-ledger-setup/ledger-codes" &&
      location.pathname === "/tools/general-ledger-setup/ledger-codes" &&
      tabData.length !== 0 &&
      isPaylodValidLC()
    ) {
      confirmationPopupLC({
        inputValidation: false,
        yesFunc,
        changeTab,
        noFunc,
        cancelFunc
      });
    } else if (!tabData.includes("create") && tabData.length !== 0) {
      history.push(tabData);
    }
  }, [tabData]);

  return {
    setTabData,
    getEditText,
    tabData
  };
};

export default useLedgerGrpPopup;
