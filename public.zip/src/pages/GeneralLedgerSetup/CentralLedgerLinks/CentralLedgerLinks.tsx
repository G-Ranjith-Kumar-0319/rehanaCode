import Layout from "@/components/Layout/Layout";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import GeneralLedgerSetup from "../GeneralLedgerSetup";
import GenralLedgerFooter from "../GeneralLedgerFooter";

const CentralLedgerLinks = () => {
  const submitHandler = () => {};
  const handleCancelCallBack = () => {};
  return (
    <>
      <GeneralLedgerSetup>
        <div className="general-ledger-listing-container general-ledger-scroll-height">
          <div className="d-flex justify-end">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
            >
              Link-Unlink
            </Button>
          </div>
        </div>
        <GenralLedgerFooter
          onSubmit={submitHandler}
          cancelCallback={handleCancelCallBack}
        />
      </GeneralLedgerSetup>
    </>
  );
};
export default CentralLedgerLinks;
