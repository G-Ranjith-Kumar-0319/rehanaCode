import React from "react";
import { useAppSelector } from "@/store/store";
import GeneralLedgerSetup from "../GeneralLedgerSetup";
import GenralLedgerFooter from "../GeneralLedgerFooter";

const CCentreLedgerLinks = () => {
  const {} = useAppSelector((state) => state.glCentreLedgerLinks);
  return (
    <>
      <GeneralLedgerSetup>
        <h1>CCentreLedgerLinks</h1>
        <GenralLedgerFooter
          onSubmit={() => {}}
          cancelCallback={() => {}}
        />
      </GeneralLedgerSetup>
    </>
  );
};
export default CCentreLedgerLinks;
