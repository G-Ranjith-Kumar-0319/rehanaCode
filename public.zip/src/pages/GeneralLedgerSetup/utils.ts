import React from "react";
import { ledgerCodeType } from "@/types/UseStateType";
import { isTextEqual } from "./ProfileModels/utils";
import { TLedgerCodeType } from "./State/glLedgerCodes.slice";

export function handleKeyPress(e: React.KeyboardEvent<HTMLInputElement>, pattern: any) {
  const isValid = pattern?.test(e.key) || e.key === "Backspace" || e.key === "Delete" || e.key === "Tab";
  if (!isValid) {
    e.preventDefault();
  }
}

export function deepSome(array: any[], value: string, key: string, exclude?: any) {
  return array?.some((t: any) => {
    if (exclude && t[key] === exclude) {
      return false;
    }
    return isTextEqual(t[key], value);
  });
}

export function checkGlLedgerType(ledgerType: TLedgerCodeType) {
  if (
    ledgerType &&
    (ledgerType?.value === ledgerCodeType.ES ||
      ledgerType?.value === ledgerCodeType.EX ||
      ledgerType?.value === ledgerCodeType.IN)
  ) {
    return true;
  }
  return false;
}

type DataItem = { [key: string]: any };
// Define the sorting order type
type SortOrder = "asc" | "desc";
const sortData = <T extends DataItem>(data: T[], key: keyof T, order: SortOrder = "asc"): T[] => {
  if (data && key) {
    return [...data].sort((a, b) => {
      const aValue = a[key];
      const bValue = b[key];

      // Ensure the comparison is case-insensitive for strings
      if (typeof aValue === "string" && typeof bValue === "string") {
        const aValueLower = aValue.toLowerCase();
        const bValueLower = bValue.toLowerCase();
        if (aValueLower < bValueLower) return order === "asc" ? -1 : 1;
        if (aValueLower > bValueLower) return order === "asc" ? 1 : -1;
      } else {
        // Generic comparison for other types
        if (aValue < bValue) return order === "asc" ? -1 : 1;
        if (aValue > bValue) return order === "asc" ? 1 : -1;
      }

      return 0;
    });
  }
  return [...data];
};

export const voucherTypeMapping: { [key: string]: number } = {
  NL: 0,
  OP: 2,
  CB: 3
};

export default sortData;
