import { getCurrentFinancialYear, STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";
import { createAsyncThunk, createSlice, current, PayloadAction } from "@reduxjs/toolkit";
import { actions } from "@/store/state/poParams.slice";
import { FormData as TCDInputDetail } from "../CostCentres/hook/useCostCentreForm";

/* eslint-disable camelcase */
export type TCostCentreGroup = {
  cost_group_id: number | string;
  description: string;
  parent_group_id: null | number;
  is_costgroup_update: boolean;
  audit_desc: string;
  lstCostCentre: any[] | null;
  lstCostCentreGroups: TCostCentreGroup[] | null;
};

export type TCostCentreTreeFile = {
  cost_id: number;
  cost_des: string;
  cost_code: string;
  cost_abrv: string;
  cost_hold: string;
  spendcheck: string;
  threshold: number | string;
  commitment: number;
  unpaid: number;
  exp_budget_limit: number;
  inc_budget_limit: number;
  audit_desc: string;
};

export type TreeNode = {
  index: string;
  canMove?: boolean;
  isFolder: boolean;
  children: string[];
  data: string;
  canRename?: boolean;
  parent_group_id?: null | number | string;
  id?: null | number | string;
  audit_desc?: string;
  is_dragged?: boolean;
};

export type TCostCentreTree = {
  [key: string]: TreeNode;
};

type deletedId = {
  cost_group_id: any;
  audit_desc: any;
};

type detailsDeletedId = {
  cost_id: any;
  audit_desc: any;
};

type TCostCentreType = {
  costCentreGrpList: TCostCentreGroup[];
  constCenterDetails: { [key: string]: any };
  status?: STATUS;
  grpInputDetails: TCGInputDetails;
  costCenterTree: TCostCentreTree;
  calltreeApi: boolean;
  callCostCentreGrpApi: boolean;
  expandedItems: string[];
  selectedItems: any[];
  focusedItem: any;
  costCentreDetailsDeleteId: any[];
  costCenterDetailList: any[];
  newCCGList: TreeNode[];
  grpInputError: boolean;
  costCentreGroupDeletedId: any[];
  costCenterPayload: TcostCenterPayload;
  // ---Cost center detail validation states----//
  isCodeExist: undefined | string;
  isDescExist: undefined | string;
  isAbbrExist: undefined | string;
  ccdInputDetail: any;
  newCostDetailList: any[];
  ccdErrorsState: { [key: string]: any };
  isViewLoading: boolean;
  isSubmitting: boolean;
  isTabClick: boolean;
  ccdUniquCheckRequest: boolean;
};

type TCGInputDetails = {
  isFormDirty: boolean;
  inputText: string;
  id: number;
};

export type TcostCenterPayload = {
  lstCostCentreGroups: TCostCentreGroup[] | null;
  deletedCostCentreIds:
    | {
        cost_id: number;
        audit_desc: string;
      }[]
    | null;
  deletedCostCentreGroupIds:
    | {
        cost_group_id: number;
        audit_desc: string;
      }[]
    | null;

  lstMoveCostCentres:
    | {
        cost_id: number;
        new_group_id: number;
      }[]
    | null;
  lstMoveGroups:
    | {
        group_id: number;
        new_parent_id: number;
      }[]
    | null;
};

export enum TCostCentreGrpForm {
  CREATE = "CREATE",
  EDIT = "EDIT"
}

type TDNDTarget = {
  targetType: string;
  treeId: string;
  parentItem: string;
  depth: number;
  linearIndex: number;
  childIndex: number;
  linePosition: string;
  targetItem: string;
};

const costCenterPayloadInitial = {
  deletedCostCentreGroupIds: null,
  deletedCostCentreIds: null,
  lstCostCentreGroups: null,
  lstMoveCostCentres: null,
  lstMoveGroups: null
};

const initialState: TCostCentreType = {
  costCentreGrpList: [],
  costCenterDetailList: [],
  constCenterDetails: {},
  grpInputDetails: {
    id: 0,
    isFormDirty: false,
    inputText: ""
  },
  ccdInputDetail: {
    code_id: 0,
    isFormDirty: false,
    threshold: 100,
    spendcheck: "T",
    cost_code: "",
    cost_des: "",
    cost_abrv: ""
  },
  ccdErrorsState: {
    cost_code: undefined,
    cost_des: undefined,
    cost_abrv: undefined,
    threshold: false
  },
  costCenterTree: {},
  calltreeApi: true,
  callCostCentreGrpApi: true,
  expandedItems: [],
  selectedItems: [],
  focusedItem: undefined,
  newCCGList: [],
  isSubmitting: false,
  grpInputError: false,
  isCodeExist: undefined,
  isDescExist: undefined,
  isAbbrExist: undefined,
  newCostDetailList: [],
  costCenterPayload: costCenterPayloadInitial,
  isViewLoading: false,
  ccdUniquCheckRequest: false,
  costCentreGroupDeletedId: [
    {
      cost_group_id: "",
      audit_desc: ""
    }
  ],
  costCentreDetailsDeleteId: [
    {
      cost_id: "",
      audit_desc: ""
    }
  ],
  isTabClick: true
};

// Thunk to get all Cost Centre Group

export const getCostCentreGrps = createAsyncThunk("costCenterGrps/get", async () => {
  const response = await client.get(`${apiRoot}/gl-cost-centre/group`);

  return response.data;
});

export const getCostCentreTree = createAsyncThunk("costCenterTree/get", async () => {
  const response = await client.get(`${apiRoot}/gl-cost-centre/details-structure`);

  return response.data;
});

// cost center details id Get Thunk
export const getCostCenterList = createAsyncThunk(
  "costCentres/gl-cost-center-id",
  async ({ costId }: { costId: any }) => {
    const response = await client.get(`${apiRoot}/gl-cost-centre/id?costId=${costId}`, {});
    return response.data;
  }
);

// cost center group id Get Thunk
export const getCostCenterGroupList = createAsyncThunk(
  "costCentres/gl-cost-center-group-id",
  async ({ costGroupId }: { costGroupId: any }) => {
    const response = await client.get(`${apiRoot}/gl-cost-centre/group-id?costGroupId=${costGroupId}`, {});
    return response.data;
  }
);

export const ValidateCostCentreGroup = createAsyncThunk(
  "costCentres/gl-cost-center-group-validate",
  async ({ cost_group_id, editGroup, callback }: { cost_group_id: any; editGroup: boolean; callback: any }) => {
    const response = await client.get(
      `${apiRoot}/gl-cost-centre/validate-costcentre-group-delete?isGroupDelete=${editGroup}&costId=${cost_group_id}`,
      {}
    );
    if (callback) {
      callback(response.data); // Invoke the callback with the response data
    }
    return response.data;
  }
);
// ------ Cost center detail && validaton requests--------
export const getCostCenterDetailList = createAsyncThunk("costCentres/getCostCenterDetailList", async () => {
  const response = await client.get(`${apiRoot}/gl-cost-centre`);
  return response.data;
});
// Validate code year
export const validateCostCentreCodeYear = createAsyncThunk(
  "costCentres/validateCostCentreCodeYear",
  async ({ costId, costCode, yearId }: any) => {
    const response = await client.get(`${apiRoot}/gl-cost-centre/validate-costcentre-code-year`, {
      params: {
        costId,
        costCode,
        yearId
      }
    });
    return response.data;
  }
);
// Validate desc year
export const validateCostCentreDescYear = createAsyncThunk(
  "costCentres/validateCostCentreDescYear",
  async ({ costId, costDes, yearId }: any) => {
    const response = await client.get(`${apiRoot}/gl-cost-centre/validate-costcentre-desc-year`, {
      params: {
        costId,
        costDes,
        yearId
      }
    });
    return response.data;
  }
);
// Validate abbreviation year
export const validateCostCentreAbrvYear = createAsyncThunk(
  "costCentres/validateCostCentreAbrvYear",
  async ({ costId, costAbrv, yearId }: any) => {
    const response = await client.get(`${apiRoot}/gl-cost-centre/validate-costcentre-abrv-year`, {
      params: {
        costId,
        costAbrv,
        yearId
      }
    });
    return response.data;
  }
);
// ------------------------------------------//

export const postCostCentrePayload = createAsyncThunk("costCentres/post", async (data, thunkAPI) => {
  const { getState, dispatch } = thunkAPI;
  const state: any = getState();
  const ccgList = state?.glCostCentre?.newCCGList;
  const ccdList = state?.glCostCentre?.newCostDetailList;
  const payload = state?.glCostCentre?.costCenterPayload;
  const ccTree = state.glCostCentre.costCenterTree;
  const lstCostCentreGroups = createCCGPayload(ccgList, ccdList);
  const lstMoveGroups = createMoveGrpsPayload(ccTree);
  const lstMoveCostCentres = createMoveCostCentresPayload(ccTree);

  const costCentreGroupDeleteDataFinal = state.glCostCentre.costCentreGroupDeletedId
    .slice(1)
    .filter((data: { cost_group_id: number; audit_desc: string }) => data.cost_group_id > 0)
    .map((data: { cost_group_id: number; audit_desc: string }) => ({
      cost_group_id: data.cost_group_id,
      audit_desc: `${data.audit_desc}`
    }));

  const costCentreDetailsDeleteDataFinal = state.glCostCentre.costCentreDetailsDeleteId
    .slice(1)
    .filter((data: { cost_id: number; audit_desc: string }) => data.cost_id > 0)
    .map((data: { cost_id: number; audit_desc: string }) => ({
      cost_id: data.cost_id,
      audit_desc: `${data.audit_desc}`
    }));

  const updatedPayload: TcostCenterPayload = {
    ...payload,
    lstCostCentreGroups,
    lstMoveGroups,
    lstMoveCostCentres,
    deletedCostCentreIds: !costCentreDetailsDeleteDataFinal?.length ? null : costCentreDetailsDeleteDataFinal,
    deletedCostCentreGroupIds: !costCentreGroupDeleteDataFinal?.length ? null : costCentreGroupDeleteDataFinal
  };

  try {
    const response: any = await client.post(`${apiRoot}/gl-cost-centre`, updatedPayload);
    if (response.data.validationType === 0) {
      setTimeout(() => {
        dispatch(getCostCentreTree());
        dispatch(getCostCentreGrps());
        dispatch(getCostCenterDetailList());
      }, 500);
    }
  } catch (error) {
    console.log(error);
  }
});

const costCentreGrpRecurr = (newTreeObj: any, currentCCGList: any[], newData: any) => {
  const latestCCGrpList = currentCCGList?.map((data: any) => {
    const costGrp = { ...data };
    const arr = [...(costGrp.lstCostCentreGroups as [])];

    if (data.description === newTreeObj?.parent_group_id?.toString()) {
      const newarr = [...arr, { ...newData }];
      costGrp.lstCostCentreGroups = [...newarr];
      return costGrp;
    }
    const newCCGrpList = costCentreGrpRecurr(newTreeObj, arr, newData);
    const newarr = [...newCCGrpList];
    costGrp.lstCostCentreGroups = [...newarr];
    return costGrp;
  });

  return latestCCGrpList;
};

const createCCGPayload = (ccgList: TreeNode[], ccdList: any) => {
  let lstCostCentreGroups: TCostCentreGroup[] = [];
  if (ccgList?.length > 0) {
    const addCostCenterDetail = (children = []) =>
      children.map((t) => ccdList?.find((ccdItem: any) => t === ccdItem.cost_des)).filter((item: any) => item);

    ccgList?.forEach((obj: TreeNode) => {
      const newTreeObj = { ...obj };
      const isCCGOld = newTreeObj?.parent_group_id !== 0 && typeof newTreeObj?.parent_group_id !== "string";
      const newData: TCostCentreGroup = {
        cost_group_id: newTreeObj?.id ?? 0,
        description: newTreeObj.data,
        audit_desc: newTreeObj.audit_desc || "test",
        is_costgroup_update: newTreeObj?.id !== 0,
        parent_group_id: typeof newTreeObj?.parent_group_id !== "string" ? (newTreeObj?.parent_group_id as number) : 0,
        lstCostCentre: addCostCenterDetail(obj?.children as any) || [], // To prepare cost center for group
        lstCostCentreGroups: []
      };
      if (isCCGOld) {
        lstCostCentreGroups = [...lstCostCentreGroups, newData];
      } else if (typeof newTreeObj?.parent_group_id === "string") {
        const currentCCGList = [...(lstCostCentreGroups || [])];
        const latestCCGrpList = costCentreGrpRecurr(newTreeObj, currentCCGList, newData);

        lstCostCentreGroups = [...latestCCGrpList];
      }
    });
  }

  return lstCostCentreGroups.length > 0 ? lstCostCentreGroups : null;
};

const createMoveGrpsPayload = (newTreeObj: TCostCentreTree) => {
  const lstMoveGroups = Object.keys(newTreeObj)
    .filter((key) => {
      const obj = newTreeObj[key];
      return obj.is_dragged && obj.isFolder;
    })
    .map((key) => {
      const obj = newTreeObj[key];
      const parentId = typeof obj.parent_group_id === "string" ? 0 : obj.parent_group_id;
      return {
        group_id: obj.id,
        new_parent_id: parentId,
        new_parent_desc: obj.data
      };
    });

  return lstMoveGroups.length > 0 ? lstMoveGroups : null;
};

const createMoveCostCentresPayload = (newTreeObj: TCostCentreTree) => {
  const lstMoveCostCentres = Object.keys(newTreeObj)
    .filter((key) => {
      const obj = newTreeObj[key];
      return obj.is_dragged && !obj.isFolder;
    })
    .map((key) => {
      const obj = newTreeObj[key];
      const parentId = typeof obj.parent_group_id === "string" ? 0 : obj.parent_group_id;
      return {
        cost_id: obj.id,
        new_group_id: parentId,
        new_group_desc: obj.data
      };
    });

  return lstMoveCostCentres.length > 0 ? lstMoveCostCentres : null;
};

const slice = createSlice({
  initialState,
  name: "glCostCentre",
  extraReducers: (builder) => {
    builder
      .addCase(getCostCentreGrps.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getCostCentreGrps.fulfilled, (state, action: PayloadAction<TCostCentreGroup[] | any>) => {
        state.status = STATUS.SUCCESS;
        state.costCentreGrpList = action.payload;
        state.callCostCentreGrpApi = false;
      })
      .addCase(getCostCentreGrps.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    // get cost center group list
    builder.addCase(getCostCenterDetailList.fulfilled, (state, action: PayloadAction<any>) => {
      state.costCenterDetailList = action.payload;
      state.ccdUniquCheckRequest = true;
    });
    // valid Cost Center Code
    builder
      .addCase(validateCostCentreCodeYear.fulfilled, (state, action: PayloadAction<any>) => {
        state.isCodeExist = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(validateCostCentreCodeYear.pending, (state, action) => {
        state.status = STATUS.LOADING;
      });

    // valid Cost Center Description
    builder
      .addCase(validateCostCentreDescYear.fulfilled, (state, action: PayloadAction<any>) => {
        state.isDescExist = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(validateCostCentreDescYear.pending, (state, action) => {
        state.status = STATUS.LOADING;
      });
    // valid Cost Center Abbreviation
    builder
      .addCase(validateCostCentreAbrvYear.fulfilled, (state, action: PayloadAction<any>) => {
        state.isAbbrExist = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(validateCostCentreAbrvYear.pending, (state, action) => {
        state.status = STATUS.LOADING;
      });
    builder
      .addCase(getCostCentreTree.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getCostCentreTree.fulfilled, (state, action: PayloadAction<TCostCentreTree | any>) => {
        state.status = STATUS.SUCCESS;
        state.calltreeApi = false;
        state.costCenterTree = action.payload;

        const rootFolder = action.payload.root?.children[0];
        state.selectedItems = [rootFolder];
        state.focusedItem = action.payload[rootFolder];

        if (!state.isTabClick) {
          state.expandedItems = [rootFolder];
        }
      })
      .addCase(getCostCentreTree.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getCostCenterList.pending, (state) => {
        state.isViewLoading = true;
      })
      .addCase(getCostCenterList.fulfilled, (state, action: PayloadAction<any>) => {
        state.constCenterDetails = action.payload;
        state.isViewLoading = false;
      })
      .addCase(getCostCenterList.rejected, (state, action) => {});
    builder
      .addCase(getCostCenterGroupList.pending, (state) => {})
      .addCase(getCostCenterGroupList.fulfilled, (state, action: PayloadAction<any>) => {})
      .addCase(getCostCenterGroupList.rejected, (state, action) => {});
    builder
      .addCase(postCostCentrePayload.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(postCostCentrePayload.fulfilled, (state, action) => {
        state.status = STATUS.LOADING;
        state.newCostDetailList = [];
        state.costCenterPayload = costCenterPayloadInitial;
        state.newCCGList = [];
        state.newCostDetailList = [];
        state.costCenterTree = {};
        state.costCentreGroupDeletedId = [
          {
            cost_group_id: "",
            audit_desc: ""
          }
        ];
        state.costCentreDetailsDeleteId = [
          {
            cost_id: "",
            audit_desc: ""
          }
        ];
      })
      .addCase(postCostCentrePayload.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {
    setInputDetails: (state, action: PayloadAction<TCGInputDetails>) => {
      state.grpInputDetails = { ...action.payload };
    },
    setFocusedItem: (state, action: PayloadAction<TreeNode>) => {
      state.focusedItem = { ...action.payload };
    },
    setExpandedItems: (state, action) => {
      state.expandedItems = [...action.payload];
    },
    setSelectedItems: (state, action) => {
      state.selectedItems = [...action.payload];
    },
    updateCostCentreTree: (state, action) => {
      state.costCenterTree = { ...action.payload };
    },
    costCentreGroupAllDeletedIds: (state, action: PayloadAction<any>) => {
      state.costCentreGroupDeletedId = [...state.costCentreGroupDeletedId, action.payload];
    },
    costCentreDetailedIds: (state, action: PayloadAction<any>) => {
      state.costCentreDetailsDeleteId = [...state.costCentreDetailsDeleteId, action.payload];
    },
    setTreeNode: (state, action: PayloadAction<TreeNode>) => {
      const newTreeObj = { ...state.costCenterTree };
      const newItemIndex = action.payload.index;
      const parentIndex = action.payload.parent_group_id;
      let newCCGList = [...state.newCCGList];
      newTreeObj[state.focusedItem.index].children.push(newItemIndex);

      // adding newly created grp as children in newly created grp
      if (typeof parentIndex === "string") {
        newCCGList = [...current(state.newCCGList)].map((data: TreeNode) => {
          if (parentIndex === data.index) {
            const children = [...data.children];
            children.push(newItemIndex);
            const obj = {
              ...data,
              children
            };
            return obj;
          }

          return data;
        });
      }

      state.costCenterTree = {
        ...newTreeObj,
        [newItemIndex]: { ...action.payload }
      };
      if (action?.payload.isFolder) {
        state.newCCGList = [...state.newCCGList, action.payload];
      }
    },
    updateCostGrp: (state, action: PayloadAction<TreeNode>) => {
      const newTreeObj = { ...current(state.costCenterTree) };
      const editedItemIndex = action.payload.index;
      const editedItemId = action.payload.id;
      const newCCGList = [...current(state.newCCGList)];
      const focusedItem = { ...state.focusedItem };
      const parentIndex = focusedItem.parent_group_id;

      const oldData = newTreeObj[editedItemId === 0 ? focusedItem.index : editedItemIndex];
      const newData: TreeNode = JSON.parse(
        JSON.stringify({
          ...oldData,
          data: action.payload.data,
          index: editedItemIndex
        })
      );

      if (editedItemId !== 0) {
        // If editing existing group
        newTreeObj[editedItemIndex] = { ...newData };
        state.costCenterTree = {
          ...newTreeObj
        };
        state.focusedItem = { ...newData };
        // Updating Edited Group in Tree Object
        if (newCCGList.some((data: TreeNode) => data.id === focusedItem.id)) {
          const ccgList = [...newCCGList].map((data: TreeNode) => {
            if (data.id === focusedItem.id) {
              return {
                ...action.payload,
                children: data.children,
                index: editedItemIndex
              };
            }

            return data;
          });
          state.newCCGList = [...ccgList];
        } else {
          state.newCCGList = [...newCCGList, action.payload];
        }

        const newGrpList = [...current(state.costCentreGrpList)].map((data: TCostCentreGroup) => {
          if (data.cost_group_id === focusedItem.id) {
            return {
              ...data,
              description: action.payload.data
            };
          }
          return data;
        });

        state.costCentreGrpList = [...newGrpList]; // Updating Group List
      } else {
        // If editing newly created group

        // Deleting old group and adding new group
        delete newTreeObj[focusedItem.index];
        newTreeObj[editedItemIndex] = { ...newData };

        const parentId =
          typeof parentIndex === "string" ? focusedItem.parent_group_id : `${focusedItem.parent_group_id}_CG`;

        // Getting parent object and updating its children
        const parentObj = { ...newTreeObj[parentId] };
        const newChildren = parentObj.children.filter((data) => data !== focusedItem.index);
        newChildren.push(editedItemIndex);
        parentObj.children = [...newChildren];

        if (newData.children.length > 0) {
          newData.children.forEach((data) => {
            const childObj = { ...newTreeObj[data] };
            delete newTreeObj[data];
            newTreeObj[data] = {
              ...childObj,
              parent_group_id: editedItemIndex
            };
          });
        }

        // Deleting old parent group and adding new parent group with updated children
        delete newTreeObj[parentId];
        newTreeObj[parentId] = { ...parentObj };

        state.costCenterTree = { ...newTreeObj };
        const ccgList = [...newCCGList].map((data: TreeNode) => {
          if (data.data === focusedItem.data) {
            return {
              ...action.payload,
              children: data.children,
              index: editedItemIndex,
              parent_group_id: focusedItem.parent_group_id
            };
          }

          if (data.parent_group_id === focusedItem.index) {
            return {
              ...data,
              parent_group_id: editedItemIndex
            };
          }

          return data;
        });

        state.newCCGList = [...ccgList];
      }

      state.focusedItem = { ...newData };
      state.selectedItems = [newData.index];
    },
    setGrpInputError: (state, action: PayloadAction<boolean>) => {
      state.grpInputError = action.payload;
    },
    resetCostCenter: (state) => {
      state.newCCGList = [];
      state.newCostDetailList = [];
      state.calltreeApi = true;
      state.callCostCentreGrpApi = true;
      state.costCenterPayload = costCenterPayloadInitial;
      state.costCentreGroupDeletedId = [
        {
          cost_group_id: "",
          audit_desc: ""
        }
      ];
      state.costCentreDetailsDeleteId = [
        {
          cost_id: "",
          audit_desc: ""
        }
      ];
      state.costCentreGrpList = [];
      state.costCenterDetailList = [];
      state.selectedItems = [];
      state.expandedItems = [];
      state.focusedItem = undefined;
      state.isTabClick = true;
    },
    resetNewCCGList: (state, actions) => {
      state.newCCGList = [...actions.payload];
    },
    // ------------------Cost Center Detail Set States-------------------------//
    setCDInputDetail: (state, action: PayloadAction<any>) => {
      state.ccdInputDetail = action.payload;
    },
    setCostCenterForView: (state, action: PayloadAction<any>) => {
      state.constCenterDetails = action.payload;
    },
    toViewCostCenterDetail: (state, action: PayloadAction<any>) => {
      const updateList = (list: TCostCentreTreeFile[], item: any) => {
        const index = list.findIndex((i: any) => i.cost_code === item.cost_code);
        if (index !== -1) {
          // Update existing item
          return list.map((i, idx) => (idx === index ? item : i));
        }
        // Add new item
        return [...list, item];
      };

      state.costCenterDetailList = updateList(state.costCenterDetailList, action.payload); // To check unique
      state.newCostDetailList = updateList(state.newCostDetailList, action.payload);
    },
    updateNewCostDetaiList: (state, action) => {
      state.newCostDetailList = [...action.payload];
    },
    clearAlreadyExistData: (state) => {
      state.isAbbrExist = undefined;
      state.isDescExist = undefined;
      state.isCodeExist = undefined;
    },
    setErrorState: (state, action) => {
      state.ccdErrorsState = action.payload;
    },
    updatedTreeNode: (state, action) => {
      const exitingItemIndex = action.payload.index;
      state.costCenterTree[exitingItemIndex] = action.payload;
    },
    updateUniqueCheckList: (state, action) => {
      state.costCenterDetailList = [...action.payload];
    },
    setSubmitting: (state, action) => {
      state.isSubmitting = action.payload;
    },
    updateCcgList: (state, action: PayloadAction<any>) => {
      let found = false;
      const findParentAndUpdate = [...current(state.newCCGList)]?.map((parent: any) => {
        if (parent?.data === action.payload?.cost_group_desc) {
          found = true;
          return {
            ...parent,
            children: [...parent?.children, action.payload?.cost_des]
          };
        }
        return parent;
      });
      if (!found) {
        const createParent: any = {
          id: action.payload.cost_group_id ?? 0,
          isFolder: true,
          children: [action.payload?.cost_des],
          index: action.payload?.cost_group_desc,
          data: action.payload?.cost_group_desc,
          parent_group_id: action.payload?.parent_group_id
        };
        state.newCCGList = [...state.newCCGList, createParent];
      } else {
        state.newCCGList = findParentAndUpdate;
      }
    },
    changeTreeItemPosition: (state, action: PayloadAction<{ target: TDNDTarget; items: TreeNode[] }>) => {
      const newTreeObj = { ...current(state.costCenterTree) };
      const newCCGList = [...current(state.newCCGList)];
      const newCostDetailList = [...current(state.newCostDetailList)];
      const { target, items } = action.payload;
      const dropToFolderId = target.targetItem; // targetItem
      const { index: dragItemIndex, id: dragItemId } = items[0]; // dragItem

      // Check if dragItem is not dropped to same folder
      if (dropToFolderId !== dragItemIndex) {
        // Updating Dragged object
        const targetObj = { ...newTreeObj[dragItemIndex] };
        const targetParentId = targetObj.parent_group_id;
        const targetOldParentId = typeof targetParentId === "string" ? targetParentId : `${targetParentId}_CG`;
        targetObj.is_dragged = dragItemId !== 0;
        // Updating old Parent of Dragged Object
        const oldParent = { ...newTreeObj[targetOldParentId!] };
        const targetParent = newTreeObj[dropToFolderId];
        targetObj.parent_group_id = targetParent.id === 0 ? targetParent.index : targetParent.id;

        const oldParentChild = oldParent.children.filter((data) => data !== dragItemIndex);

        oldParent.children = [...oldParentChild];

        // Updating old parent
        delete newTreeObj[targetOldParentId];
        newTreeObj[targetOldParentId] = { ...oldParent };

        // Updating new parent
        const newParent = { ...newTreeObj[dropToFolderId] };
        const newParentChild = [...newParent.children];
        newParentChild.push(dragItemIndex);
        newParent.children = [...newParentChild];

        delete newTreeObj[dropToFolderId];
        newTreeObj[dropToFolderId] = { ...newParent };

        // Update Draged Object
        delete newTreeObj[dragItemIndex];
        newTreeObj[dragItemIndex] = { ...targetObj };

        state.costCenterTree = { ...newTreeObj };

        // If Newly created group is dragged to another folder
        if (dragItemId === 0 && items[0].isFolder) {
          const latestCCGList = newCCGList.map((data: TreeNode) => {
            if (data.index === dragItemIndex) {
              const targetParent = newTreeObj[dropToFolderId];
              return {
                ...data,
                parent_group_id: targetParent.id === 0 ? targetParent.index : targetParent.id
              };
            }
            return data;
          });
          state.newCCGList = [...latestCCGList];
        }

        // If Newly created detail is dragged to another folder
        if (dragItemId === 0 && !items[0].isFolder) {
          const latestCostDetailList = newCostDetailList.map((data: TCostCentreTreeFile) => {
            if (data.cost_des === dragItemIndex) {
              const targetParent = newTreeObj[dropToFolderId];
              return {
                ...data,
                cost_group_id: targetParent.id === 0 ? targetParent.index : targetParent.id
              };
            }
            return data;
          });
          state.newCostDetailList = [...latestCostDetailList];
        }

        state.selectedItems = [dropToFolderId];
        state.focusedItem = { ...newTreeObj[dropToFolderId] };
        state.expandedItems = [...state.expandedItems, dropToFolderId];
      }
    },
    setTabClick: (state, action: PayloadAction<boolean>) => {
      state.isTabClick = action.payload;
    }
  }
});

export const { actions: costCentreActions, reducer } = slice;
export default reducer;
