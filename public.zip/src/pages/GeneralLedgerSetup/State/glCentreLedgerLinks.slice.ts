import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";

type TinitialState = {};

const initialState: TinitialState = {};

const slice = createSlice({
  initialState,
  name: "glCentreLedgerLinks",
  extraReducers: (builder) => {},
  reducers: {}
});

export const { actions: centreLinksAction, reducer } = slice;
export default reducer;
