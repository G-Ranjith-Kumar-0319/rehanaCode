import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";
import { createAsyncThunk, createSlice, PayloadAction, current } from "@reduxjs/toolkit";
import { getSessionItem } from "@/utils/getDataSource";
import PeriodInitialData from "../ProfileModels/Grid/PeriodInitialData";
import { getRemainingVal, isArrayLength, isTextEqual } from "../ProfileModels/utils";

/* eslint-disable camelcase */
type TGeneralLedgerProfileModalData = {
  model_id: number;
  model_des: string;
  old_modal_des?: string | undefined;
  no_periods: number;
  percent_remaining: number;
  deletable: string;
  model_des_upper: string;
};

type TGeneralLedgerProfileModalPeriod = {
  model_id?: number;
  period?: number;
  period_name: string;
  profile: number;
};

type TInputDetails = {
  isFormDirty: boolean;
  inputText: string;
  id: number;
};

type TNewProfileModalData = TGeneralLedgerProfileModalData & {
  periods?: TGeneralLedgerProfileModalPeriod[];
};

type LedgerGroupsListingType = {
  profileSelectedRow?: { [key: string]: any } | undefined;
  periodSelectedRow?: { [key: string]: any } | undefined;
  status?: STATUS | String;
  profileModalData: TGeneralLedgerProfileModalData[];
  profileModalPeriod: TGeneralLedgerProfileModalPeriod[];
  choosePeriodsData: TGeneralLedgerProfileModalPeriod[];
  tobeUsedChooseModalPeriods: any;
  availableChooseperiodSelectedRow?: any;
  tobeUsedChoosePeriodSelectedRow?: any;
  newProfileModalData: TNewProfileModalData[];
  inputDetails: TInputDetails;
  isAddError: boolean;
  finalProfileList: TNewProfileModalData[];
  resetZero: boolean;
  isProfileDataExist: boolean;
  tableProfileData: TGeneralLedgerProfileModalData[];
  inputStatus: boolean;
  resetInput: number | undefined;
};

export type TgetProfileModalId = {
  id?: number;
};

const initialState: LedgerGroupsListingType = {
  profileModalData: [],
  tobeUsedChooseModalPeriods: [],
  inputStatus: false,
  choosePeriodsData: [],
  newProfileModalData: [],
  inputDetails: {
    id: 0,
    isFormDirty: false,
    inputText: ""
  },
  isAddError: false,
  profileModalPeriod: PeriodInitialData,
  profileSelectedRow: undefined,
  periodSelectedRow: undefined,
  finalProfileList: [],
  resetZero: false,
  isProfileDataExist: false,
  tableProfileData: [],
  resetInput: undefined
};

// Profile Model Get Thunk

export const getProfileModalData = createAsyncThunk("profileModal/list", async () => {
  const response = await client.get(`${apiRoot}/gl-setup/gl-profile-model`);

  return response.data;
});

export const getProfileModalPeriods = createAsyncThunk("profileModal/period", async ({ id }: TgetProfileModalId) => {
  if (id) {
    const response = await client.get(`${apiRoot}/gl-setup/gl-profile-model-periods`, {
      params: {
        modelId: id
      }
    });
    return response.data;
  }

  return [];
});

// Profile Model Post Thunk

export const postProfileModelData = createAsyncThunk("profileModal/post", async (data, thunkAPI) => {
  const { getState, dispatch } = thunkAPI;
  const state: any = getState();
  // Session will have data only when tab change while editing
  const newProfileList = isArrayLength(getSessionItem("saveDataOnTabChange"))
    ? getSessionItem("saveDataOnTabChange")
    : state?.generalLedgerProfileModel?.newProfileModalData;

  try {
    const response = await client.post(`${apiRoot}/gl-setup/gl-profile-model`, newProfileList);
    dispatch(getProfileModalData());
    dispatch(profileModalActions.setProfileDataExist(false));
  } catch (error) {
    console.log(error);
  }
});

const sortArr = (data: TGeneralLedgerProfileModalPeriod[]) => data.sort((a: any, b: any) => a.period - b.period);

const slice = createSlice({
  initialState,
  name: "profileModalData",
  extraReducers: (builder) => {
    builder
      .addCase(getProfileModalData.pending, (state, action) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getProfileModalData.fulfilled, (state, actions: PayloadAction<any>) => {
        state.profileModalData = actions.payload;
        state.isProfileDataExist = true;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getProfileModalData.rejected, (state, actions) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getProfileModalPeriods.fulfilled, (state, actions: PayloadAction<any>) => {
        if (state.profileSelectedRow?.model_id) {
          state.profileModalPeriod = actions.payload;
          state.choosePeriodsData = PeriodInitialData;
        }
        state.status = STATUS.SUCCESS;
      })
      .addCase(getProfileModalPeriods.rejected, (state, actions) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(postProfileModelData.pending, (state, action) => {
        state.status = STATUS.LOADING;
      })
      .addCase(postProfileModelData.fulfilled, (state, action) => {
        state.status = STATUS.SUCCESS;
        state.newProfileModalData = [];
        state.profileModalData = [];
        state.periodSelectedRow = undefined;
      })
      .addCase(postProfileModelData.rejected, (state, action) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {
    setAvailableChoosePeriodSelectedRow: (state, action: PayloadAction<{ [key: string]: any }>) => {
      state.availableChooseperiodSelectedRow = action.payload;
    },
    setTobeUsedChoosePeriodSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.tobeUsedChoosePeriodSelectedRow = action.payload;
    },
    setTobeUsedChoosePeriods: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const oldChooseData = sortArr([...current(state.tobeUsedChooseModalPeriods)]);
      const latestChosenList = sortArr([...state.tobeUsedChooseModalPeriods, action.payload]);
      const choosePeriodData = state.tobeUsedChoosePeriodSelectedRow;
      const oldIndex = oldChooseData.findIndex(
        (profile: any) => profile?.period_name.toString() === choosePeriodData?.period_name?.toString()
      );

      state.tobeUsedChooseModalPeriods = [...state.tobeUsedChooseModalPeriods, action.payload];
      state.tobeUsedChoosePeriodSelectedRow = { ...latestChosenList[oldIndex] };
    },
    setAvailableChoosePeriods: (state, action: PayloadAction<any>) => {
      const oldChooseData = sortArr([...current(state.choosePeriodsData)]);
      const latestChosenList = sortArr([...state.choosePeriodsData, action.payload]);
      const choosePeriodData = state.availableChooseperiodSelectedRow;
      const oldIndex = oldChooseData.findIndex(
        (profile: any) => profile?.period_name.toString() === choosePeriodData?.period_name?.toString()
      );

      state.choosePeriodsData = [...state.choosePeriodsData, action.payload];
      state.availableChooseperiodSelectedRow = { ...latestChosenList[oldIndex] };
    },

    removeFromAvailableChoosePeriods: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const profileModalDatas = current(state.choosePeriodsData);
      const newChooseData = [...profileModalDatas].sort((a: any, b: any) => a.period - b.period);
      const oldIndex = newChooseData.findIndex(
        (profile: any) => profile?.period_name.toString() === action.payload?.period_name?.toString()
      );

      const filtered = newChooseData.filter(
        (profile: any) => profile?.period_name.toString() !== action.payload?.period_name?.toString()
      );

      state.choosePeriodsData = [...filtered];
      state.availableChooseperiodSelectedRow = {
        ...filtered[oldIndex === profileModalDatas.length - 1 ? filtered.length - 1 : oldIndex]
      };

      if (state.tobeUsedChooseModalPeriods.length > 1) {
        state.tobeUsedChoosePeriodSelectedRow = { ...state.tobeUsedChoosePeriodSelectedRow };
      }
    },
    removeFromTobeUsedChequeBooks: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const choosePriodsDatas = current(state.tobeUsedChooseModalPeriods);
      const newChooseData = [...choosePriodsDatas].sort((a: any, b: any) => a.period - b.period);
      const oldIndex = newChooseData.findIndex(
        (profile: any) => profile?.period_name.toString() === action.payload?.period_name?.toString()
      );

      const filtered = newChooseData.filter(
        (profile: any) => profile?.period_name.toString() !== action.payload?.period_name?.toString()
      );

      state.tobeUsedChooseModalPeriods = [...filtered];
      state.tobeUsedChoosePeriodSelectedRow = {
        ...filtered[oldIndex === choosePriodsDatas.length - 1 ? filtered.length - 1 : oldIndex]
      };

      if (state.choosePeriodsData.length > 1) {
        state.availableChooseperiodSelectedRow = { ...state.availableChooseperiodSelectedRow };
      }
    },

    moveAllAvailableItemsRightToLeft: (state, action: PayloadAction<any>) => {
      state.tobeUsedChooseModalPeriods = sortArr([
        ...state.tobeUsedChooseModalPeriods.concat(state?.choosePeriodsData)
      ]);
      state.choosePeriodsData = [];
      state.tobeUsedChoosePeriodSelectedRow = { ...state.tobeUsedChooseModalPeriods[0] };
    },
    removeAllPeriodsRightToLeft: (state, action: PayloadAction<any>) => {
      state.choosePeriodsData = sortArr([...state.choosePeriodsData.concat(state?.tobeUsedChooseModalPeriods)]);
      state.tobeUsedChooseModalPeriods = [];
      state.availableChooseperiodSelectedRow = { ...state.choosePeriodsData[0] };
    },
    selectChooseItems: (state, action: PayloadAction<any>) => {
      const totalItems = action.payload.length;
      if (totalItems > 0) {
        const newObj = { ...current(state.profileSelectedRow) };
        const distribution = 100 / totalItems;
        const newPeriod = [...action.payload].sort((a, b) => a.period - b.period);
        const updatedPeriod = newPeriod.map((data: any) => {
          const newData = { ...data };
          newData.profile = distribution.toFixed(2);
          return newData;
        });

        const totalVal = updatedPeriod
          ?.reduce((acc: number, data: any) => acc + parseFloat(data?.profile), 0)
          .toFixed(2);

        const remainingData = getRemainingVal(parseFloat(totalVal));
        const lastEleProfile = updatedPeriod[totalItems - 1].profile;
        updatedPeriod[totalItems - 1].profile = (parseFloat(lastEleProfile) + parseFloat(remainingData)).toFixed(2);

        const remainingPeriod = PeriodInitialData.filter(
          (item: any) => !updatedPeriod.some((data) => data.period === item.period)
        );

        newObj.percent_remaining = 0.0;
        const newPeriods = [...updatedPeriod, ...remainingPeriod].sort((a, b) => a.period - b.period);
        newObj.periods = [...newPeriods];

        if (newObj?.model_id === 0 || state.newProfileModalData.some((data) => data.model_id === newObj?.model_id)) {
          const newArr = [...current(state.newProfileModalData)].filter(
            (data) => data?.model_des !== newObj?.model_des
          );
          state.newProfileModalData = [...newArr, newObj as any];
        } else {
          const newArr = [...current(state.profileModalData)].filter((data) => data?.model_des !== newObj?.model_des);

          state.profileModalData = [...newArr];
          state.newProfileModalData = [...state.newProfileModalData, newObj as any];
        }

        state.profileSelectedRow = { ...newObj };
      }
    },
    resetSpread: (state) => {
      state.choosePeriodsData = PeriodInitialData;
      state.availableChooseperiodSelectedRow = { ...PeriodInitialData[0] };
      state.tobeUsedChoosePeriodSelectedRow = undefined;
      state.tobeUsedChooseModalPeriods = [];
    },
    setInputDetails: (state, action: PayloadAction<TInputDetails>) => {
      state.inputDetails = { ...action.payload };
    },
    setInputError: (state, action: PayloadAction<boolean>) => {
      state.isAddError = action.payload;
    },
    setNewProfileData: (state, action: PayloadAction<TNewProfileModalData>) => {
      state.newProfileModalData.push({ ...action.payload, periods: PeriodInitialData, no_periods: 12 });
    },
    updateNewProfileData: (state, action: PayloadAction<TNewProfileModalData[]>) => {
      state.newProfileModalData = action.payload;
    },
    resetNewProfileSlice: (state) => {
      state.newProfileModalData = [];
    },
    setProfileSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.profileSelectedRow = action.payload;
    },
    setPeriodeSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.periodSelectedRow = action.payload;
    },
    setFinalProfileList: (state, action: PayloadAction<TNewProfileModalData[]>) => {
      state.finalProfileList = action.payload;
    },
    setProfileModalPeriod: (state, action: PayloadAction<TGeneralLedgerProfileModalPeriod[]>) => {
      state.profileModalPeriod = action.payload;
    },
    updateProfileModelData: (state, action: PayloadAction<TNewProfileModalData>) => {
      if (
        action.payload.model_id === 0 ||
        state.newProfileModalData.some((data) => data.model_id === action.payload.model_id)
      ) {
        const newArr = [...state.newProfileModalData].filter((data) => data.model_des !== action.payload.model_des);
        state.newProfileModalData = [...newArr, action.payload];
      } else {
        const filtered = [...state.profileModalData].filter((data) => data.model_des !== action.payload.model_des);
        state.profileModalData = [...filtered, action.payload];
      }

      state.profileSelectedRow = { ...action.payload };
      state.profileModalPeriod = action.payload.periods || [];
    },
    replaceProfileModelData: (state, action) => {
      state.profileModalData = action.payload;
    },
    setProfileTableData: (state, action) => {
      state.tableProfileData = action.payload;
    },
    setProfileDataExist: (state, action: PayloadAction<boolean>) => {
      state.isProfileDataExist = action.payload;
    },
    setInputStatus: (state, action: PayloadAction<boolean>) => {
      state.inputStatus = action.payload;
    },
    resetInput: (state) => {
      state.resetInput = 0.0;
    },
    resetPMSlice: (state) => {
      state.isProfileDataExist = false;
      state.profileModalData = [];
      state.newProfileModalData = [];
      state.profileModalPeriod = PeriodInitialData;
    }
  }
});

export const { actions: profileModalActions, reducer } = slice;
export default reducer;
