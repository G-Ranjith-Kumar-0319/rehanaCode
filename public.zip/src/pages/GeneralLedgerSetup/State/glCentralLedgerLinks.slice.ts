import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";

type TinitialState = {};

const initialState: TinitialState = {};

const slice = createSlice({
  initialState,
  name: "glCentralLedgerLinks",
  extraReducers: (builder) => {},
  reducers: {}
});

export const { actions: centralLinksAction, reducer } = slice;
export default reducer;
