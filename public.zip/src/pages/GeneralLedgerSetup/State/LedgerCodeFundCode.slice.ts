import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { client, apiRoot } from "@/config";
import { STATUS } from "@/types/UseStateType";
import ledgerCodeFundCodecolumnDef from "../LedgerCodes/Modals/columnDef";

export type TFundCodes = {
  ledgerCodeFundCodes: { [key: string]: any }[];
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;
};
type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type fundCodesState = {
  ledgerCodeFundCodes: { [key: string]: any }[];
  selectedLedgerFundCode?: { [key: string]: any };
  error?: string;
  status?: STATUS;
  filters?: TFilters;
  columnDef: TColumnDef;
};

const initialState: fundCodesState = {
  columnDef: ledgerCodeFundCodecolumnDef,
  ledgerCodeFundCodes: [],
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined
  }
};

/** Thunks for get the ledger Code fund code */
export const getLedgerCodeFundCodes = createAsyncThunk(
  "fundCodes/getLedgerCodeFundCodes",
  async ({ status, callback }: { status: number; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/gl-ledger-code/fund`, {
      params: { status }
    });
    if (response.data && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

const slice = createSlice({
  extraReducers: (builder) => {
    builder
      .addCase(getLedgerCodeFundCodes.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getLedgerCodeFundCodes.fulfilled, (state, action: PayloadAction<any>) => {
        state.ledgerCodeFundCodes = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getLedgerCodeFundCodes.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload.error.message;
      });
  },
  initialState,
  name: "ledgerCodeFundCode",
  reducers: {
    resetToInitial: (state) => {
      state.ledgerCodeFundCodes = [];
    },
    selectRow: (state, action: PayloadAction<any>) => {
      state.selectedLedgerFundCode = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (ledgerCodeFundCodecolumnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    },
    reset: (state) => {
      state.ledgerCodeFundCodes = initialState.ledgerCodeFundCodes;
      state.filters = initialState.filters;
      state.selectedLedgerFundCode = initialState.selectedLedgerFundCode;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
