import { actions } from "@/pages/Invoice/State/InvoicePostingPeriod.slice";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";
import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { setToSession } from "@/utils/getDataSource";
import { deepEqual } from "assert";

export type TLedgerGroupData = {
  id: number;
  description: string;
  system?: string;
  deletable?: string;
};

type TNewLedgerGroupData = {
  id: number;
  description: string;
};

type LadgerGrpFrmData = {
  isFormDirty: boolean;
  inputText: string;
  id: number;
};

type LedgerGroupsListingType = {
  selectedRow?: { [key: string]: any };
  status?: STATUS;
  ledgerGroupsList: TLedgerGroupData[];
  upDatedList: TLedgerGroupData[];
  newGrpsList: TNewLedgerGroupData[];
  isFormActive: boolean;
  ladgerGrpData: LadgerGrpFrmData;
  isBtnClick: boolean;
  newCreatedEditItem?: TLedgerGroupData;
  deletedIds: Number[];
  finalSortedList: TLedgerGroupData[];
  isError: boolean;
  isCancelClicked: boolean;
};

const initialState: LedgerGroupsListingType = {
  isCancelClicked: false,
  ledgerGroupsList: [],
  newGrpsList: [],
  upDatedList: [],
  deletedIds: [],
  isFormActive: false,
  ladgerGrpData: {
    id: 0,
    isFormDirty: false,
    inputText: ""
  },
  isBtnClick: false,
  finalSortedList: [],
  isError: false
};

// Ledger Group Get Thunk

export const getLedgerGroupsList = createAsyncThunk("ledgerGroup/list", async () => {
  const response = await client.get(`${apiRoot}/gl-setup/gl-ledger-group`);

  return response.data;
});

// Post Thunk

export const postLedgerData = createAsyncThunk("ledgerGroup/post", async (data, thunkAPI) => {
  const { getState, dispatch } = thunkAPI;
  const state: any = getState();
  const newGrpsList = state?.ledgerGroupsList?.newGrpsList;
  const deletedIds = state.ledgerGroupsList?.deletedIds;
  const postObj = {
    upsertLedgerGroup: newGrpsList?.length === 0 ? null : newGrpsList,
    deleteLedgerGroup: deletedIds?.length === 0 ? null : deletedIds
  };
  try {
    const response = await client.post(`${apiRoot}/gl-setup/gl-ledger-group`, postObj);
    dispatch(ledgerGrpAction.clearDeletedIds());
  } catch (e) {
    console.log(e);
  }
});

const slice = createSlice({
  initialState,
  name: "ledgerGroupsList",
  extraReducers: (builder) => {
    builder
      .addCase(postLedgerData.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(postLedgerData.fulfilled, (state) => {
        state.status = STATUS.SUCCESS;
        state.newGrpsList = [];
        state.deletedIds = [];
      })
      .addCase(postLedgerData.rejected, (state) => {
        state.status = STATUS.FAILED;
      });

    builder
      .addCase(getLedgerGroupsList.pending, (state, action) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getLedgerGroupsList.fulfilled, (state, actions: PayloadAction<any>) => {
        state.ledgerGroupsList = actions.payload.sort((a: any, b: any) => a.description.localeCompare(b.description));
        state.status = STATUS.SUCCESS;
      })
      .addCase(getLedgerGroupsList.rejected, (state, actions) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    },
    addNewGrpsList: (state, action: PayloadAction<TLedgerGroupData>) => {
      if (action.payload.id !== 0) {
        const newArr = [...state.newGrpsList];
        const newList = newArr.filter((data) => data.id !== action.payload.id);
        state.newGrpsList = [...newList, { ...action.payload }];
      } else {
        state.newGrpsList?.push({ ...action.payload });
      }
    },
    setDeletedIds: (state, action) => {
      state.deletedIds = action?.payload?.id !== 0 ? [...state.deletedIds, action.payload.id] : state.deletedIds;
    },
    updateLedgerGroupList: (state, actions: PayloadAction<any>) => {
      state.ledgerGroupsList = actions.payload;
    },
    emptyNewList: (state) => {
      state.newGrpsList = [];
    },
    setLadgerGrpData: (state, action: PayloadAction<LadgerGrpFrmData>) => {
      state.ladgerGrpData = { ...action.payload };
    },
    setIsBtnClick: (state, action: PayloadAction<boolean>) => {
      setToSession("setisBtn", action.payload);
      state.isBtnClick = action.payload;
    },
    setNewCreatedEditItem: (state, action: PayloadAction<TLedgerGroupData>) => {
      state.newCreatedEditItem = action.payload;
    },
    changeNewGrpList(state, action: PayloadAction<TLedgerGroupData>) {
      const newArr = state.newGrpsList.filter((data) => data.description !== action.payload.description);
      state.newGrpsList = [...newArr];
      state.newCreatedEditItem = undefined;
    },
    resetSlice(state) {
      state.newCreatedEditItem = undefined;
      state.newGrpsList = [];
      state.deletedIds = [];
    },
    setFinalSortedList: (state, action: PayloadAction<any>) => {
      state.finalSortedList = action.payload;
    },
    filternewGrpsList: (state, action) => {
      state.newGrpsList = action.payload;
    },
    clearDeletedIds: (state) => {
      state.deletedIds = [];
    },
    setFormError: (state, action: PayloadAction<boolean>) => {
      state.isError = action.payload;
    },
    setCancelBtnClick: (state, action: PayloadAction<boolean>) => {
      state.isCancelClicked = action.payload;
    }
  }
});

export const { actions: ledgerGrpAction, reducer } = slice;
export default reducer;
