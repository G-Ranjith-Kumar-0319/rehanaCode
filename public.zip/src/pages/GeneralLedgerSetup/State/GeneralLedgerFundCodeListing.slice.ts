import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import { apiRoot, client } from "../../../config";

type GeneralLedgerFundCodeType = {
  fundCodeList: { [key: string]: any }[];
  newFundList: { [key: string]: any }[];
  finalFundCodeList?: { [key: string]: any }[];
  selectedRow?: { [key: string]: any };
  error: any;
  cancelError: string;
  status: any;
  funcCodeValidStatus: any;
  funcDescValidStatus: any;
  fundCodeDirty?: boolean;
  previousYear: string | number | undefined;
  nextYear: string | number | undefined;
  previousState: string | number | undefined;
  isCancelClickedFundCode: boolean;
};

const initialState: GeneralLedgerFundCodeType = {
  fundCodeList: [],
  newFundList: [],
  finalFundCodeList: [],
  error: "",
  cancelError: "",
  status: STATUS,
  funcCodeValidStatus: STATUS,
  funcDescValidStatus: STATUS,
  fundCodeDirty: false,
  previousYear: undefined,
  nextYear: undefined,
  previousState: undefined,
  isCancelClickedFundCode: false
};

export const getFundCodeListingData = createAsyncThunk(
  "bankReconciliation/Status",
  async ({ callback }: { callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode`);
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getGeneralLedgerFundCodeNext = createAsyncThunk(
  "generalLedgerSetup/next-fund-code",
  async ({ callback }: any) => {
    const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-next`);
    if (callback) {
      callback(response.data); // Invoke the callback with the response data
    }
    return response.data;
  }
);

export const getPreviousYear = createAsyncThunk("generalLedgerSetup/getPreviousYear", async () => {
  const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-prev-year?yearId=${getCurrentFinancialYear()}`);
  return response.data; // Invoke the callback with the response data
});

export const getNextYear = createAsyncThunk("generalLedgerSetup/getNextYear", async () => {
  const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-next-year?yearId=${getCurrentFinancialYear()}`);
  return response.data;
});

export const getPrevState = createAsyncThunk("generalLedgerSetup/getPrevState", async () => {
  const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-prev-state?yearId=${getCurrentFinancialYear()}`);
  return response.data;
});

export const getGeneralLedgerExcludeFundCFR = createAsyncThunk(
  "generalLedgerSetup/exclude-fund-cfr",
  async ({ fundId, callback }: any) => {
    const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-cfr-mapping`, {
      params: {
        fundId
      }
    });
    if (callback) {
      callback(response.data); // Invoke the callback with the response data
    }
    return response.data;
  }
);

export const getGeneralLedgerExcludeFundCFRVisibility = createAsyncThunk(
  "generalLedgerSetup/gl-setup/gl-fundcode-check-cfr",
  async ({ callback }: any) => {
    const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-check-cfr`, {
      params: {
        yearId: getCurrentFinancialYear()
      }
    });
    if (callback) {
      callback(response.data); // Invoke the callback with the response data
    }
    return response.data;
  }
);

export const getGeneralLedgerFundDataBrowse = createAsyncThunk(
  "generalLedgerSetup/get-fund-data-id",
  async ({ fundId, callback }: any) => {
    const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-browse`, {
      params: {
        fundId
      }
    });
    if (callback) {
      callback(response.data); // Invoke the callback with the response data
    }
    return response.data;
  }
);

export const getGeneralLedgerValidateFundDesc = createAsyncThunk(
  "generalLedgerSetup/gl-fundcode-check-funddesc-exist",
  async ({ yearId, fundDesc, linkValue, callback }: any) => {
    const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-check-funddesc-exist`, {
      params: {
        yearId,
        fundDesc,
        linkValue
      }
    });
    if (callback) {
      callback(response.data); // Invoke the callback with the response data
    }
    return response.data;
  }
);

export const getGeneralLedgerValidateFundCode = createAsyncThunk(
  "generalLedgerSetup/gl-fundcode-check-ledgercode-exist",
  async ({ yearId, ledgerCode, linkValue, callback }: any) => {
    const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-check-ledgercode-exist`, {
      params: {
        yearId,
        ledgerCode,
        linkValue
      }
    });
    if (callback) {
      callback(response.data); // Invoke the callback with the response data
    }
    return response.data;
  }
);

export const generalLedgerFundCodeAddEdit = createAsyncThunk(
  "generalLedgerSetup/fund-code-add-edit",
  async ({ callback }: { callback?: (data: any) => void }, thunkAPI) => {
    const { getState } = thunkAPI;
    const state: any = getState();
    const newFundList = state?.generalLedgerFundCode?.newFundList;
    if (newFundList === undefined || newFundList?.length === 0) {
      return false;
    }
    const lastUpdatedValues = newFundList.reduce((acc: any[], current: any) => {
      const existing = acc.find((item) => item.fund_code === current.fund_code);
      if (!existing) {
        acc.push(current);
      } else {
        acc[acc.indexOf(existing)] = current;
      }
      return acc;
    }, []);
    const request = {
      lstFundCodes: lastUpdatedValues?.length === 0 ? [] : lastUpdatedValues,
      deletedFundIds: [],
      year_id: getCurrentFinancialYear()
    };
    const res = await client.post(`${apiRoot}/gl-setup/gl-fundcode`, request);

    if (callback) {
      callback(res.data); // Invoke the callback with the response data
    }

    return res.data;
  }
);

const slice = createSlice({
  extraReducers: (builder) => {
    builder
      .addCase(getFundCodeListingData.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getFundCodeListingData.fulfilled, (state, action: PayloadAction<any>) => {
        state.fundCodeList = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getFundCodeListingData.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(generalLedgerFundCodeAddEdit.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(generalLedgerFundCodeAddEdit.fulfilled, (state) => {
        state.status = STATUS.SUCCESS;
        state.newFundList = [];
      })
      .addCase(generalLedgerFundCodeAddEdit.rejected, (state) => {
        state.status = STATUS.FAILED;
      })
      .addCase(getPreviousYear.fulfilled, (state, action: PayloadAction<any>) => {
        state.previousYear = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getNextYear.fulfilled, (state, action: PayloadAction<any>) => {
        state.nextYear = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getPrevState.fulfilled, (state, action: PayloadAction<any>) => {
        state.previousState = action.payload;
        state.status = STATUS.SUCCESS;
      });
    builder
      .addCase(getGeneralLedgerValidateFundDesc.pending, (state) => {
        state.funcDescValidStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getGeneralLedgerValidateFundDesc.fulfilled, (state) => {
        state.funcDescValidStatus = STATUS.SUCCESS;
      })
      .addCase(getGeneralLedgerValidateFundDesc.rejected, (state) => {
        state.funcDescValidStatus = STATUS.FAILED;
      });
  },
  initialState,
  name: "fundCodeList",
  reducers: {
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    },
    addNewFundList: (state, action: PayloadAction<any>) => {
      state.newFundList?.push({
        fund_id: action.payload.fund_id || 0,
        fund_code: String(action.payload.fund_code),
        ledger_code: action.payload.ledger_code,
        ledger_des: action.payload.ledger_des,
        mffund: action.payload.mffund,
        ledgers_attached: null,
        private_fund: "F",
        cfr_excluded: action.payload.cfr_excluded
      });
    },
    setFuncCodeDirtyData: (state, action: PayloadAction<any>) => {
      state.fundCodeDirty = action.payload;
    },
    updateFundList: (state, action: PayloadAction<any>) => {
      const updatedList = state.newFundList.map((item) => {
        if (item.fund_code === action.payload.fund_code) {
          return { ...item, ...action.payload };
        }
        return item;
      });
      state.newFundList = updatedList;
    },
    emptyNewFundList: (state) => {
      state.newFundList = [];
    },
    resetList: (state) => {
      state.newFundList = [];
      state.selectedRow = undefined;
      state.finalFundCodeList = [];
    },
    setFinalFundCodeList: (state, action: PayloadAction<any>) => {
      state.finalFundCodeList = action.payload;
    },
    updateFinalFundCodeList: (state, action: PayloadAction<any>) => {
      state.finalFundCodeList = action.payload;
    },
    setCancelBtnClickFundCode: (state, action: PayloadAction<boolean>) => {
      state.isCancelClickedFundCode = action.payload;
    }
  }
});

export const { actions: generalLedgerFuncCodeAction, reducer } = slice;
export default reducer;
