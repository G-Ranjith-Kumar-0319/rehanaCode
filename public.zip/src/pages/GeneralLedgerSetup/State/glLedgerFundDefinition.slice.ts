import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";
import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import { sortDataAll } from "@/utils/getDataSource";
import LedgerFundModalDef from "../LedgerCodes/AddLedgerChooseFundDefinition/LedgerFundDef";

type TLedgerCodeData = {
  fundDefinitionList: any[];
  linkedFundList: any[];
  otherFundList: any[];
  callLedgerCodesApi: boolean;
  isOtherLinkFund: boolean;
  stepFormData?: {};
  error: any;
  status: any;
  statusRemove: any;
  filters?: TFilters;
  otherFundSelectedRow?: { [key: string]: any };
  linkFundSelectedRow?: { [key: string]: any };
  columnDef: TColumnDef;
};

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

const initialState: TLedgerCodeData = {
  columnDef: LedgerFundModalDef,
  fundDefinitionList: [],
  linkedFundList: [],
  otherFundList: [],
  callLedgerCodesApi: true,
  isOtherLinkFund: false,
  status: STATUS,
  statusRemove: STATUS,
  error: "",
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: undefined
  }
};

export const getFundDefinitionListingData = createAsyncThunk(
  "LedgerCode/getFundDefinitionListingData",
  async ({ leddefId, callback }: { leddefId: any; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/gl-ledger-code/choose-funds`, {
      params: {
        leddefId
      }
    });

    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getValidateBeforeRemoveLinkData = createAsyncThunk(
  "LedgerCode/getValidateBeforeRemoveLinkData",
  async ({ fundId, leddefId, callback }: { fundId: number; leddefId: any; callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/gl-ledger-code/budget-count`, {
      params: {
        fundId,
        leddefId
      }
    });

    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

const slice = createSlice({
  initialState,
  name: "glLedgerFundDefList",
  extraReducers: (builder) => {
    builder
      .addCase(getFundDefinitionListingData.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getFundDefinitionListingData.fulfilled, (state, action: PayloadAction<any>) => {
        state.fundDefinitionList = action.payload;
        state.isOtherLinkFund = true;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getFundDefinitionListingData.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getValidateBeforeRemoveLinkData.pending, (state) => {
        state.statusRemove = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getValidateBeforeRemoveLinkData.fulfilled, (state, action: PayloadAction<any>) => {
        state.statusRemove = STATUS.SUCCESS;
      })
      .addCase(getValidateBeforeRemoveLinkData.rejected, (state) => {
        state.statusRemove = STATUS.FAILED;
      });
  },
  reducers: {
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    setLinkedFundList: (state, action: PayloadAction<any>) => {
      const updatedPayload = action.payload.map((item: any) => ({
        ...item,
        ledger_des: item.fund_des ? item.fund_des : item.ledger_des
      }));

      state.linkedFundList = sortDataAll(updatedPayload, state?.filters?.sequenceValue || "");
    },
    setOtherFundList: (state, action: PayloadAction<any>) => {
      const updatedPayload = action.payload.map((item: any) => ({
        ...item,
        fund_des: item.ledger_des ? item.ledger_des : item.fund_des
      }));
      state.otherFundList = sortDataAll(updatedPayload, state?.filters?.sequenceValue || "");
    },
    setOtherFundSelectedRow: (state, action: PayloadAction<any>) => {
      state.otherFundSelectedRow = action.payload;
    },
    setLinkFundSelectedRow: (state, action: PayloadAction<any>) => {
      state.linkFundSelectedRow = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setIsOtherLinkFund: (state, action: PayloadAction<boolean>) => {
      state.isOtherLinkFund = action.payload;
    },
    resetSelectedRows: (state) => {
      state.otherFundSelectedRow = undefined;
      state.linkFundSelectedRow = undefined;
    },
    resetFundData: (state) => {
      state.fundDefinitionList = [];
      state.linkedFundList = [];
      state.otherFundList = [];
      state.isOtherLinkFund = false;
    }
  }
});

export const { actions: ledgerFundDefinitionAction, reducer } = slice;
export default reducer;
