import { getCurrentFinancialYear, STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";
import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { getFinancialYear } from "@/store/state/financialYear.slice";

/* eslint-disable camelcase */
type StepFormData = {
  ledgerGrpSelected?: TLedgerGrp;
  selectedLedgerCodeType?: TLedgerCodeType;
};

export type TLedgerGrp = {
  group_des: string;
  group_id: number;
};
export type TLedgerCodeType = {
  code: string;
  description: string;
};

type TLedgerCodeData = {
  ledgerCodesList: any[];
  callLedgerCodesApi: boolean;
  callLedgergrpApi: boolean;
  stepFormData: StepFormData;
  status?: STATUS;
  ledgerGrpList: TLedgerGrp[];
  error: string | undefined;
  wizardList: any[];
  isWizardLoaded: boolean;
  selectedWizardDropDown: any;
  CCCodeExist: any;
  CCDodeExist: any;
  isEarningChecks: any;
  isLowestUnfinalizedYr: any;
  isLedgerDescExist: any;
  financialYearData: any;
  isWarnBudgetCheck: any;
};

const initialState: TLedgerCodeData = {
  ledgerCodesList: [],
  callLedgerCodesApi: true,
  callLedgergrpApi: true,
  ledgerGrpList: [],
  stepFormData: {},
  error: "",

  //  Wizard Step 1 initial states-------Start
  wizardList: [],
  isWizardLoaded: false,
  selectedWizardDropDown: undefined,
  CCCodeExist: undefined,
  CCDodeExist: undefined,
  isEarningChecks: undefined,
  isLowestUnfinalizedYr: undefined,
  isLedgerDescExist: undefined,
  financialYearData: undefined,
  isWarnBudgetCheck: undefined
};
//  Wizard Step 1 initial states-------End

// This function is for Ledger Cost Listing
export const getLedgerCodeList = createAsyncThunk(
  "glLedgerCost/listAll",
  async ({ callback }: { callback?: (data: any) => void }) => {
    const response = await client.post(`${apiRoot}/gl-ledger-code/filter-by-all`, {});
    if (callback) callback(response.data);
    return response.data;
  }
);

// Thunk to fetch ledger groups start here
export const getLedgerGroupsList = createAsyncThunk("ledgerGrp/list", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/ledger-group`);

  return response.data;
});
// Thunk to fetch ledger groups end here

// Ledger code denifination wazard Step 1------ Start
export const getWizardDropDown = createAsyncThunk("ledgerCodes/getWizardDropDown", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/ledger-type`);

  return response.data;
});

// DropDown validatation requests
export const creditorExist = createAsyncThunk("ledgerCodes/creditorExist", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/creditor-exist`);

  return response.data;
});
export const debtorExist = createAsyncThunk("ledgerCodes/debtorExist", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/debtor-exist`);
  return response.data;
});
export const lowestUnfinalizedYear = createAsyncThunk("ledgerCodes/lowestUnfinalizedYear", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/lowest-unfinalized-yr`);
  return response.data;
});
export const earningChecks = createAsyncThunk("ledgerCodes/earningChecks", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/earnings-checks`);
  return response.data;
});
export const ledgerDescExist = createAsyncThunk("ledgerCodes/ledgerDescExist", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/ledger-desc-exist`);
  return response.data;
});

export const getfinancialYearData = createAsyncThunk("ledgerCodes/getfinancialYearData", async () => {
  const response = await client.get(`${apiRoot}/common/financial-year?yearId=${getCurrentFinancialYear()}`);
  return response.data;
});
export const warnBudgetCheck = createAsyncThunk("ledgerCodes/warnBudgetCheck", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/budget-check`);
  return response.data;
});

// Ledger code denifination wazard Step 1------ End

const slice = createSlice({
  initialState,
  name: "glLedgerCodes",
  extraReducers: (builder) => {
    builder
      // Start of Listing Reducer
      .addCase(getLedgerCodeList.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getLedgerCodeList.fulfilled, (state, action: PayloadAction<any>) => {
        state.ledgerCodesList = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getLedgerCodeList.rejected, (state) => {
        state.status = STATUS.FAILED;
      })
      // End of Listing Reducer

      // Start of Ledger Group Reducer
      .addCase(getLedgerGroupsList.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getLedgerGroupsList.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.ledgerGrpList = action.payload;
        state.callLedgergrpApi = false;
      })
      .addCase(getLedgerGroupsList.rejected, (state) => {
        state.status = STATUS.FAILED;
      })
      // End of Ledger Group Reducer

      // Builder for wizard dropdown step 1 -----Start
      .addCase(getWizardDropDown.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getWizardDropDown.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.wizardList = action.payload;
        state.isWizardLoaded = true;
      })
      .addCase(getWizardDropDown.rejected, (state) => {
        state.status = STATUS.FAILED;
      })
      .addCase(creditorExist.fulfilled, (state, action) => {
        state.CCCodeExist = action.payload;
      })
      .addCase(debtorExist.fulfilled, (state, action) => {
        state.CCDodeExist = action.payload;
      })
      .addCase(lowestUnfinalizedYear.fulfilled, (state, action) => {
        state.isLowestUnfinalizedYr = action.payload;
      })
      .addCase(earningChecks.fulfilled, (state, action) => {
        state.isEarningChecks = action.payload;
      })
      .addCase(ledgerDescExist.fulfilled, (state, action) => {
        state.isLedgerDescExist = action.payload;
      })
      .addCase(getfinancialYearData.fulfilled, (state, action) => {
        state.financialYearData = action.payload;
      })
      .addCase(warnBudgetCheck.fulfilled, (state, action) => {
        state.isWarnBudgetCheck = action.payload;
      });
    // Builder for wizard dropdown step 1 --------End
  },
  reducers: {
    setStepFromData: (state, action: PayloadAction<TLedgerGrp>) => {
      state.stepFormData = { ...state.stepFormData, ledgerGrpSelected: action.payload };
    },

    // Wizard Step 1 setStates------------Start
    setSelectedWizardList: (state, action) => {
      state.wizardList = [...action.payload];
    },
    setSelectedWizardDropDown: (state, action: PayloadAction<any>) => {
      state.stepFormData = { ...state.stepFormData, selectedLedgerCodeType: action.payload };
    },
    // Wizard Step 1 setStates------------End

    // Common set State----
    resetForm: (state) => {
      state.stepFormData = {};
      state.selectedWizardDropDown = undefined;
    }
  }
});

export const { actions: ledgerCodesAction, reducer } = slice;
export default reducer;
