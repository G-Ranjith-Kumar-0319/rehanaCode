import { getCurrentFinancialYear, STATUS } from "@/types/UseStateType";
import { apiRoot, client, log } from "@/config";
import { createAsyncThunk, createSlice, current, PayloadAction } from "@reduxjs/toolkit";
import { getFinancialYear } from "@/store/state/financialYear.slice";
import { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import ledgerCodesColumnDef from "../LedgerCodes/Grid/columnDef";
import useSortedData from "../hooks/useSortedData";
import sortData from "../utils";
/* eslint-disable camelcase */

type TFundCode = {
  fund_id: number;
  fund_code: string;
  fund_des: string;
  cfr_code: string;
};

type TVatDetails = {
  vat_id?: number;
  vat_code?: string;
  rate?: string;
  vat_consolidation_code?: string;
  in_use?: string;
  out_of_scope?: string;
  recoverable?: string;
  // allow_vat_ledger: boolean;
};

type TBankDetails = {
  bank_account_name: string;
  bank_account: string;
  bank_sort_code: string;
  bacs_user_number: string;
  bacs_account_code: string;
  bacs_exclude_header_trailer: string;
  bacs_bureau_number: string;
  user_defined_extension: boolean;
  bacs_file_extension: string;
  bacs_file_type_id: number;
};

type TCardItemDetails = {
  id: number;
  number: number;
  name: string;
  doe: string;
  active: string;
};

type TNormalVat = {
  normal_vat_id: number | null;
  normal_vat_code: string | null;
  normal_vat_desc: string | null;
};

export type TledgeCodeDetails = {
  leddef_id: number;
  ledger_code: string;
  isUpdated?: boolean;
  group_id: number;
  group_des: string;
  ledger_short: string;
  model_id: number | null;
  model_des: string | null;
  ledger_des: string;
  ledger_type: string;
  ledger_type_des?: string;
  services: string;
  leddef_hidden: string;
  funds: TFundCode[] | null;
  normal_vat: TNormalVat | null;
  vat: TVatDetails | null;
  bank: TBankDetails | null;
  cardsDetail: {
    cards: TCardItemDetails[];
    deleteCardIds: number[];
  } | null;
};

type TLedgerCodePayload = {
  ledger: TledgeCodeDetails[];
  deleteIds: number[] | null;
};

type StepFormData = {
  ledgerGrpSelected?: TLedgerGrp;
  selectedLedgerCodeType?: TLedgerCodeType;
};

export type TLedgerGrp = {
  group_des: string;
  group_id: number;
};
export type TLedgerCodeType = {
  code: string;
  description: string;
  value: String;
};

type TFilters = {
  lookingFor?: string;
  sequenceValue?: string;
  sequenceIndex?: string;
};

type TLedgerCodeData = {
  ledgerCodesList: TledgeCodeDetails[];
  normalProfileList: any[];
  callLedgerCodesApi: boolean;
  callLedgergrpApi: boolean;
  stepFormData: StepFormData;
  status?: STATUS;
  ledgerGrpList: TLedgerGrp[];
  error: string | undefined;
  wizardList: any[];
  isWizardLoaded: boolean;
  isNewLedgerSubmitting?: boolean;
  selectedWizardDropDown: any;
  CCCodeExist: any;
  CCDodeExist: any;
  isEarningChecks: any;
  isLowestUnfinalizedYr: any;
  isLedgerDescExist: any;
  financialYearData: any;
  isWarnBudgetCheck: any;
  filters?: TFilters;
  tempEditDetail?: TledgeCodeDetails | null;
  columnDef: TColumnDef;
  selectedRowGlCodes?: TledgeCodeDetails;
  ledgerCodePayload: TLedgerCodePayload;
  ledgerCodeForm: {
    formData: TledgeCodeDetails;
    isFormDirty: boolean;
  };
  newLedgerCodesList: TledgeCodeDetails[];
  deleteLCIds: number[];
  deleteCardIds: number[];
  newLedgerErrorState?: { [key: string]: any };
  isCodeExist?: undefined | string;
  isDescExist?: undefined | string;
  errorState: any;
  isFormSubmitting?: boolean;
  tableLedgerCodeList: any;
  vatCodeList: VatCodeList[];
  callVatCodeApi: boolean;
};

type VatCodeList = {
  vat_id: number;
  year_id: number;
  vat_code: string;
  leddef_id: number;
  rate: number;
  in_use: "T" | "F";
  out_of_scope: "T" | "F";
  recoverable: "T" | "F";
  next_year_vat_id: null;
  previous_year_vat_id: null;
  vat_consolidation_code: string;
};

const initialFormState = {
  leddef_id: 0,
  ledger_code: "", // 4 Screen
  group_id: 0, // 2nd Screen
  group_des: "", // 2nd Screen
  ledger_short: "",
  model_id: null,
  model_des: null,
  ledger_des: "", // 4th Screen
  ledger_type: "", // 1st Screen
  ledger_type_des: "", // 1st Screen
  services: "F",
  leddef_hidden: "F",
  funds: null, // 3rd Screen
  normal_vat: null,
  vat: null,
  bank: null,
  cardsDetail: null
};

const initialState: TLedgerCodeData = {
  ledgerCodesList: [],
  normalProfileList: [],
  tableLedgerCodeList: [],
  callLedgerCodesApi: true,
  callLedgergrpApi: true,
  isNewLedgerSubmitting: false,
  ledgerGrpList: [],
  stepFormData: {},
  isFormSubmitting: false,
  tempEditDetail: null,
  error: "",
  columnDef: ledgerCodesColumnDef,
  filters: {
    lookingFor: "",
    sequenceIndex: "0",
    sequenceValue: "ledger_code"
  },
  newLedgerErrorState: {
    ledger_code: undefined,
    ledger_des: undefined
  },
  isCodeExist: undefined,
  isDescExist: undefined,
  //  Wizard Step 1 initial states-------Start
  wizardList: [],
  isWizardLoaded: false,
  selectedWizardDropDown: undefined,
  CCCodeExist: undefined,
  CCDodeExist: undefined,
  isEarningChecks: undefined,
  isLowestUnfinalizedYr: undefined,
  isLedgerDescExist: undefined,
  financialYearData: undefined,
  isWarnBudgetCheck: undefined,
  errorState: {
    ledger_des: false
  },

  ledgerCodePayload: {
    ledger: [],
    deleteIds: []
  },
  ledgerCodeForm: {
    formData: initialFormState,
    isFormDirty: false
  },
  newLedgerCodesList: [],
  deleteLCIds: [],
  deleteCardIds: [],
  vatCodeList: [],
  callVatCodeApi: true
};
//  Wizard Step 1 initial states-------End

// This function is for Ledger Cost Listing
export const getLedgerCodeList = createAsyncThunk(
  "glLedgerCost/listAll",
  async ({ sequence, callback }: { sequence: any; callback?: (data: any) => void }) => {
    const response = await client.post(`${apiRoot}/gl-ledger-code/filter-by-all`, {
      sequence
    });
    if (callback) callback(response.data);
    return response.data;
  }
);

// Thunk to fetch ledger groups start here
export const getLedgerGroupsList = createAsyncThunk("ledgerGrp/list", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/ledger-group`);

  return response.data;
});
// Thunk to fetch ledger groups end here

// Thunk to fetch normal profile start here
export const getNormalProfileList = createAsyncThunk("normalProfile/list", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/profile-model-browse`);

  return response.data;
});

// Ledger code denifination wazard Step 1------ Start
export const getWizardDropDown = createAsyncThunk("ledgerCodes/getWizardDropDown", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/ledger-type`);

  return response.data;
});

// Validate ledger code year for screen 4
export const validateNewLedgerCodeYear = createAsyncThunk(
  "ledgerCode/validateNewLedgerCodeYear",
  async ({ linkValue, ledgerCode, yearId }: any) => {
    const response = await client.get(`${apiRoot}/gl-ledger-code/ledger-code-exist`, {
      params: {
        linkValue,
        ledgerCode,
        yearId
      }
    });
    return response.data;
  }
);
//-----

// Validate desc year for screen 4
export const validatenewLedgerDescYear = createAsyncThunk(
  "ledgerCode/validatenewLedgerDescYear",
  async ({ linkValue, ledgerDesc, yearId }: any) => {
    const response = await client.get(`${apiRoot}/gl-ledger-code/ledger-desc-exist`, {
      params: {
        linkValue,
        ledgerDesc,
        yearId
      }
    });
    return response.data;
  }
);

// Validate VAT Code year for Next and Previous Year
export const validateGLVatCodeYear = createAsyncThunk(
  "ledgerCode/validateGLVatCodeYear",
  async ({ linkValue, vatCode, yearId }: any) => {
    const response = await client.get(`${apiRoot}/gl-ledger-code/vat-code-exist-year`, {
      params: {
        linkValue,
        vatCode,
        yearId
      }
    });
    return response.data;
  }
);

// Get Current Year VAT Code List
export const getVatCodesList = createAsyncThunk("ledgerCode/getVatCodesList", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/vat-codes`);
  return response.data;
});

// DropDown validatation requests
export const creditorExist = createAsyncThunk("ledgerCodes/creditorExist", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/creditor-exist`);

  return response.data;
});
export const debtorExist = createAsyncThunk("ledgerCodes/debtorExist", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/debtor-exist`);
  return response.data;
});
export const lowestUnfinalizedYear = createAsyncThunk("ledgerCodes/lowestUnfinalizedYear", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/lowest-unfinalized-yr`);
  return response.data;
});
export const earningChecks = createAsyncThunk("ledgerCodes/earningChecks", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/earnings-checks`);
  return response.data;
});
export const ledgerDescExist = createAsyncThunk("ledgerCodes/ledgerDescExist", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/ledger-desc-exist`);
  return response.data;
});

export const getfinancialYearData = createAsyncThunk("ledgerCodes/getfinancialYearData", async () => {
  const response = await client.get(`${apiRoot}/common/financial-year?yearId=${getCurrentFinancialYear()}`);
  return response.data;
});
export const warnBudgetCheck = createAsyncThunk("ledgerCodes/warnBudgetCheck", async () => {
  const response = await client.get(`${apiRoot}/gl-ledger-code/budget-check`);
  return response.data;
});
// Ledger code denifination wazard Step 1------ End

// Ledger Code Post API Start here
export const postLedgerCodes = createAsyncThunk("ledgerCodes/postLedgerCodes", async (data, thunkAPI) => {
  const { getState, dispatch } = thunkAPI;
  const state: any = getState();
  const { newLedgerCodesList } = state.glLedgerCodes;
  const { deleteLCIds } = state.glLedgerCodes;
  const newPayload = {
    ledger: newLedgerCodesList,
    deleteIds: deleteLCIds.length > 0 ? deleteLCIds : null
  } as TLedgerCodePayload;

  try {
    dispatch(ledgerCodesAction.setFromSubmitting(true));
    const response: any = await client.post(`${apiRoot}/gl-ledger-code`, newPayload);
    if (response.data.validationType === 0) {
      dispatch(getLedgerCodeList({ sequence: 0 }));
      dispatch(ledgerCodesAction.resetFilters());
      dispatch(ledgerCodesAction.resetForm());
      dispatch(ledgerCodesAction.resetLedgerCodesState());
    }
    dispatch(ledgerCodesAction.setFromSubmitting(false));
  } catch (error) {
    console.log(error);
  }
});
// Ledger Code Post API End here

// Get ledger codes details start here
export const getLedgerCodeDetails = createAsyncThunk(
  "ledgerCodes/getLedgerCodeDetails",
  async (leddefId: string, thunkAPI) => {
    const { getState, dispatch } = thunkAPI;
    const state = getState();
    if (leddefId) {
      dispatch(ledgerCodesAction.setFromSubmitting(true));
      const response = await client.get(`${apiRoot}/gl-ledger-code/leddef-details?leddefId=${leddefId}`);
      dispatch(ledgerCodesAction.setFromSubmitting(false));
      return response.data;
    }

    return {};
  }
);
// Get ledger codes details End here
// Ledger Code check CFR Valid Start here
export const getCFRValid = createAsyncThunk(
  "ledgerGrp/cfrValid",
  async ({ callback }: { callback?: (data: any) => void }) => {
    const financialYear = getCurrentFinancialYear();
    const response = await client.get(`${apiRoot}/gl-setup/gl-fundcode-check-cfr?yearId=${financialYear}`);
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);
// Ledger Code check CFR Valid Start here

const slice = createSlice({
  initialState,
  name: "glLedgerCodes",
  extraReducers: (builder) => {
    builder
      // Start of Listing Reducer
      .addCase(getLedgerCodeList.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getLedgerCodeList.fulfilled, (state, action: PayloadAction<any>) => {
        state.ledgerCodesList = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getLedgerCodeList.rejected, (state) => {
        state.status = STATUS.FAILED;
      })
      // End of Listing Reducer

      // Start of Normal Profile  Reducer
      .addCase(getNormalProfileList.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getNormalProfileList.fulfilled, (state, action: PayloadAction<any>) => {
        state.normalProfileList = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getNormalProfileList.rejected, (state) => {
        state.status = STATUS.FAILED;
      })
      // End of Listing Reducer

      // Start of Ledger Group Reducer
      .addCase(getLedgerGroupsList.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getLedgerGroupsList.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.ledgerGrpList = action.payload;
        state.callLedgergrpApi = false;
      })
      .addCase(getLedgerGroupsList.rejected, (state) => {
        state.status = STATUS.FAILED;
      })
      // End of Ledger Group Reducer

      // Builder for wizard dropdown step 1 -----Start
      .addCase(getWizardDropDown.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getWizardDropDown.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.wizardList = action.payload;
        state.isWizardLoaded = true;
      })
      .addCase(getWizardDropDown.rejected, (state) => {
        state.status = STATUS.FAILED;
      })
      .addCase(creditorExist.fulfilled, (state, action) => {
        state.CCCodeExist = action.payload;
      })
      .addCase(debtorExist.fulfilled, (state, action) => {
        state.CCDodeExist = action.payload;
      })
      .addCase(lowestUnfinalizedYear.fulfilled, (state, action) => {
        state.isLowestUnfinalizedYr = action.payload;
      })
      .addCase(earningChecks.fulfilled, (state, action) => {
        state.isEarningChecks = action.payload;
      })
      .addCase(ledgerDescExist.fulfilled, (state, action) => {
        state.isLedgerDescExist = action.payload;
      })
      .addCase(getfinancialYearData.fulfilled, (state, action) => {
        state.financialYearData = action.payload;
      })
      .addCase(warnBudgetCheck.fulfilled, (state, action) => {
        state.isWarnBudgetCheck = action.payload;
      });
    // Builder for wizard dropdown step 1 --------End

    // valid New Ledger Code for screen 4
    builder
      .addCase(validateNewLedgerCodeYear.fulfilled, (state, action: PayloadAction<any>) => {
        state.isCodeExist = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(validateNewLedgerCodeYear.pending, (state, action) => {
        state.status = STATUS.LOADING;
      });
    // valid New Ledger description for screen 4
    builder
      .addCase(validatenewLedgerDescYear.fulfilled, (state, action: PayloadAction<any>) => {
        state.isDescExist = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(validatenewLedgerDescYear.pending, (state, action) => {
        // state.status = STATUS.LOADING;
      })
      // Builder for Vat code List of current year
      .addCase(getVatCodesList.pending, (state, action) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getVatCodesList.fulfilled, (state, action: PayloadAction<any>) => {
        state.vatCodeList = action.payload;
        state.callVatCodeApi = false;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getVatCodesList.rejected, (state, action) => {
        state.status = STATUS.FAILED;
      })
      // Builder for Ledger Code details start here
      .addCase(getLedgerCodeDetails.pending, (state, action) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getLedgerCodeDetails.fulfilled, (state, action: PayloadAction<any>) => {
        const newPayload = action.payload;
        state.ledgerCodeForm = { isFormDirty: false, formData: newPayload };
        state.tempEditDetail = newPayload;
        const newLedgerCodesList = [...current(state.ledgerCodesList)].map((item) => {
          if (item.leddef_id === newPayload.leddef_id) {
            return newPayload;
          }
          return item;
        });
        state.ledgerCodesList = [...newLedgerCodesList];
        state.status = STATUS.SUCCESS;
      })
      .addCase(getLedgerCodeDetails.rejected, (state, action) => {
        state.status = STATUS.FAILED;
      })
      // Checking CFR Column Status
      .addCase(getCFRValid.pending, (state, action) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getCFRValid.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
      })
      .addCase(getCFRValid.rejected, (state, action) => {
        state.status = STATUS.FAILED;
      });
    // Builder for Ledger Code details end here
  },
  reducers: {
    setLedgerFormData: (state, action: PayloadAction<TledgeCodeDetails>) => {
      state.ledgerCodeForm = {
        ...state.ledgerCodeForm,
        formData: action.payload
      };
    },
    setStepFromData: (state, action: PayloadAction<TLedgerGrp>) => {
      state.stepFormData = {
        ...state.stepFormData,
        ledgerGrpSelected: action.payload
      };
    },
    // Wizard Step 1 setStates------------Start
    setSelectedWizardList: (state, action) => {
      state.wizardList = [...action.payload];
    },
    setSelectedWizardDropDown: (state, action: PayloadAction<any>) => {
      state.stepFormData = {
        ...state.stepFormData,
        selectedLedgerCodeType: action.payload
      };
    },
    // Wizard Step 1 setStates------------End

    // Common set State----
    resetForm: (state) => {
      state.stepFormData = {};
      state.selectedWizardDropDown = undefined;
      state.ledgerCodeForm = { formData: initialFormState, isFormDirty: false };
    },
    updateErrorState: (state, action) => {
      state.errorState = action.payload;
    },
    resetLedgerCodesState: (state) => {
      state.stepFormData = {};
      state.selectedWizardDropDown = undefined;
      state.ledgerCodeForm = { formData: initialFormState, isFormDirty: false };
      state.newLedgerCodesList = [];
      state.deleteLCIds = [];
      state.deleteCardIds = [];
      state.tableLedgerCodeList = [];
      state.isFormSubmitting = false;
    },
    setFromSubmitting: (state, action: PayloadAction<boolean>) => {
      state.isFormSubmitting = action.payload;
    },
    // setLedgerCode
    // Add new Ledger Code
    setNewLCData: (state, action: PayloadAction<TledgeCodeDetails>) => {
      const newData = action.payload;
      const oldLedgerList = [...current(state.newLedgerCodesList)];
      const oldExistingLedgerList = [...current(state.ledgerCodesList)];

      // Here first it will check if the new data is new or existing
      if (newData.leddef_id === 0) {
        // if new
        // Check if the new data is already in the list of newly added array
        const eleIndex = oldLedgerList.findIndex((item) => item.ledger_code === newData.ledger_code);
        if (eleIndex > -1) {
          oldLedgerList.splice(eleIndex, 1);
          state.newLedgerCodesList = [...oldLedgerList, newData];
        } else {
          state.newLedgerCodesList.push(newData);
        }
      } else {
        // Check if the edited data is already in the list of old listing array
        const eleIndex = oldExistingLedgerList.findIndex((item) => item.leddef_id === newData.leddef_id);

        if (eleIndex > -1) {
          // If the edited data is already in the list of old listing array then remove it from the list and add it to the new list
          oldExistingLedgerList.splice(eleIndex, 1);
          state.ledgerCodesList = [...oldExistingLedgerList];
          state.newLedgerCodesList.push(newData);
        } else {
          // If the edited data is not in the list of old listing array then check if it is in the list of newly added array
          const eleIndex = oldLedgerList.findIndex((item) => item.leddef_id === newData.leddef_id);
          if (eleIndex > -1) {
            oldLedgerList.splice(eleIndex, 1);
            state.newLedgerCodesList = [...oldLedgerList, newData];
          }
        }
      }
      state.selectedRowGlCodes = newData;
    },
    setFilters: (state, action: PayloadAction<TFilters>) => {
      state.filters = {
        ...state.filters,
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filters = {
        ...initialState.filters,
        sequenceValue: (ledgerCodesColumnDef || [])?.filter((col) => !!col.sequence)?.at(0)?.field
      };
    },

    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    selectGlListSelectedRow: (state, action: PayloadAction<any>) => {
      state.selectedRowGlCodes = action.payload;
    },
    setNewLedgerErrorState: (state, action: PayloadAction<any>) => {
      state.newLedgerErrorState = action.payload;
    },
    resetNewLedgerErrorState: (state) => {
      state.newLedgerErrorState = undefined;
    },
    setNewLedgerSubmitting: (state, action: PayloadAction<any>) => {
      state.isNewLedgerSubmitting = action.payload;
    },
    setTableList: (state, action: PayloadAction<any>) => {
      state.tableLedgerCodeList = sortData(action.payload, state.filters?.sequenceValue as string);
    }
  }
});

export const { actions: ledgerCodesAction, reducer } = slice;
export default reducer;
