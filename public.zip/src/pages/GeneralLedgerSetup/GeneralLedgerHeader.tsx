import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { Tab, TabList, TabPanel } from "@essnextgen/ui-kit";
import { useHistory, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { deleteSessionItem, getSessionItem, setToSession } from "@/utils/getDataSource";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import useLedgerGrpPopup from "./hooks/useLedgerGrpPopup";
import generalLedgerTabData from "./GeneralLedgerTabData";
import { profileModalActions as profileAcion } from "./State/ProfileModalTab.slice";
import { ledgerGrpAction } from "./State/LedgerGroupsList.slice";
import { generalLedgerFuncCodeAction } from "./State/GeneralLedgerFundCodeListing.slice";
import { costCentreActions } from "./State/CostCentresTab.slice";
import { ledgerCodesAction } from "./State/glLedgerCodes.slice";

const GeneralLedgerHeader = ({ getTitle }: any) => {
  const { resetSlice } = ledgerGrpAction;
  const { resetList } = generalLedgerFuncCodeAction;
  const { setTabData, tabData } = useLedgerGrpPopup();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const location = useLocation();
  const handleActiveTab = (tabType: string) => location.pathname.includes(tabType);
  const dispatch = useDispatch();

  const onTabSwitch = (routePath: string) => {
    setTabData(routePath);
    if (location.pathname === "/tools/fund-codes/add" || location.pathname.includes("/tools/fund-codes/edit")) {
      history.push(routePath);
    }
  };

  useEffect(() => {
    setTabData(location.pathname);
    setToSession("setisBtn", false);
  }, []);

  useEffect(
    () => () => {
      const currentPath = history.location.pathname;
      if (!currentPath.includes("/tools")) {
        dispatch(resetSlice()); // reset the value of ledger group
        dispatch(resetList()); // reset the value of fund code
        deleteSessionItem("glWarnBudget");
      }
    },
    [history]
  );

  useEffect(
    () => () => {
      const currentPath = history.location.pathname;
      if (!currentPath.includes("/profile-models")) {
        dispatch(profileAcion.setProfileDataExist(false));
        deleteSessionItem("saveDataOnTabChange");
        dispatch(profileAcion.resetPMSlice());
      }

      if (!currentPath.includes("/cost-centres")) {
        dispatch(costCentreActions.resetCostCenter());
      }

      if (!currentPath.includes("/ledger-codes")) {
        dispatch(ledgerCodesAction.resetLedgerCodesState());
        dispatch(ledgerCodesAction.resetFilters());
        dispatch(ledgerCodesAction.resetForm());
      }
    },
    [history]
  );
  const disableTabOnRoute = (tabUrl: string) => {
    const currentPath = history.location.pathname;
    if (
      currentPath.includes("/ledger-codes") &&
      currentPath !== "/tools/general-ledger-setup/ledger-codes" &&
      !tabUrl.includes("/ledger-codes")
    ) {
      return true;
    }
    return false;
  };

  const disableTabRouteSwitch = () => {
    const currentPath = history.location.pathname;
    return currentPath.includes("/ledger-codes") && currentPath !== "/tools/general-ledger-setup/ledger-codes";
  };
  return (
    <>
      <TabList
        id="element-id"
        isScrollable
      >
        {generalLedgerTabData?.map((tab: any, index: number) => {
          const count = index + 1;
          if (handleActiveTab(tab.activeTabName) && typeof getTitle === "function") {
            getTitle(tab.title);
          }
          return (
            <Tab
              disabled={disableTabOnRoute(tab.routePath)}
              onClick={() => {
                if (!disableTabRouteSwitch()) {
                  onTabSwitch(tab.routePath);
                }
              }}
              active={handleActiveTab(tab.activeTabName)}
              ariaControls={`panel-${count}`}
              dataTestId={`tab${count}`}
              className={tab.className}
              id={`tab-${count}`}
              key={count}
            >
              {count}: {t(tab.title)}
            </Tab>
          );
        })}
      </TabList>
      {/* It is just for blue border */}
      <TabPanel hidden={false} />
      {/*  */}
    </>
  );
};

export default GeneralLedgerHeader;
