import Input from "@/components/Input/Input";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { useAppSelector } from "@/store/store";
import { UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { FormLabel, Grid, GridItem, NotificationStatus, useTranslation, ValidationTextLevel } from "@essnextgen/ui-kit";
import { yupResolver } from "@hookform/resolvers/yup";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { object, string } from "yup";
import { useHistory, useParams } from "react-router-dom";
import { setToSession } from "@/utils/getDataSource";
import { getLedgerGroupsList, ledgerGrpAction, TLedgerGroupData } from "../../State/LedgerGroupsList.slice";
import FORMTYPE from "./type";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import useLedgerGrpPopup from "../../hooks/useLedgerGrpPopup";

type FormData = {
  ledgerGrpName: string;
};

const LedgerGrpFrorm = ({ formType = FORMTYPE.CREATE, title }: { formType: FORMTYPE; title: string }) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { id }: any = useParams();
  const newId = id ? parseInt(id, 10) : 0;
  const { ledgerGroupsList, ladgerGrpData, newGrpsList, newCreatedEditItem, isError, isCancelClicked } = useAppSelector(
    (state) => state.ledgerGroupsList
  );
  const { inputText } = ladgerGrpData;
  const {
    addNewGrpsList,
    setLadgerGrpData,
    setIsBtnClick,
    setSelectedRow,
    changeNewGrpList,
    setFormError,
    setCancelBtnClick
  } = ledgerGrpAction;
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();

  const formSchema = object({
    ledgerGrpName: string().max(32, "32 Character is required")
  });

  const {
    register,
    formState: { errors, isDirty },
    getValues,
    setValue,
    watch,
    setFocus
  } = useForm<FormData>({
    resolver: yupResolver(formSchema) as any,
    defaultValues: {
      ledgerGrpName: inputText || ""
    }
  });

  const grpName = watch("ledgerGrpName");
  const { getEditText } = useLedgerGrpPopup();

  useEffect(() => {
    dispatch(setFormError(false));
    dispatch(setLadgerGrpData({ isFormDirty: isDirty, inputText: grpName, id: newId }));
  }, [grpName, isDirty]);

  useEffect(() => {
    dispatch(getLedgerGroupsList());
  }, []);

  useEffect(() => {
    // Code for Edit Form
    if (formType === FORMTYPE.EDIT) {
      const editText = getEditText(newId);

      setValue("ledgerGrpName", editText?.description || "");
      dispatch(
        setLadgerGrpData({
          id: editText?.id || 0,
          isFormDirty: false,
          inputText: editText?.description || ""
        })
      );
    }
  }, [ledgerGroupsList]);

  const { onChange, name: fieldName, ref: fieldRef } = register("ledgerGrpName");

  const blankMsgPopup = () => {
    dispatch(setFormError(true));
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE?.ALERT,
        message: t("generalLedgerSetup.blankErrorMessage"),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus?.ERROR,
        className: "primary-focus"
      })
    );
    dispatch(setIsBtnClick(false));
    setToSession("setisBtn", false);
  };

  const uniqueMsgPopup = (isDuplicated: boolean, id = 0 as number, data = {} as TLedgerGroupData) => {
    if (isDuplicated) {
      dispatch(
        uiActions.alertPopup({
          enable: true,
          type: MODAL_TYPE?.ALERT,
          message: t("generalLedgerSetup.uniqueMessage"),
          title: t("common.simsFMSModule"),
          notificationType: NotificationStatus?.ERROR,
          className: "primary-focus"
        })
      );
      dispatch(setIsBtnClick(false));
      setToSession("setisBtn", false);
      dispatch(setFormError(true));
    } else {
      dispatch(setFormError(false));
      dispatch(setIsBtnClick(true));
      setToSession("setisBtn", true);
      dispatch(setLadgerGrpData({ inputText: "", isFormDirty: false, id: 0 }));
      dispatch(
        addNewGrpsList({
          id,
          description: grpName,
          deletable: data?.deletable || "",
          system: data?.system || ""
        })
      );

      if (formType === FORMTYPE.EDIT && id === 0 && newCreatedEditItem) {
        dispatch(changeNewGrpList(newCreatedEditItem));
      }
      dispatch(setSelectedRow({ id, description: grpName }));
      history.push("/tools/general-ledger-setup/ledger-groups");
    }
  };

  const handleGrpDescription = () => {
    dispatch(setIsBtnClick(true));
    setToSession("setisBtn", true);

    if (grpName.trim().length === 0) {
      blankMsgPopup();
    } else if (formType === FORMTYPE.EDIT) {
      const editText = getEditText(newId);
      if (editText?.description === grpName) {
        dispatch(setSelectedRow({ ...editText }));
        history.push("/tools/general-ledger-setup/ledger-groups");
      } else if (newId !== 0) {
        const isDuplicated = [...ledgerGroupsList, ...newGrpsList].some(
          (data) =>
            data.description.toLocaleLowerCase().trim() === grpName.toLocaleLowerCase().trim() &&
            editText?.id !== data.id
        );

        uniqueMsgPopup(isDuplicated, parseInt(id, 10), editText);
      } else {
        const isDuplicated = [...ledgerGroupsList, ...newGrpsList].some(
          (data) =>
            data.description.toLocaleLowerCase().trim() === grpName.toLocaleLowerCase().trim() &&
            newCreatedEditItem?.description !== data.description
        );

        uniqueMsgPopup(isDuplicated, parseInt(id, 10), editText);
      }
    } else {
      const isDuplicated = [...ledgerGroupsList, ...newGrpsList].some(
        (data) => data.description.toLocaleLowerCase().trim() === grpName.toLocaleLowerCase().trim()
      );

      uniqueMsgPopup(isDuplicated, 0);
    }
  };

  useEffect(() => {
    setFocus("ledgerGrpName");
  }, [setFocus]);

  // This will manage keep your changes model as well
  const handleCancelCallback = () => {
    setToSession("setisBtn", true);
    history.push("/tools/general-ledger-setup/ledger-groups");
  };
  //
  return (
    <GeneralLedgerSetup>
      <div className="tab-container ledger-grp-form">
        <Grid className="">
          <GridItem sm={4}>
            <div className="essui-global-typography-default-subtitle">Ledger Group Definition</div>
          </GridItem>
        </Grid>

        <Grid className="mt-8 mb-8">
          <GridItem
            sm={4}
            md={4}
            lg={4}
            xl={4}
            xxl={4}
          >
            <div>
              <FormLabel forId="ledgerGrpName">Group Name</FormLabel>
              <Input
                id="ledgerGrpName"
                aria-label="Search Group"
                value={watch("ledgerGrpName")}
                searchable
                inputRef={fieldRef}
                name={fieldName}
                maxLength={32}
                onChange={onChange}
                validationTextLevel={isError ? ValidationTextLevel.Error : undefined}
              />
            </div>
          </GridItem>
        </Grid>
        <GenralLedgerFooter
          cancelCallback={handleCancelCallback}
          onSubmit={handleGrpDescription}
        />
      </div>
    </GeneralLedgerSetup>
  );
};
export default LedgerGrpFrorm;
