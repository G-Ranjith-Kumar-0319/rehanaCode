import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "@/store/store";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS } from "@/types/UseStateType";
import { Grid, GridItem } from "@essnextgen/ui-kit";
import { useHistory } from "react-router-dom";
import LedgerGrpsColumnDef from "../Grid/columnDef";
import CustomCell from "./CustomCell";
import {
  getLedgerGroupsList,
  ledgerGrpAction,
  postLedgerData,
  TLedgerGroupData
} from "../../State/LedgerGroupsList.slice";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import CreateLedgerGroupCTA from "./CreateLedgerGroupCTA";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import useLedgerGrpPopup from "../../hooks/useLedgerGrpPopup";

const LedgerGroups = () => {
  const dispatch = useAppDispatch();
  const history = useHistory();
  const { setTabData } = useLedgerGrpPopup();
  const { ledgerGroupsList, status, selectedRow, newGrpsList, finalSortedList } = useAppSelector(
    (state) => state.ledgerGroupsList
  );
  const [newLedgerGrpList, setLedgerNewGrpList] = useState(ledgerGroupsList);
  const { setSelectedRow, setCancelBtnClick } = ledgerGrpAction;
  const sortArray = (arrOne: TLedgerGroupData[], arrTwo: TLedgerGroupData[]) => {
    if (arrTwo.length > 0) {
      const removeArrIds = arrTwo.filter((item) => item.id !== 0).map((item) => item.id);
      const newLedgerArr = arrOne.filter((item) => !removeArrIds.includes(item.id));
      const newArr = newLedgerArr.concat(arrTwo);
      const newdata = [...newArr].sort((a: any, b: any) => a.description.localeCompare(b.description));
      setLedgerNewGrpList([...newdata]);
      dispatch(ledgerGrpAction.setFinalSortedList(newdata));
    } else {
      setLedgerNewGrpList([...arrOne]);
      dispatch(ledgerGrpAction.setFinalSortedList(arrOne));
    }
  };
  useEffect(() => {
    dispatch(getLedgerGroupsList());
  }, []);

  useEffect(() => {
    sortArray(newLedgerGrpList, newGrpsList);
  }, [newGrpsList]);

  useEffect(() => {
    if (ledgerGroupsList.length > 0) {
      sortArray(ledgerGroupsList, newGrpsList);
    }
  }, [ledgerGroupsList]);

  const submitHandler = () => {
    dispatch(postLedgerData());
  };
  useEffect(() => {
    if (selectedRow === undefined) {
      dispatch(setSelectedRow(newLedgerGrpList.at(0)));
    } else {
      const found = newGrpsList.find((t) => t.description.toLowerCase() === selectedRow?.description.toLowerCase());
      dispatch(
        setSelectedRow(
          found === undefined
            ? finalSortedList.find((t) => t.description.toLowerCase() === selectedRow?.description.toLowerCase())
            : found
        )
      );
      setTimeout(() => {
        const element = document.getElementById(`rowIndex-generalLedgerGrpList-${newLedgerGrpList.indexOf(found!)}`);
        element?.scrollIntoView({ block: "center", behavior: "smooth" });
      }, 1000);
    }

    return () => {
      dispatch(setSelectedRow(undefined));
    };
  }, [newLedgerGrpList, newGrpsList, finalSortedList]);

  const handleCancelCallBack = () => {
    setTabData("/");
    dispatch(setCancelBtnClick(true));
  };

  return (
    <GeneralLedgerSetup>
      <div className="general-ledger-listing-container general-ledger-scroll-height">
        <Grid container>
          <GridItem
            sm={12}
            md={12}
            lg={12}
            xl={12}
          >
            <GridTableNew
              dataTestId="generalLedgerGrpList"
              filters={<CreateLedgerGroupCTA />}
              columnDef={LedgerGrpsColumnDef}
              isLoading={status === STATUS.LOADING}
              dataSource={[...new Set(finalSortedList)]}
              isRowSelectionEnabled
              selectedRow={selectedRow}
              isScrollable
              customCell={CustomCell}
            />
          </GridItem>
        </Grid>
      </div>
      <GenralLedgerFooter
        cancelCallback={handleCancelCallBack}
        onSubmit={submitHandler}
      />
    </GeneralLedgerSetup>
  );
};
export default LedgerGroups;
