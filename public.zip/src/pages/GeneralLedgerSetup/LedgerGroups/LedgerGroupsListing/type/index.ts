enum FORMTYPE {
  CREATE = "CREATE",
  EDIT = "EDIT"
}

export default FORMTYPE;
