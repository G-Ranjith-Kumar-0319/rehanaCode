import { cellRendererType } from "@/components/GridTableNew/GridTableNew";
import GridRowActions, { OptionsType } from "@/components/GridRowActions/GridRowActions";
import { Icon, IconSize } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { ledgerGrpAction, TLedgerGroupData } from "../../State/LedgerGroupsList.slice";

const CustomCell = ({ field, row }: cellRendererType) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { finalSortedList, newGrpsList } = useAppSelector((state) => state.ledgerGroupsList);
  const {
    setDeletedIds,
    setFinalSortedList,
    filternewGrpsList,
    updateLedgerGroupList,
    setNewCreatedEditItem,
    setSelectedRow
  } = ledgerGrpAction;
  const enbaleDeleteButton = (row?.system === "F" && row?.deletable === "T") || row?.id === 0;

  const deleteItemAndUpdateList = () => {
    dispatch(setDeletedIds(row));
    const itemIndex = finalSortedList.indexOf(row as TLedgerGroupData);
    const arrLength = finalSortedList.length;
    const selectIndex = itemIndex === arrLength - 1 ? arrLength - 2 : itemIndex + 1;
    const focusItem = finalSortedList[selectIndex];
    dispatch(setSelectedRow(focusItem));
    const filtered = finalSortedList.filter((t) => t?.description !== row?.description);
    dispatch(setFinalSortedList(filtered));
    dispatch(updateLedgerGroupList(filtered));
    const newList = newGrpsList?.filter((t) => t?.description !== row?.description);
    dispatch(filternewGrpsList(newList));
  };

  const onActionHandler = (e: any, selectedItem: any) => {
    if (selectedItem?.value === "delete") {
      deleteItemAndUpdateList();
    } else if (row?.system !== "T") {
      setSelectedRow(row);
      if (row?.id === 0 && row !== undefined) {
        dispatch(setNewCreatedEditItem({ id: 0, description: row?.description }));
      }
      history.push(`/tools/ledger-groups/edit/${row?.id}`);
    }
  };
  const options: OptionsType[] = [
    {
      text: "edit",
      value: "edit",
      disabled: row?.system === "T" && row?.id !== 0,
      children: <div className="option">{t("generalLedgerSetup.editLedger")}</div>
    },
    {
      text: "delete",
      value: "delete",
      disabled: !enbaleDeleteButton,
      children: <div className="option">{t("generalLedgerSetup.deleteLedger")}</div>
    }
  ];

  const getContent = () => (
    <GridRowActions
      name={
        <Icon
          size={IconSize.Medium}
          name="overflow-menu--horizontal"
        />
      }
      options={options}
      onClick={onActionHandler}
    />
  );

  return getContent();
};

export default CustomCell;
