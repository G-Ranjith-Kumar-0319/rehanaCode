import { Grid, GridItem, ButtonSize, Button } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { AddLarge } from "@carbon/icons-react";
import { CARBON_ICON } from "@/types/UseStateType";
import { useHistory } from "react-router-dom";
import { setToSession } from "@/utils/getDataSource";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useEffect } from "react";
import { ledgerGrpAction } from "../../State/LedgerGroupsList.slice";

const CreateLedgerGroupCTA = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { setLadgerGrpData, setIsBtnClick } = ledgerGrpAction;
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const createLedgerHandler = () => {
    setToSession("setisBtn", false);
    dispatch(setIsBtnClick(false));
    dispatch(setLadgerGrpData({ inputText: "", isFormDirty: false, id: 0 }));
    history.push("/tools/ledger-groups/create");
  };

  useEffect(() => {
    setTimeout(() => {
      document.getElementById("gllg-add-btn")?.focus();
    }, 100);
  }, []);
  return (
    <Grid>
      <GridItem
        md={12}
        lg={12}
        xl={12}
        className="btn-container"
      >
        <Button
          onClick={createLedgerHandler}
          size={ButtonSize.Small}
          title={t("generalLedgerSetup.addLedger")}
          id="gllg-add-btn"
          className="essui-button essui-button--utility essui-button--small br-0 focus-active"
        >
          <AddLarge
            size={CARBON_ICON.SIZE}
            color={CARBON_ICON.COLOR_BLACK}
          />
        </Button>
      </GridItem>
    </Grid>
  );
};

export default CreateLedgerGroupCTA;
