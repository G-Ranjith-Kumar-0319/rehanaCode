import { Grid, GridItem, ButtonSize, Button } from "@essnextgen/ui-kit";
import { AddLarge } from "@carbon/icons-react";
import { CARBON_ICON } from "@/types/UseStateType";

const LedgerGroupFilter = () => (
  <Grid>
    <GridItem
      md={12}
      lg={12}
      xl={12}
      className="btn-container"
    >
      <Button
        onClick={() => {}}
        size={ButtonSize.Small}
        title="Add a New Ledger Group"
        className="essui-button essui-button--utility essui-button--small br-0"
      >
        <AddLarge
          size={CARBON_ICON.SIZE}
          color={CARBON_ICON.COLOR_BLACK}
        />
      </Button>
    </GridItem>
  </Grid>
);

export default LedgerGroupFilter;
