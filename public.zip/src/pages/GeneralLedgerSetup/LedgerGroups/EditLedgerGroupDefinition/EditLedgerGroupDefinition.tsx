import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import LedgerGrpFrorm from "../LedgerGroupsListing/LedgerGrpFrorm";
import FORMTYPE from "../LedgerGroupsListing/type";

const EditLedgerGroupDefinition = () => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <LedgerGrpFrorm
      formType={FORMTYPE.EDIT}
      title={t("generalLedgerSetup.ledgerDefination")}
    />
  );
};

export default EditLedgerGroupDefinition;
