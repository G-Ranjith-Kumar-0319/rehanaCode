import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import LedgerGrpFrorm from "../LedgerGroupsListing/LedgerGrpFrorm";
import FORMTYPE from "../LedgerGroupsListing/type";

const LedgerGroupDefinition = () => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <LedgerGrpFrorm
      formType={FORMTYPE.CREATE}
      title={t("generalLedgerSetup.ledgerDefination")}
    />
  );
};

export default LedgerGroupDefinition;
