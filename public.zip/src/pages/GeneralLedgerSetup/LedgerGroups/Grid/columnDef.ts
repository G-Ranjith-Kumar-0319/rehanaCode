import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const LedgerGrpsColumnDef: TColumnDef = [
  {
    headerName: "Description",
    field: "description",
    columnWidth: 90
  },
  {
    headerName: "",
    field: "actions",
    cellRenderer: "GridCellLink",
    columnWidth: 10
  }
];

export default LedgerGrpsColumnDef;
