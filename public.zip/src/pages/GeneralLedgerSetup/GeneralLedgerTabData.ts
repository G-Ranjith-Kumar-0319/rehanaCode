const generalLedgerTabData = [
  {
    routePath: "/tools/general-ledger-setup/fund-codes",
    activeTabName: "fund-code",
    className: "set__tab--size",
    title: "generalLedgerSetup.fundCodes"
  },
  {
    routePath: "/tools/general-ledger-setup/cost-centres",
    activeTabName: "cost-centres",
    className: "set__tab--size",
    title: "generalLedgerSetup.costCenters"
  },
  {
    routePath: "/tools/general-ledger-setup/profile-models",
    activeTabName: "profile-models",
    className: "set__tab--size",
    title: "generalLedgerSetup.profileModels"
  },
  {
    routePath: "/tools/general-ledger-setup/ledger-groups",
    activeTabName: "ledger-groups",
    className: "set__tab--size",
    title: "generalLedgerSetup.ledgerGroups"
  },
  {
    routePath: "/tools/general-ledger-setup/ledger-codes",
    activeTabName: "ledger-codes",
    className: "set__tab--size",
    title: "generalLedgerSetup.ledgerCodes"
  },
  {
    routePath: "/tools/general-ledger-setup/c-centre-ledger-links",
    activeTabName: "c-centre-ledger-links",
    className: "set__tab--size",
    title: "generalLedgerSetup.centreLedgerLinks"
  },
  {
    routePath: "/tools/general-ledger-setup/central-ledger-links",
    activeTabName: "central-ledger-links",
    className: "set__tab--size",
    title: "generalLedgerSetup.centralLedgerLnks"
  },
  {
    routePath: "/tools/general-ledger-setup/cfr-mappings",
    activeTabName: "cfr-mappings",
    className: "set__tab--size",
    title: "generalLedgerSetup.CFRMapping"
  },
  {
    routePath: "/tools/general-ledger-setup/e-procurement-templates",
    activeTabName: "e-procurement-templates",
    className: "set__tab--size",
    title: "generalLedgerSetup.eProcurement"
  },
  {
    routePath: "/tools/general-ledger-setup/esfa-mappings",
    activeTabName: "esfa-mappings",
    className: "set__tab--size",
    title: "generalLedgerSetup.esfaMapping"
  }
];

export default generalLedgerTabData;
