import { FormLabel, Grid, GridItem, ValidationTextLevel } from "@essnextgen/ui-kit";
import Input from "@/components/Input/Input";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { object, string } from "yup";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useEffect, useLayoutEffect } from "react";
import { useAppSelector } from "@/store/store";
import { useHistory, useLocation, useParams } from "react-router-dom";
import { profileModalActions } from "../State/ProfileModalTab.slice";
import { getUpperCaseText, isTextEqual } from "./utils";
import GeneralLedgerSetup from "../GeneralLedgerSetup";
import useProfileModelForm from "./hook/useProfileModelForm";
import GenralLedgerFooter from "../GeneralLedgerFooter";

type FormData = {
  profileModelDes: string;
};

const ProfileModelsAddEditForm = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const params = useParams<any>();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { id: index } = params || {};
  const { isAddError, profileSelectedRow, tableProfileData, profileModalData, newProfileModalData, inputDetails } =
    useAppSelector((state) => state.generalLedgerProfileModel);
  const {
    setInputError,
    setInputDetails,
    setNewProfileData,
    setProfileSelectedRow,
    updateNewProfileData,
    replaceProfileModelData
  } = profileModalActions;

  const { isInputValid } = useProfileModelForm();
  const formSchema = object({
    profileModelDes: string().max(32, "32 Character is required")
  });

  const {
    register,
    formState: { errors, isDirty },
    getValues,
    setValue,
    watch,
    setFocus
  } = useForm<FormData>({
    resolver: yupResolver(formSchema) as any,
    defaultValues: {
      profileModelDes: ""
    }
  });

  const { onChange, name: fieldName, ref: fieldRef } = register("profileModelDes");
  const profileDescription = watch("profileModelDes");
  const profileSubmitHandler = () => {
    const isValid = isInputValid();
    if (isValid) {
      // Update Existing Item
      if (index >= 0) {
        // Here index is comming from param
        const item = tableProfileData[index];
        const findIndex = profileModalData?.findIndex((t) => isTextEqual(t?.model_des, item?.model_des));
        if (findIndex !== -1) {
          const newData = {
            ...profileModalData[findIndex],
            model_des: profileDescription,
            model_des_upper: getUpperCaseText(profileDescription)
          };
          // Remove the item from profileModalData
          const updatedProfileModalData = [
            ...profileModalData.slice(0, findIndex),
            ...profileModalData.slice(findIndex + 1)
          ];
          // Add the item to newProfileModalData
          const updatedNewProfileModalData = [...newProfileModalData, newData];
          // Dispatch the updated arrays
          dispatch(replaceProfileModelData(updatedProfileModalData));
          dispatch(updateNewProfileData(updatedNewProfileModalData));
          dispatch(setProfileSelectedRow(newData));
        } else {
          const findIndex = newProfileModalData?.findIndex((t) => isTextEqual(t?.model_des, item?.model_des));
          if (findIndex !== -1) {
            const newData = {
              ...newProfileModalData[findIndex],
              model_des: profileDescription,
              model_des_upper: getUpperCaseText(profileDescription)
            };
            const clone = [...newProfileModalData];
            clone[findIndex] = newData;
            dispatch(updateNewProfileData(clone));
            dispatch(setProfileSelectedRow(newData));
          }
        }
      } else {
        // Add New Item
        const newData = {
          model_id: 0,
          model_des: profileDescription,
          model_des_upper: getUpperCaseText(profileDescription),
          percent_remaining: 100,
          deletable: "",
          no_periods: 12
        };
        dispatch(setNewProfileData(newData));
        dispatch(setProfileSelectedRow(newData));
        dispatch(setInputDetails({ id: 0, inputText: "", isFormDirty: false }));
        dispatch(setInputError(false));
      }
      history.push("/tools/general-ledger-setup/profile-models");
    }
  };

  const cancelHandler = () => {
    history.push("/tools/general-ledger-setup/profile-models");
    dispatch(setInputDetails({ id: 0, inputText: "", isFormDirty: false }));
  };

  useEffect(() => {
    setFocus("profileModelDes");
  }, [setFocus]);

  useEffect(() => {
    dispatch(setInputError(false));
    const inputT = {
      id: 0,
      inputText: profileDescription,
      isFormDirty: isDirty
    };
    dispatch(setInputDetails(inputT));
  }, [isDirty, profileDescription, profileSelectedRow]);

  // prefill data on while edit
  useLayoutEffect(() => {
    const desc = profileSelectedRow?.model_des;
    if (index) setValue("profileModelDes", desc);
  }, [profileSelectedRow]);
  //

  return (
    <GeneralLedgerSetup>
      <div className="tab-container ledger-grp-form">
        <Grid className="">
          <GridItem sm={4}>
            <div className="essui-global-typography-default-subtitle">Profile Model Definition</div>
          </GridItem>
        </Grid>

        <Grid className="mt-8 mb-8">
          <GridItem
            sm={4}
            md={4}
            lg={4}
            xl={4}
            xxl={4}
          >
            <div>
              <FormLabel forId="profileModelDes">Model Name</FormLabel>
              <Input
                id="profileModelDes"
                value={watch("profileModelDes")}
                searchable
                aria-label="Search Group"
                onChange={onChange}
                inputRef={fieldRef}
                name={fieldName}
                maxLength={32}
                validationTextLevel={isAddError ? ValidationTextLevel.Error : undefined}
              />
            </div>
          </GridItem>
        </Grid>
        <GenralLedgerFooter
          onSubmit={profileSubmitHandler}
          cancelCallback={cancelHandler}
        />
      </div>
    </GeneralLedgerSetup>
  );
};

export default ProfileModelsAddEditForm;
