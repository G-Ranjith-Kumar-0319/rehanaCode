import React, { useEffect } from "react";
import { CARBON_ICON } from "@/types/UseStateType";
import { AddLarge } from "@carbon/icons-react";
import { Button, ButtonSize, Grid, GridItem, NotificationStatus } from "@essnextgen/ui-kit";
import { useHistory } from "react-router-dom";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import { useDispatch } from "react-redux";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import useProfileModelForm from "./hook/useProfileModelForm";

const AddProfileModelDesc = () => {
  const { periodValidator } = useProfileModelForm();
  const history = useHistory();
  const dispatch = useDispatch();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const isWarnBudget = getSessionItem("glWarnBudget");
  const getAlertMessage = (message: string) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        message: t(`generalLedgerSetup.ledgerCode.${message}`),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus.WARNING,
        callback: () => {
          setToSession("glWarnBudget", true);
          history.push("/tools/profile-models/add");
        }
      })
    );
  };
  const addProfileModels = () => {
    const isPeriodValidator = periodValidator();
    if (isPeriodValidator) {
      if (isWarnBudget === false) {
        getAlertMessage("warnBudgetAlertMsg");
      } else {
        history.push("/tools/profile-models/add");
      }
    }
  };

  useEffect(() => {
    setTimeout(() => {
      document.getElementById("glPm-add-btn")?.focus();
    }, 100);
  }, []);
  return (
    <>
      <Grid>
        <GridItem
          md={12}
          lg={12}
          xl={12}
          className="btn-container"
        >
          <Button
            onClick={addProfileModels}
            size={ButtonSize.Small}
            id="glPm-add-btn"
            title={t("generalLedgerSetup.addProfileModel")}
            className="essui-button essui-button--utility essui-button--small br-0 focus-active"
          >
            <AddLarge
              size={CARBON_ICON.SIZE}
              color={CARBON_ICON.COLOR_BLACK}
            />
          </Button>
        </GridItem>
      </Grid>
    </>
  );
};

export default AddProfileModelDesc;
