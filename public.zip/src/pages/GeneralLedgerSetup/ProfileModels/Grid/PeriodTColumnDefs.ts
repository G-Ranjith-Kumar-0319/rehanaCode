import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const ProfilePeriodModalDef: TColumnDef = [
  {
    headerName: "Period",
    field: "period_name",
    columnWidth: 50
  },
  {
    headerName: "Profile",
    field: "profile",
    align: "right",
    cellRenderer: "GridCellLink",
    columnWidth: 50
  }
];

export default ProfilePeriodModalDef;
