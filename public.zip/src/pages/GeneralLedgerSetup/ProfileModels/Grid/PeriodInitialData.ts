const PeriodInitialData = [
  {
    period_name: "Apr",
    period: 1,
    profile: 0
  },
  {
    period_name: "May",
    period: 2,
    profile: 0
  },
  {
    period_name: "Jun",
    period: 3,
    profile: 0
  },
  {
    period_name: "Jul",
    period: 4,
    profile: 0
  },
  {
    period_name: "Aug",
    period: 5,
    profile: 0
  },
  {
    period_name: "Sep",
    period: 6,
    profile: 0
  },
  {
    period_name: "Oct",
    period: 7,
    profile: 0
  },
  {
    period_name: "Nov",
    period: 8,
    profile: 0
  },
  {
    period_name: "Dec",
    period: 9,
    profile: 0
  },
  {
    period_name: "Jan",
    period: 10,
    profile: 0
  },
  {
    period_name: "Feb",
    period: 11,
    profile: 0
  },
  {
    period_name: "Mar",
    period: 12,
    profile: 0
  }
];

export default PeriodInitialData;
