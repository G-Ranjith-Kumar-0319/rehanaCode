import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const ProfileDescModalDef: TColumnDef = [
  {
    headerName: "Description",
    field: "model_des"
  },
  {
    field: "action",
    cellRenderer: "GridCellLink",
    columnWidth: 20
  }
];

export default ProfileDescModalDef;
