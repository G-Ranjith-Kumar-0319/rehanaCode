import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { Grid, GridItem, Loader, LoaderType } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useEffect, useRef, useState } from "react";
import { useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import Layout from "@/components/Layout/Layout";
import useDebounce from "@/hooks/useDebounce";
import { set } from "date-fns";
import {
  getProfileModalData,
  getProfileModalPeriods,
  postProfileModelData,
  profileModalActions as profileAcion
} from "../State/ProfileModalTab.slice";
import GeneralLedgerSetup from "../GeneralLedgerSetup";
import AddProfileModelDesc from "./AddProfileModelDesc";
import ProfileModelActionBtn from "./ProfileModelActionBtn";
import ProfilePeriodModalDef from "./Grid/PeriodTColumnDefs";
import GenralLedgerFooter from "../GeneralLedgerFooter";
import ProfileCustomCell from "./Cells/ProfileCustomCell";
import PeriodCustomCell from "./Cells/PeriodCustomCell";
import ProfileDescModalDef from "./Grid/ProfileTColumnDefs";
import useSortedData from "../hooks/useSortedData";
import useProfileModelForm from "./hook/useProfileModelForm";
import getLowerCaseText, { isArrayLength } from "./utils";
import PeriodInitialData from "./Grid/PeriodInitialData";
import ChoosePeriodsModal from "./ChoosePeriods/ChoosePeriodsModal";

const ProfileModels = () => {
  const dispatch = useDispatch();
  const { periodValidator, cancelWarningPopup } = useProfileModelForm();
  const {
    profileModalData,
    status,
    profileSelectedRow,
    profileModalPeriod,
    periodSelectedRow,
    newProfileModalData,
    finalProfileList,
    isProfileDataExist,
    tableProfileData,
    inputStatus
  } = useAppSelector((state) => state.generalLedgerProfileModel);

  const [spreadModel, setSpreadModel] = useState(false);
  const sorted = useSortedData(finalProfileList, "model_des", "asc");
  // Profile Modal Request on mount
  useEffect(() => {
    dispatch(profileAcion.setProfileTableData(sorted));
  }, [sorted]);

  useEffect(() => {
    if (!isProfileDataExist) {
      dispatch(getProfileModalData());
    }
  }, []);

  // get Period modal data on selected row
  const addPeriodAgainstProfile = (res: any) => {
    if (isArrayLength(res?.payload)) {
      const updatedData = profileModalData?.map((item: any) => {
        if (item?.model_id === res?.payload[0].model_id) {
          return { ...item, periods: res.payload }; // Ensure immutability
        }
        return item;
      });
      dispatch(profileAcion.replaceProfileModelData(updatedData));
    }
  };

  // Get Period modal data on selected row
  const delayedModelId = parseInt(useDebounce(profileSelectedRow?.model_id, 200), 10);
  useEffect(() => {
    (async () => {
      const isNan = delayedModelId.toString() === ("NaN" as any);
      if (delayedModelId !== 0 && !isNan && !profileSelectedRow?.periods) {
        const res: any = await dispatch(getProfileModalPeriods({ id: Number(delayedModelId) }));
        addPeriodAgainstProfile(res);
      } else if ((delayedModelId === 0 && !isNan) || isArrayLength(profileSelectedRow?.periods)) {
        dispatch(profileAcion.setProfileModalPeriod(profileSelectedRow?.periods));
      }
    })();
  }, [dispatch, delayedModelId, newProfileModalData]);

  useEffect(() => {
    dispatch(profileAcion.setFinalProfileList([...profileModalData, ...newProfileModalData]));
  }, [profileModalData, newProfileModalData]);

  useEffect(() => {
    if (profileSelectedRow === undefined) {
      dispatch(profileAcion.setProfileSelectedRow(tableProfileData.at(0)));
    } else {
      const found = newProfileModalData.find(
        (t) => getLowerCaseText(t?.model_des) === getLowerCaseText(profileSelectedRow?.model_des)
      );

      dispatch(
        profileAcion.setProfileSelectedRow(
          found === undefined
            ? tableProfileData.find(
                (t) => getLowerCaseText(t?.model_des) === getLowerCaseText(profileSelectedRow?.model_des)
              )
            : found
        )
      );
      const element = document.getElementById(`rowIndex-GLProfileList-${tableProfileData.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [profileModalData, newProfileModalData, tableProfileData, profileSelectedRow]);

  useEffect(() => {
    if (periodSelectedRow === undefined) {
      dispatch(profileAcion.setPeriodeSelectedRow(profileModalPeriod.at(0)));
    } else {
      const found = profileModalPeriod?.find(
        (t) => getLowerCaseText(t?.period_name) === getLowerCaseText(periodSelectedRow?.period_name)
      );

      dispatch(
        profileAcion.setPeriodeSelectedRow(
          found === undefined
            ? profileModalPeriod?.find(
                (t) => getLowerCaseText(t?.period_name) === getLowerCaseText(periodSelectedRow?.period_name)
              )
            : found
        )
      );
    }

    return () => {
      dispatch(profileAcion.setPeriodeSelectedRow(undefined));
    };
  }, [profileModalPeriod]);

  const postHandler = () => {
    const isPeriodValidator = periodValidator();
    if (isPeriodValidator && newProfileModalData.length !== 0) {
      dispatch(postProfileModelData());
      dispatch(profileAcion.setProfileDataExist(false));
    }
  };

  const profileSelectedRowHandler = (row: any) => {
    if (getLowerCaseText(row?.model_des) !== getLowerCaseText(profileSelectedRow?.model_des)) {
      const isPeriodValidator = periodValidator();
      if (isPeriodValidator) {
        setTimeout(() => {
          dispatch(profileAcion.setProfileSelectedRow(row));
        }, 0);
      } else {
        setTimeout(() => {
          handleSelectedRowClass(row, "remove");
          handleSelectedRowClass(profileSelectedRow, "add");
          dispatch(profileAcion.setProfileSelectedRow(profileSelectedRow));
        }, 0);
      }
    }
  };

  const handleSelectedRowClass = (row: any, type: "add" | "remove") => {
    const eleIndex = tableProfileData.findIndex((ele) => ele.model_des === row?.model_des);
    const element = document.getElementById(`rowIndex-GLProfileList-${eleIndex}`);
    element?.classList[type === "remove" ? "remove" : "add"]("selected-row");
  };

  return (
    <>
      <GeneralLedgerSetup>
        <Layout
          isBreadcrumbRequired={false}
          className="wrapper general-ledger-listing-container general-ledger-profile-scroll-height profile-table"
        >
          {tableProfileData.length === 0 || status === STATUS.LOADING ? (
            <Loader
              loaderType={LoaderType.Circular}
              loaderText="Loading..."
            />
          ) : (
            <Grid>
              <GridItem
                sm={4}
                md={8}
                lg={6}
                xl={6}
              >
                <GridTableNew
                  dataTestId="GLProfileList"
                  isScrollable
                  filters={<AddProfileModelDesc />}
                  columnDef={ProfileDescModalDef}
                  isLoading={false}
                  dataSource={[...new Set(tableProfileData)]}
                  selectedRow={profileSelectedRow}
                  selectedRowHandler={(row) => {
                    profileSelectedRowHandler(row);
                  }}
                  customCell={ProfileCustomCell}
                  className="profile-model-table"
                />
              </GridItem>
              <GridItem
                sm={4}
                md={8}
                lg={6}
                xl={6}
              >
                <GridTableNew
                  isAutoFocusInitially={false}
                  isRowSelectOnArrowkey={!inputStatus}
                  dataTestId="GLProfilePeriodList"
                  columnDef={ProfilePeriodModalDef}
                  isLoading={false} // show loader onl while saving
                  dataSource={profileModalPeriod || PeriodInitialData}
                  customCell={PeriodCustomCell}
                  selectedRowHandler={(row) => {
                    dispatch(profileAcion.setPeriodeSelectedRow(row));
                  }}
                  footer={<ProfileModelActionBtn setSpreadModel={setSpreadModel} />}
                  selectedRow={periodSelectedRow}
                />
              </GridItem>

              <ChoosePeriodsModal
                setSpreadModel={setSpreadModel}
                spreadModel={spreadModel}
              />
            </Grid>
          )}
        </Layout>
        <GenralLedgerFooter
          onSubmit={postHandler}
          cancelCallback={cancelWarningPopup}
        />
      </GeneralLedgerSetup>
    </>
  );
};
export default ProfileModels;
