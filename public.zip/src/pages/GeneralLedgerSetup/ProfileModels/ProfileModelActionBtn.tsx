import { Button, ButtonColor, ButtonSize, Grid, GridItem, Icon, IconSize } from "@essnextgen/ui-kit";
import { useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { profileModalActions as profileAcion, profileModalActions } from "../State/ProfileModalTab.slice";
import PeriodInitialData from "./Grid/PeriodInitialData";

const ProfileModelCTA = ({ setSpreadModel }: any) => {
  const dispatch = useDispatch();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { profileSelectedRow, tableProfileData } = useAppSelector((state) => state.generalLedgerProfileModel);

  const resetToZero = () => {
    const newProfileData = { ...profileSelectedRow, percent_remaining: 100.0, periods: PeriodInitialData };
    dispatch(profileAcion.updateProfileModelData(newProfileData as any));
    dispatch(profileAcion.resetInput());
  };
  return (
    <>
      <Grid
        container
        className="row-gap-16"
      >
        <GridItem
          sm={4}
          md={4}
          lg={6}
          xl={6}
        >
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Secondary}
            onClick={() => setSpreadModel(true)}
          >
            {t("profileModal.selectSpread")}
          </Button>
        </GridItem>
        <GridItem
          sm={4}
          md={4}
          lg={6}
          xl={6}
          className="align-center d-flex justify-end justify-start-resposnive"
        >
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Secondary}
            onClick={resetToZero}
          >
            {t("profileModal.resetToZero")}
          </Button>
          <div className="ml-16">
            <div className="essui-form-label">{t("profileModal.remainingPercentage")}</div>
            <div className="mt-8">
              {profileSelectedRow?.percent_remaining
                ? parseFloat(profileSelectedRow?.percent_remaining)?.toFixed(2)
                : "0.00"}
            </div>
          </div>
        </GridItem>
      </Grid>
    </>
  );
};

export default ProfileModelCTA;
