const getLowerCaseText = (text: string) => text?.trim()?.toLocaleLowerCase();
export const getUpperCaseText = (text: string) => text?.trim()?.toLocaleUpperCase();

export const getRemainingVal = (totalValue: number) => (100 - totalValue).toFixed(2);
export const isTextEqual = (text1: string, text2: string) => text1.trim().toLowerCase() === text2.trim().toLowerCase();
/**
 * Checks if the input is a non-empty array.
 *
 * @param res - The input to be checked.
 * @returns true if the input is a non-empty array, false otherwise.
 */
export const isArrayLength = (res: any): boolean => res && Array.isArray(res) && res.length > 0;
export default getLowerCaseText;
