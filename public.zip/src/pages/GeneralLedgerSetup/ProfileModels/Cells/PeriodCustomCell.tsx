import NumberInput from "@/components/NumberInput/NumberInput";
import { useAppSelector } from "@/store/store";
import { specialCharacters, STATUS } from "@/types/UseStateType";
import { getSessionItem, setToSession, usNumberFormat } from "@/utils/getDataSource";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { getRemainingVal, isTextEqual } from "../utils";
import { profileModalActions } from "../../State/ProfileModalTab.slice";

const PeriodCustomCell = ({ field, row }: any) => {
  const dispatch = useDispatch();
  const inputRef = useRef<HTMLInputElement>(null);
  const ousideClickRef = useRef<any>(null);
  const { profileSelectedRow, profileModalData, newProfileModalData, status, periodSelectedRow, resetInput } =
    useAppSelector((state) => state.generalLedgerProfileModel);

  const {
    replaceProfileModelData,
    updateNewProfileData,
    setProfileSelectedRow,
    setPeriodeSelectedRow,
    setInputStatus
  } = profileModalActions;
  const [showInput, setShowInput] = useState(false);
  const [inputValue, setInputValue] = useState(row?.profile);

  const editAction = () => {
    // will implement edit functionality here
    setShowInput(true);
    dispatch(setInputStatus(true));
    inputRef.current?.focus();
  };

  const editActionValue = (e: any) => {
    const value = parseFloat(e.target.value || 0.0);
    setInputValue(value);
  };

  const activePeriodView = () => {
    setShowInput(false);
    dispatch(setInputStatus(false));
    const newProfileData = { ...profileSelectedRow };
    const newRow = { ...row };

    const newPeriod = newProfileData?.periods?.map((data: any) => {
      if (data.period === row.period) {
        const newData = { ...data };
        newData.profile = inputValue;
        return newData;
      }
      return data;
    });

    const totalVal = newPeriod?.reduce((acc: number, data: any) => acc + parseFloat(data?.profile), 0);

    newProfileData.percent_remaining = getRemainingVal(totalVal);
    newProfileData.periods = newPeriod;

    const profileIndex = profileModalData?.findIndex((item: any) =>
      isTextEqual(item?.model_des, newProfileData?.model_des)
    );
    const updatedProfileModalData: any = [...profileModalData];
    const updatedNewProfileModalData: any = [...newProfileModalData];

    if (profileIndex !== -1) {
      // Remove from profileModalData and add to newProfileModalData
      updatedProfileModalData.splice(profileIndex, 1);
      updatedNewProfileModalData.push(newProfileData);
    } else {
      // Just update newProfileModalData
      const newProfileIndex = updatedNewProfileModalData.findIndex((item: any) =>
        isTextEqual(item.model_des, newProfileData.model_des)
      );
      if (newProfileIndex !== -1) {
        updatedNewProfileModalData[newProfileIndex] = newProfileData;
      } else {
        updatedNewProfileModalData.push(newProfileData);
      }
    }

    dispatch(replaceProfileModelData(updatedProfileModalData as any));
    dispatch(updateNewProfileData(updatedNewProfileModalData as any));
    dispatch(setProfileSelectedRow(newProfileData));
    dispatch(setPeriodeSelectedRow(row));
  };

  useEffect(() => {
    setInputValue(row?.profile);
  }, [row?.profile]);

  useEffect(() => {
    setShowInput(false);
  }, [row]);

  // Reset input value
  useEffect(() => {
    if (resetInput !== undefined) {
      setInputValue(resetInput);
    }
  }, [resetInput]);

  const handleClickOutside = (event: any) => {
    if (ousideClickRef.current && !ousideClickRef.current.contains(event.target)) {
      activePeriodView();
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [ousideClickRef, profileSelectedRow, row, inputValue]);

  useEffect(() => {
    const inputElement = document.querySelector(`.period-input-${row.period}`) as HTMLInputElement;
    if (inputElement) {
      inputElement.focus();
      setTimeout(() => inputElement.select(), 0);
    }
  }, [showInput]);

  const getContent = () => {
    if (field === "profile") {
      return (
        <div className="d-flex justify-end">
          {showInput ? (
            <>
              <div
                ref={ousideClickRef}
                className="d-flex justify-end"
              >
                <NumberInput
                  inputRef={inputRef}
                  id="profileValue"
                  decimals={2}
                  maxLength={3}
                  onChange={editActionValue}
                  name="profileValue"
                  className={`period-input period-input-${row.period}`}
                  defaultValue={inputValue}
                />

                <Button
                  onClick={activePeriodView}
                  className="grid-actions__button ml-8"
                  iconName="checkmark--alt"
                  iconClassName="right"
                  size={ButtonSize.Small}
                  color={ButtonColor.Tertiary}
                  ariaLabel="txtEdit"
                />
              </div>
            </>
          ) : (
            <>
              {inputValue === 0 ? specialCharacters.zero : usNumberFormat(inputValue)}
              <Button
                onClick={editAction}
                className="grid-actions__button ml-8"
                iconName="edit--alt"
                size={ButtonSize.Small}
                color={ButtonColor.Tertiary}
                ariaLabel="txtEdit"
                disabled={status !== STATUS.SUCCESS}
              />
            </>
          )}
        </div>
      );
    }
    return null;
  };
  return getContent();
};

export default PeriodCustomCell;
