import GridRowActions from "@/components/GridRowActions/GridRowActions";
import { TABLE_ACTION } from "@/types/UseStateType";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { Icon, IconSize } from "@essnextgen/ui-kit";
import { useHistory } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import { deepEqual } from "assert";
import { useEffect } from "react";
import useSortedData from "../../hooks/useSortedData";
import { isTextEqual } from "../utils";
import useProfileModelForm from "../hook/useProfileModelForm";

const ProfileCustomCell = ({ field, row }: any) => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const history = useHistory();
  const { tableProfileData } = useAppSelector((state) => state.generalLedgerProfileModel);
  const { periodValidator } = useProfileModelForm();

  const options: any = [
    {
      text: "edit",
      value: "edit",
      disabled: false,
      children: <div className="option">{t("generalLedgerSetup.editModel")}</div>
    },
    {
      text: "delete",
      value: "delete",
      disabled: false,
      children: <div className="option glpp-delete-cta">{t("generalLedgerSetup.profileDeleteModel")}</div>
    }
  ];

  const handleProfileAction = (e: any, action: any) => {
    if (action.value === TABLE_ACTION.EDIT) {
      // find item from list and redirect to edit with index
      if (periodValidator()) {
        history.push(
          `/tools/profile-models/edit/${
            tableProfileData?.findIndex((t) => isTextEqual(t.model_des, row.model_des)) ?? -1
          }`
        );
      }
    }
  };

  if (field === "action") {
    return (
      <>
        <GridRowActions
          name={
            <Icon
              size={IconSize.Medium}
              name="overflow-menu--horizontal"
            />
          }
          options={options}
          onClick={handleProfileAction}
        />
      </>
    );
  }
  return null;
};

export default ProfileCustomCell;
