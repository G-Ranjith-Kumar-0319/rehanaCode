import ProfileModelsAddEditForm from "../ProfileModelsAddEditForm";

const AddProfileModels = () => <ProfileModelsAddEditForm />;
export default AddProfileModels;
