import GridTableNew, { TColumnDef } from "@/components/GridTableNew/GridTableNew";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS } from "@/types/UseStateType";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import ProfilePeriodModalDef from "../Grid/PeriodTColumnDefs";
import useChoosePeriodsModal from "./useChoosePeriodsModal";
import { profileModalActions as choosePeriodActions } from "../../State/ProfileModalTab.slice";
import TableHeader from "./TableHeader";

const ChoosePeriodsModal = ({ setSpreadModel, spreadModel }: any) => {
  const dispatch = useDispatch<AppDispatch>();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    moveSingleAvailabeItemToToRight,
    moveSignleRecordRighToLeft,
    tobeUsedChequeBookSelectedRowHandler,
    moveAllAvailabeItemsleftToRight,
    moveAllChoosePeriodsRightToleft,
    tobePeriodLeftSelectedRowHandler
  } = useChoosePeriodsModal();
  const {
    status,
    choosePeriodsData,
    tobeUsedChooseModalPeriods,
    tobeUsedChoosePeriodSelectedRow,
    availableChooseperiodSelectedRow
  } = useAppSelector((state) => state.generalLedgerProfileModel);

  const profilePeriodModalDefCopy: TColumnDef = JSON.parse(JSON.stringify(ProfilePeriodModalDef));
  const columns = profilePeriodModalDefCopy
    .filter((col) => col.field !== "profile")
    ?.map((col) => {
      col.headerName = "";
      return col;
    });
  const sortData = (array: any[]) => array.slice().sort((a, b) => a.period - b.period);

  const handleClose = () => {
    setSpreadModel(false);
    dispatch(choosePeriodActions.resetSpread());
  };

  const selectPeriods = () => {
    handleClose();
    dispatch(choosePeriodActions.selectChooseItems(tobeUsedChooseModalPeriods));
  };
  useEffect(() => {}, [tobeUsedChoosePeriodSelectedRow, availableChooseperiodSelectedRow]);

  useEffect(() => {
    if (availableChooseperiodSelectedRow === undefined && choosePeriodsData.length > 0) {
      dispatch(choosePeriodActions.setAvailableChoosePeriodSelectedRow(choosePeriodsData.at(0) as any));
    } else {
      const found = choosePeriodsData?.find((t) => t?.period === availableChooseperiodSelectedRow?.period);

      dispatch(choosePeriodActions.setAvailableChoosePeriodSelectedRow(found as any));
    }

    return () => {
      dispatch(choosePeriodActions.setAvailableChoosePeriodSelectedRow({}));
    };
  }, [availableChooseperiodSelectedRow]);

  useEffect(() => {
    if (tobeUsedChoosePeriodSelectedRow === undefined && tobeUsedChooseModalPeriods.length > 0) {
      dispatch(choosePeriodActions.setTobeUsedChoosePeriodSelectedRow(tobeUsedChooseModalPeriods.at(0) as any));
    } else {
      const found = tobeUsedChooseModalPeriods?.find((t: any) => t?.period === tobeUsedChoosePeriodSelectedRow?.period);

      dispatch(choosePeriodActions.setTobeUsedChoosePeriodSelectedRow(found));
    }

    return () => {
      dispatch(choosePeriodActions.setTobeUsedChoosePeriodSelectedRow(undefined));
    };
  }, [tobeUsedChoosePeriodSelectedRow]);

  return (
    <Dialog
      dataTestId="test-id"
      escapeExits
      id="element-id"
      returnFocusOnDeactivate
      title="Choose Periods"
      className="dialog__divider"
      onClose={handleClose}
      isOpen={spreadModel}
    >
      <DialogContent>
        <div>
          <Grid
            container
            className="mt-16 mb-16"
          >
            <GridItem
              sm={4}
              md={8}
              lg={4}
              xl={4}
              className="grid-table-scrool"
            >
              <GridTableNew
                filters={
                  <TableHeader
                    headerText={t("generalLedgerSetup.availableItems")}
                    tableHeaderText={t("generalLedgerSetup.desc")}
                  />
                }
                hideHeader
                dataTestId="GLProfilePeriodList"
                columnDef={columns}
                isLoading={status === STATUS.LOADING}
                dataSource={choosePeriodsData.length ? sortData(choosePeriodsData) : []}
                selectedRow={availableChooseperiodSelectedRow}
                selectedRowHandler={tobePeriodLeftSelectedRowHandler}
                isScrollable
                className="spread-table"
              />
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={4}
              xl={4}
              className="pl-30 pr-30"
            >
              <div className="d-flex justify-end flex-wrap row-gap-8">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="w-100 justify-start"
                  iconName="arrow--right"
                  onClick={moveSingleAvailabeItemToToRight}
                >
                  Choose
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="w-100 mb-16 justify-start"
                  iconName="arrow--right"
                  onClick={moveAllAvailabeItemsleftToRight}
                >
                  Choose All
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="w-100 justify-start"
                  iconName="arrow--left"
                  onClick={moveSignleRecordRighToLeft}
                >
                  Remove
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="w-100 justify-start"
                  iconName="arrow--left"
                  onClick={moveAllChoosePeriodsRightToleft}
                >
                  Remove All
                </Button>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={8}
              lg={4}
              xl={4}
              className="grid-table-scrool"
            >
              <GridTableNew
                filters={
                  <TableHeader
                    headerText={t("generalLedgerSetup.chosenItems")}
                    tableHeaderText={t("generalLedgerSetup.desc")}
                  />
                }
                selectedRow={tobeUsedChoosePeriodSelectedRow}
                selectedRowHandler={tobeUsedChequeBookSelectedRowHandler}
                dataSource={tobeUsedChooseModalPeriods.length ? sortData(tobeUsedChooseModalPeriods) : []}
                columnDef={columns}
                hideHeader
                isLoading={status === STATUS.LOADING}
                isScrollable
                className="spread-table"
              />
            </GridItem>
          </Grid>
        </div>
      </DialogContent>
      <DialogFooter>
        <Grid>
          <GridItem
            sm={2}
            md={4}
            lg={6}
            xl={6}
          >
            <div>
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </div>
          </GridItem>
          <GridItem
            sm={2}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="d-flex justify-end">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                className="ml-4 mr-4"
                onClick={handleClose}
              >
                Cancel
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
                className="ml-4"
                onClick={selectPeriods}
              >
                Select
              </Button>
            </div>
          </GridItem>
        </Grid>
      </DialogFooter>
    </Dialog>
  );
};

export default ChoosePeriodsModal;
