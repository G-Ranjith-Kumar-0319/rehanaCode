import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { profileModalActions as choosePeriodActions } from "../../State/ProfileModalTab.slice";

const useChoosePeriodsModal = () => {
  const dispatch = useDispatch<AppDispatch>();
  const {
    availableChooseperiodSelectedRow,
    tobeUsedChoosePeriodSelectedRow,
    choosePeriodsData,
    tobeUsedChooseModalPeriods
  } = useAppSelector((state) => state.generalLedgerProfileModel);

  const moveSingleAvailabeItemToToRight = () => {
    if (choosePeriodsData.length > 0) {
      dispatch(choosePeriodActions.setTobeUsedChoosePeriods(availableChooseperiodSelectedRow));
      dispatch(choosePeriodActions.removeFromAvailableChoosePeriods(availableChooseperiodSelectedRow));
    }
  };

  const moveSignleRecordRighToLeft = () => {
    if (tobeUsedChoosePeriodSelectedRow && tobeUsedChooseModalPeriods.length > 0) {
      const rowTobeMovedLeft = { ...tobeUsedChoosePeriodSelectedRow };
      dispatch(choosePeriodActions.setAvailableChoosePeriods(rowTobeMovedLeft));
      dispatch(choosePeriodActions.removeFromTobeUsedChequeBooks(rowTobeMovedLeft));
    }
  };

  const moveAllAvailabeItemsleftToRight = () => {
    const rowTobeMovedAllRight = { ...tobeUsedChoosePeriodSelectedRow };
    dispatch(choosePeriodActions.moveAllAvailableItemsRightToLeft(rowTobeMovedAllRight));
  };

  const moveAllChoosePeriodsRightToleft = () => {
    const rowTobeMovedAllRight = { ...tobeUsedChoosePeriodSelectedRow };
    dispatch(choosePeriodActions.removeAllPeriodsRightToLeft(rowTobeMovedAllRight));
  };

  const tobeUsedChequeBookSelectedRowHandler = (row: { [key: string]: any } | undefined) => {
    dispatch(choosePeriodActions.setTobeUsedChoosePeriodSelectedRow(row));
  };

  const tobePeriodLeftSelectedRowHandler = (row: any) => {
    dispatch(choosePeriodActions.setAvailableChoosePeriodSelectedRow(row));
  };

  return {
    moveSingleAvailabeItemToToRight,
    moveSignleRecordRighToLeft,
    tobeUsedChequeBookSelectedRowHandler,
    moveAllAvailabeItemsleftToRight,
    moveAllChoosePeriodsRightToleft,
    tobePeriodLeftSelectedRowHandler,
    availableChooseperiodSelectedRow,
    tobeUsedChoosePeriodSelectedRow
  };
};

export default useChoosePeriodsModal;
