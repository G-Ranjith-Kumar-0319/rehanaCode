type TableHeaderProps = {
  className?: string;
  headerText: string;
  tableHeaderText: string;
};

const TableHeader = ({ headerText, className, tableHeaderText }: TableHeaderProps) => (
  <div>
    <span className={`essui-global-typography-default-subtitle table-heading main-header ${className || ""}`}>
      {headerText}
    </span>
    <span className="sub-heading">{tableHeaderText}</span>
  </div>
);

TableHeader.defaultProps = {
  className: undefined
};

export default TableHeader;
