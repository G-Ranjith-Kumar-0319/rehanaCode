import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { useHistory, useParams } from "react-router-dom";
import { setToSession } from "@/utils/getDataSource";
import { postProfileModelData, profileModalActions } from "../../State/ProfileModalTab.slice";
import getLowerCaseText, { isTextEqual } from "../utils";

type TConfirmationPopup = {
  yesFunc?: () => void;
  noFunc?: () => void;
  cancelFunc?: () => void;
  changeTab: () => void;
  inputValidation?: boolean;
};
const useProfileModelForm = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { id: index }: any = useParams();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { inputDetails, isAddError, profileSelectedRow, finalProfileList, newProfileModalData, profileModalPeriod } =
    useAppSelector((state) => state.generalLedgerProfileModel);

  const { inputText } = inputDetails;
  const { setInputError, setInputDetails, setNewProfileData, resetNewProfileSlice, setPeriodeSelectedRow } =
    profileModalActions;
  const isRemaining =
    (profileSelectedRow?.percent_remaining <= 100 && profileSelectedRow?.percent_remaining > 0) ||
    profileSelectedRow?.percent_remaining < 0;
  const isInputValid = (formText = inputText) => {
    if (getLowerCaseText(formText).length === 0) {
      dispatch(setInputError(true));
      dispatch(
        uiActions.alertPopup({
          enable: true,
          type: MODAL_TYPE?.ALERT,
          message: t("generalLedgerSetup.profileModelsBlankMsg"),
          title: t("common.simsFMSModule"),
          notificationType: NotificationStatus?.ERROR,
          className: "primary-focus"
        })
      );

      return false;
    }

    let isDuplicated;
    if (index >= 0) {
      isDuplicated = finalProfileList.some(
        (data) =>
          !isTextEqual(inputText, profileSelectedRow?.model_des) &&
          getLowerCaseText(data.model_des) === getLowerCaseText(formText)
      );
    } else {
      isDuplicated = finalProfileList.some((data) => getLowerCaseText(data.model_des) === getLowerCaseText(formText));
    }

    if (isDuplicated) {
      dispatch(setInputError(true));
      dispatch(
        uiActions.alertPopup({
          enable: true,
          type: MODAL_TYPE?.ALERT,
          message: t("generalLedgerSetup.uniqueMessage"),
          title: t("common.simsFMSModule"),
          notificationType: NotificationStatus?.ERROR,
          className: "primary-focus"
        })
      );
      return false;
    }
    return true;
  };

  const periodValidator = () => {
    dispatch(setPeriodeSelectedRow(profileModalPeriod[0]));

    if (isRemaining) {
      dispatch(
        uiActions.alertPopup({
          enable: true,
          type: MODAL_TYPE?.ALERT,
          message: t("generalLedgerSetup.profileModelsProfileError"),
          title: t("common.simsFMSModule"),
          notificationType: NotificationStatus?.ERROR,
          className: "primary-focus"
        })
      );
      return false;
    }
    return true;
  };

  const confirmationPopup = ({
    yesFunc,
    noFunc,
    cancelFunc,
    changeTab,
    inputValidation = false
  }: TConfirmationPopup) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        message: t("common.keepChangesWishMsg"),
        title: t("common.simsFMSModule"),
        type: MODAL_TYPE.CONFIRMV2,
        yesCallback: async () => {
          if (inputValidation) {
            const isValid = isInputValid();
            if (isValid) {
              changeTab();
              if (!history.location.pathname.includes("/profile-models/edit/")) {
                dispatch(
                  uiActions.alertPopup({
                    enable: true,
                    type: MODAL_TYPE?.ALERT,
                    message: t("generalLedgerSetup.profileModelsProfileError"),
                    title: t("common.simsFMSModule"),
                    notificationType: NotificationStatus?.ERROR,
                    className: "primary-focus"
                  })
                );
              } else {
                dispatch(setInputError(false));
                // API Dispatch code
                const newDataToAdd = {
                  ...profileSelectedRow,
                  model_des: inputText,
                  model_des_upper: inputText.toLocaleUpperCase(),
                  periods: profileModalPeriod
                };
                const existingData = [...newProfileModalData]?.filter(
                  (t) => t?.model_des !== profileSelectedRow?.model_des
                );
                setToSession("saveDataOnTabChange", [...existingData, newDataToAdd]);
                dispatch(postProfileModelData());
                dispatch(setInputDetails({ id: 0, inputText: "", isFormDirty: false }));
                if (typeof yesFunc === "function") yesFunc();
              }
            } else {
              changeTab();
            }
          } else {
            const isPeriodValid = periodValidator();
            if (!isPeriodValid) {
              changeTab();
            } else {
              dispatch(setInputError(false));
              // API Dispatch code
              dispatch(postProfileModelData());
              dispatch(setInputDetails({ id: 0, inputText: "", isFormDirty: false }));
              if (typeof yesFunc === "function") yesFunc();
            }
          }
        },
        noCallback: () => {
          dispatch(setInputDetails({ id: 0, inputText: "", isFormDirty: false }));
          dispatch(resetNewProfileSlice());
          if (typeof noFunc === "function") noFunc();
        },
        isCancelBtnEnable: true,
        cancelCallback: () => {
          if (typeof cancelFunc === "function") cancelFunc();
        }
      })
    );
  };

  const cancelWarningPopup = () => {
    if (newProfileModalData.length > 0 || isRemaining) {
      dispatch(
        uiActions.confirmPopup({
          enable: true,
          message: t("generalLedgerSetup.cancelWarningMsg"),
          title: t("common.simsFMSModule"),
          type: MODAL_TYPE.CONFIRMV2,
          yesCallback: async () => {
            dispatch(resetNewProfileSlice());
            history.push("/");
          },
          noCallback: () => {
            history.push("/tools/general-ledger-setup/profile-models");
          }
        })
      );
    } else {
      history.push("/");
    }
  };
  return {
    isInputValid,
    confirmationPopup,
    periodValidator,
    cancelWarningPopup,
    isRemaining
  };
};

export default useProfileModelForm;
