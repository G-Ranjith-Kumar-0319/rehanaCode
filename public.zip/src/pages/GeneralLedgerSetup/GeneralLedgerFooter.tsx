import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import React from "react";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, TabPanel } from "@essnextgen/ui-kit";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { useLocation } from "react-router-dom";

interface GenralLedgerFooterProps {
  onSubmit?: () => void; // Required function for submission
  cancelCallback?: () => void; // Optional function for cancellation
  saveAndContinue?: () => void; // Optional function for cancellation
  backCtaCallback?: {
    backCta: () => void;
    isDisabled: boolean;
    title?: string;
  };
  nextCtaCallback?: {
    nextCta: () => void;
    isDisabled: boolean;
    title?: string;
  };
  finishCtaCallback?: {
    finishCta: () => void;
    isDisabled: boolean;
  };
}
const GenralLedgerFooter: React.FC<GenralLedgerFooterProps> = ({
  onSubmit,
  cancelCallback,
  saveAndContinue,
  backCtaCallback,
  nextCtaCallback,
  finishCtaCallback
}) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const location = useLocation();

  return (
    <>
      <div className="tab__container footer-cta-container">
        <TabPanel
          aria-labelledby="tab-1"
          id="panel-1"
          className="d-block border-none"
        >
          <Grid container>
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={6}
              className="grid-container-item save-cancel-button"
            >
              <div className="rightbtn ">
                {onSubmit && (
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Primary}
                    onClick={onSubmit}
                    id="saveButton"
                    className="focus-cta"
                  >
                    {t("common.save")}
                  </Button>
                )}
                {saveAndContinue && (
                  <Button
                    id="gl-footer-conitiue-callback"
                    onClick={saveAndContinue}
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    className="focus-cta"
                  >
                    {t("common.saveAndContinue")}
                  </Button>
                )}

                {nextCtaCallback && (
                  <Button
                    id="gl-footer-next-callback"
                    onClick={nextCtaCallback.nextCta}
                    size={ButtonSize.Small}
                    color={ButtonColor.Primary}
                    disabled={nextCtaCallback.isDisabled}
                  >
                    {nextCtaCallback?.title || t("common.next")}
                  </Button>
                )}
                {finishCtaCallback && (
                  <Button
                    onClick={finishCtaCallback.finishCta}
                    size={ButtonSize.Small}
                    color={ButtonColor.Primary}
                    disabled={finishCtaCallback.isDisabled}
                  >
                    {t("common.finish")}
                  </Button>
                )}
                {backCtaCallback && (
                  <Button
                    id="gl-footer-back-callback"
                    onClick={backCtaCallback.backCta}
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    disabled={backCtaCallback.isDisabled}
                  >
                    {backCtaCallback?.title || t("common.back")}
                  </Button>
                )}
                {cancelCallback && (
                  <Button
                    id="gl-footer-cancel-callback"
                    onClick={cancelCallback}
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    className="focus-cta"
                  >
                    {t("common.cancel")}
                  </Button>
                )}
              </div>
            </GridItem>
            <GridItem
              sm={2}
              md={4}
              lg={6}
              xl={6}
              className="grid-container-item"
            >
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </GridItem>
          </Grid>
        </TabPanel>
      </div>
    </>
  );
};
GenralLedgerFooter.defaultProps = {
  cancelCallback: undefined,
  saveAndContinue: undefined,
  onSubmit: undefined,
  backCtaCallback: undefined,
  nextCtaCallback: undefined,
  finishCtaCallback: undefined
};

export default GenralLedgerFooter;
