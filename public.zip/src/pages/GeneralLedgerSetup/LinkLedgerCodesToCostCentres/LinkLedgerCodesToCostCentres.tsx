import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import { Button, ButtonColor, ButtonSize, FormLabel, Grid, GridItem } from "@essnextgen/ui-kit";

const LinkLedgerCodesToCostCentres = () => (
  <>
    <Layout pageTitle="General Ledger Setup">
      <Grid>
        <GridItem
          sm={4}
          md={8}
          lg={6}
          xl={6}
        >
          <Grid className="mb-16">
            <GridItem sm={4}>
              <div className="essui-global-typography-default-subtitle">Available Cost Centres</div>
            </GridItem>
          </Grid>
        </GridItem>
        <GridItem
          sm={4}
          md={8}
          lg={6}
          xl={6}
        >
          <Grid className="mb-16">
            <GridItem sm={4}>
              <div className="essui-global-typography-default-subtitle">Available Ledger Codes</div>
            </GridItem>
          </Grid>
        </GridItem>
      </Grid>
    </Layout>

    <Layout isBreadcrumbRequired={false}>
      <Grid>
        <GridItem
          sm={4}
          md={4}
          lg={6}
          xl={6}
        >
          <div>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Tertiary}
            >
              Help
            </Button>
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={4}
          lg={6}
          xl={6}
        >
          <div className="d-flex justify-end gap-8 justify-start-resposnive">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
            >
              Cancel
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
            >
              Create Links
            </Button>
          </div>
        </GridItem>
      </Grid>
    </Layout>
  </>
);
export default LinkLedgerCodesToCostCentres;
