import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { useHistory, useParams, useLocation } from "react-router-dom";
import getLowerCaseText from "../../ProfileModels/utils";
import { costCentreActions, postCostCentrePayload, TCostCentreTree, TreeNode } from "../../State/CostCentresTab.slice";
import useCostCentreForm from "./useCostCentreForm";

type TConfirmationPopup = {
  yesFunc?: () => void;
  noFunc?: () => void;
  cancelFunc?: () => void;
  changeTab: () => void;
  inputValidation?: boolean;
  inputDetailValidation?: boolean;
};
const useCostCentrePopup = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { id }: any = useParams();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const location = useLocation();
  const {
    costCentreGrpList,
    grpInputDetails,
    newCCGList,
    focusedItem,
    ccdErrorsState,
    costCentreGroupDeletedId,
    costCentreDetailsDeleteId,
    newCostDetailList,
    costCenterPayload,
    costCenterTree
  } = useAppSelector((state) => state.glCostCentre);
  const { inputText } = grpInputDetails;
  const { validateFields, isLocalValid, onSubmit, setSubmitLoader } = useCostCentreForm();

  const { setGrpInputError, setInputDetails, setTreeNode, resetCostCenter, updateCostGrp } = costCentreActions;

  const isInputValid = (formText = inputText) => {
    if (formText.trim().length === 0) {
      dispatch(setGrpInputError(true));
      dispatch(
        uiActions.alertPopup({
          enable: true,
          type: MODAL_TYPE?.ALERT,
          message: t("generalLedgerSetup.costGroupMessage"),
          title: t("common.simsFMSModule"),
          notificationType: NotificationStatus?.ERROR
        })
      );

      return false;
    }

    let isDuplicated = false;
    if (location.pathname.includes("/tools/cost-centres/add-cost-group")) {
      isDuplicated = costCentreGrpList.some(
        (data) =>
          getLowerCaseText(data.description) === getLowerCaseText(formText) ||
          newCCGList.some((data) => getLowerCaseText(data.data) === getLowerCaseText(formText))
      );
    } else {
      const newlist = newCCGList.map((data) => ({
        ...data,
        description: data.data
      }));
      isDuplicated = [...costCentreGrpList, ...newlist].some(
        (data) =>
          getLowerCaseText(data.description) === getLowerCaseText(formText) &&
          getLowerCaseText(data.description) !== getLowerCaseText(focusedItem.data)
      );
    }

    if (isDuplicated) {
      dispatch(
        uiActions.alertPopup({
          enable: true,
          type: MODAL_TYPE?.ALERT,
          message: t("generalLedgerSetup.uniqueMessage"),
          title: t("common.simsFMSModule"),
          notificationType: NotificationStatus?.ERROR
        })
      );

      return false;
    }
    if (!focusedItem.isFolder) {
      dispatch(
        uiActions.alertPopup({
          enable: true,
          type: MODAL_TYPE?.ALERT,
          message: t("generalLedgerSetup.costCentres.costGrpFailedMsg"),
          title: t("common.simsFMSModule"),
          notificationType: NotificationStatus?.ERROR,
          callback: () => {
            history.push("/tools/general-ledger-setup/cost-centres");
          }
        })
      );

      return false;
    }
    return true;
  };

  const confirmationPopupCCG = ({
    yesFunc,
    noFunc,
    cancelFunc,
    changeTab,
    inputValidation = false,
    inputDetailValidation = false
  }: TConfirmationPopup) => {
    dispatch(
      uiActions.confirmPopup({
        enable: true,
        message: t("common.keepChangesWishMsg"),
        title: t("common.simsFMSModule"),
        type: MODAL_TYPE.CONFIRMV2,
        yesCallback: async () => {
          if (inputValidation) {
            const isValid = isInputValid();
            if (isValid) {
              const isCreated = location.pathname.includes("/cost-centres/add-cost-group") || focusedItem.id === 0;
              const auditDes = isCreated
                ? `New Cost Centre Group: ${inputText} added to group: ${focusedItem.data}`
                : `Cost Centre Group: ${focusedItem.data} renamed to: ${inputText}`;

              const obj: TreeNode = {
                id: isCreated ? 0 : focusedItem.id,
                isFolder: true,
                children: [],
                index: isCreated ? inputText : focusedItem.index,
                data: inputText,
                parent_group_id: focusedItem.id !== 0 ? focusedItem.id : focusedItem.index,
                audit_desc: auditDes
              };

              if (location.pathname.includes("/cost-centres/add-cost-group")) {
                dispatch(setTreeNode(obj));
              } else {
                dispatch(updateCostGrp(obj));
              }
              dispatch(postCostCentrePayload());
              dispatch(setInputDetails({ id: 0, inputText: "", isFormDirty: false }));
              if (typeof yesFunc === "function") yesFunc();
            } else {
              changeTab();
            }
          } else if (inputDetailValidation) {
            dispatch(costCentreActions.setSubmitting(true));
            const isValid = isLocalValid() || (await validateFields(true));
            dispatch(costCentreActions.setSubmitting(false));
            if (isValid) {
              onSubmit(true);
              dispatch(postCostCentrePayload());
              if (typeof yesFunc === "function") yesFunc();
            } else {
              changeTab();
            }
          } else {
            dispatch(setInputDetails({ id: 0, inputText: "", isFormDirty: false }));
            if (typeof yesFunc === "function") yesFunc();
            dispatch(postCostCentrePayload());
          }
        },
        noCallback: () => {
          dispatch(setInputDetails({ id: 0, inputText: "", isFormDirty: false }));
          dispatch(
            costCentreActions.setCDInputDetail({
              code_id: 0,
              description: "",
              isFormDirty: false
            })
          );
          dispatch(resetCostCenter());
          if (typeof noFunc === "function") noFunc();
        },
        isCancelBtnEnable: true,
        cancelCallback: () => {
          if (typeof cancelFunc === "function") cancelFunc();
        }
      })
    );
  };

  const areAllPropertiesNull = (obj: any) => Object.values(obj).every((value) => value === null);

  const isPaylodValid = () =>
    costCentreGroupDeletedId?.length > 1 ||
    newCCGList?.length > 0 ||
    costCentreDetailsDeleteId?.length > 1 ||
    newCostDetailList?.length > 0 ||
    Object.keys(costCenterTree as TCostCentreTree).filter((key) => {
      const obj = costCenterTree[key];
      return obj.is_dragged;
    }).length > 0;

  const cancelWarningPopup = () => {
    if (isPaylodValid()) {
      dispatch(
        uiActions.confirmPopup({
          enable: true,
          message: t("generalLedgerSetup.cancelWarningMsg"),
          title: t("common.simsFMSModule"),
          type: MODAL_TYPE.CONFIRMV2,
          yesCallback: async () => {
            dispatch(resetCostCenter());
            history.push("/");
          },
          noCallback: () => {
            history.push("/tools/general-ledger-setup/cost-centres");
          }
        })
      );
    } else {
      history.push("/");
    }
  };

  return {
    isInputValid,
    confirmationPopupCCG,
    cancelWarningPopup,
    areAllPropertiesNull,
    isPaylodValid
  };
};

export default useCostCentrePopup;
