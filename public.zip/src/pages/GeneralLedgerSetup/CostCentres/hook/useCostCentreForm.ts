import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useForm } from "react-hook-form";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useAppSelector } from "@/store/store";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { BOOLEAN_DATA, STATUS } from "@/types/UseStateType";
import { useHistory, useParams } from "react-router-dom";
import useDebounce from "@/hooks/useDebounce";
import {
  costCentreActions,
  getCostCenterDetailList,
  TreeNode,
  validateCostCentreAbrvYear,
  validateCostCentreCodeYear,
  validateCostCentreDescYear
} from "../../State/CostCentresTab.slice";
import { isArrayLength, isTextEqual } from "../../ProfileModels/utils";
import { deepSome } from "../../utils";

/* eslint-disable camelcase */
export type FormData = {
  cost_code: string;
  cost_des: string;
  cost_abrv: string;
  cost_hold: any;
  threshold: any;
  spendcheck: any;
};
/* eslint-enable camelcase */
const useCostCentreForm = () => {
  const {
    register,
    getFieldState,
    formState: { errors, isDirty },
    getValues,
    setError,
    setValue,
    trigger,
    watch,
    handleSubmit,
    clearErrors,
    reset,
    setFocus
  } = useForm<FormData>({
    defaultValues: {
      threshold: 100,
      spendcheck: true,
      cost_code: "",
      cost_des: "",
      cost_abrv: ""
    }
  });

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const { index }: { index: string } = useParams();
  const {
    isCodeExist,
    isDescExist,
    isAbbrExist,
    costCenterDetailList,
    ccdErrorsState,
    focusedItem,
    ccdInputDetail,
    costCenterTree,
    constCenterDetails,
    expandedItems,
    status
  } = useAppSelector((state) => state.glCostCentre);
  const loading = status === STATUS.LOADING;
  const { previousYear, nextYear, previousState } = useAppSelector((state: any) => state.generalLedgerFundCode);
  const [submitLoader, setSubmitLoader] = useState(false);

  const findCodeInPreNextYear = async (year: string) =>
    dispatch(validateCostCentreCodeYear({ costId: 0, costCode: ccdInputDetail?.cost_code, yearId: year }));
  const findDescInPreNextYear = async (year: string) =>
    dispatch(validateCostCentreDescYear({ costId: 0, costDes: ccdInputDetail?.cost_des, yearId: year }));
  const findAbbrInPreNextYear = async (year: string) =>
    dispatch(validateCostCentreAbrvYear({ costId: 0, costAbrv: ccdInputDetail?.cost_abrv, yearId: year }));
  const { setErrorState } = costCentreActions;

  const getAlertMessage = (message: string) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        message: t(`generalLedgerSetup.costCentre.${message}`),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus.ERROR
      })
    );
  };

  const clearErrorState = (field: keyof FormData) => {
    dispatch(setErrorState({ ...ccdErrorsState, [field]: false }));
    clearErrors(field);
  };

  // update errors if focus out and Response from endpoint change
  useEffect(() => {
    const updatedErrors = {
      ...ccdErrorsState,
      ...(isCodeExist && { cost_code: isCodeExist === BOOLEAN_DATA?.True }),
      ...(isDescExist && { cost_des: isDescExist === BOOLEAN_DATA?.True }),
      ...(isAbbrExist && { cost_abrv: isAbbrExist === BOOLEAN_DATA?.True })
    };
  }, [isCodeExist, isDescExist, isAbbrExist]);
  //
  const handleErrorByField = (field: keyof FormData, error: string, showPopup = false) => {
    dispatch(setErrorState({ ...ccdErrorsState, [field]: true }));
    if (showPopup) {
      getAlertMessage(error);
    }
  };

  const validateCode = async (value: string, showPopup = false) => {
    let errorMessage = "";
    // Check if the cost code is unique in the current list
    const found = deepSome(costCenterDetailList, value, "cost_code");
    // Return true if Edit mode as field is disable on edit
    if (index) {
      return true;
    }
    // Validate cost code
    if (!value) {
      errorMessage = "costCodeRequired";
    } else if (found) {
      errorMessage = "costCodeNotUnique";
    } else if (nextYear && nextYear !== 0) {
      const res: any = await findCodeInPreNextYear(nextYear);
      if (res?.payload === BOOLEAN_DATA.True) {
        errorMessage = "costCodeExistInNextYear";
      } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
        clearErrorState("cost_code");
      }
    } else if (previousYear && previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
      const res: any = await findCodeInPreNextYear(previousYear);
      if (res?.payload === BOOLEAN_DATA.True) {
        errorMessage = "costCodeExistInPrevYear";
      } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
        clearErrorState("cost_code");
      }
    }
    // Handle error message if any
    if (errorMessage) {
      handleErrorByField("cost_code", errorMessage, showPopup);
      return false;
    }
    clearErrorState("cost_code");
    return true;
  };

  const validateDescription = async (value: string, showPopup = false) => {
    let errorMessage = "";
    let dontMatchWith;
    // For Edit
    if (index) {
      dontMatchWith = costCenterDetailList?.find((t) => isTextEqual(t?.cost_des, constCenterDetails?.cost_des));
    }
    const found = value && deepSome(costCenterDetailList, value, "cost_des", index && dontMatchWith?.cost_des);
    // Validate description
    if (!value) {
      errorMessage = "costDescRequired";
    } else if (previousYear && previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
      const notToCallAPi = index && !ccdInputDetail?.isFormDirty;
      if (!notToCallAPi) {
        const res: any = await findDescInPreNextYear(previousYear);
        if (res.payload === BOOLEAN_DATA.True) {
          errorMessage = "costDescExistInPrevYear";
        } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
          clearErrorState("cost_des");
        }
      }
    } else if (nextYear && nextYear !== 0) {
      const notToCallAPi = index && !ccdInputDetail?.isFormDirty;
      if (!notToCallAPi) {
        const res: any = await findDescInPreNextYear(nextYear);
        if (res.payload === BOOLEAN_DATA.True) {
          errorMessage = "costDescExistInNextYear";
        } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
          clearErrorState("cost_des");
        }
      }
    }

    if (found && errorMessage === "") {
      errorMessage = "costDescNotUnique";
    }
    // Handle error message if any
    if (errorMessage) {
      handleErrorByField("cost_des", errorMessage, showPopup);
      return false;
    }

    // Clear error state
    clearErrorState("cost_des");
    return true;
  };

  const validateAbbreviation = async (value: string, showPopup = false) => {
    let errorMessage = "";
    let dontMatchWith;
    // For Edit
    if (index) {
      dontMatchWith = costCenterDetailList?.find((t) => isTextEqual(t?.cost_abrv, constCenterDetails?.cost_abrv));
    }
    const found = value && deepSome(costCenterDetailList, value, "cost_abrv", index && dontMatchWith?.cost_abrv);
    // Validate abbreviation
    if (!value) {
      errorMessage = "costAbbRequired";
    } else if (previousYear && previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
      const notToCallApi = index && !ccdInputDetail?.isFormDirty;
      if (!notToCallApi) {
        const res: any = await findAbbrInPreNextYear(previousYear);
        if (res?.payload === BOOLEAN_DATA.True) {
          errorMessage = "costAbbExistInPrevYear";
        } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
          clearErrorState("cost_abrv");
        }
      }
    } else if (nextYear && nextYear !== 0) {
      const notToCallApi = index && !ccdInputDetail?.isFormDirty;
      if (!notToCallApi) {
        const res: any = await findAbbrInPreNextYear(nextYear);
        if (res?.payload === BOOLEAN_DATA.True) {
          errorMessage = "costAbbExistInNextYear";
        } else if (res?.payload === BOOLEAN_DATA.False && value && !found) {
          clearErrorState("cost_abrv");
        }
      }
    }
    if (found && errorMessage === "") {
      errorMessage = "costAbbNotUnique";
    }
    // Handle error message if any
    if (errorMessage) {
      handleErrorByField("cost_abrv", errorMessage, showPopup);
      return false;
    }
    // Clear error state
    clearErrorState("cost_abrv");
    return true;
  };

  const validateThreasHold = (value: string, showPopup = false) => {
    if (value === "") {
      handleErrorByField("threshold", "costDetailFailedMsg", showPopup);
      return false;
    }
    dispatch(setErrorState({ ...ccdErrorsState, threshold: false }));
    clearErrorState("threshold");
    return true;
  };

  const validateFields = async (showPopup = false) => {
    const values = ccdInputDetail || getValues();
    if (
      (await validateCode(values.cost_code, showPopup)) &&
      (await validateDescription(values.cost_des, showPopup)) &&
      (await validateAbbreviation(values.cost_abrv, showPopup)) &&
      validateThreasHold(values.threshold, showPopup)
    ) {
      return true;
    }
    return false;
  };

  const getAbbreviationValue = () => {
    let description = watch("cost_des");
    if (description.length > 12) {
      description = description.substring(0, 12);
    }
    setValue("cost_abrv", description);
  };

  const goToListPage = () => {
    history.push("/tools/general-ledger-setup/cost-centres");
  };

  const clearForm = () => {
    setValue("cost_code", "");
    setValue("cost_des", "");
    setValue("cost_abrv", "");
    setValue("cost_hold", "");
    setValue("spendcheck", true);
    setValue("threshold", 100);
    setFocus("cost_code"); // Focus after save and continue...
  };

  const getParentId = () => {
    if (index) {
      // Assuming it's edit mode
      return focusedItem?.parent_group_id || focusedItem?.index;
    }
    return focusedItem?.id || focusedItem?.index;
  };

  const findParent = () => {
    const index =
      typeof focusedItem?.parent_group_id === "number"
        ? `${focusedItem?.parent_group_id}_CG`
        : focusedItem?.parent_group_id;
    return costCenterTree[index];
  };

  const parentData = findParent();

  const newCCD = {
    cost_id: index ? focusedItem?.id : 0,
    cost_code: ccdInputDetail.cost_code,
    cost_abrv: ccdInputDetail.cost_abrv,
    cost_des: ccdInputDetail.cost_des,
    cost_hold: ccdInputDetail.cost_hold,
    spendcheck: ccdInputDetail.spendcheck,
    threshold: ccdInputDetail?.threshold,
    commitment: 0,
    unpaid: 0,
    exp_budget_limit: 0,
    inc_budget_limit: 0,
    audit_desc: `${t("generalLedgerSetup.costCentre.newCostCenter")}: ${`${watch("cost_code")} ${watch("cost_des")}`}`,
    cost_group_id: index ? parentData?.id : focusedItem?.id,
    cost_group_desc: index ? parentData?.data : focusedItem?.data,
    parent_group_id: index ? parentData?.parent_group_id : focusedItem?.parent_group_id
  };

  const submitCostDetail = () => {
    const treeObj: TreeNode = {
      id: index ? focusedItem?.id : 0,
      isFolder: false,
      children: [],
      index: focusedItem?.index.includes("_CC") ? focusedItem?.index : watch("cost_des"),
      data: watch("cost_des"),
      parent_group_id: getParentId()
    };
    if (index) {
      // Edit Mode
      dispatch(costCentreActions.updatedTreeNode({ ...treeObj, index }));
      dispatch(costCentreActions.setCostCenterForView(newCCD));
      dispatch(costCentreActions.setFocusedItem(treeObj));
    } else {
      // Create Mode
      dispatch(costCentreActions.setTreeNode(treeObj)); // Add item in tree for view
      dispatch(costCentreActions.setExpandedItems([...new Set([...expandedItems, focusedItem?.index])] as string[]));
    }
    dispatch(costCentreActions.updateCcgList(newCCD)); // Push in new ccg list for payload
    dispatch(costCentreActions.toViewCostCenterDetail(newCCD)); // Push to view CC Detail
  };

  const isLocalValid = () => Object.values(ccdErrorsState)?.every((t) => t === false);
  // Submit Form
  const onSubmit = async (isContinue: boolean) => {
    dispatch(costCentreActions.setSubmitting(true));
    const isValid = isLocalValid() || (await validateFields(true));
    if (isValid && !isContinue) {
      // On Save---
      submitCostDetail();
      goToListPage(); // Redirect to list page---
    } else if (isValid) {
      // On Save And Continue---
      submitCostDetail();
      clearForm();
    }
    dispatch(costCentreActions.setSubmitting(false));
  };
  return {
    register,
    errors,
    setValue,
    watch,
    handleSubmit,
    getAbbreviationValue,
    validateFields,
    validateCode,
    validateDescription,
    validateAbbreviation,
    trigger,
    reset,
    getValues,
    setFocus,
    clearForm,
    goToListPage,
    validateThreasHold,
    isDirty,
    onSubmit,
    isLocalValid,
    setSubmitLoader,
    submitLoader
  };
};

export default useCostCentreForm;
