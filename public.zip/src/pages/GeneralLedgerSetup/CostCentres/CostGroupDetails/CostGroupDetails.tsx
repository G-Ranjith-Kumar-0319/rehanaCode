import { Grid, GridItem } from "@essnextgen/ui-kit";
import { useAppSelector } from "@/store/store";

const CostGroupDetails = () => {
  const { focusedItem } = useAppSelector((state: any) => state?.glCostCentre);

  return (
    <div className="general-ledger-listing-container general-ledger-scroll-height">
      <Grid>
        <GridItem>
          <Grid className="mb-16">
            <GridItem sm={4}>
              <div className="essui-global-typography-default-subtitle">COST GROUP DETAILS</div>
            </GridItem>
          </Grid>
          <Grid className="row-gap-16 marginb15">
            <GridItem>
              <div className="essui-form-label mb-8">Description</div>
              <div>{focusedItem?.data}</div>
            </GridItem>
          </Grid>
        </GridItem>
      </Grid>
    </div>
  );
};

export default CostGroupDetails;
