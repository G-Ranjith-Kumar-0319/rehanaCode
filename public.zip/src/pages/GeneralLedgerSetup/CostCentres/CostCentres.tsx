import {
  Button,
  ButtonSize,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  Loader,
  LoaderType,
  Notification,
  NotificationStatus
} from "@essnextgen/ui-kit";
import { DocumentAdd, FolderAdd, Subtract } from "@carbon/icons-react";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import { useDispatch } from "react-redux";
import { StaticTreeDataProvider } from "react-complex-tree";
import { useHistory, useLocation } from "react-router-dom";
import { BOOLEAN_DATA, STATUS } from "@/types/UseStateType";
import { getSessionItem, setToSession } from "@/utils/getDataSource";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import {
  costCentreActions,
  getCostCentreTree,
  TreeNode,
  ValidateCostCentreGroup,
  postCostCentrePayload
} from "../State/CostCentresTab.slice";
import GeneralLedgerSetup from "../GeneralLedgerSetup";
import CostCentreTree from "./components/CostCentreTree";
import CostCentreDetails from "./CostCentreDetails/CostCentreDetails";
import CostGroupDetails from "./CostGroupDetails/CostGroupDetails";
import GenralLedgerFooter from "../GeneralLedgerFooter";
import { getNextYear, getPreviousYear, getPrevState } from "../State/GeneralLedgerFundCodeListing.slice";
import useCostCentrePopup from "./hook/useCostCentrePopup";
import { isTextEqual } from "../ProfileModels/utils";

const CostCentres = () => {
  const {
    costCenterTree,
    costCenterPayload,
    focusedItem,
    costCentreGroupDeletedId,
    costCentreDetailsDeleteId,
    costCenterDetailList,
    status,
    newCCGList,
    newCostDetailList,
    isViewLoading,
    constCenterDetails
  } = useAppSelector((state) => state.glCostCentre);
  const { isPaylodValid, areAllPropertiesNull, cancelWarningPopup } = useCostCentrePopup();

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const location = useLocation();

  const {
    updateCostCentreTree,
    costCentreGroupAllDeletedIds,
    costCentreDetailedIds,
    setSelectedItems,
    setFocusedItem,
    resetNewCCGList,
    updateUniqueCheckList,
    updateNewCostDetaiList
  } = costCentreActions;
  const { previousYear, nextYear, previousState } = useAppSelector((state: any) => state.generalLedgerFundCode);
  const [isOpen, setIsOpen] = useState(false);
  const dispatch = useDispatch<AppDispatch>();
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [deletedIds, setDeletedIds] = useState<any>();
  const [costCentreDeletedIds, setCostCentreDeletedIds] = useState<any>();
  const [validateYear, setValidateYear] = useState(false);
  const history = useHistory();

  const isWarnBudget = getSessionItem("glWarnBudget");
  const getAlertMessage = (message: string) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: MODAL_TYPE.ALERT,
        message: t(`generalLedgerSetup.ledgerCode.${message}`),
        title: t("common.simsFMSModule"),
        notificationType: NotificationStatus.WARNING,
        callback: () => {
          setToSession("glWarnBudget", true);
          history.push("/tools/cost-centres/add-file");
        }
      })
    );
  };

  const createCostCenterDetail = () => {
    if (isWarnBudget === false) {
      getAlertMessage("warnBudgetAlertMsg");
    } else {
      history.push("/tools/cost-centres/add-file");
    }
  };

  const onSubmitHandler = () => {
    if (isPaylodValid()) {
      dispatch(postCostCentrePayload());
    }
  };

  const deleteItem = (keyToDelete: any) => {
    if (deletedIds) {
      setDeletedIds([...deletedIds, keyToDelete]);
    } else {
      setDeletedIds([keyToDelete]);
    }

    const updatedItems = Object.keys(costCenterTree)
      .filter((key) => costCenterTree[key].index !== keyToDelete)
      .reduce((acc: any, key) => {
        acc[key] = costCenterTree[key];
        return acc;
      }, {});

    const index = newCCGList.findIndex((child) => child.index === focusedItem.index);
    const newCCGListFinal = [...newCCGList];

    if (index !== -1) {
      newCCGListFinal.splice(index);
    }
    if (focusedItem.id === 0) {
      dispatch(resetNewCCGList(newCCGListFinal));
    }
    const parentIndex =
      typeof focusedItem.parent_group_id === "number"
        ? `${focusedItem.parent_group_id}_CG`
        : focusedItem.parent_group_id;
    const parentId = costCenterTree[parentIndex];
    const updatedChildren = parentId.children.filter((val) => val !== focusedItem.index);
    const cloneParent = { ...parentId };
    cloneParent.children = updatedChildren;

    const cloneTree = { ...costCenterTree };
    cloneTree[`${parentId.id}_CG`] = cloneParent;

    dispatch(updateCostCentreTree(cloneTree));
    const elements = document.getElementsByClassName(`cost__center-tree-list ${keyToDelete}`);
    for (let i = 0; i < elements.length; i += 1) {
      const abc = elements[i] as HTMLElement;
      abc.style.display = "none";
    }

    dispatch(
      costCentreGroupAllDeletedIds({
        cost_group_id: focusedItem.id,
        audit_desc: `Cost Centre Group Deleted:${focusedItem.data}`
      })
    );
  };

  useEffect(() => {
    if (costCentreGroupDeletedId.length > 1 && deletedIds) {
      deletedIds.forEach((val: any) => {
        const elements = document.getElementsByClassName(`cost__center-tree-list ${val}`);
        for (let i = 0; i < elements.length; i += 1) {
          const abc = elements[i] as HTMLElement;
          abc.style.display = "none";
        }
      });
    }
  });

  useEffect(() => {
    document.getElementById("saveButton")?.focus();
    document.getElementById("saveButton")?.blur();
  }, [isDeleteOpen, isOpen]);

  const setSelectedItemData = () => {
    const parentIndex =
      typeof focusedItem.parent_group_id === "number"
        ? `${focusedItem.parent_group_id}_CG`
        : focusedItem.parent_group_id;
    const parentId = costCenterTree[parentIndex];
    const updatedChildren = parentId.children.filter((val) => val !== focusedItem.index);
    const cloneParent = { ...parentId };
    cloneParent.children = updatedChildren;

    const cloneTree = { ...costCenterTree };
    cloneTree[parentIndex] = cloneParent;

    dispatch(updateCostCentreTree(cloneTree));
    const childLength = cloneParent.children.length;
    const index = parentId.children.findIndex((child) => child === focusedItem.index);
    let selectedId;
    if (index === childLength && cloneParent.children.length > 0) {
      selectedId = parentId.children[index - 1];
    } else if (cloneParent.children.length > 0) {
      selectedId = parentId.children[index + 1];
    } else if (cloneParent.children.length === 0) {
      selectedId = parentIndex;
    }
    return selectedId;
  };

  const getCostCentreDeleteId = () => {
    const parentIndex =
      typeof focusedItem.parent_group_id === "number"
        ? `${focusedItem.parent_group_id}_CG`
        : focusedItem.parent_group_id;
    const parentId = costCenterTree[parentIndex];
    const updatedChildren = parentId.children.filter((val) => val !== focusedItem.index);
    const cloneParent = { ...parentId };
    cloneParent.children = updatedChildren;

    const cloneTree = { ...costCenterTree };
    cloneTree[parentIndex] = cloneParent;
    if (focusedItem.id > 0 && cloneTree[focusedItem.index].children.length === 0) {
      dispatch(
        ValidateCostCentreGroup({
          cost_group_id: focusedItem.id,
          editGroup: true,
          callback: (response: any) => {
            if (response === 1) {
              setIsOpen(true);
            } else {
              deleteItem(focusedItem.index);
              const selectedId = setSelectedItemData();
              const id = focusedItem.parent_group_id;
              const tree = costCenterTree[`${selectedId}`];
              dispatch(setFocusedItem(tree as TreeNode));
              dispatch(setSelectedItems([`${selectedId}`]));
            }
          }
        })
      );
    } else if (focusedItem.id === 0 && cloneTree[focusedItem.index].children.length === 0) {
      deleteItem(focusedItem.index);
      const selectedId = setSelectedItemData();

      const id = focusedItem.parent_group_id;
      const tree = costCenterTree[`${selectedId}`];
      dispatch(setFocusedItem(tree as TreeNode));
      dispatch(setSelectedItems([`${selectedId}`]));
    } else {
      setIsOpen(true);
    }
  };

  // Manage edit route on edit file or folder accordingly
  const handleEditCostCenter = () => {
    const baseRoute = focusedItem?.isFolder ? "edit-cost-group" : "edit-file";
    history.push(`/tools/cost-centres/${baseRoute}/${focusedItem.index}`);
  };

  // Get "Next Year/Prev Year/Prev State" on load
  useEffect(() => {
    if (!previousState) dispatch(getPrevState());
    if (!nextYear) dispatch(getNextYear());
    if (!previousYear) dispatch(getPreviousYear());
  }, []);

  // const center delete
  const constCenterDetailsItem = (keyToDelete: any) => {
    if (costCentreDeletedIds) {
      setCostCentreDeletedIds([...costCentreDeletedIds, keyToDelete]);
    } else {
      setCostCentreDeletedIds([keyToDelete]);
    }
    const updatedItems = Object.keys(costCenterTree)
      .filter((key) => costCenterTree[key].index !== keyToDelete)
      .reduce((acc: any, key) => {
        acc[key] = costCenterTree[key];
        return acc;
      }, {});

    const index = newCostDetailList?.findIndex((child) => child.cost_des === focusedItem.data);
    const newCCDListFinal = [...newCostDetailList];
    if (index !== -1) {
      newCCDListFinal.splice(index);
    }
    if (focusedItem.id === 0) {
      dispatch(updateNewCostDetaiList(newCCDListFinal));
    }
    const parentIndex =
      typeof focusedItem.parent_group_id === "number"
        ? `${focusedItem.parent_group_id}_CG`
        : focusedItem.parent_group_id;
    const parentId = costCenterTree[parentIndex];
    const updatedChildren = parentId.children.filter((val) => val !== focusedItem.index);
    const cloneParent = { ...parentId };
    cloneParent.children = updatedChildren;

    const cloneTree = { ...costCenterTree };
    cloneTree[parentIndex] = cloneParent;

    dispatch(updateCostCentreTree(cloneTree));
    const elements = document.getElementsByClassName(`cost__center-tree-list ${keyToDelete}`);
    for (let i = 0; i < elements.length; i += 1) {
      const abc = elements[i] as HTMLElement;
      abc.style.display = "none";
    }

    dispatch(
      costCentreDetailedIds({
        cost_id: focusedItem.id,
        audit_desc: `Cost Centre Deleted:${focusedItem?.data}`
      })
    );
  };

  useEffect(() => {
    if (costCentreDetailsDeleteId.length > 1 && costCentreDeletedIds) {
      costCentreDeletedIds.forEach((val: any) => {
        const elements = document.getElementsByClassName(`cost__center-tree-list ${val}`);
        for (let i = 0; i < elements.length; i += 1) {
          const abc = elements[i] as HTMLElement;
          abc.style.display = "none";
        }
      });
    }
  });

  const removeFromUnqicheckList = () => {
    const removeFromUniqueCheck =
      costCenterDetailList && costCenterDetailList?.filter((t) => !isTextEqual(t?.cost_des, focusedItem?.data));
    dispatch(updateUniqueCheckList(removeFromUniqueCheck));
  };

  const getCostCentreDelete = () => {
    if (focusedItem.id > 0) {
      if (previousYear !== 0 && previousState !== BOOLEAN_DATA.False) {
        setValidateYear(true);
      } else {
        dispatch(
          ValidateCostCentreGroup({
            cost_group_id: focusedItem.id,
            editGroup: false,
            callback: (response: any) => {
              if (response === 1) {
                setIsDeleteOpen(true);
              } else {
                constCenterDetailsItem(focusedItem.index);
                removeFromUnqicheckList();
                const selectedId = setSelectedItemData();
                const id = focusedItem?.id;
                const tree = costCenterTree[`${selectedId}`];
                dispatch(setFocusedItem(tree as TreeNode));
                dispatch(setSelectedItems([`${selectedId}`]));
              }
            }
          })
        );
      }
    } else {
      constCenterDetailsItem(focusedItem.index);
      const selectedId = setSelectedItemData();

      const id = focusedItem.parent_group_id;
      const tree = costCenterTree[`${selectedId}`];
      dispatch(setFocusedItem(tree as TreeNode));
      dispatch(setSelectedItems([`${selectedId}`]));
      removeFromUnqicheckList();
    }
  };

  useEffect(() => {
    const allCtas = document.querySelectorAll(".focus-cta");
    let currentCta = 0;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Tab" && location.pathname === "/tools/general-ledger-setup/cost-centres") {
        e.preventDefault();
        const previousElement = document.activeElement;
        currentCta = previousElement ? currentCta % allCtas.length : 0;
        (allCtas[currentCta] as HTMLElement).focus();
        currentCta += 1;
      }
    };

    document.addEventListener("keydown", handleKeyDown);

    // Cleanup function to remove the event listener
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [location.pathname]);

  return (
    <>
      <GeneralLedgerSetup>
        <div className="wrapper general-ledger-listing-container general-ledger-scroll-height cost__center">
          {status === STATUS.LOADING ? (
            <Loader
              loaderType={LoaderType.Circular}
              loaderText="Please wait"
              isLoaderModal={false}
            />
          ) : (
            <Grid className="mt-8">
              <GridItem
                sm={4}
                md={8}
                lg={5}
                xl={5}
                className="cost__center-tree-grid"
              >
                <CostCentreTree />
              </GridItem>

              <GridItem
                lg={1}
                xl={1}
                className="button-list-container"
              >
                <div className="button-list">
                  <Button
                    className="cost-center-cta"
                    title={t("generalLedgerSetup.costCentres.addGroup")}
                    onClick={() => history.push("/tools/cost-centres/add-cost-group")}
                  >
                    <FolderAdd
                      width="24"
                      height="24"
                    />
                  </Button>
                  <Button
                    className={`cost-center-cta ${!focusedItem?.isFolder && "disabled"}`}
                    title={t("generalLedgerSetup.costCentres.addDetail")}
                    onClick={createCostCenterDetail}
                    disabled={!focusedItem?.isFolder}
                  >
                    <DocumentAdd
                      width="24"
                      height="24"
                    />
                  </Button>
                  <Button
                    className="cost-center-cta"
                    title={t("generalLedgerSetup.costCentres.editItem")}
                    disabled={!focusedItem?.parent_group_id || isViewLoading}
                    onClick={handleEditCostCenter}
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="edit--alt"
                      className={focusedItem?.parent_group_id ? "" : "button-disabled-icon "}
                    />
                  </Button>
                  <Button
                    className="cost-center-cta glcc-delete-cta"
                    title={t("generalLedgerSetup.costCentres.deleteItem")}
                    disabled={!focusedItem?.parent_group_id}
                    onClick={focusedItem?.isFolder ? getCostCentreDeleteId : getCostCentreDelete}
                  >
                    <Subtract
                      width="24"
                      height="24"
                      className={focusedItem?.parent_group_id ? "" : "button-disabled-icon "}
                    />
                  </Button>
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={8}
                lg={5}
                xl={5}
                className="border-left"
              >
                {focusedItem?.isFolder ? <CostGroupDetails /> : <CostCentreDetails />}
              </GridItem>
            </Grid>
          )}
        </div>
        <GenralLedgerFooter
          onSubmit={onSubmitHandler}
          cancelCallback={cancelWarningPopup}
        />
        <Modalv2
          className="essui-dialog cancel-popup"
          header={t("common.simsFMSModule")}
          isOpen={isDeleteOpen || isOpen}
          onClose={() => {
            setIsDeleteOpen(false);
            setIsOpen(false);
          }}
          primaryButton={
            <Button
              size={ButtonSize.Small}
              onClick={() => {
                setIsDeleteOpen(false);
                setIsOpen(false);
              }}
            >
              {t("common.ok")}
            </Button>
          }
        >
          <Notification
            actionElement={1}
            className="confirm-modal-text"
            dataTestId="switch-to-list-warning-id"
            escapeExits
            id="switch-to-list-warning-id"
            hideCloseButton
            status={NotificationStatus.WARNING}
            title={
              focusedItem?.isFolder
                ? `${t("generalLedgerSetup.costCentres.warningMsgCostCentreGroup")}`
                : `${t("generalLedgerSetup.costCentres.warningMsgCostCentreDetail")}`
            }
          />
        </Modalv2>
        <Modalv2
          className="essui-dialog cancel-popup"
          header={t("common.simsFMSModule")}
          isOpen={validateYear}
          onClose={() => {
            setValidateYear(false);
          }}
          primaryButton={
            <Button
              size={ButtonSize.Small}
              onClick={() => {
                setValidateYear(false);
              }}
            >
              {t("common.ok")}
            </Button>
          }
        >
          <Notification
            actionElement={1}
            className="confirm-modal-text"
            dataTestId="switch-to-list-warning-id"
            escapeExits
            id="switch-to-list-warning-id"
            hideCloseButton
            status={NotificationStatus.WARNING}
            title={`${t("generalLedgerSetup.costCentres.lastYearFinalised")}`}
          />
        </Modalv2>
      </GeneralLedgerSetup>
    </>
  );
};

export default CostCentres;
