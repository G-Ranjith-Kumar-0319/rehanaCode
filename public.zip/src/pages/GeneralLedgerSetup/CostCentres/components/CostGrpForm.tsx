import Input from "@/components/Input/Input";
import { FormLabel, Grid, GridItem, ValidationTextLevel } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { yupResolver } from "@hookform/resolvers/yup";
import { object, string } from "yup";
import { useForm } from "react-hook-form";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useHistory, useParams } from "react-router-dom";
import { useAppSelector } from "@/store/store";
import useCostCentrePopup from "../hook/useCostCentrePopup";
import {
  costCentreActions,
  getCostCentreGrps,
  getCostCentreTree,
  TCostCentreGrpForm,
  TreeNode
} from "../../State/CostCentresTab.slice";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import GenralLedgerFooter from "../../GeneralLedgerFooter";

type FormData = {
  costGrpName: string;
};

const CostGrpForm = ({ formType = TCostCentreGrpForm.CREATE }: { formType?: TCostCentreGrpForm }) => {
  const dispatch = useDispatch();
  const {
    setInputDetails,
    setTreeNode,
    setGrpInputError,
    setFocusedItem,
    setSelectedItems,
    updateCostGrp,
    setExpandedItems,
    setTabClick
  } = costCentreActions;
  const { callCostCentreGrpApi, focusedItem, newCCGList, calltreeApi, grpInputError, costCenterTree, expandedItems } =
    useAppSelector((state) => state.glCostCentre);
  const history = useHistory();
  const formSchema = object({
    costGrpName: string().max(32, "32 Character is required")
  });
  const { isInputValid } = useCostCentrePopup();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { index }: any = useParams();

  const {
    register,
    formState: { errors, isDirty },
    getValues,
    setValue,
    watch,
    setFocus
  } = useForm<FormData>({
    resolver: yupResolver(formSchema) as any,
    defaultValues: {
      costGrpName: ""
    }
  });

  const { onChange, name: fieldName, ref: fieldRef } = register("costGrpName");

  const costGrpName = watch("costGrpName"); // Watch change in Input value

  useEffect(() => {
    // On Load focus input and reset the error state
    setFocus("costGrpName");
    setGrpInputError(false);
  }, [setFocus]);

  useEffect(() => {
    // Call the Tree API Required as when user directly call the create/edit route
    if (calltreeApi) {
      dispatch(getCostCentreTree());
    }
  }, [calltreeApi]);

  useEffect(() => {
    // Call all the grp data to check for duplicates
    if (callCostCentreGrpApi) {
      dispatch(getCostCentreGrps());
    }
  }, [callCostCentreGrpApi]);

  useEffect(() => {
    // Update Input State during create and edit
    dispatch(setGrpInputError(false));
    const inputT = {
      id: getCcgID(), // give ID based on create and edit scenario
      inputText: costGrpName,
      isFormDirty: isDirty
    };
    dispatch(setInputDetails(inputT));
  }, [isDirty, costGrpName]);

  useEffect(() => {
    // Updates input value on edit
    if (formType === TCostCentreGrpForm.EDIT) {
      const ccgVal = costCenterTree[index] || "";
      setFocusedItem({ ...ccgVal });
      setSelectedItems([ccgVal.index]);
      setValue("costGrpName", ccgVal.data);
    }
  }, [costCenterTree]);

  const getCcgID = () => {
    if (formType === TCostCentreGrpForm.EDIT) {
      const ccgVal = costCenterTree[index];
      if (ccgVal === undefined) {
        history.push("/tools/cost-centres/add-cost-group/");
        return 0;
      }
      if (ccgVal?.id === 0) {
        return 0;
      }
      return ccgVal.id as number;
    }

    return 0;
  };
  const saveNewGrp = (updateFocus = false) => {
    dispatch(setInputDetails({ id: 0, inputText: "", isFormDirty: false }));
    const isCreated = formType === TCostCentreGrpForm.CREATE || focusedItem.id === 0;
    const auditDes = isCreated
      ? `New Cost Centre Group: ${costGrpName} added to group: ${focusedItem.data}`
      : `Cost Centre Group: ${focusedItem.data} renamed to: ${costGrpName}`;

    const obj: TreeNode = {
      id: isCreated ? 0 : focusedItem.id,
      isFolder: true,
      children: [],
      index: isCreated ? costGrpName : focusedItem.index,
      data: costGrpName,
      parent_group_id: focusedItem.id !== 0 ? focusedItem.id : focusedItem.index,
      audit_desc: auditDes
    };

    if (formType === TCostCentreGrpForm.CREATE) {
      dispatch(setTreeNode(obj));
      const expandFolder = [focusedItem.index, obj.index]; // Expland parent while creating
      dispatch(setExpandedItems([...new Set([...expandedItems, ...expandFolder])] as string[]));
    } else {
      dispatch(updateCostGrp(obj));
    }
  };
  const saveHandler = (isContinue = false) => {
    const isValid = isInputValid(costGrpName);
    if (!isContinue && isValid) {
      saveNewGrp();
      history.push("/tools/general-ledger-setup/cost-centres");
    } else if (isContinue && isValid) {
      saveNewGrp();
      setValue("costGrpName", "");
      setFocus("costGrpName");
    }
  };

  const handleOnBlur = () => {
    setGrpInputError(true);
    dispatch(setGrpInputError(true));
  };

  const handleCancelCallBack = () => {
    dispatch(setTabClick(false));
    history.push("/tools/general-ledger-setup/cost-centres");
  };

  useEffect(() => {
    dispatch(setTabClick(false));
  }, []);

  return (
    <GeneralLedgerSetup>
      <div className="tab-container ledger-grp-form">
        <Grid className="">
          <GridItem sm={4}>
            <div className="essui-global-typography-default-subtitle">
              {t(
                `generalLedgerSetup.costCentre.${formType === TCostCentreGrpForm.CREATE ? "createCCGrp" : "editCCGrp"}`
              )}
            </div>
          </GridItem>
        </Grid>
        <Grid className="mt-16 mb-8">
          <GridItem
            sm={4}
            md={4}
            lg={4}
            xl={4}
            xxl={4}
          >
            <div>
              <FormLabel forId="txtGroupName">Group Name</FormLabel>
              <Input
                id="costGrpName"
                value={watch("costGrpName")}
                name={fieldName}
                inputRef={fieldRef}
                aria-label="Search Group"
                onChange={onChange}
                onBlur={(e) => {
                  if ((e.target as HTMLInputElement).value === "") {
                    handleOnBlur();
                  }
                }}
                searchable
                maxLength={32}
                validationTextLevel={grpInputError ? ValidationTextLevel.Error : undefined}
              />
            </div>
          </GridItem>
        </Grid>
        {formType === TCostCentreGrpForm.CREATE ? (
          <GenralLedgerFooter
            onSubmit={() => saveHandler()}
            saveAndContinue={() => saveHandler(true)}
            cancelCallback={handleCancelCallBack}
          />
        ) : (
          <GenralLedgerFooter
            onSubmit={() => saveHandler()}
            cancelCallback={handleCancelCallBack}
          />
        )}
      </div>
    </GeneralLedgerSetup>
  );
};

CostGrpForm.defaultProps = {
  formType: TCostCentreGrpForm.CREATE
};
export default CostGrpForm;
