import { Button, Icon, IconColor, IconSize, Loader, LoaderType } from "@essnextgen/ui-kit";
import {
  Tree,
  StaticTreeDataProvider,
  ControlledTreeEnvironment,
  DraggingPosition,
  TreeItem
} from "react-complex-tree";
import "react-complex-tree/lib/style-modern.css";
import { useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { Folder, FolderOpen, License } from "@carbon/icons-react";
import { STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { costCentreActions, getCostCentreTree, TCostCentreTree, TreeNode } from "../../State/CostCentresTab.slice";

const CostCentreTree = () => {
  const [focusedItem, setFocusedItem] = useState();
  const [expandedItems, setExpandedItems] = useState([]);
  const [selectedItems, setSelectedItems] = useState([]);
  const dispatch = useDispatch();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    costCenterTree,
    calltreeApi,
    status,
    selectedItems: selectedItemsSlice,
    expandedItems: expandedItemsSlice,
    focusedItem: focusedItemSlice,
    isTabClick,
    newCCGList
  } = useAppSelector((state) => state.glCostCentre);

  const {
    setExpandedItems: setExpandedItemsSlice,
    setSelectedItems: setSelectedItemsSlice,
    setFocusedItem: setFocusedItemSlice,
    changeTreeItemPosition,
    setTabClick
  } = costCentreActions;

  const dataProvider = new StaticTreeDataProvider(costCenterTree, (item, newName) => ({
    ...item,
    data: newName
  }));

  const listener = (changedItemIds: (string | number)[]) => {
    const changedItems = changedItemIds.map(dataProvider.getTreeItem);
    console.log("changedItems", changedItemIds);
  };
  dataProvider.onDidChangeTreeData(listener);

  useEffect(() => {
    if (calltreeApi) {
      dispatch(getCostCentreTree());
    }
  }, [calltreeApi]);

  // const onDropItem = (items: TreeItem<TreeNode>[], target: DraggingPosition) => {
  const onDropItem = (items: any, target: any) => {
    dispatch(changeTreeItemPosition({ items, target }));
  };

  // To manage scroll after create new CCG----------
  useEffect(() => {
    // Open folder with no items
    const findFolderIndices = (tree: any) => {
      const indices: any = [];
      Object.keys(tree).forEach((key) => {
        const item = tree[key];
        if (item?.isFolder && item?.children?.length === 0) {
          indices.push(item.index);
        }
      });
      return indices;
    };
    const folderIndices = findFolderIndices(costCenterTree);
    //
    setTimeout(() => {
      if (focusedItemSlice?.index) {
        const escapedIndex = CSS.escape(focusedItemSlice.index);
        const element = document.querySelector(`.cost__center-tree-list .${escapedIndex}`);
        if (element) {
          element.scrollIntoView({ block: "center", behavior: "smooth" });
        }
      }
    }, 200);
  }, []);

  // Don't remove this useEffect, it is used to update the expanded items in the tree
  useEffect(() => {
    setExpandedItems([...expandedItemsSlice] as any);
  }, [expandedItemsSlice]);

  useEffect(() => {
    setSelectedItems([selectedItemsSlice] as any);
  }, [selectedItemsSlice]);

  useEffect(() => {
    if (focusedItemSlice) {
      setFocusedItem(focusedItemSlice.index);
    }
  }, [focusedItemSlice]);
  // Till here

  useEffect(() => {
    if (Object.keys(costCenterTree).length > 0 && isTabClick) {
      setTimeout(() => {
        const focusEle = document.querySelector(`.tree-item-${focusedItemSlice.index}`) as HTMLElement;
        focusEle?.click();
        focusEle?.focus();
        dispatch(setTabClick(false));
      }, 0);
    }
  }, [isTabClick]);

  return (
    <>
      {status === STATUS.FAILED && (
        <div className="no-result">
          <Icon
            color={IconColor.Neutral500}
            size={IconSize.Small}
            name="information"
          />
          {t("common.noDataDisplay")}
        </div>
      )}
      {status === STATUS.LOADING && (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Please wait"
          isLoaderModal={false}
        />
      )}
      {status === STATUS.SUCCESS && Object.keys(selectedItems).length > 0 && (
        <ControlledTreeEnvironment
          items={costCenterTree}
          getItemTitle={(item) => item.data}
          viewState={{
            "tree-2": {
              focusedItem,
              selectedItems,
              expandedItems
            }
          }}
          canSearchByStartingTyping={false}
          canDragAndDrop
          canDropOnFolder
          onDrop={(items: TreeItem<any>[], target: DraggingPosition) => {
            onDropItem(items, target);
          }} // onDrop
          onFocusItem={(item) => {
            dispatch(setFocusedItemSlice(item as TreeNode));
            dispatch(setSelectedItemsSlice([item.index]));
          }}
          onSelectItems={(items) => dispatch(setSelectedItemsSlice(items))}
          onExpandItem={(item) => {
            dispatch(setExpandedItemsSlice([...new Set([...expandedItems, item.index])] as string[]));
          }}
          onCollapseItem={(item) =>
            dispatch(
              setExpandedItemsSlice(expandedItems.filter((expandedItemIndex) => expandedItemIndex !== item.index))
            )
          }
          renderItemTitle={({ title }) => <span>{title}</span>}
          renderItemArrow={({ item, context }) =>
            item.isFolder ? <span {...context.arrowProps}>{context.isExpanded ? "v " : "> "}</span> : null
          }
          renderItem={({ title, arrow, depth, context, children, item, info }) => (
            <li
              {...context.itemContainerWithChildrenProps}
              style={{
                margin: 0
              }}
              className={`cost__center-tree-list ${item.index}`}
            >
              {/* eslint-disable no-nested-ternary */}
              <div
                className={`cost__center-tree-select ${item.index} tree-item-${item.index} ${
                  !!selectedItemsSlice && item.index === selectedItemsSlice[0] ? "selected-folder" : ""
                }`}
                {...context.itemContainerWithoutChildrenProps}
                {...context.interactiveElementProps}
              >
                <div className="cost__center-tree-details">
                  {/* eslint-disable no-nested-ternary */}
                  {depth === 0 ? (
                    <FolderOpen
                      width="25"
                      height="25"
                    />
                  ) : !!item && item?.isFolder ? (
                    <Folder
                      width="25"
                      height="25"
                    />
                  ) : (
                    <License
                      width="25"
                      height="25"
                    />
                  )}

                  <h5 className="cost__center-tree-heading">{title}</h5>
                </div>

                {item?.isFolder && (
                  <Button className="folder-arrow">
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name={`${
                        !!focusedItemSlice && expandedItemsSlice.includes(item?.index as string)
                          ? "chevron--up"
                          : "chevron--down"
                      }`}
                    />
                  </Button>
                )}
              </div>
              {children}
            </li>
          )}
          renderTreeContainer={({ children, containerProps }) => <div {...containerProps}>{children}</div>}
          renderItemsContainer={({ children, containerProps }) => (
            <ul
              tabIndex={-1}
              {...containerProps}
              className="cost__center-tree-container"
            >
              {children}
            </ul>
          )}
        >
          <Tree
            treeId="tree-2"
            rootItem="root"
            treeLabel="Cost Center Tree"
          />
        </ControlledTreeEnvironment>
      )}
    </>
  );
};

export default CostCentreTree;
