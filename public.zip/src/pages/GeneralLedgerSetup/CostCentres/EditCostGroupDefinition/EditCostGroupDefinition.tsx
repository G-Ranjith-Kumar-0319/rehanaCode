import { TCostCentreGrpForm } from "../../State/CostCentresTab.slice";
import CostGrpForm from "../components/CostGrpForm";

const EditCostGroupDefinition = () => <CostGrpForm formType={TCostCentreGrpForm.EDIT} />;
export default EditCostGroupDefinition;
