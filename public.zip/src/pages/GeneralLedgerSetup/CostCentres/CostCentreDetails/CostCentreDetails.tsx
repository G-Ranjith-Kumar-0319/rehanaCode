import { CheckBox, Grid, GridItem, Loader, LoaderType } from "@essnextgen/ui-kit";
import { useEffect, useState } from "react";
import { AppDispatch, useAppSelector } from "@/store/store";
import { useDispatch } from "react-redux";
import { API_STATUS, BOOLEAN_DATA, STATUS } from "@/types/UseStateType";
import { costCentreActions, getCostCenterList } from "../../State/CostCentresTab.slice";
import { isTextEqual } from "../../ProfileModels/utils";

type CostCenter = {
  spendcheck: boolean;
};

const CostCentreDetails = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { constCenterDetails, focusedItem, newCostDetailList, isViewLoading, costCenterTree, ccdInputDetail } =
    useAppSelector((state: any) => state?.glCostCentre);
  const costId = focusedItem?.id ?? "";
  const [costCenterCheckBox, setCostCenterCheckBox] = useState<any>({
    spendcheck: false
  });

  const handleCheckboxChange = () => {
    setCostCenterCheckBox((prevValue: any) => !prevValue.spendcheck);
  };

  const getConstCenterDetails = () => {
    dispatch(getCostCenterList({ costId }));
  };

  const findInLocalState = () => {
    const found = newCostDetailList?.find((t: any) => isTextEqual(t?.cost_des, focusedItem?.data));
    if (found) {
      dispatch(costCentreActions.setCostCenterForView(found));
      return true;
    }
    return false;
  };
  useEffect(() => {
    if (findInLocalState()) return;
    if (costId) {
      getConstCenterDetails();
    }
  }, [costId, focusedItem?.data]);

  return (
    <div className="general-ledger-listing-container general-ledger-scroll-height">
      {isViewLoading ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        <Grid>
          <GridItem
            sm={4}
            md={6}
            lg={6}
            xl={12}
          >
            <Grid className="mb-16">
              <GridItem sm={4}>
                <div className="essui-global-typography-default-subtitle">COST CENTRE DETAILS</div>
              </GridItem>
            </Grid>
            <Grid className="row-gap-16 marginb15">
              <GridItem
                sm={4}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="essui-form-label mb-8">Code</div>
                <div>{constCenterDetails?.cost_code}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="essui-form-label mb-8">Description</div>
                <div>{constCenterDetails?.cost_des}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="essui-form-label mb-8">Abbreviation</div>
                <div>{constCenterDetails?.cost_abrv}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="essui-form-label mb-8">Holder</div>
                <div>{constCenterDetails?.cost_hold ? constCenterDetails?.cost_hold : "-"}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={6}
                xl={6}
              >
                <div className="essui-form-label mb-8">Threshold</div>
                <div>{constCenterDetails?.threshold}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={6}
                xl={6}
                className="align-center checkbox-mgtop"
              >
                <div className="essui-form-label mb-8">
                  <CheckBox
                    id="txtCheckbox"
                    disabled
                    isSelected={constCenterDetails?.spendcheck === BOOLEAN_DATA?.True || constCenterDetails?.spendcheck}
                    label="Check Spending"
                    onChange={handleCheckboxChange}
                  />
                </div>
              </GridItem>
            </Grid>
          </GridItem>
        </Grid>
      )}
    </div>
  );
};

export default CostCentreDetails;
