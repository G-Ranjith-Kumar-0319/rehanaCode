import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import { CheckBox, FormLabel, Grid, GridItem, Loader, LoaderType, ValidationTextLevel } from "@essnextgen/ui-kit";
import { useHistory, useParams } from "react-router-dom";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import { BOOLEAN_DATA, STATUS } from "@/types/UseStateType";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import useDebounce from "@/hooks/useDebounce";
import GeneralLedgerSetup from "../../GeneralLedgerSetup";
import GenralLedgerFooter from "../../GeneralLedgerFooter";
import {
  costCentreActions,
  getCostCenterDetailList,
  getCostCentreGrps,
  getCostCentreTree
} from "../../State/CostCentresTab.slice";
import useCostCentreForm from "../hook/useCostCentreForm";
import { handleKeyPress } from "../../utils";
import { isArrayLength } from "../../ProfileModels/utils";

const AddEditCostCentreFile = () => {
  const {
    register,
    errors,
    setValue,
    reset,
    watch,
    getAbbreviationValue,
    validateCode,
    validateDescription,
    validateAbbreviation,
    trigger,
    onSubmit,
    validateThreasHold,
    isDirty,
    setSubmitLoader,
    submitLoader
  } = useCostCentreForm();
  const history = useHistory();
  const { index } = useParams<any>();
  const dispatch = useDispatch();
  const {
    ccdErrorsState,
    constCenterDetails,
    costCenterDetailList,
    isSubmitting,
    focusedItem,
    calltreeApi,
    callCostCentreGrpApi,
    ccdUniquCheckRequest
  } = useAppSelector((state) => state.glCostCentre);
  const { setErrorState, setTabClick } = costCentreActions;
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const handleCancelCallBack = () => {
    dispatch(setTabClick(false));
    history.push("/tools/general-ledger-setup/cost-centres");
  };

  const delayedDesc = useDebounce(watch("cost_des"), 300);
  const delayedCode = useDebounce(watch("cost_code"), 300);
  const delayedAbrv = useDebounce(watch("cost_abrv"), 300);
  const delayedHold = useDebounce(watch("cost_hold"), 300);
  const delayedThresHold = useDebounce(watch("threshold"), 300);
  const delayedThreSpread = watch("spendcheck");

  useEffect(() => {
    if (!isArrayLength(costCenterDetailList)) dispatch(getCostCenterDetailList());
  }, [costCenterDetailList, dispatch]);
  useEffect(() => {
    dispatch(
      costCentreActions.setCDInputDetail({
        code_id: 0,
        cost_code: delayedCode,
        cost_abrv: delayedAbrv,
        cost_des: delayedDesc,
        cost_hold: delayedHold,
        threshold: delayedThresHold,
        isFormDirty: isDirty,
        spendcheck: delayedThreSpread ? BOOLEAN_DATA?.True : BOOLEAN_DATA?.False
      })
    );
  }, [isDirty, delayedThreSpread, delayedThresHold, delayedHold, delayedDesc, delayedCode, delayedAbrv]);

  const manageFieldsOnEdit = () => {
    if (constCenterDetails) {
      reset(constCenterDetails as any);
    }
  };

  // Clear error on change event
  const clearError = (field: string) => {
    dispatch(setErrorState({ ...ccdErrorsState, [field]: false }));
  };
  // ------ Clear required state on unmount-----
  useEffect(() => {
    if (index) {
      manageFieldsOnEdit(); // Function to manage form while edit mode
    }
    return () => {
      dispatch(costCentreActions.clearAlreadyExistData());
      dispatch(
        costCentreActions.setErrorState({
          cost_code: undefined,
          cost_des: undefined,
          cost_abrv: undefined,
          threshold: false
        })
      );
    };
  }, []);
  // -------------//

  useEffect(() => {
    dispatch(setTabClick(false));
  }, []);

  useEffect(() => {
    // Call the Tree API Required as when user directly call the create/edit route
    if (calltreeApi) {
      dispatch(getCostCentreTree());
    }
  }, [calltreeApi]);

  useEffect(() => {
    // Call all the grp data to check for duplicates
    if (callCostCentreGrpApi) {
      dispatch(getCostCentreGrps());
    }
  }, [callCostCentreGrpApi]);

  return (
    <>
      <GeneralLedgerSetup>
        <Layout
          isBreadcrumbRequired={false}
          className="p-0 glccd-form-layout"
        >
          <Grid className="mb-16">
            <GridItem sm={4}>
              <div className="essui-global-typography-default-subtitle">
                {t("generalLedgerSetup.costCentre.creatCostCentreMsg")}
              </div>
            </GridItem>
          </Grid>
          {isSubmitting ? (
            <Grid className="glccd-loader">
              <Loader
                loaderType={LoaderType.Circular}
                loaderText="Loading..."
              />
            </Grid>
          ) : null}

          <>
            <Grid className="mb-8">
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
              >
                <div>
                  <FormLabel forId="code">Code</FormLabel>
                  <Input
                    autoFocus
                    id="code"
                    value={watch("cost_code")}
                    inputRef={(e) => register("cost_code").ref(e)}
                    name={
                      register("cost_code", {
                        required: true
                      }).name
                    }
                    onChange={(e) => {
                      clearError("cost_code");
                      setValue("cost_code", e.target.value, {
                        shouldDirty: true
                      });
                    }}
                    disabled={index}
                    onKeyDown={(e: any) => handleKeyPress(e, /[a-zA-Z0-9]/)}
                    maxLength={9} // This ensures the input box itself restricts input to 9 characters
                    onBlur={(e: any) => validateCode(e.target.value)}
                    validationTextLevel={
                      errors.cost_code || ccdErrorsState?.cost_code ? ValidationTextLevel.Error : undefined
                    }
                  />
                </div>
              </GridItem>
            </Grid>
            <Grid className="mb-8">
              <GridItem
                sm={4}
                md={3}
                lg={3}
                xl={3}
              >
                <div>
                  <FormLabel forId="description">Description</FormLabel>
                  <Input
                    searchable
                    id="description"
                    value={watch("cost_des")}
                    inputRef={(e) => register("cost_des").ref(e)}
                    name={
                      register("cost_des", {
                        required: true
                      }).name
                    }
                    onChange={(e) => {
                      clearError("cost_des");
                      setValue("cost_des", e.target.value, {
                        shouldDirty: true
                      });
                    }}
                    autoFocus={!!index}
                    maxLength={32}
                    onBlur={(e: any) => validateDescription(e.target.value)}
                    validationTextLevel={
                      errors.cost_des || ccdErrorsState?.cost_des ? ValidationTextLevel.Error : undefined
                    }
                  />
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={2}
                lg={2}
                xl={2}
              >
                <div>
                  <FormLabel forId="abbreviation">Abbreviation</FormLabel>
                  <Input
                    searchable
                    id="abbreviation"
                    value={watch("cost_abrv")}
                    inputRef={(e) => register("cost_abrv").ref(e)}
                    name={
                      register("cost_abrv", {
                        required: true
                      }).name
                    }
                    onChange={(e) => {
                      clearError("cost_abrv");
                      setValue("cost_abrv", e.target.value, {
                        shouldDirty: true
                      });
                    }}
                    maxLength={12}
                    onFocus={(e: any) => !e.target.value && getAbbreviationValue()}
                    onBlur={(e: any) => validateAbbreviation(e.target.value)}
                    validationTextLevel={
                      errors.cost_abrv || ccdErrorsState?.cost_abrv ? ValidationTextLevel.Error : undefined
                    }
                  />
                </div>
              </GridItem>
            </Grid>
            <Grid className="mb-8">
              <GridItem
                sm={4}
                md={3}
                lg={3}
                xl={3}
              >
                <div>
                  <FormLabel forId="holder">Holder</FormLabel>
                  <Input
                    id="holder"
                    searchable
                    value={watch("cost_hold")}
                    inputRef={(e) => register("cost_hold").ref(e)}
                    name={
                      register("cost_hold", {
                        required: true
                      }).name
                    }
                    onChange={(e) =>
                      setValue("cost_hold", e.target.value, {
                        shouldDirty: true
                      })
                    }
                    maxLength={25}
                    onBlur={() => trigger("cost_hold")}
                  />
                </div>
              </GridItem>
              <GridItem
                sm={4}
                md={1}
                lg={1}
                xl={1}
              >
                <div>
                  <FormLabel forId="threshold">Threshold</FormLabel>
                  <Input
                    searchable
                    id="threshold"
                    value={watch("threshold")}
                    inputRef={(e) => register("threshold").ref(e)}
                    name={
                      register("threshold", {
                        required: true
                      }).name
                    }
                    onChange={(e) =>
                      setValue("threshold", e.target.value, {
                        shouldDirty: true
                      })
                    }
                    onKeyDown={(e: any) => handleKeyPress(e, /^[0-9]$/)}
                    onBlur={(e: any) => validateThreasHold(e.target.value)}
                    maxLength={3}
                    validationTextLevel={
                      errors.threshold || ccdErrorsState?.threshold ? ValidationTextLevel.Error : undefined
                    }
                  />
                </div>
              </GridItem>
            </Grid>
            <Grid className="mb-8">
              <GridItem
                sm={4}
                md={12}
                lg={12}
                xl={12}
              >
                <div className="checkSpending">
                  <CheckBox
                    label="Check Spending"
                    id="checkSpending"
                    isSelected={watch("spendcheck") === BOOLEAN_DATA?.True || watch("spendcheck")}
                    value={watch("spendcheck")}
                    onChange={(e: any) =>
                      setValue("spendcheck", e.target.checked, {
                        shouldDirty: true
                      })
                    }
                  />
                </div>
              </GridItem>
            </Grid>
          </>

          {index ? (
            <GenralLedgerFooter
              onSubmit={() => onSubmit(false)}
              cancelCallback={handleCancelCallBack}
            />
          ) : (
            <GenralLedgerFooter
              saveAndContinue={() => onSubmit(true)}
              onSubmit={() => onSubmit(false)}
              cancelCallback={handleCancelCallBack}
            />
          )}
        </Layout>
      </GeneralLedgerSetup>
    </>
  );
};
export default AddEditCostCentreFile;
