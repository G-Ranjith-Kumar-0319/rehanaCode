import CostGrpForm from "../components/CostGrpForm";

const NewCostGroupDefinition = () => <CostGrpForm />;
export default NewCostGroupDefinition;
