import Layout from "@/components/Layout/Layout";

const ToolsComponent = () => (
  <>
    <Layout
      isBreadcrumbRequired
      type="transparent"
    >
      <div className="essui-global-typography-default-h3">Coming Soon.....</div>
    </Layout>
  </>
);

export default ToolsComponent;
