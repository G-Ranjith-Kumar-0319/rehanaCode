import { Button, ButtonColor, ButtonSize, Divider, FormLabel, Grid, GridItem } from "@essnextgen/ui-kit";

import Input from "@/components/Input/Input";
import Layout from "@/components/Layout/Layout";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";

const SummaryBACSGenerated = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  return (
    <>
      <Layout
        pageTitle="Summary of BACS to be generated"
        className=""
      >
        <Grid className="mb-8">
          <GridItem sm={4}>
            <div className="essui-global-typography-default-subtitle">Bank Balance</div>
          </GridItem>
        </Grid>
        <Grid className="row-gap-16">
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label mb-5">Current</div>
              <div>407,690.73</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label mb-5">Processing</div>
              <div>14,860.08</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label mb-5">New</div>
              <div>392,149.78</div>
            </div>
          </GridItem>
        </Grid>
      </Layout>

      <Layout
        isBreadcrumbRequired={false}
        className=""
      >
        <Grid
          justify="space-between"
          className="mt-8"
        >
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <HelpButton
              identifier="testIdentifier"
              labelName="Help"
            />
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="d-flex justify-end flex-wrap justify-start-resposnive gap-8">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                Cancel
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                {t("common.back")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                Create
              </Button>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};

export default SummaryBACSGenerated;
