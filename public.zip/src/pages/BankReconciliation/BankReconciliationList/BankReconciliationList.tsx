import { Context, SyntheticEvent, useEffect, useState } from "react";
import {
  IPaginationProps,
  Loader,
  LoaderType,
  Pagination,
  ButtonSize,
  ButtonColor,
  Button,
  Notification,
  NotificationStatus
} from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import Layout from "@/components/Layout/Layout";
import GridTableNew, { RowType } from "@/components/GridTableNew/GridTableNew";
import "./Style.scss";
import { STATUS, getCurrentFinancialYear } from "@/types/UseStateType";
import { useAppContext } from "@/routes/Routes";
import { useHistory } from "react-router-dom";
import { getFinancialYear } from "@/store/state/financialYear.slice";
import { Modalv2 } from "@/components/Modalv2/Modalv2";
import { getSessionItem as getSessionData } from "@/utils/getDataSource";
import { getBankReconciliations, bankRecActions } from "../state/BankReconciliation.slice";
import { getBankReconciliationStatus } from "../state/BankReconciliationStatus.slice";
import BankReconciliationToolbar from "../BankReconciliationToolbar";
import BankReconciliationFilters from "./Grid/BankReconciliationFilters";
import CustomCell from "./Grid/CustomCell";
import { getVerifyBalaceDetail } from "../state/BankReconciliationStatement.slice";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];
export type TAuthoriseState = {
  flag: boolean;
  success?: number;
  total?: number;
};

const BankReconciliationList = () => {
  const dispatch = useDispatch<AppDispatch>();
  const {
    status,
    selectedRow,
    checkedRows,
    filterState,
    status: listStatus,
    conlumnDef: bRColumnDef,
    bankRreconciliationList,
    nextYearStartDate
  } = useAppSelector((state) => state.bankReconciliation);
  const { redirectToBankReconciledDetails } = useAppContext();
  const [lookingFor, setLookingFor] = useState<string | undefined>(undefined);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dataTestId = "bankRecListGrid";
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;
  const history = useHistory();
  const historyState = { ...(history.location.state as any) };
  const { deleteStatus } = useAppSelector((state) => state.bankReconciliationStatement);
  const { data, pageSize, currentPage, totalPages } = useAppSelector(
    ({ bankReconciliation }) => bankReconciliation?.bankRreconciliationList
  );
  const [isVerifyBalancesModalOpen, setIsVerifyBalancesModalOpen] = useState<boolean>(false);

  const onChangeHandler: onChangeType = (e, page) => {
    lookingForChangehandler("");
    dispatch(
      bankRecActions.setFilters({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(pageSize),
        viewname: "All",
        highLightedRecordId: undefined
      })
    );
  };

  useEffect(() => {
    dispatch(getBankReconciliations({ ...filterState }));
  }, [filterState]);

  useEffect(() => {
    dispatch(getBankReconciliationStatus());
    financialYear();
  }, []);

  useEffect(() => {
    if (lookingFor !== filterState?.lookingFor && lookingFor !== undefined) {
      dispatch(bankRecActions.setFilters({ lookingFor, applyFilter: true, highLightedRecordId: undefined }));
    }
  }, [lookingFor, filterState?.lookingFor]);

  const lookingForChangehandler = (value: string) => {
    setLookingFor(value);
  };

  const financialYear = async () => {
    const resultFinYear: any = await dispatch(getFinancialYear(getCurrentFinancialYear()));
    dispatch(bankRecActions.setNextYearStartDate(resultFinYear.payload.nextYearStartDate));
  };

  const onchangePrevRecord: onChangeType = (e, page) => {
    dispatch(
      getBankReconciliations({
        ...filterState,
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: "",
        callback: (data) => dispatch(bankRecActions.setSelectedRow(data.data?.at(data.data?.length - 1)))
      })
    );
  };

  const selectPrevRecord = (e: SyntheticEvent) => {
    if (selectedRow && data) {
      const indexNo = data.indexOf(selectedRow);
      const index = indexNo !== 0 ? indexNo - 1 : 0;
      document.getElementById(getIndex(dataTestId, index))?.focus();
      if (indexNo > 0) {
        dispatch(bankRecActions.setSelectedRow(data[indexNo - 1]));
      } else if (currentPage > 1) {
        onchangePrevRecord(e, currentPage - 1);
      }
    }
  };

  const selectNextRecord = (e: SyntheticEvent) => {
    if (selectedRow && data) {
      const indexNo = data.indexOf(selectedRow);
      const index = data.length - 1 > indexNo ? indexNo + 1 : data.length - 1;
      document.getElementById(getIndex(dataTestId, index))?.focus();
      if (indexNo < 9 && (data.length - 1 !== indexNo || currentPage !== totalPages)) {
        dispatch(bankRecActions.setSelectedRow(data[indexNo + 1]));
      } else if (currentPage < totalPages) {
        onChangeHandler(e, currentPage + 1);
      }
    }
  };

  const onEnterKeyPress = () => {
    dispatch(bankRecActions.setSelectedRow(selectedRow));
    const { bankreconciledDetailsLink } = redirectToBankReconciledDetails(selectedRow);
    history.push({
      pathname: bankreconciledDetailsLink,
      state: {
        ...historyState,
        bankRreconciliationList,
        selectedRowState: selectedRow
      }
    });
  };

  const onRowSelect: (row?: RowType | undefined) => void = (row) => {
    if (status === STATUS.SUCCESS) {
      dispatch(bankRecActions.setSelectedRow(row));
    }
  };

  const handleVerifyBalancesClick = () => {
    setIsVerifyBalancesModalOpen((preVal) => !preVal);

    setTimeout(() => {
      const focusButton = document.querySelector(".essui-overlay-container .essui-button--secondary") as HTMLElement;
      if (focusButton) {
        focusButton.focus();
      }
    }, 10);
  };

  return (
    <>
      {deleteStatus === STATUS.LOADING ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        <Layout
          pageTitle={t("bankReconciliation.bankReconciliation")}
          className="purchase-order purchase-order__list"
          rightContent={
            <BankReconciliationToolbar
              goToPrevRecord={selectPrevRecord}
              goToNextRecord={selectNextRecord}
              nextYearStartDate={nextYearStartDate}
              handleVerifyBalance={handleVerifyBalancesClick}
            />
          }
          type="transparent"
        >
          <GridTableNew
            dataTestId={dataTestId}
            filters={
              <BankReconciliationFilters
                lookingFor={lookingFor}
                lookingForChangehandler={lookingForChangehandler}
                nextYearStartDate={nextYearStartDate}
              />
            }
            dataSource={data || []}
            isLoading={listStatus === STATUS.LOADING}
            columnDef={bRColumnDef}
            checkedRows={checkedRows}
            footer={
              <Pagination
                count={totalPages}
                page={currentPage}
                onChange={onChangeHandler}
              />
            }
            customCell={CustomCell}
            selectedRow={selectedRow}
            onEnterKeyPress={onEnterKeyPress}
            selectedRowHandler={onRowSelect}
          />
        </Layout>
      )}

      <Modalv2
        className="verify-balances-modal"
        header={t("alertMessage.verifyBalancesAlert.title")}
        isOpen={isVerifyBalancesModalOpen}
        primaryButton={
          <Button
            size={ButtonSize.Small}
            onClick={() => {
              dispatch(
                getVerifyBalaceDetail({
                  uniqueIdentifier: getSessionData("uniqueIdentifier") ? getSessionData("uniqueIdentifier") : "",
                  t,
                  callBackModal: true
                })
              );
              setIsVerifyBalancesModalOpen(false);
            }}
          >
            {t("common.yes")}
          </Button>
        }
        secondaryButton={
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Secondary}
            onClick={() => {
              setIsVerifyBalancesModalOpen(false);
            }}
          >
            {t("common.no")}
          </Button>
        }
        onClose={() => {
          setIsVerifyBalancesModalOpen(false);
        }}
      >
        <>
          <Notification
            actionElement={1}
            className="confirm-modal-text"
            dataTestId="switch-to-list-warning-id"
            escapeExits
            id="switch-to-list-warning-id"
            hideCloseButton
            status={NotificationStatus.WARNING}
            title={t("alertMessage.verifyBalancesAlert.message")}
          />
        </>
      </Modalv2>
    </>
  );
};

export default BankReconciliationList;
