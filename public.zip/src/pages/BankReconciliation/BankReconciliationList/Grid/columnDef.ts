import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const bankReconciliationDef: TColumnDef = [
  {
    headerName: "Statement Date",
    field: "statement_date",
    cellRenderer: "GridCellLink",
    sequence: true,
    sequenceName: "Date"
  },
  {
    headerName: "Statement No.",
    field: "statement_no",
    sequence: true,
    sequenceName: "Stat. No."
  },
  {
    headerName: "Account",
    field: "ledger_des"
  },
  {
    headerName: "Account No.",
    field: "bank_account"
  },
  {
    headerName: "Sort Code",
    field: "bank_sort_code"
  },
  {
    headerName: "",
    field: "detailLink",
    cellRenderer: "GridCellLink"
  }
];

export default bankReconciliationDef;
