import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import {
  Dropdown,
  DropdownItem,
  FormLabel,
  RadioButton,
  RadioLabelPosition,
  TextInputSize,
  ISelectedItem
} from "@essnextgen/ui-kit";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { AppDispatch, useAppSelector } from "@/store/store";
import { BANK_RECON_SEQ_NAME, KEYBOARD_STRING, STATUS } from "@/types/UseStateType";
import { actions as brStatusAction } from "../../state/BankReconciliationStatus.slice";
import { bankRecActions } from "../../state/BankReconciliation.slice";

import columnDef from "./columnDef";

type TBankReconciliationFilters = {
  lookingFor: string | undefined;
  lookingForChangehandler: Function;
  nextYearStartDate?: any;
};

const BankReconciliationFilters = (props: TBankReconciliationFilters) => {
  const { lookingFor, lookingForChangehandler, nextYearStartDate } = props;

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const dispatch = useDispatch<AppDispatch>();

  const { filterState, status, bankRreconciliationList } = useAppSelector((state) => state.bankReconciliation);
  const { bankReconciliationViews, selectedView } = useAppSelector((state) => state.bankReconciliationViews);

  const lookingForCallback = (value: any) => {
    lookingForChangehandler(value);
  };

  const handleSequenceFieldKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey = e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp;

    if (isArrowKey) {
      e.preventDefault();
      lookingForChangehandler("");

      const nextSequenceValue =
        filterState?.sequenceValue === BANK_RECON_SEQ_NAME.STATEMENT_DATE
          ? BANK_RECON_SEQ_NAME.STATEMENT_NO
          : BANK_RECON_SEQ_NAME.STATEMENT_DATE;
      const index = nextSequenceValue === BANK_RECON_SEQ_NAME.STATEMENT_NO ? 1 : 0;

      handleSequenceChange(nextSequenceValue, index);
    }
  };

  const handleSequenceOrderKeyDown = (e: React.KeyboardEvent) => {
    const isArrowKey = e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp;
    if (isArrowKey) {
      e.preventDefault();
      if (filterState?.sortOrder === 0) {
        onDescendingSort();
      } else if (filterState?.sortOrder === 1) {
        onAscendingSort();
      }
    }
  };

  const onAscendingSort = () => {
    lookingForChangehandler("");
    dispatch(
      bankRecActions.setFilters({
        lookingFor: "",
        sortOrder: 0,
        applyFilter: true,
        highLightedRecordId: undefined
      })
    );
  };

  const onDescendingSort = () => {
    lookingForChangehandler("");
    dispatch(
      bankRecActions.setFilters({
        lookingFor: "",
        sortOrder: 1,
        applyFilter: true,
        highLightedRecordId: undefined
      })
    );
  };

  const onViewSelection = (item: ISelectedItem) => {
    lookingForChangehandler("");
    dispatch(brStatusAction.setBankReconciliationView(item));
    dispatch(
      bankRecActions.setFilters({
        lookingFor: "",
        viewname: item.value,
        applyFilter: true,
        pageNumber: 1,
        highLightedRecordId: undefined
      })
    );
  };

  useEffect(() => {
    if (filterState?.sequenceValue) {
      const isChecked = columns[0].checkboxSelection === true ? 1 : 0;
      const getRow = columns.find((row) => row.field === filterState?.sequenceValue);
      columns.splice(columns.indexOf(getRow!), 1); // delete
      columns.splice(isChecked, 0, getRow!);
      setColumn([...columnDef]);
      dispatch(bankRecActions.setColumnDef(columns));
    }
  }, [filterState]);

  const handleSequenceChange = (value: React.SetStateAction<string>, sequenceNewIndex: number) => {
    dispatch(
      bankRecActions.setFilters({
        lookingFor: "",
        sequence: sequenceNewIndex,
        sequenceValue: String(value),
        applyFilter: sequenceNewIndex !== 1 ? true : filterState?.applyFilter,
        highLightedRecordId: undefined
      })
    );
  };

  const onSequenceChange = (column: any, index: number) => {
    lookingForChangehandler("");
    handleSequenceChange(column.field, index);
  };

  return (
    <div className="filters">
      <LookingFor
        initialValue={lookingFor}
        callback={lookingForCallback}
        changeHandler={() => {}}
        hasDatePicker
        isBankReconciliation
        nextYearStartDate={nextYearStartDate}
        disableDatePicker={filterState?.sequenceValue !== "statement_date"}
        isInputReadOnly={status === STATUS.LOADING}
        className="essui-global-typography-default-h2 looking-for-container"
      />
      <div className="essui-global-typography-default-h2 sequence-container">
        <FormLabel>{t("bankReconciliation.sequence")}</FormLabel>
        <div className="sequence">
          <div
            className="essui-textinput sequence-fields"
            onKeyDown={handleSequenceFieldKeyDown}
          >
            {(columnDef.filter((col) => !!col.sequence) || []).map((column, index) => {
              const sequenceId = `sequence=${index + 1}`;
              return (
                <RadioButton
                  label={column.sequenceName ? column.sequenceName : column.headerName}
                  labelPosition={RadioLabelPosition.Right}
                  value={column.field}
                  onChange={() => {
                    onSequenceChange(column, index);
                  }}
                  isSelected={filterState?.sequenceValue === column.field}
                  key={sequenceId}
                  name="sequenceColumn"
                />
              );
            })}
          </div>
          <div
            className="essui-textinput sequence-order"
            onKeyDown={handleSequenceOrderKeyDown}
          >
            <RadioButton
              label={t("common.ascending")}
              labelPosition={RadioLabelPosition.Right}
              value={0}
              onChange={onAscendingSort}
              isSelected={filterState?.sortOrder === 0}
              name="sequenceOrder"
            />
            <RadioButton
              label={t("common.descending")}
              labelPosition={RadioLabelPosition.Right}
              value={1}
              onChange={onDescendingSort}
              isSelected={filterState?.sortOrder === 1}
              name="sequenceOrder"
            />
          </div>
        </div>
      </div>
      <div className="view-filter">
        <FormLabel forId="view">{t("purchaseOrder.view")}</FormLabel>
        <Dropdown
          size={TextInputSize.Medium}
          searchable
          selectedItem={selectedView}
          isScrollbarVisible
          onSelect={(e: React.SyntheticEvent, item: ISelectedItem) => onViewSelection(item)}
          scrollbarHeight={Number(bankRreconciliationList?.totalCount || 0) <= 3 ? 120 : undefined}
          inputWidth={300}
        >
          {(bankReconciliationViews || []).map((view: { [key: string]: string }, i: any) => {
            const id = `dropdown-${i}`;
            return (
              <DropdownItem
                key={id}
                id={id}
                text={view.ledger_des}
                value={view.ledger_code}
              >
                {view.ledger_des}
              </DropdownItem>
            );
          })}
        </Dropdown>
      </div>
    </div>
  );
};

BankReconciliationFilters.defaultProps = {
  nextYearStartDate: undefined
};

export default BankReconciliationFilters;
