import "./Style.scss";
import Modal from "@/components/Modal/Modal";
import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { FormLabel, Grid, GridItem, Loader, LoaderType } from "@essnextgen/ui-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { getInvoicePostingPeriod } from "@/pages/Invoice/State/InvoicePostingPeriod.slice";
import { usNumberFormat } from "@/utils/getDataSource";
import BodyUtil from "@/shared/utils/NoScroll";
import { getPayingInProgressDetails } from "../state/BankReconciliationStatement.slice";
import payInProgressColumnDef from "./Grid/columnDef";
import CustomCell from "./Grid/CustomCell";

type TPayingInProgress = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  row: { [key: string]: any };
};
const PayingInProcessingModal = ({ setOpen, isOpen, row }: TPayingInProgress) => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [payingInProgressDetail, setPayingInProgressDetail] = useState<any>("");
  const [selectedPayInProgressRow, setSelectedPayInProgressRow] = useState<any>();
  const [postingPeriodMonth, setPostingPeriodMonth] = useState<string>("");
  const dispatch = useDispatch<AppDispatch>();
  const { postingPeriodDetails } = useAppSelector((state) => state.invoicePostingPeriod);
  useEffect(() => {
    dispatch(getInvoicePostingPeriod(0));
    setPayingInProgressDetail("");
    const paySlipId: number = Number(row?.unique_id?.slice(2));

    dispatch(
      getPayingInProgressDetails({
        paySlipId,
        callback(data) {
          if (data) {
            setPayingInProgressDetail(data);
            setSelectedPayInProgressRow(data?.paySlipReceipt[0]);
          }
        }
      })
    );
  }, []);

  useEffect(() => {
    if (postingPeriodDetails?.length && payingInProgressDetail) {
      const month = postingPeriodDetails?.filter(
        (p: any) => Number(p.code) === payingInProgressDetail?.paySlip?.posting_period
      )[0]?.description;
      setPostingPeriodMonth(month);
    }
  }, [postingPeriodDetails, payingInProgressDetail]);

  const prependZero = (num: number) => {
    if (num >= 1 && num <= 9) {
      return `0${num}`;
    }
    return num.toString();
  };
  return (
    <>
      <Modal
        header={t("payingInProgress.payingInProgTitle")}
        isOpen={isOpen}
        primaryBtnText={t("common.close")}
        primaryBtnClick={() => {
          BodyUtil.NoScroll.remove();
          setOpen(false);
        }}
        className="payin-processing-modal dialog__divider"
      >
        {!payingInProgressDetail ? (
          <Loader
            loaderType={LoaderType.Circular}
            loaderText="Loading..."
          />
        ) : (
          <div className="overflow-hidden">
            <Grid className="marginb15 row-gap-16">
              <GridItem
                sm={3}
                md={4}
                lg={4}
                xl={4}
              >
                <div>
                  <div className="essui-form-label pb-8">{t("payingInProgress.reference")}</div>
                  <div>{payingInProgressDetail?.paySlip?.paying_in_slip_ref}</div>
                </div>
              </GridItem>
              <GridItem
                sm={3}
                md={4}
                lg={4}
                xl={4}
              >
                <div>
                  <div className="essui-form-label pb-8">{t("payingInProgress.destination")}</div>
                  <div>{payingInProgressDetail?.paySlip?.destination}</div>
                </div>
              </GridItem>
              <GridItem
                sm={3}
                md={4}
                lg={4}
                xl={4}
              >
                <div>
                  <div className="essui-form-label pb-8">{t("payingInProgress.postingPeriod")}</div>
                  <div>
                    {prependZero(payingInProgressDetail?.paySlip?.posting_period)} {postingPeriodMonth}
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={3}
                md={4}
                lg={4}
                xl={4}
              >
                <div>
                  <div className="essui-form-label pb-8">{t("payingInProgress.date")}</div>
                  <div>
                    {new Date(payingInProgressDetail?.paySlip?.paying_in_slip_date).toLocaleDateString("en-GB", {
                      day: "2-digit",
                      month: "short",
                      year: "numeric"
                    })}
                  </div>
                </div>
              </GridItem>
              <GridItem
                sm={3}
                md={4}
                lg={4}
                xl={4}
              >
                <div>
                  <div className="essui-form-label pb-8">{t("payingInProgress.status")}</div>
                  <div>{payingInProgressDetail?.paySlip?.status}</div>
                </div>
              </GridItem>
            </Grid>
            <GridTableNew
              isScrollable
              filters={
                <div className="essui-global-typography-default-subtitle">{t("payingInProgress.receiptsTitle")}</div>
              }
              dataSource={payingInProgressDetail?.paySlipReceipt || []}
              isLoading={!payingInProgressDetail}
              columnDef={payInProgressColumnDef}
              selectedRowHandler={(row) => setSelectedPayInProgressRow(row)}
              selectedRow={selectedPayInProgressRow}
              customCell={CustomCell}
            />
            <Grid>
              <GridItem>
                <div>
                  <FormLabel className="mb-5 mt-16 essui-global-typography-default-subtitle">
                    {t("payingInProgress.totals")}
                  </FormLabel>
                </div>
              </GridItem>
            </Grid>
            <Grid className="mt-12 justify__content--between row-gap-16 pr-32">
              <GridItem>
                <div>
                  <FormLabel className="mb-5">{t("payingInProgress.items")}</FormLabel>
                  <div>{selectedPayInProgressRow?.receipt_count}</div>
                </div>
              </GridItem>
              <GridItem>
                <div>
                  <FormLabel className="mb-5">{t("payingInProgress.cash")}</FormLabel>
                  <div>{usNumberFormat(selectedPayInProgressRow?.cash_total)}</div>
                </div>
              </GridItem>
              <GridItem className="d-flex align-end">
                <div>
                  <b>+</b>
                </div>
              </GridItem>
              <GridItem>
                <div>
                  <FormLabel className="mb-5">{t("payingInProgress.cheque")}</FormLabel>
                  <div>{usNumberFormat(selectedPayInProgressRow?.cheque_total)}</div>
                </div>
              </GridItem>
              <GridItem className="d-flex align-end">
                <div>
                  <b>=</b>
                </div>
              </GridItem>
              <GridItem>
                <div>
                  <FormLabel className="mb-5">&nbsp;</FormLabel>
                  <div>{usNumberFormat(selectedPayInProgressRow?.receipts_total)}</div>
                </div>
              </GridItem>
            </Grid>
          </div>
        )}
      </Modal>
    </>
  );
};
export default PayingInProcessingModal;
