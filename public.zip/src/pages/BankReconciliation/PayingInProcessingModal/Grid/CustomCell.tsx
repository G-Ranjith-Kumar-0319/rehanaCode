import { cellRendererType } from "@/components/GridTable/GridTable";

const CustomCell = ({ field, row }: cellRendererType) => {
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const getContent = () => {
    console.log("field is ", field);
    switch (field) {
      case "receipt_date":
        return (
          <>
            {new Date(row?.receipt_date).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })}
          </>
        );
      case "amount":
        return <>{numberFormatter.format(row?.amount)}</>;
      default:
        return null;
    }
  };
  return getContent();
};

export default CustomCell;
