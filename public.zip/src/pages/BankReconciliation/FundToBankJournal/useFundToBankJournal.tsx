import { useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useEffect, useState } from "react";

/* eslint-disable import/prefer-default-export */
export const useFundToBankJournal = () => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { bankGlFundToBankData } = useAppSelector((state) => state?.bankReconciliationStatement);
  const [fundToBankData, setFundToBankData] = useState<any>(bankGlFundToBankData);
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  useEffect(() => {
    setFundToBankData(bankGlFundToBankData);
  }, [bankGlFundToBankData]);

  return {
    fundToBankData,
    numberFormatter,
    t
  };
};
