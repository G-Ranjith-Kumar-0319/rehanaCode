import { AppDispatch, useAppSelector } from "@/store/store";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { ISelectedItem, NotificationStatus } from "@essnextgen/ui-kit";
import { useForm } from "react-hook-form";
import {
  getBankreconBankAccounts,
  actions as bankReconActions,
  getBankreconAccountNo
} from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import { getDateInStringFormat } from "@/utils/constants";
import { format, isAfter, parse } from "date-fns";
import { KEYBOARD_STRING, specialCharacters } from "@/types/UseStateType";
import { addBankreconStatement, bankreconValidateStatement } from "../state/BankReconciliation.slice";

/* eslint-disable camelcase */
type FormData = {
  ledger_code: string;
  ledger_des: string;
  ledger_id: string;
  bank_account: string;
  statement_no: string;
  input_date: string;
};

const useAddStatement = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState<boolean>(false);
  const [isBankAccountModalOpen, setIsBankAccountModalOpen] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const [isOpenAlert, setIsOpenAlert] = useState<boolean>(false);
  const [alertType, setAlertType] = useState<NotificationStatus>(NotificationStatus.ERROR);
  const [bankId, setBankId] = useState<string>("");
  const [isValueEmpty, setIsValueEmpty] = useState<boolean>(false);
  const [isStatementNoEmpty, setIsStatementNoEmpty] = useState<boolean>(false);
  const [formattedDate, setFormattedDate] = useState<string>("");
  const [isBankreconWarningMsgOpen, setIsBankreconWarningMsgOpen] = useState<boolean>(false);
  const [isBankReconLastStatementOpen, setIsBankReconLastStatementOpen] = useState<boolean>(false);
  const { addBankreconStatus, validateStatus } = useAppSelector((state) => state.bankReconciliation);
  const historyState = history.location.state as any;
  const [futureDate, setFutureDate] = useState<boolean>(false);
  const [selectedDate, setSelectedDate] = useState<any>(undefined);
  const { bankreconBankAccounts, bankStatus, bankAccountStatus } = useAppSelector(
    (state) => state.bankreconBankAccounts
  );
  const formMethods = useForm<FormData>({
    mode: "all",
    shouldFocusError: false,
    defaultValues: {
      ledger_des: ""
    }
  });

  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    setFocus,
    setError,
    reset,
    watch,
    formState: { errors, isDirty },
    getValues
  } = formMethods;

  const bankAccountClick = () => {
    dispatch(bankReconActions.setFilters({ lookingFor: "" }));
    setIsBankAccountModalOpen(true);
  };

  const dateChangeHandler = (date: Date) => {
    const value = getDateInStringFormat(date);
    setIsValueEmpty(false);
    setValue("input_date", value);
  };

  const onBankAccountSelectedRow = async (row: any) => {
    dispatch(bankReconActions.selectBankAccountRow(row));
    setBankId(row.bank_id);
    const bankReconAccountNo: any = await dispatch(getBankreconAccountNo({ bankId: row.bank_id }));
    if (bankReconAccountNo) {
      setValue("ledger_code", row?.ledger_code, { shouldValidate: true });
      setValue("ledger_des", row?.ledger_des);
      setValue("bank_account", bankReconAccountNo?.payload?.bank_account);
      if (bankReconAccountNo?.payload?.statementNo >= 0) {
        setIsStatementNoEmpty(false);
        setValue("statement_no", bankReconAccountNo?.payload?.statementNo + 1);
      }
    }
  };

  const datepickerChangeHandler = (newDate: any) => {
    setSelectedDate(newDate);
    const value = getDateInStringFormat(newDate);
    setIsValueEmpty(false);
    setValue("input_date", value);
  };

  const subtractDaysFromDate = (date: Date, days: number) => {
    const result = new Date(date);
    result.setDate(result.getDate() - days);
    return result;
  };

  const onBankAccountNoSelection = () => {
    setIsBankAccountModalOpen(true);
    setValue("ledger_code", "");
    setValue("ledger_des", "");
    setValue("bank_account", "");
  };

  const onBankAccountSelection = (selectedItem: ISelectedItem | undefined) => {
    const bankAccount = bankreconBankAccounts.filter((s) => s.ledger_code === selectedItem?.value)[0];
    if (selectedItem?.text) {
      setBankId(bankAccount?.bank_id);
      dispatch(
        getBankreconAccountNo({
          bankId: bankAccount.bank_id,
          callback: (data) => {
            if (data) {
              setValue("ledger_code", bankAccount?.ledger_code, { shouldValidate: true });
              setValue("ledger_des", bankAccount?.ledger_des);
              setValue("bank_account", data?.bank_account);
              if (data?.statementNo >= 0) {
                setIsStatementNoEmpty(false);
                setValue("statement_no", data?.statementNo + 1);
              }
            }
          }
        })
      );
      dispatch(bankReconActions.selectBankAccountRow(bankAccount));
    } else {
      dispatch(bankReconActions.selectBankAccountRow(undefined));
    }
  };

  const onBankAccountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    register("ledger_code").onChange(e);
    const { value } = e.target;
    if (!value.trim()) {
      dispatch(bankReconActions.selectBankAccountRow(undefined));
      setValue("ledger_code", specialCharacters.BLANKVALUE);
      setValue("ledger_des", specialCharacters.BLANKVALUE);
      setValue("bank_account", specialCharacters.BLANKVALUE);
      dispatch(bankReconActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(bankReconActions.setFilters({ lookingFor: value }));
    }
  };

  const onSubmit = handleSubmit(
    (data) => {
      if (!data.input_date || !data.statement_no) {
        setIsOpenAlert(true);
        setAlertType(NotificationStatus.WARNING);
        setMessage(t("alertMessage.mandatoryFields.message"));
        return;
      }
      const date = parse(data.input_date, "dd/MM/yyyy", new Date());
      const currentDate = new Date();

      const isFutureDate = isAfter(date, currentDate);
      setFutureDate(isFutureDate);

      const formattedDate = format(date, "yyyy-MM-dd");
      setFormattedDate(formattedDate);
      dispatch(
        bankreconValidateStatement({
          bankId: Number(bankId),
          StatementNo: Number(data.statement_no),
          statementDate: formattedDate,
          uniqueIdentifier: "ceebaf9a-5b87-47a5-bd53-8804a4ac2e97",
          callback: (validateData) => {
            if (!validateData.isValid && isFutureDate) {
              setIsOpenAlert(true);
              setIsValueEmpty(true);
              setAlertType(NotificationStatus.WARNING);
              setMessage(t("alertMessage.statementCannotBeFuture.message"));
            } else if (validateData.isValid && !validateData.continue) {
              setMessage(validateData.message);
              setIsBankreconWarningMsgOpen(true);
            } else if (validateData.continue) {
              setMessage(validateData.message);
              setIsBankReconLastStatementOpen(true);
            } else if (validateData.isValid && isFutureDate) {
              setIsOpenAlert(true);
              setIsValueEmpty(true);
              setAlertType(NotificationStatus.WARNING);
              setMessage(t("alertMessage.statementCannotBeFuture.message"));
            } else {
              dispatch(
                addBankreconStatement({
                  bankId: Number(bankId),
                  StatementNo: Number(data.statement_no),
                  statementDate: formattedDate,
                  seriesNo: validateData.series_no,
                  uniqueIdentifier: "ceebaf9a-5b87-47a5-bd53-8804a4ac2e97",
                  callback: (responseData) => {
                    const newHistoryState = {
                      formattedDate,
                      isDirty: true,
                      selectedRowState: responseData.bankReconciliationStatement
                    };
                    const nextStartDate = historyState?.nextYearStartDate;
                    history.push({
                      pathname: `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankId}/bankStatementId/${responseData.bankReconciliationStatement.bank_statement_id}`,
                      state: {
                        ...newHistoryState,
                        nextYearStartDate: nextStartDate,
                        from: "add statement"
                      }
                    });
                  }
                })
              );
            }
          }
        })
      );
    },
    (error) => {
      setMessage(t("alertMessage.mandatoryFields.message"));
      setIsOpenAlert(true);
      setAlertType(NotificationStatus.WARNING);
    }
  );

  useEffect(() => {
    dispatch(
      getBankreconBankAccounts({
        sequence: Number(KEYBOARD_STRING.Zero),
        callback: async (data) => {
          if (data.length === 1) {
            setBankId(data[0].bank_id);
            const bankReconAccountNo: any = await dispatch(getBankreconAccountNo({ bankId: data[0].bank_id }));
            if (bankReconAccountNo) {
              setValue("ledger_code", data[0]?.ledger_code, { shouldValidate: true });
              setValue("ledger_des", data[0]?.ledger_des);
              setValue("bank_account", bankReconAccountNo?.payload?.bank_account);
              if (bankReconAccountNo?.payload?.statementNo) {
                setValue("statement_no", bankReconAccountNo?.payload?.statementNo + 1);
              }
            }
          } else {
            setValue("statement_no", "0");
          }
        }
      })
    );
  }, []);

  const handleKeyDowInputn = (event: any) => {
    if (
      event.key === "Tab" ||
      event.key === "Backspace" ||
      event.key === "Delete" ||
      event.key === "ArrowLeft" ||
      event.key === "ArrowRight"
    ) {
      return;
    }
    if (!/^\d$/.test(event.key)) {
      event.preventDefault();
    }
  };

  return {
    t,
    setValue,
    getValues,
    register,
    watch,
    errors,
    bankreconBankAccounts,
    isConfirmModalOpen,
    setIsConfirmModalOpen,
    isBankAccountModalOpen,
    setIsBankAccountModalOpen,
    bankAccountClick,
    onBankAccountSelectedRow,
    onBankAccountSelection,
    formMethods,
    handleKeyDowInputn,
    dispatch,
    handleSubmit,
    setMessage,
    isOpenAlert,
    setIsOpenAlert,
    alertType,
    message,
    dateChangeHandler,
    isBankreconWarningMsgOpen,
    setIsBankreconWarningMsgOpen,
    bankId,
    isValueEmpty,
    setIsValueEmpty,
    bankStatus,
    bankAccountStatus,
    isBankReconLastStatementOpen,
    setIsBankReconLastStatementOpen,
    history,
    isStatementNoEmpty,
    setIsStatementNoEmpty,
    historyState,
    onSubmit,
    formattedDate,
    validateStatus,
    addBankreconStatus,
    subtractDaysFromDate,
    datepickerChangeHandler,
    selectedDate,
    onBankAccountNoSelection,
    onBankAccountChange,
    futureDate,
    setAlertType
  };
};

export default useAddStatement;
