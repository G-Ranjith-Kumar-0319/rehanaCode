import Input from "@/components/Input/Input";
import "./style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  ISelectedItem,
  Icon,
  IconColor,
  IconSize,
  Loader,
  LoaderType,
  NotificationStatus,
  TextInput,
  TextInputSize,
  ValidationTextLevel
} from "@essnextgen/ui-kit";
import DatePicker from "react-datepicker";
import { dateFormat, datePicker } from "@/utils/constants";

import { MIN_DATE, STATUS, specialCharacters } from "@/types/UseStateType";
import { forwardRef } from "react";
import InputDate from "@/shared/components/InputDate/InputDate";
import HelpButton from "@/components/OpenLinkButton/HelpButton";
import BankAccount from "@/shared/components/BankReconciliationBankAccount/BankAccount";
import AlertModal from "@/shared/components/AlertModal/AlertModal";
import { actions as bankReconActions } from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import useAddStatement from "./useAddStatement";
import { addBankreconStatement, bankRecActions } from "../state/BankReconciliation.slice";

const AddStatement = () => {
  const {
    t,
    setValue,
    getValues,
    register,
    watch,
    errors,
    bankreconBankAccounts,
    isBankAccountModalOpen,
    setIsBankAccountModalOpen,
    bankAccountClick,
    onBankAccountSelectedRow,
    onBankAccountSelection,
    handleKeyDowInputn,
    dispatch,
    isOpenAlert,
    setIsOpenAlert,
    alertType,
    message,
    dateChangeHandler,
    isBankreconWarningMsgOpen,
    setIsBankreconWarningMsgOpen,
    bankId,
    isValueEmpty,
    setIsValueEmpty,
    bankStatus,
    bankAccountStatus,
    isBankReconLastStatementOpen,
    setIsBankReconLastStatementOpen,
    history,
    isStatementNoEmpty,
    setIsStatementNoEmpty,
    onSubmit,
    formattedDate,
    validateStatus,
    addBankreconStatus,
    subtractDaysFromDate,
    datepickerChangeHandler,
    selectedDate,
    historyState,
    onBankAccountNoSelection,
    onBankAccountChange,
    futureDate,
    setAlertType,
    setMessage
  } = useAddStatement();

  const CustomButton = forwardRef(({ value, onClick }: any, ref: any) => (
    <Button
      color={ButtonColor.Secondary}
      onClick={onClick}
      className="input-search-button essui-button-icon-only--small"
      size={ButtonSize.Small}
      ref={ref}
      aria-label="search"
    >
      <Icon
        size={IconSize.Medium}
        color={IconColor.Primary500}
        name="calendar"
      />
    </Button>
  ));

  return (
    <>
      {(bankStatus === STATUS.LOADING && isBankAccountModalOpen === false) ||
      bankAccountStatus === STATUS.LOADING ||
      validateStatus === STATUS.LOADING ||
      addBankreconStatus === STATUS.LOADING ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : null}
      {bankStatus === STATUS.SUCCESS &&
      bankAccountStatus !== STATUS.LOADING &&
      validateStatus !== STATUS.LOADING &&
      addBankreconStatus !== STATUS.LOADING ? (
        <Layout
          pageTitle={t("bankReconciliation.addAStatement")}
          className="add-statement"
        >
          <Grid container>
            <GridItem
              sm={12}
              md={12}
              lg={12}
              xl={12}
              className="mb-15"
            >
              <div className="essui-global-typography-default-subtitle">{t("bankReconciliation.account")}</div>
            </GridItem>
          </Grid>
          <Grid container>
            <GridItem
              sm={4}
              md={4}
              lg={5}
              xl={5}
              className="mb-8"
            >
              <div className="essui-form-label">{t("bankReconciliation.account")}</div>
              <div className="two-inputs">
                <div className="width-25">
                  <Input
                    id="BankReconAccount"
                    searchable
                    autoFocus
                    searchItems={bankreconBankAccounts.map((b) => ({
                      text: b.ledger_code,
                      value: b.ledger_code
                    }))}
                    onSelect={(selectedItem: ISelectedItem | undefined) => onBankAccountSelection(selectedItem)}
                    onNoSelection={onBankAccountNoSelection}
                    inputWidth={108}
                    isLabel={false}
                    maxLength={100}
                    value={watch("ledger_code")}
                    inputRef={(e) => register("ledger_code").ref(e)}
                    name={register("ledger_code", { required: true }).name}
                    onBlur={(e: any) => register("ledger_code").onBlur(e)}
                    onChange={onBankAccountChange}
                    validationTextLevel={errors.ledger_code ? ValidationTextLevel.Error : undefined}
                  />
                </div>
                <div className="width100 playback">
                  <div className="read-only essui-textinput essui-textinput--medium width-88">
                    {watch("ledger_des")}
                  </div>
                  <div className="playback">
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      aria-label="search"
                      onClick={bankAccountClick}
                      className="essui-button-icon-only--small"
                    >
                      <Icon
                        color={IconColor.Primary500}
                        size={IconSize.Medium}
                        name="search"
                      />
                    </Button>
                  </div>
                </div>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
              className="mb-8"
            >
              <FormLabel forId="txtAccountNumber">{t("bankReconciliation.number")}</FormLabel>
              <div className="w-100 read-only essui-textinput essui-textinput--medium">{watch("bank_account")}</div>
            </GridItem>
          </Grid>

          <Divider />

          <Grid container>
            <GridItem
              sm={4}
              md={4}
              lg={12}
              xl={12}
              className="mb-20 mr-t10"
            >
              <div className="essui-global-typography-default-subtitle">{t("bankReconciliation.statement")}</div>
            </GridItem>
          </Grid>
          <Grid container>
            <GridItem
              sm={4}
              md={4}
              lg={5}
              xl={5}
              className="mb-8"
            >
              <div className="input-search">
                <FormLabel forId="txtNumber">{t("bankReconciliation.number")}</FormLabel>
                <div>
                  <TextInput
                    className={`text-width w-100 ${isStatementNoEmpty ? "value-empty" : ""}`}
                    maxLength={4}
                    value={watch("statement_no")}
                    inputRef={(e) => register("statement_no").ref(e)}
                    onChange={(e) => {
                      let { value } = e.target;
                      value = value.replace(/\D/g, "").replace(/^0+/, "");
                      setValue("statement_no", value);
                      register("statement_no").onChange(e);
                      if (value) {
                        setIsStatementNoEmpty(false);
                      } else {
                        setIsStatementNoEmpty(true);
                      }
                    }}
                    name={register("statement_no").name}
                    onKeyDown={handleKeyDowInputn}
                    validationTextLevel={errors.statement_no ? ValidationTextLevel.Error : undefined}
                  />
                </div>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={4}
              lg={3}
              xl={3}
              className="mb-8"
            >
              <FormLabel forId="looking-for">{t("bankReconciliation.date")}</FormLabel>
              <div className="looking-for">
                <InputDate
                  id="looking-for"
                  dateSeparator="/"
                  size={TextInputSize.Medium}
                  value={watch("input_date")}
                  autoComplete={false}
                  searchable={false}
                  onDateChange={(date) => {
                    if (date) {
                      setIsValueEmpty(false);
                    } else {
                      setIsValueEmpty(true);
                    }
                    setValue("input_date", date);
                  }}
                  className={isValueEmpty ? "value-empty" : ""}
                />
                <DatePicker
                  onChange={() => {}}
                  customInput={<CustomButton />}
                  maxDate={subtractDaysFromDate(historyState.nextYearStartDate, 0)}
                  minDate={new Date(MIN_DATE.MINDATE)}
                  showMonthDropdown
                  showYearDropdown
                  selected={selectedDate}
                  onSelect={datepickerChangeHandler}
                  dateFormat={dateFormat.european}
                  value={selectedDate ? selectedDate!.toLocaleDateString("en-GB").toString() : ""}
                  dropdownMode="scroll"
                  scrollableYearDropdown
                  yearDropdownItemNumber={datePicker.NumberofItemsInDropdown}
                />
              </div>
            </GridItem>
          </Grid>
          <Grid
            justify="space-between"
            className="mt-8"
          >
            <GridItem
              sm={8}
              lg={8}
              md={4}
            >
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </GridItem>
            <GridItem>
              <Grid
                className="action-buttons"
                justify="space-between"
              >
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  onClick={() => {
                    history.replace({
                      ...history.location,
                      state: {
                        ...(history.location.state as any),
                        ...historyState,
                        isDirty: false
                      }
                    });
                    history.goBack();
                  }}
                >
                  {t("common.cancel")}
                </Button>
                <Button
                  size={ButtonSize.Small}
                  onClick={async () => {
                    onSubmit();
                  }}
                >
                  {t("common.save")}
                </Button>
              </Grid>
            </GridItem>
          </Grid>
        </Layout>
      ) : null}
      <BankAccount
        isOpen={isBankAccountModalOpen}
        setOpen={setIsBankAccountModalOpen}
        onSelectedRow={onBankAccountSelectedRow}
      />
      <AlertModal
        isOpen={isOpenAlert}
        setOpen={setIsOpenAlert}
        title={t("alertMessage.title")}
        notificationType={alertType}
        message={message}
        callback={() => {
          const inputDate = getValues("input_date");
          const statementNo = getValues("statement_no");
          if (!inputDate) {
            setIsValueEmpty(true);
          }
          if (!statementNo) {
            setIsStatementNoEmpty(true);
          }
          setIsOpenAlert(false);
        }}
      />
      <AlertModal
        isOpen={isBankreconWarningMsgOpen}
        setOpen={setIsBankreconWarningMsgOpen}
        title={t("alertMessage.title")}
        notificationType={NotificationStatus.WARNING}
        message={message}
        callback={() => {
          setIsStatementNoEmpty(true);
          setIsBankreconWarningMsgOpen(false);
        }}
      />
      <ConfirmModal
        isOpen={isBankReconLastStatementOpen}
        setOpen={setIsBankReconLastStatementOpen}
        title={t("alertMessage.title")}
        message={message}
        className="close-button-disabled"
        confirm={() => {
          if (futureDate) {
            setIsOpenAlert(true);
            setIsValueEmpty(true);
            setAlertType(NotificationStatus.WARNING);
            setMessage(t("alertMessage.statementCannotBeFuture.message"));
          } else {
            dispatch(
              addBankreconStatement({
                bankId: Number(bankId),
                StatementNo: Number(getValues("statement_no")),
                statementDate: formattedDate,
                seriesNo: 1,
                uniqueIdentifier: "ceebaf9a-5b87-47a5-bd53-8804a4ac2e97",
                callback: (responseData) => {
                  const newHistoryState = {
                    formattedDate,
                    isDirty: true,
                    selectedRowState: responseData.bankReconciliationStatement
                  };
                  const nextStartDate = historyState?.nextYearStartDate;
                  history.push({
                    pathname: `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankId}/bankStatementId/${responseData.bankReconciliationStatement.bank_statement_id}`,
                    state: {
                      ...newHistoryState,
                      nextYearStartDate: nextStartDate,
                      from: "add statement"
                    }
                  });
                }
              })
            );
          }
        }}
        callback={({ confirm }) => {
          if (futureDate) {
            setIsOpenAlert(true);
            setIsValueEmpty(true);
            setAlertType(NotificationStatus.WARNING);
            setMessage(t("alertMessage.statementCannotBeFuture.message"));
          }
          if (!confirm) {
            setIsStatementNoEmpty(true);
            setIsBankReconLastStatementOpen(false);
          }
        }}
      />
    </>
  );
};
export default AddStatement;
