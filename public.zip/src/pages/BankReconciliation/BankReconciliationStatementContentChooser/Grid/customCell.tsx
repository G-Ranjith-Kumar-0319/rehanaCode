import { cellRendererType } from "../../../../components/GridTable/GridTable";

const CustomCell = ({ field, row }: cellRendererType) => {
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const getContent = () => {
    switch (field) {
      case "item_date":
        return (
          <>
            {new Date(row?.item_date).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })}
          </>
        );
      case "rcvamount":
        return <>{numberFormatter.format(row?.rcvamount)}</>;
      case "payamount":
        return <>{numberFormatter.format(row?.payamount)}</>;
      default: {
        return <div />;
      }
    }
  };
  return getContent();
};

export default CustomCell;
