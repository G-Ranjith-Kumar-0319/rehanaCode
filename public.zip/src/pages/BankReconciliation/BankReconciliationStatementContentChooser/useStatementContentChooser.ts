import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { RowType, TColumnDef } from "@/components/GridTableNew/GridTableNew";
import { sortByDiffKey, usNumberFormat, getSessionItem as getSessionData } from "@/utils/getDataSource";
import { useHistory, useParams } from "react-router-dom";
import useDebounce from "@/hooks/useDebounce";
import foundNearestMatch from "@/utils/nearestMatch";
import { deepEqual } from "@/utils/constants";
import { BUTTON_TYPE, SCC_SEQUENCE_TYPE } from "@/types/UseStateType";
import ColumnDef from "./Grid/columnDef";
import { getBankReconciliationStatement, actions as sccActions } from "../state/BankReconciliationStatement.slice";

const useStatementContentsChooser = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const {
    bankReconStatus,
    unreconciledDetails: unreconciledList,
    reconciledDetails: reconciledList,
    sccFilterState,
    sccColumnDef,
    selectedBankReconiledRow,
    selectedBankUnreconciledRow
  } = useAppSelector((state) => state.bankReconciliationStatement);
  const [sequenceValue, setSequenceValue] = useState<string>(sccFilterState?.sequenceValue!);
  const [columns, setColumn] = useState<TColumnDef>([...ColumnDef]);
  const [isShowArrowDown, setIsShowArrowDown] = useState<boolean>(false);
  const [lookingFor, setLookingFor] = useState<string>("");
  const debouncedValue = useDebounce(lookingFor!, 600);
  const [buttonClicked, setButtonClicked] = useState<any>("");
  const [selectedRow, setSelectedRow] = useState<any>("");

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const { bankid, bankStatementId } = useParams<{
    bankid: string;
    bankStatementId: any;
  }>();

  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const calculateTotal = (
    transactions: any[] | undefined,
    key: SCC_SEQUENCE_TYPE.RCV_AMOUNT | SCC_SEQUENCE_TYPE.PAY_AMOUNT
  ): number => transactions?.reduce((total, item) => total + Number(item[key]), 0.0) ?? 0.0;

  const calculateStatementDetails = (transactions: any) => {
    if (!transactions) return { totalReceipts: 0.0, totalPayments: 0.0, netAmount: 0.0 };

    const receiptsValue = calculateTotal(transactions, SCC_SEQUENCE_TYPE.RCV_AMOUNT);
    const totalReceipts = usNumberFormat(receiptsValue);
    const paymentsValue = calculateTotal(transactions, SCC_SEQUENCE_TYPE.PAY_AMOUNT);
    const totalPayments = usNumberFormat(paymentsValue);
    const netAmount = usNumberFormat(receiptsValue - paymentsValue);
    const newAmountRaw = receiptsValue - paymentsValue;

    return { totalReceipts, totalPayments, netAmount, newAmountRaw };
  };

  const unreconciledDetails = calculateStatementDetails(unreconciledList);
  const reconciledDetails = calculateStatementDetails(reconciledList);

  const unreconciledTotalReceipts = unreconciledDetails.totalReceipts;
  const reconciledTotalReceipts = reconciledDetails.totalReceipts;
  const unreconciledTotalPayments = unreconciledDetails.totalPayments;
  const reconciledTotalPayments = reconciledDetails.totalPayments;
  const unreconciledNetAmount = unreconciledDetails.netAmount;
  const reconciledNetAmount = reconciledDetails.netAmount;
  const openingBal = historyState?.selectedBankReconRow?.opening_bal ?? "0.00";

  const closingBalance = openingBal + reconciledDetails?.newAmountRaw ?? 0.0;

  const lookingForChangehandler = (value: string) => {
    setLookingFor(value);
  };

  const lookingForCallback = (value: any) => {
    lookingForChangehandler(value);
  };

  const isDate = (value: string) => {
    const dateRegex = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/;
    return dateRegex.test(value);
  };

  const convertToISODate = (value: string) => {
    const [day, month, year] = value.split("/");
    return `${year}-${month}-${day}`;
  };

  const findNearestDate = (list: any[], targetDate: string): any => {
    const targetTime = new Date(targetDate).getTime();
    let nearestPast: any = null;
    let nearestFuture: any = null;

    list.forEach((item) => {
      const itemTime = new Date(item.item_date).getTime();

      if (itemTime <= targetTime) {
        if (!nearestPast || targetTime - itemTime < targetTime - new Date(nearestPast.item_date).getTime()) {
          nearestPast = item;
        }
      } else if (!nearestFuture || itemTime - targetTime < new Date(nearestFuture.item_date).getTime() - targetTime) {
        nearestFuture = item;
      }
    });

    return nearestPast || nearestFuture;
  };

  useEffect(() => {
    dispatch(sccActions.setSccColumnDef(ColumnDef));
    if (historyState?.sccDetails === undefined) {
      dispatch(
        getBankReconciliationStatement({
          bankId: bankid,
          bank_statement_id: bankStatementId,
          sequence: 0,
          statementChooser: true,
          uniqueIdentifier: getSessionData("uniqueIdentifier") ? getSessionData("uniqueIdentifier") : "",
          callback: (data) => {
            if (data?.unreconciledDetails?.bankReconciledTransactions.length > 0) {
              setIsShowArrowDown(false);
              dispatch(
                sccActions.setSelectedBankUnReconiledRow(data.unreconciledDetails.bankReconciledTransactions[0])
              );
            }
            if (data?.reconciledDetails?.bankReconciledTransactions.length > 0) {
              dispatch(sccActions.setSelectedBankReconiledRow(data?.reconciledDetails?.bankReconciledTransactions[0]));
            }
          }
        })
      );
    } else {
      if (unreconciledList.length > 0) {
        dispatch(sccActions.setSelectedBankUnReconiledRow(unreconciledList[0]));
      }
      if (reconciledList.length > 0) {
        dispatch(sccActions.setSelectedBankReconiledRow(reconciledList[0]));
      }
    }
  }, []);

  useEffect(() => {
    if (lookingFor !== sccFilterState?.lookingFor && lookingFor !== undefined) {
      setLookingFor(lookingFor);
    }
  }, [lookingFor, sccFilterState?.lookingFor]);

  const handleFindAndScroll = (list: any, action: any, elementIdPrefix: string) => {
    let found: { [key: string]: any } | null | undefined;
    let searchValue: string;
    const reversedList = [...list].reverse();
    if (isDate(debouncedValue)) {
      searchValue = convertToISODate(debouncedValue);
      found = findNearestDate([...list], searchValue);
    } else if (sequenceValue !== SCC_SEQUENCE_TYPE.PAY_AMOUNT && sequenceValue !== SCC_SEQUENCE_TYPE.RCV_AMOUNT) {
      searchValue = debouncedValue?.toUpperCase();
      found = [...list].find((element) =>
        debouncedValue ? element[sequenceValue]?.toString()?.toUpperCase()?.startsWith(searchValue) : false
      );
    } else {
      searchValue = debouncedValue;
    }

    if (found && found !== undefined) dispatch(action(found));

    if (found === undefined) {
      found = foundNearestMatch([...list], [{ fieldName: sequenceValue, searchValue }], true);
      if (sequenceValue === SCC_SEQUENCE_TYPE.REF) {
        const foundIndex = list.findIndex((record: { [key: string]: any }) => record?.unique_id === found?.unique_id);
        if (foundIndex !== list.length - 1 && foundIndex > 0) {
          found = list[foundIndex + 1];
        }
      }
      dispatch(action(found!));
    }
    const element = document.getElementById(`${elementIdPrefix}-${list.indexOf(found!)}`);
    element?.scrollIntoView({ block: "center", behavior: "smooth" });
  };

  useEffect(() => {
    if (debouncedValue !== "") {
      if (unreconciledList && unreconciledList.length && !isShowArrowDown) {
        handleFindAndScroll(
          unreconciledList,
          sccActions.setSelectedBankUnReconiledRow,
          "rowIndex-unreconciledDetailsGrid"
        );
      } else if (reconciledList && reconciledList.length && isShowArrowDown) {
        handleFindAndScroll(reconciledList, sccActions.setSelectedBankReconiledRow, "rowIndex-reconciledDetailsGrid");
      }
    }
  }, [debouncedValue]);

  const onFocusUnreconciled = () => {
    lookingForChangehandler("");
    setIsShowArrowDown(false);
  };

  const onFocusReconciled = () => {
    lookingForChangehandler("");
    setIsShowArrowDown(true);
  };

  const handleKeyDowInputn = (event: any) => {
    const { key, target } = event;
    const input = target.value;

    if (key === "Tab" || key === "Backspace" || key === "Delete" || key === "ArrowLeft" || key === "ArrowRight") {
      return;
    }

    const isDigit = /^\d$/.test(key);
    const isAlphabet = /^[a-zA-Z]$/.test(key);
    const isDecimalPoint = key === "." && !input.includes(".");

    if (sequenceValue === SCC_SEQUENCE_TYPE.REF) {
      if (!isDigit && !isAlphabet) {
        event.preventDefault();
      }
    } else if (!isDigit && !isDecimalPoint) {
      event.preventDefault();
    }
  };

  const moveRecordToReconcile = () => {
    lookingForChangehandler("");
    if (unreconciledList.length > 0) {
      const recordMoveToDown = { ...selectedBankUnreconciledRow };
      setSelectedRow(recordMoveToDown);
      dispatch(sccActions.choose(recordMoveToDown));
      setButtonClicked(BUTTON_TYPE.CHOOSE);
    }
    history.replace({
      ...history.location,
      state: {
        ...historyState,
        isDirty: true
      }
    });
    setIsShowArrowDown(true);
  };

  const moveAllRecordsToReconcile = () => {
    lookingForChangehandler("");
    if (unreconciledList.length > 0) {
      dispatch(sccActions.chooseAll());
      setButtonClicked(BUTTON_TYPE.CHOOSE_ALL);
      history.replace({
        ...history.location,
        state: {
          ...historyState,
          isDirty: true
        }
      });
    }
    setIsShowArrowDown(true);
  };

  const removeRecordFromReconcile = () => {
    lookingForChangehandler("");
    if (reconciledList.length > 0) {
      const recordMoveToUp = { ...selectedBankReconiledRow };
      setSelectedRow(recordMoveToUp);
      dispatch(sccActions.remove(recordMoveToUp));
      setButtonClicked(BUTTON_TYPE.REMOVE);
    }
    history.replace({
      ...history.location,
      state: {
        ...historyState,
        isDirty: true
      }
    });
    setIsShowArrowDown(false);
  };

  const removeAllRecordsFromReconcile = () => {
    lookingForChangehandler("");
    if (reconciledList.length > 0) {
      dispatch(sccActions.removeAll());
      setButtonClicked(BUTTON_TYPE.REMOVE_ALL);
      history.replace({
        ...history.location,
        state: {
          ...historyState,
          isDirty: true
        }
      });
    }
    setIsShowArrowDown(false);
  };

  const handleSortingAndDispatch = (
    list: any,
    setDetailsAction: any,
    setSelectedRowAction: any,
    elementPrefix: any
  ) => {
    const sortedList = sortByDiffKey(list, String(sequenceValue), SCC_SEQUENCE_TYPE.REF);
    dispatch(setDetailsAction(sortedList));

    if (buttonClicked === BUTTON_TYPE.CHOOSE || buttonClicked === BUTTON_TYPE.REMOVE) {
      dispatch(setSelectedRowAction(selectedRow));
    } else {
      dispatch(setSelectedRowAction(sortedList[sortedList.length - 1]));
    }

    setTimeout(() => {
      const index =
        buttonClicked === BUTTON_TYPE.CHOOSE || buttonClicked === BUTTON_TYPE.REMOVE
          ? sortedList.findIndex((row: { [key: string]: any }) => row?.unique_id === selectedRow?.unique_id)
          : sortedList.length - 1;
      const element = document.getElementById(`${elementPrefix}-${index}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
      setSelectedRow("");
      setButtonClicked("");
    }, 500);
  };

  useEffect(() => {
    if (buttonClicked === BUTTON_TYPE.CHOOSE) {
      handleSortingAndDispatch(
        reconciledList,
        sccActions.setReconiledDetails,
        sccActions.setSelectedBankReconiledRow,
        "rowIndex-reconciledDetailsGrid"
      );
    } else if (buttonClicked === BUTTON_TYPE.REMOVE) {
      handleSortingAndDispatch(
        unreconciledList,
        sccActions.setUnReconiledDetails,
        sccActions.setSelectedBankUnReconiledRow,
        "rowIndex-unreconciledDetailsGrid"
      );
    } else if (buttonClicked === BUTTON_TYPE.CHOOSE_ALL) {
      handleSortingAndDispatch(
        reconciledList,
        sccActions.setReconiledDetails,
        sccActions.setSelectedBankReconiledRow,
        "rowIndex-reconciledDetailsGrid"
      );
    } else if (buttonClicked === BUTTON_TYPE.REMOVE_ALL) {
      handleSortingAndDispatch(
        unreconciledList,
        sccActions.setUnReconiledDetails,
        sccActions.setSelectedBankUnReconiledRow,
        "rowIndex-unreconciledDetailsGrid"
      );
    }
  }, [buttonClicked]);

  const scrollToFirstElement = (list: any, setDataAction: any, gridId: string, value: any) => {
    if (list.length > 0) {
      const sortedList = sortByDiffKey(list, String(value), SCC_SEQUENCE_TYPE.REF);
      dispatch(setDataAction(sortedList));
    }
  };

  const handleSequenceChange = (value: React.SetStateAction<string>, sequenceIndex: number) => {
    lookingForChangehandler("");
    let columnSet = [];
    switch (value) {
      case "item_date":
        columnSet = new Set([columns[0], columns[1], columns[2], columns[3], columns[4], columns[5]]) as any;
        dispatch(sccActions.setSccColumnDef(columnSet));
        break;

      case "ref":
        columnSet = new Set([columns[1], columns[0], columns[2], columns[3], ...sccColumnDef]) as any;
        dispatch(sccActions.setSccColumnDef(columnSet));
        break;

      case "payamount":
        columnSet = new Set([columns[4], columns[5], columns[1], columns[0], ...sccColumnDef]) as any;
        dispatch(sccActions.setSccColumnDef(columnSet));
        break;

      case "rcvamount":
        columnSet = new Set([columns[5], columns[4], columns[1], columns[0], ...sccColumnDef]) as any;
        dispatch(sccActions.setSccColumnDef(columnSet));
        break;

      default:
        columnSet = new Set([columns[0], columns[1], columns[2], columns[3], ...sccColumnDef]) as any;
        dispatch(sccActions.setSccColumnDef(columnSet));
        break;
    }
    setColumn([...ColumnDef]);
    setSequenceValue(value);
    if (isShowArrowDown) {
      scrollToFirstElement(unreconciledList, sccActions.setUnreconciledSortedData, "unreconciledDetailsGrid", value);
      scrollToFirstElement(reconciledList, sccActions.setReconciledSortedData, "reconciledDetailsGrid", value);
    } else {
      scrollToFirstElement(reconciledList, sccActions.setReconciledSortedData, "reconciledDetailsGrid", value);
      scrollToFirstElement(unreconciledList, sccActions.setUnreconciledSortedData, "unreconciledDetailsGrid", value);
    }
  };

  const onReconiledRowSelect = (row: { [key: string]: any } | undefined) => {
    if (!row || (Array.isArray(row) && row.length === 0)) {
      return;
    }
    if (deepEqual(row, selectedBankReconiledRow)) {
      dispatch(sccActions.setSelectedBankReconiledRow(selectedBankReconiledRow));
    } else {
      dispatch(sccActions.setSelectedBankReconiledRow(row));
    }
  };

  const onUnReconiledRowSelect = (row: any) => {
    if (!row || (Array.isArray(row) && row.length === 0)) {
      return;
    }
    if (deepEqual(row, selectedBankUnreconciledRow)) {
      dispatch(sccActions.setSelectedBankUnReconiledRow(selectedBankUnreconciledRow));
    } else {
      dispatch(sccActions.setSelectedBankUnReconiledRow(row));
    }
  };

  const onSaveHandler = () => {
    dispatch(sccActions.addSccRow(reconciledList));
    const newHistoryState = {
      ...historyState,
      sccDetails: reconciledList,
      isDirty: true
    };
    history.push(
      `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}`,
      {
        ...newHistoryState
      }
    );
  };

  const onCancelHandler = () => {
    dispatch(sccActions.updateSccRow());
    history.push(
      `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}`,
      {
        ...historyState
      }
    );
  };

  return {
    t,
    handleSequenceChange,
    sccColumnDef,
    sequenceValue,
    bankReconStatus,
    selectedBankReconiledRow,
    selectedBankUnreconciledRow,
    onReconiledRowSelect,
    onUnReconiledRowSelect,
    unreconciledTotalReceipts,
    reconciledTotalReceipts,
    unreconciledTotalPayments,
    reconciledTotalPayments,
    unreconciledNetAmount,
    reconciledNetAmount,
    moveRecordToReconcile,
    moveAllRecordsToReconcile,
    removeRecordFromReconcile,
    removeAllRecordsFromReconcile,
    reconciledDetails: reconciledList,
    unreconciledDetails: unreconciledList,
    isShowArrowDown,
    setIsShowArrowDown,
    lookingFor,
    lookingForCallback,
    onFocusReconciled,
    onFocusUnreconciled,
    onSaveHandler,
    onCancelHandler,
    historyState,
    numberFormatter,
    closingBalance,
    handleKeyDowInputn
  };
};

export default useStatementContentsChooser;
