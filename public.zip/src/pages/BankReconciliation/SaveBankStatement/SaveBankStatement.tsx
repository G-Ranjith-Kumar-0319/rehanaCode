import Layout from "@/components/Layout/Layout";
import { FormLabel, Grid, GridItem } from "@essnextgen/ui-kit";

const SaveBankStatement = () => (
  <>
    <Layout
      className="save-bank-statement"
      pageTitle="Save Bank a Statement"
    >
      <div className="">
        <Grid
          container
          dataTestId="test-id"
          className="row-gap-16"
        >
          <GridItem
            lg={3}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div className="">
              <div className="essui-form-label mb-5">St. No.</div>
              <div>1253</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div className="">
              <div className="essui-form-label mb-5">St. Date</div>
              <div>18 March 2024</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div className="">
              <div className="essui-form-label mb-5">Account No.</div>
              <div>01177112</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div className="">
              <div className="essui-form-label mb-5">Acc. Sort Code</div>
              <div>40-32-16</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div className="">
              <div className="essui-form-label mb-5">Bank Ledger</div>
              <div>6,01218.13</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div className="">
              <div className="essui-form-label mb-5">Open. Balance</div>
              <div>7,01602.45</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            md={4}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div className="">
              <div className="essui-form-label mb-5">Close. Balance</div>
              <div>6,99999.00</div>
            </div>
          </GridItem>
        </Grid>
      </div>
    </Layout>
  </>
);

export default SaveBankStatement;
