import Layout from "@/components/Layout/Layout";
import { Button, ButtonColor, ButtonSize, Grid, GridItem, useTranslation } from "@essnextgen/ui-kit";

const DebitCardPaymentView = () => (
  <Layout pageTitle="Debit Card Payment View">
    <Grid>
      <GridItem
        sm={3}
        md={4}
        lg={6}
        xl={6}
      >
        <div>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Tertiary}
          >
            Help
          </Button>
        </div>
      </GridItem>
    </Grid>
  </Layout>
);
export default DebitCardPaymentView;
