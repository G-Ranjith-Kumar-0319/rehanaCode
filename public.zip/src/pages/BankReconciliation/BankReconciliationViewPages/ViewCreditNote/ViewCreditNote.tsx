import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  Orientation,
  useTranslation
} from "@essnextgen/ui-kit";
import { UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import Input from "@/components/Input/Input";

const ViewCreditNote = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  return (
    <>
      <Layout
        pageTitle="View Credit Note"
        isBreadcrumbRequired
      >
        <Grid>
          <GridItem
            lg={4}
            xl={4}
          >
            <div className="essui-form-label mb-5">{t("bankReconciliation.supplier")}</div>
            <div className="">
              <p className="m-0">Buckwell Publishers</p>
              <p className="m-0">32 Kings Park West</p>
              <p className="m-0"> BridgeWater Tranding Estate</p>
              <p className="m-0">Banbury</p>
            </div>
          </GridItem>
          <GridItem
            lg={8}
            xl={8}
            className="border-left"
          >
            <Grid className="row-gap-16">
              <GridItem
                sm={2}
                md={4}
                lg={4}
                xl={4}
              >
                <div className="essui-form-label mb-5">{t("bankReconciliation.creditNoteNumber")}</div>
                <div>10 Feb 2023</div>
              </GridItem>
              <GridItem
                sm={2}
                md={4}
                lg={4}
                xl={4}
              >
                <div className="essui-form-label mb-5">{t("bankReconciliation.creditDate")}</div>
                <div>10 Feb 2023</div>
              </GridItem>
              <GridItem
                sm={2}
                md={4}
                lg={4}
                xl={4}
              >
                <div className="essui-form-label mb-5">{t("bankReconciliation.invoiceNumber")}</div>
                <div>1</div>
              </GridItem>
              <GridItem
                sm={2}
                md={4}
                lg={4}
                xl={4}
              >
                <div className="essui-form-label mb-5">{t("bankReconciliation.creditNoteTotal")}</div>
                <div>152,338.00</div>
              </GridItem>
              <GridItem
                sm={2}
                md={4}
                lg={4}
                xl={4}
              >
                <div className="essui-form-label mb-5">{t("bankReconciliation.payTo")}</div>
                <div>Bank Account</div>
              </GridItem>
              <GridItem
                sm={2}
                md={4}
                lg={4}
                xl={4}
                className="d-flex align-center"
              >
                <CheckBox
                  id="txtCheckbox"
                  isSelected={false}
                  label={t("bankReconciliation.onHold")}
                  onChange={() => {}}
                />
              </GridItem>
            </Grid>
            <Divider orientation={Orientation.HORIZONTAL} />
          </GridItem>
          <GridItem
            lg={4}
            xl={4}
            className="mt-32"
          >
            <Input
              id="status"
              searchable={false}
              value="Paid"
              button={
                <Button
                  color={ButtonColor.Secondary}
                  onClick={() => {}}
                  size={ButtonSize.Small}
                  className="essui-button-icon-only--small"
                  ariaLabel="Status-btn"
                >
                  <Icon
                    color={IconColor.Primary500}
                    size={IconSize.Medium}
                    name="view"
                  />
                </Button>
              }
              disabled
              labelText={t("bankReconciliation.status")}
            />
          </GridItem>
        </Grid>
        <Grid className="mt-8">
          <GridItem
            lg={12}
            xl={12}
          >
            <div className="essui-form-label mb-5">{t("bankReconciliation.narrative")}</div>
            <div>Test</div>
          </GridItem>
        </Grid>
      </Layout>

      <Layout isBreadcrumbRequired={false}>
        <Grid className="mt-6">
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-8">
              <div className="essui-form-label">{t("bankReconciliation.totalVat")}</div>
              <div className="mt-8">0.00</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-8">
              <div className="essui-form-label">{t("bankReconciliation.tranNo")}</div>
              <div className="mt-8">00027087</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            xl={3}
            sm={2}
          >
            <div className="mb-8">
              <div className="essui-form-label">{t("bankReconciliation.invoiveTotalIncludingVat")}</div>
              <div className="mt-8">23.00</div>
            </div>
          </GridItem>
        </Grid>
        <Grid>
          <GridItem
            sm={3}
            md={4}
            lg={6}
            xl={6}
          >
            <div>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Tertiary}
              >
                Help
              </Button>
            </div>
          </GridItem>
        </Grid>
      </Layout>
    </>
  );
};
export default ViewCreditNote;
