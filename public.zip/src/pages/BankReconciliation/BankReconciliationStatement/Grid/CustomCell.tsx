import { cellRendererType } from "@/components/GridTable/GridTable";
import { RootContext, useAppContext } from "@/routes/Routes";
import { Button, ButtonColor, ButtonSize, Icon, Notification, NotificationStatus } from "@essnextgen/ui-kit";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { useContext, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import {
  BANK_RECON_SOURCE_TYPE,
  BANK_RECON_TRANS_TYPE,
  BOOLEAN_DATA,
  getCurrentFinancialYear
} from "@/types/UseStateType";
import {
  checkTransCurrentYr,
  getBankViewGlFundToBack,
  getPaymentRunId
} from "../../state/BankReconciliationStatement.slice";
import BankReconciliationModals from "../BankReconciliationModals";

const CustomCell = ({ field, row }: cellRendererType) => {
  const { redirectToBankReconciledDetails } = useAppContext();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { bankreconciledDetailsLink } = redirectToBankReconciledDetails(row);
  const { bankRreconciliationList } = useAppSelector((state) => state.bankReconciliation);
  const history = useHistory();
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const dispatch = useDispatch<AppDispatch>();
  const state = history.location.state as any;
  const currentFinYear = getCurrentFinancialYear();
  const [isOpenAlert, setIsOpenAlert] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<string>("");
  const [isPCPaymentModalOpen, setIsPCPaymentModalOpen] = useState<boolean>(false);
  const [isARPaymentModalOpen, setIsARPaymentModalOpen] = useState<boolean>(false);
  const [isNIPaymentModalOpen, setIsNIPaymentModalOpen] = useState<boolean>(false);
  const [isFundToBank, setIsFundToBankOpen] = useState<boolean>(false);
  const { bankid, bankStatementId } = useParams<{ bankid: string; bankStatementId: any }>();
  const navigateToApType = () => {
    let apNavUrl = `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}/`;
    const transType: string = row?.unique_id?.slice(0, 2);
    const paymentId: number = Number(row?.unique_id?.slice(2));
    switch (transType) {
      case BANK_RECON_SOURCE_TYPE.BACS_A:
      case BANK_RECON_SOURCE_TYPE.BACS_P:
        apNavUrl += `bacs-payment/view-payments/${paymentId}/B`;
        break;
      case BANK_RECON_SOURCE_TYPE.CHEQUE:
        fetchPaymentRunId();
        return;
      case BANK_RECON_SOURCE_TYPE.DEBIT_CARD:
        apNavUrl += `debit-payment/view-payments/${paymentId}/D`;
        break;
      default:
        break;
    }
    history.push(apNavUrl, {
      ...state
    });
  };
  const fetchPaymentRunId = () => {
    const paymentId: number = Number(row?.unique_id?.slice(2));
    dispatch(
      getPaymentRunId({
        paymentId,
        callback: (data) => {
          if (data?.length) {
            let apNavUrl = `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}/`;
            apNavUrl += `cheque-payment/cheque-processing/cheque-processing-detail/${data[0]?.payment_run_id}`;
            // let apNavUrl = `/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}/view-payment/${data[0]?.payment_run_id}/C`;
            history.push(apNavUrl, {
              ...state
            });
            // navigateToApType(data[0]?.payment_run_id);
          } else {
            setAlertMessage(t("purchaseOrder.errors.genricError"));
            setIsOpenAlert(true);
          }
        }
      })
    );
  };
  const checkForValidAR = () => {
    const invalidTransTypes = ["PA", "RI", "RF"];
    const transType: string = row?.unique_id?.slice(0, 2);
    if (!invalidTransTypes.includes(transType)) {
      setIsARPaymentModalOpen(true);
    } else {
      setAlertMessage(t("payingInProgress.arTypeError"));
      setIsOpenAlert(true);
    }
  };
  const openGLView = () => {
    const transType: string = row?.unique_id?.slice(0, 2);
    if (transType === "FB") {
      dispatch(
        getBankViewGlFundToBack({
          voucherLineId: Number(row?.unique_id?.slice(2))
        })
      );
      setIsFundToBankOpen(true);
    }
    if (transType === "JN")
      history.push(
        `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}/mannual-journal-processing`,
        {
          ...state
        }
      );
  };
  const viewTrasactionByType = () => {
    switch (row?.itemType) {
      case BANK_RECON_TRANS_TYPE.AP:
        navigateToApType();
        // fetchPaymentRunId();
        break;
      case BANK_RECON_TRANS_TYPE.PC:
        setIsPCPaymentModalOpen(true);
        break;
      case BANK_RECON_TRANS_TYPE.NI:
        setIsNIPaymentModalOpen(true);
        break;
      case BANK_RECON_TRANS_TYPE.AR:
        checkForValidAR();
        break;
      case BANK_RECON_TRANS_TYPE.GL:
        openGLView();
        break;
      default:
        break;
    }
  };

  const viewTransactionTypeHander = () => {
    setIsOpenAlert(false);
    setIsARPaymentModalOpen(false);
    setIsNIPaymentModalOpen(false);
    setIsPCPaymentModalOpen(false);
    dispatch(
      checkTransCurrentYr({
        uniqueId: row?.unique_id,
        currentYearId: Number(currentFinYear),
        callback: (data) => {
          if (data === BOOLEAN_DATA.True) {
            viewTrasactionByType();
          } else {
            setAlertMessage(data);
            setIsOpenAlert(true);
          }
        }
      })
    );
  };
  const getContent = () => {
    switch (field) {
      case "item_date":
        return (
          <>
            {new Date(row?.item_date).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            })}
          </>
        );
      case "rcvamount":
        return <>{numberFormatter.format(row?.rcvamount)}</>;
      case "payamount":
        return <>{numberFormatter.format(row?.payamount)}</>;
      case "actions":
        return (
          <>
            <Button
              color={ButtonColor.Utility}
              className="segments-buttons"
              onClick={() => viewTransactionTypeHander()}
            >
              {t("common.view02")}
            </Button>
            <BankReconciliationModals
              row={row!}
              isOpenAlert={isOpenAlert}
              setIsOpenAlert={setIsOpenAlert}
              alertMessage={alertMessage}
              isPCPaymentModalOpen={isPCPaymentModalOpen}
              setIsPCPaymentModalOpen={setIsPCPaymentModalOpen}
              isARPaymentModalOpen={isARPaymentModalOpen}
              setIsARPaymentModalOpen={setIsARPaymentModalOpen}
              isNIPaymentModalOpen={isNIPaymentModalOpen}
              isFundToBankJournalOpen={isFundToBank}
              setIsFundToBankJournalOpen={setIsFundToBankOpen}
              setIsNIPaymentModalOpen={setIsNIPaymentModalOpen}
            />
          </>
        );
      default: {
        return <div />;
      }
    }
  };
  return getContent();
};

export default CustomCell;
