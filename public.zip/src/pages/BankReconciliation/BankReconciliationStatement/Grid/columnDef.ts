import { TColumnDef } from "@/components/GridTable/GridTable";

export const bankReconciliationStatementDef: TColumnDef = [
  {
    headerName: "Date",
    field: "item_date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Reference",
    field: "ref",
    sequence: true
  },
  {
    headerName: "Description",
    field: "description"
  },
  {
    headerName: "Type",
    field: "itemType"
  },
  {
    headerName: "Payments",
    field: "payamount",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Receipts",
    field: "rcvamount",
    cellRenderer: "GridCellLink",
    align: "right"
  },

  {
    headerName: "",
    field: "actions",
    align: "right",
    cellRenderer: "GridCellLink"
  }
];

export default bankReconciliationStatementDef;
