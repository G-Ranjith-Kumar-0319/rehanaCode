import Layout from "@/components/Layout/Layout";
import { FormLabel, Grid, GridItem, Loader, LoaderType, IPaginationProps } from "@essnextgen/ui-kit";
import "./Style.scss";
import { SyntheticEvent, useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { useDispatch } from "react-redux";
import bankReconciliationStatementDef from "@/pages/BankReconciliation/BankReconciliationStatement/Grid/columnDef";
import { AppDispatch, useAppSelector } from "@/store/store";
import { setToSession } from "@/utils/getDataSource";
import { useForm } from "react-hook-form";
import { getBankReconciliationStatement } from "../state/BankReconciliationStatement.slice";
import CustomCell from "./Grid/CustomCell";
import BankReconciliationTools from "../BankReconciliationToolbar";
import { getBankReconciliations, bankRecActions, addBankreconStatement } from "../state/BankReconciliation.slice";

type onChangeType = Pick<IPaginationProps, "onChange">["onChange"];

const BankReconciliationStatement = () => {
  const [isSaveLoading, setSaveLoading] = useState(false);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const historyState = history.location.state as any;
  const { bankid, bankStatementId } = useParams<{ bankid: string; bankStatementId: any }>();
  const { bankReconciliationStatement } = useAppSelector((state) => state.bankReconciliationStatement);
  const {
    status,
    selectedRow,
    checkedRows,
    checkedOrders,
    filterState,
    validateStatus: validatePurchaseOrderStatus,
    getFullOrderNumberStatus,
    authoriseFullOrderNumber,
    unAuthorisedRows,
    conlumnDef: bRColumnDef,
    bankRreconciliationList,
    bankReconStatementDetails
  } = useAppSelector((state) => state.bankReconciliation);

  const formMethods = useForm<FormData>({
    defaultValues: {}
  });

  const {
    register,
    setValue,
    trigger,
    handleSubmit,
    setFocus,
    setError,
    reset,
    watch,
    formState: { errors, isDirty },
    getValues
  } = formMethods;
  useEffect(() => {
    dispatch(
      getBankReconciliationStatement({
        bankId: bankid,
        bank_statement_id: bankStatementId,
        statementChooser: false,
        uniqueIdentifier: ""
      })
    );
  }, [bankStatementId]);
  useEffect(() => {
    if (bankReconciliationStatement?.reconciledDetails?.uniqueIdentifier) {
      setToSession("uniqueIdentifier", bankReconciliationStatement?.reconciledDetails?.uniqueIdentifier);
    } else {
      setToSession("uniqueIdentifier", "");
    }
  }, [bankReconciliationStatement]);

  const selectRowHandler = (row: { [key: string]: any } | undefined, data?: any) => {
    const bankReconciledDetailsLink = row
      ? `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${row.bank_id}/bankStatementId/${row.bank_statement_id}`
      : "";
    history.push(bankReconciledDetailsLink, {
      ...(history.location.state as any),
      purchaseOrder: undefined,
      bankRreconciliationList: data || historyState.bankRreconciliationList
    });
  };

  const onChangeHandler: onChangeType = (e, page) => {
    dispatch(
      getBankReconciliations({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(historyState?.bankRreconciliationList?.pageSize),
        viewname: "All",
        highLightedRecordId: undefined,
        callback: (data, selectedRow) => {
          const index = data.data.indexOf(selectedRow);
          if (historyState?.bankRreconciliationList === undefined) {
            if (bankid) {
              historyState.bankRreconciliationList = data;
              dispatch(bankRecActions.setSelectedRow(selectedRow));
              selectRowHandler(data.data?.at(index + 1));
            } else {
              historyState.bankRreconciliationList = data;
              dispatch(bankRecActions.setSelectedRow(data.purchaseOrders?.at(1)));
              selectRowHandler(data.data?.at(1));
            }
          } else {
            historyState.bankRreconciliationList = data;
            dispatch(bankRecActions.setSelectedRow(data.data?.at(0)));
            selectRowHandler(data.data?.at(0));
          }
        }
      })
    );
  };

  const selectNextRecord = (e: SyntheticEvent) => {
    if (selectedRow && historyState?.bankRreconciliationList?.data) {
      const bankRreconciliationList = historyState?.bankRreconciliationList?.data;
      const indexNo = bankRreconciliationList?.findIndex(
        (row: { [key: string]: any }) => row?.bank_statement_id === selectedRow?.bank_statement_id
      );
      if (
        indexNo < 9 &&
        (bankRreconciliationList.length - 1 !== indexNo ||
          historyState?.bankRreconciliationList?.currentPage !== historyState?.bankRreconciliationList?.totalPages)
      ) {
        dispatch(bankRecActions.setSelectedRow(bankRreconciliationList[indexNo + 1]));
        selectRowHandler(bankRreconciliationList[indexNo + 1]);
      } else if (
        historyState?.bankRreconciliationList?.currentPage < historyState?.bankRreconciliationList?.totalPages
      ) {
        onChangeHandler(e, historyState?.bankRreconciliationList?.currentPage + 1);
      }
    } else if (historyState?.bankRreconciliationList === undefined) {
      onChangeHandler(e, 1);
    }
  };

  const onchangePrevRecord: onChangeType = (e, page) => {
    dispatch(
      getBankReconciliations({
        ...filterState,
        lookingFor: "",
        pageNumber: page,
        pageSize: String(historyState?.bankRreconciliationList?.pageSize),
        viewname: "All",
        highLightedRecordId: undefined,
        callback: (data) => {
          dispatch(
            bankRecActions.setSelectedRow(data.bankRreconciliationList?.at(data.bankRreconciliationList?.length - 1))
          );
          historyState.bankRreconciliationList = data;
          selectRowHandler(data.bankRreconciliationList?.at(data.bankRreconciliationList?.length - 1), data);
        }
      })
    );
  };

  const selectPrevRecord = (e: SyntheticEvent) => {
    if (selectedRow && historyState?.bankRreconciliationList?.data) {
      const bankRreconciliationList = historyState?.bankRreconciliationList?.data;
      const indexNo = bankRreconciliationList?.findIndex(
        (row: { [key: string]: any }) => row?.bank_statement_id === selectedRow?.bank_statement_id
      );
      if (indexNo > 0) {
        dispatch(bankRecActions.setSelectedRow(bankRreconciliationList[indexNo - 1]));
        selectRowHandler(bankRreconciliationList[indexNo - 1]);
      } else if (historyState?.purchaseOrdersList?.currentPage > 1) {
        onchangePrevRecord(e, historyState?.purchaseOrdersList?.currentPage - 1);
      } else if (history.location.pathname === "/general-ledger/bank-reconciliation/add") {
        selectRowHandler(bankRreconciliationList[indexNo]);
      }
    }
  };

  const onSubmit = handleSubmit((data) => {
    dispatch(
      addBankreconStatement({
        bankId: Number(bankid),
        StatementNo: Number(bankStatementId),
        statementDate: historyState.formattedDate,
        seriesNo: 1,
        uniqueIdentifier: "ceebaf9a-5b87-47a5-bd53-8804a4ac2e97"
      })
    );
  });
  return (
    <>
      {isSaveLoading ? (
        <Loader
          loaderType={LoaderType.Circular}
          loaderText="Loading..."
        />
      ) : (
        <>
          <Layout
            pageTitle={t("bankReconciliation.bankReconciliationStatement")}
            className="invoice-credit-note"
            isBreadcrumbRequired
            rightContent={
              <BankReconciliationTools
                goToPrevRecord={(e) => {
                  selectPrevRecord(e);
                }}
                goToNextRecord={(e) => {
                  selectNextRecord(e);
                }}
                onSubmit={onSubmit}
              />
            }
          >
            <div className="">
              <Grid
                dataTestId="test-id"
                className="row-gap-16"
              >
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">Statement No.</div>
                    <div>1253</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">Statement Date</div>
                    <div>18 March 2024</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">Account No.</div>
                    <div>01177112</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">Sort Code</div>
                    <div>40-32-16</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">Bank Ledger</div>
                    <div>612,813.00</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">Opening Balance</div>
                    <div>701,602.00</div>
                  </div>
                </GridItem>
                <GridItem
                  lg={3}
                  md={4}
                  sm={2}
                  xl={3}
                  xxl={3}
                >
                  <div className="">
                    <div className="essui-form-label mb-5">Closing Balance</div>
                    <div>699,999.00</div>
                  </div>
                </GridItem>
              </Grid>
            </div>
          </Layout>

          <Layout
            isBreadcrumbRequired={false}
            className="invoice-credit-note"
            type="transparent"
          >
            <GridTableNew
              dataTestId="bankStatement"
              filters={null}
              columnDef={bankReconciliationStatementDef}
              dataSource={bankReconciliationStatement?.reconciledDetails?.bankReconciledTransactions || []}
              isLoading={isSaveLoading}
              customCell={CustomCell}
            />
          </Layout>
        </>
      )}
    </>
  );
};

export default BankReconciliationStatement;
