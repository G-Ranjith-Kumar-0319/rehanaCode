import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize
} from "@essnextgen/ui-kit";

import Layout from "@/components/Layout/Layout";
import Input from "@/components/Input/Input";

const IndividualSalaryPayment = () => (
  <>
    <Layout pageTitle="Individual Salary Payment">
      <Grid className="row-gap-16">
        <GridItem
          sm={4}
          md={4}
          lg={4}
          xl={4}
          xxl={4}
        >
          <div>
            <div className="essui-form-label mb-5">Date</div>
            <div>28 June 2024</div>
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={4}
          lg={4}
          xl={4}
          xxl={4}
        >
          <div>
            <div className="essui-form-label mb-5">Period</div>
            <div>1 Apr</div>
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={4}
          lg={4}
          xl={4}
          xxl={4}
        >
          <div>
            <div className="essui-form-label mb-5">Week Number</div>
            <div>-</div>
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={4}
          lg={4}
          xl={4}
          xxl={4}
        >
          <div>
            <div className="essui-form-label mb-5">Paid From</div>
            <div>HDFC Bank</div>
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={4}
          lg={4}
          xl={4}
          xxl={4}
        >
          <div className="h-100 d-flex">
            <CheckBox
              label="Posted"
              disabled
              isSelected
              id="txtCheckbox"
            />
          </div>
        </GridItem>

        <GridItem
          sm={4}
          md={4}
          lg={4}
          xl={4}
          xxl={4}
        >
          <div>
            <div className="essui-form-label mb-5">Total</div>
            <div>2,787.81</div>
          </div>
        </GridItem>
      </Grid>
    </Layout>
  </>
);

export default IndividualSalaryPayment;
