import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const MannualJournalProcessingColumnDefs: TColumnDef = [
  {
    headerName: "Ledger",
    field: "ledger_code"
  },
  {
    headerName: "VAT",
    field: "vat_code"
  },
  {
    headerName: "Fund",
    field: "fund_code"
  },
  {
    headerName: "Ledger Description",
    field: "ledger_des"
  },
  {
    headerName: "Cost Centre",
    field: "cost_code"
  },
  {
    headerName: "Cost Centre Description",
    field: "cost_des"
  },
  {
    headerName: "Debit",
    field: "debit",
    align: "right",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Credit",
    field: "credit",
    align: "right",
    cellRenderer: "GridCellLink"
  }
];

export default MannualJournalProcessingColumnDefs;
