import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  SegmentedButton,
  TableUtility,
  TableWrapper
} from "@essnextgen/ui-kit";

import Input from "@/components/Input/Input";
import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { CARBON_ICON, specialCharacters, STATUS } from "@/types/UseStateType";
import { AddLarge } from "@carbon/icons-react";
import { getDate } from "@/utils/getDataSource";
import SuppliersModal from "@/shared/components/SuppliersModal/SuppliersModal";
import CustomCell from "./Grid/CustomCell";
import columnDef from "./Grid/columnDef";
import useMannualJournalProcessing from "./useMannualJournalProcessing";
import BankReconciliationToolbar from "../BankReconciliationToolbar";

const MannualJournalProcessing = () => {
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const {
    bankReconGLData,
    bankReconMJPStatus,
    selectedRow,
    periodMonth,
    setFooterNarrative,
    footerNarrative,
    totalCredits,
    totalDebits,
    prependZero,
    setOpenSupplierBrowseModal,
    openSupplierBrowseModal,
    getSupplierDetailByClientId,
    supplier
  } = useMannualJournalProcessing();

  return (
    <>
      <Layout
        pageTitle={t("bankReconciliation.manualJournalProcessing.manualJournalProc")}
        className="mannual__journal--processing"
        rightContent={
          <BankReconciliationToolbar
            goToPrevRecord={(e) => {}}
            goToNextRecord={(e) => {}}
            removeLastElement
          />
        }
      >
        <div className=" mt-10">
          <Grid className="row-gap-16">
            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">{t("bankReconciliation.manualJournalProcessing.year")}</div>
                <div className="height__equal--input">
                  {bankReconGLData.headerDetails?.year_des ?? specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>
            <GridItem
              lg={2}
              md={12}
              sm={12}
              xl={2}
              xxl={2}
            >
              <div>
                <FormLabel
                  className="mb-5"
                  forId="txtPeriod"
                >
                  {t("bankReconciliation.manualJournalProcessing.period")}
                </FormLabel>
                <Grid className="">
                  <GridItem>
                    <Input
                      id="txtPeriod"
                      searchable={false}
                      labelText=""
                      inputWidth={45}
                      value={
                        bankReconGLData.headerDetails?.period ? prependZero(bankReconGLData.headerDetails?.period) : ""
                      }
                      disabled
                      button={
                        <>
                          <Input
                            readOnly
                            searchable={false}
                            inputWidth={55}
                            value={periodMonth}
                            className="read-only"
                          />
                          <Button
                            color={ButtonColor.Secondary}
                            onClick={() => {}}
                            className="essui-button-icon-only--small"
                            disabled
                            size={ButtonSize.Small}
                            aria-label="search"
                          >
                            <Icon
                              color={IconColor.Primary500}
                              size={IconSize.Medium}
                              name="search"
                            />
                          </Button>
                        </>
                      }
                    />
                  </GridItem>
                </Grid>
              </div>
            </GridItem>
            <GridItem
              lg={2}
              md={4}
              sm={4}
              xl={2}
              xxl={2}
            >
              <div>
                <div className="essui-form-label mb-5">
                  {t("bankReconciliation.manualJournalProcessing.voucharDate")}
                </div>
                <div className="height__equal--input">
                  {bankReconGLData.headerDetails?.voucher_date
                    ? getDate(bankReconGLData.headerDetails?.voucher_date)
                    : specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={3}
              lg={3}
              xl={3}
              xxl={3}
              className="input-set-gap8"
            >
              <FormLabel
                forId="txtSupplier"
                className="mb-5"
              >
                {t("bankReconciliation.manualJournalProcessing.supplier")}
              </FormLabel>
              <Input
                disabled
                id="txtSupplier"
                searchable
                value={bankReconGLData.headerDetails?.name}
                button={
                  <>
                    <Button
                      color={ButtonColor.Secondary}
                      size={ButtonSize.Small}
                      className="essui-button-icon-only--small"
                      aria-label="petty-btn"
                      disabled={
                        bankReconGLData.headerDetails?.name !== null &&
                        bankReconGLData.headerDetails?.voucher_type !== "CB"
                      }
                      onClick={() => getSupplierDetailByClientId(bankReconGLData.headerDetails?.client_id)}
                    >
                      <Icon
                        color={IconColor.Primary500}
                        size={IconSize.Medium}
                        name="search"
                      />
                    </Button>
                  </>
                }
              />
            </GridItem>
            <GridItem
              lg={2}
              md={4}
              sm={4}
              xl={2}
              xxl={2}
            >
              <div>
                <div className="essui-form-label mb-5">
                  {t("bankReconciliation.manualJournalProcessing.postingDate")}
                </div>
                <div className="height__equal--input">
                  {bankReconGLData.headerDetails?.posting_date
                    ? getDate(bankReconGLData.headerDetails?.posting_date)
                    : specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>

            <GridItem
              lg={12}
              md={12}
              sm={12}
              xl={12}
              xxl={12}
            >
              <div>
                <div className="essui-form-label mb-5">{t("bankReconciliation.manualJournalProcessing.narrative")}</div>
                <div className="height__equal--input">
                  {bankReconGLData.headerDetails?.narrative ?? specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>

            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <FormLabel
                  className="mb-5"
                  forId="ChequeBook"
                >
                  {t("bankReconciliation.manualJournalProcessing.bankLedgerCode")}
                </FormLabel>
                <Grid className="">
                  <GridItem
                    lg={4}
                    md={2}
                    sm={2}
                    xl={4}
                    xxl={4}
                    className="pr-8"
                  >
                    <Input
                      value={bankReconGLData.headerDetails?.ledger_code}
                      searchable
                      disabled
                      id="ChequeBook"
                    />
                  </GridItem>
                  <GridItem
                    lg={8}
                    md={10}
                    sm={10}
                    xl={8}
                    xxl={8}
                    className="pl-0"
                  >
                    <Input
                      value={bankReconGLData.headerDetails?.ledger_des}
                      button={
                        <Button
                          size={ButtonSize.Small}
                          color={ButtonColor.Secondary}
                          disabled
                          aria-label="search"
                          className="essui-button-icon-only--small"
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="search"
                          />
                        </Button>
                      }
                      searchable
                      readOnly
                      className="read-only"
                    />
                  </GridItem>
                </Grid>
              </div>
            </GridItem>

            <GridItem
              lg={2}
              md={4}
              sm={4}
              xl={2}
              xxl={2}
            >
              <div>
                <div className="essui-form-label mb-5">
                  {" "}
                  {t("bankReconciliation.manualJournalProcessing.bankAccount")}
                </div>
                <div className="height__equal--input">
                  {bankReconGLData.headerDetails?.bank_account ?? specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>

            <GridItem
              lg={2}
              md={4}
              sm={4}
              xl={2}
              xxl={2}
            >
              <div>
                <div className="essui-form-label mb-5">{t("bankReconciliation.manualJournalProcessing.sortCode")}</div>
                <div className="height__equal--input">
                  {bankReconGLData.headerDetails?.bank_sort_code ?? specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>

            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">
                  {t("bankReconciliation.manualJournalProcessing.journalNumber")}
                </div>
                <div className="height__equal--input">
                  {bankReconGLData.headerDetails?.voucher_no ?? specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>

            <GridItem
              lg={2}
              md={4}
              sm={4}
              xl={2}
              xxl={2}
            >
              <div>
                <div className="essui-form-label mb-5">{t("bankReconciliation.manualJournalProcessing.reference")}</div>
                <div className="height__equal--input">
                  {bankReconGLData.headerDetails?.bank_reference ?? specialCharacters.HYPHEN}
                </div>
              </div>
            </GridItem>

            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <FormLabel
                  className="mb-5"
                  forId="ChequeNumber"
                >
                  {t("bankReconciliation.manualJournalProcessing.recurrencePattern")}
                </FormLabel>
                <div className="d-flex gap-8">
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    disabled
                  >
                    {t("common.add")}
                  </Button>
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    disabled
                  >
                    {t("common.edit")}
                  </Button>
                  <Button
                    size={ButtonSize.Small}
                    color={ButtonColor.Secondary}
                    disabled
                  >
                    {t("common.delete")}
                  </Button>
                </div>
              </div>
            </GridItem>
          </Grid>
        </div>
      </Layout>
      <Layout
        isBreadcrumbRequired={false}
        type="transparent"
      >
        <TableWrapper>
          <TableUtility className="table-utility-header essui-rowbasedtable-utility">
            {" "}
            {t("bankReconciliation.manualJournalProcessing.journalLines")}
            <Button
              size={ButtonSize.Small}
              disabled
              title={t("common.add")}
              className="essui-button essui-button--utility essui-button--small br-0"
              onClick={() => {}}
            >
              <AddLarge
                size={CARBON_ICON.SIZE}
                color={CARBON_ICON.COLOR_GREY}
              />
            </Button>
          </TableUtility>
          <GridTableNew
            columnDef={columnDef}
            customCell={CustomCell}
            dataSource={bankReconGLData.journalDetails}
            selectedRowHandler={(row) => {
              setFooterNarrative(row?.narrative);
            }}
            isLoading={bankReconMJPStatus === STATUS.LOADING}
            isScrollable
          />
        </TableWrapper>
      </Layout>

      <Layout
        isBreadcrumbRequired={false}
        className="mannual__journal--processing"
      >
        <div className="container">
          <Grid className="row-gap-16">
            <GridItem
              lg={12}
              md={12}
              sm={4}
              xl={12}
              xxl={12}
            >
              <div>
                <div className="essui-form-label mb-5">{t("bankReconciliation.manualJournalProcessing.narrative")}</div>
                <div>{footerNarrative?.length > 0 ? footerNarrative : specialCharacters.HYPHEN}</div>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={3}
              sm={2}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">{t("bankReconciliation.manualJournalProcessing.balance")}</div>
                <div>{bankReconGLData.headerDetails?.balanced ?? "0.00"}</div>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={3}
              sm={2}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">
                  {t("bankReconciliation.manualJournalProcessing.totalDebits")}
                </div>
                <div>{totalDebits}</div>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={3}
              sm={2}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">
                  {t("bankReconciliation.manualJournalProcessing.totalCredits")}
                </div>
                <div>{totalCredits}</div>
              </div>
            </GridItem>
          </Grid>
        </div>
        {openSupplierBrowseModal && (
          <SuppliersModal
            isOpen={openSupplierBrowseModal}
            setOpen={setOpenSupplierBrowseModal}
            setSelectedFromOrder={null}
            clearInvoiceRow={null}
            handleSuggetedSupplierOnKeyword={null}
            setSuggestedSupplier={null}
            viewDetailsAction={openSupplierBrowseModal}
            supplierDetailsData={supplier}
            headerTitle={t("supplier.supplierDetails")}
          />
        )}
      </Layout>
    </>
  );
};

export default MannualJournalProcessing;
