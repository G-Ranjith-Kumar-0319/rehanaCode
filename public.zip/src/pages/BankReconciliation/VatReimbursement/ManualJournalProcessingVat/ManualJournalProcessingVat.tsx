import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize
} from "@essnextgen/ui-kit";

import Input from "@/components/Input/Input";
import "./Style.scss";
import Layout from "@/components/Layout/Layout";

const ManualJournalProcessingVat = () => (
  <>
    <Layout
      pageTitle="Manual Journal Processing"
      className="manual__journal--processing"
    >
      <div className=" mt-10">
        <Grid className="row-gap-16">
          <GridItem
            lg={3}
            md={4}
            sm={4}
            xl={3}
            xxl={3}
          >
            <div>
              <div className="essui-form-label mb-5">Year</div>
              <div className="height__equal--input">2023</div>
            </div>
          </GridItem>
          <GridItem
            lg={2}
            md={12}
            sm={12}
            xl={2}
            xxl={2}
          >
            <div>
              <FormLabel
                className="mb-5"
                forId="txtPeriod"
                id="abc"
              >
                Period
              </FormLabel>
              <Grid className="">
                <GridItem>
                  <Input
                    id="txtPeriod"
                    searchable={false}
                    labelText=""
                    inputWidth={45}
                    value="1"
                    button={
                      <>
                        <Input
                          readOnly
                          searchable={false}
                          inputWidth={55}
                          value="Mar"
                          className="read-only"
                        />
                        <Button
                          color={ButtonColor.Secondary}
                          onClick={() => {}}
                          className="essui-button-icon-only--small"
                          size={ButtonSize.Small}
                          aria-label="search"
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="search"
                          />
                        </Button>
                      </>
                    }
                  />
                </GridItem>
              </Grid>
            </div>
          </GridItem>
          <GridItem
            lg={2}
            md={4}
            sm={4}
            xl={2}
            xxl={2}
          >
            <div>
              <div className="essui-form-label mb-5">Voucher Date</div>
              <div className="height__equal--input">14 Feb 2024</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
            xxl={3}
            className="input-set-gap8"
          >
            <FormLabel
              forId="txtSupplier"
              className="mb-5"
            >
              Supplier
            </FormLabel>
            <Input
              disabled
              id="txtSupplier"
              searchable
              value="1st Glass"
              button={
                <>
                  <Button
                    color={ButtonColor.Secondary}
                    size={ButtonSize.Small}
                    className="essui-button-icon-only--small"
                    aria-label="petty-btn"
                    disabled
                  >
                    <Icon
                      color={IconColor.Primary500}
                      size={IconSize.Medium}
                      name="search"
                    />
                  </Button>
                </>
              }
            />
          </GridItem>
          <GridItem
            lg={2}
            md={4}
            sm={4}
            xl={2}
            xxl={2}
          >
            <div>
              <div className="essui-form-label mb-5">Posting Date</div>
              <div className="height__equal--input">-</div>
            </div>
          </GridItem>

          <GridItem
            lg={12}
            md={12}
            sm={12}
            xl={12}
            xxl={12}
          >
            <div>
              <FormLabel
                forId="txtNarrative"
                className="mb-5"
              >
                Narrative
              </FormLabel>
              <Input
                searchable
                value="Test"
                id="txtNarrative"
              />
            </div>
          </GridItem>

          <GridItem
            lg={3}
            md={4}
            sm={4}
            xl={3}
            xxl={3}
          >
            <div>
              <FormLabel
                className="mb-5"
                forId="ChequeBook"
              >
                Bank Ledger Code
              </FormLabel>
              <Grid className="">
                <GridItem
                  lg={4}
                  md={2}
                  sm={2}
                  xl={4}
                  xxl={4}
                  className="pr-8"
                >
                  <Input
                    value="BK01"
                    searchable
                    disabled
                    id="ChequeBook"
                  />
                </GridItem>
                <GridItem
                  lg={8}
                  md={10}
                  sm={10}
                  xl={8}
                  xxl={8}
                  className="pl-0"
                >
                  <Input
                    value="Bank Account"
                    button={
                      <Button
                        size={ButtonSize.Small}
                        color={ButtonColor.Secondary}
                        disabled
                        aria-label="search"
                        className="essui-button-icon-only--small"
                      >
                        <Icon
                          color={IconColor.Primary500}
                          size={IconSize.Medium}
                          name="search"
                        />
                      </Button>
                    }
                    searchable
                    readOnly
                    className="read-only"
                  />
                </GridItem>
              </Grid>
            </div>
          </GridItem>

          <GridItem
            lg={2}
            md={4}
            sm={4}
            xl={2}
            xxl={2}
          >
            <div>
              <div className="essui-form-label mb-5">Bank Account</div>
              <div className="height__equal--input">01177112</div>
            </div>
          </GridItem>

          <GridItem
            lg={2}
            md={4}
            sm={4}
            xl={2}
            xxl={2}
          >
            <div>
              <div className="essui-form-label mb-5">Sort Code</div>
              <div className="height__equal--input">40-32-16</div>
            </div>
          </GridItem>

          <GridItem
            lg={2}
            md={4}
            sm={4}
            xl={2}
            xxl={2}
          >
            <div>
              <div className="essui-form-label mb-5">Journal Number</div>
              <div className="height__equal--input">-</div>
            </div>
          </GridItem>

          <GridItem
            lg={3}
            md={4}
            sm={4}
            xl={3}
            xxl={3}
          >
            <div>
              <FormLabel
                forId="txtReference"
                className="mb-5"
              >
                Reference
              </FormLabel>
              <Input
                searchable
                value="test"
                id="txtReference"
              />
            </div>
          </GridItem>
        </Grid>
      </div>
    </Layout>

    <Layout
      isBreadcrumbRequired={false}
      className="mannual__journal--processing"
    >
      <div className="container">
        <Grid className="row-gap-16">
          <GridItem
            lg={12}
            md={12}
            sm={4}
            xl={12}
            xxl={12}
          >
            <div>
              <div className="essui-form-label mb-5">Narrative</div>
              <div>test</div>
            </div>
          </GridItem>
        </Grid>
        <div className="mb-8">
          <Divider />
        </div>
        <Grid className="row-gap-16">
          <GridItem
            lg={3}
            md={3}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div>
              <div className="essui-form-label mb-5">Balance</div>
              <div>*No Values*</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            md={3}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div>
              <div className="essui-form-label mb-5">Total Debits</div>
              <div>701,602.45</div>
            </div>
          </GridItem>
          <GridItem
            lg={3}
            md={3}
            sm={2}
            xl={3}
            xxl={3}
          >
            <div>
              <div className="essui-form-label mb-5">Total Credit</div>
              <div>699,999.00</div>
            </div>
          </GridItem>
        </Grid>
      </div>
    </Layout>
  </>
);

export default ManualJournalProcessingVat;
