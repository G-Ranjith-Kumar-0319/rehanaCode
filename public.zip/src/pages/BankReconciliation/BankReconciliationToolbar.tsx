import {
  AddLarge,
  ArrowDown,
  ArrowUp,
  Printer,
  Save,
  /* eslint-disable camelcase */
  Thumbnail_2,
  Subtract,
  Undo,
  ScalesTipped
} from "@carbon/icons-react";
import { ButtonSize, Loader, LoaderType } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { RouteComponentProps, useHistory, useParams, withRouter } from "react-router-dom";
import Toolbar, { ToolbarType } from "@/components/Toolbar/Toolbar";
import { BaseSyntheticEvent, SyntheticEvent, useEffect, useState } from "react";
import { useAppContext } from "@/routes/Routes";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { getSessionItem, getSessionItem as getSessionData } from "@/utils/getDataSource";
import useHotKeys from "@/components/HotKeys/UseHotKeys";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import {
  actions as sccActions,
  deleteRecord,
  getBankReconciliationDocument,
  deleteBankreconStatement,
  actions as bankRecStatementActions,
  saveBankreconStatement,
  getBankReconciliationStatement
} from "@/pages/BankReconciliation/state/BankReconciliationStatement.slice";
import { bankRecActions, closeDetails, getBankReconciliations } from "./state/BankReconciliation.slice";

type BRToolbarType = {
  onSubmit?: (e?: BaseSyntheticEvent<object, any, any> | undefined) => Promise<void>;
  goToPrevRecord?: (e: SyntheticEvent) => void;
  goToNextRecord?: (e: SyntheticEvent) => void;
  handleVerifyBalance?: () => void;
  isDirty?: boolean;
  nextYearStartDate?: any;
  removeLastElement?: boolean;
  statementBalance?: any;
} & RouteComponentProps;

interface MyResponseType {
  payload: string; // Adjust this type according to your actual response structure
  // Add other properties if necessary
}

const BankReconciliationToolbar = ({
  onSubmit,
  goToPrevRecord,
  goToNextRecord,
  isDirty,
  removeLastElement,
  nextYearStartDate,
  handleVerifyBalance,
  statementBalance
}: BRToolbarType) => {
  const { redirectToBankReconciledDetails, setPromise } = useAppContext();
  const history = useHistory();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { bankRreconciliationList, filterState } = useAppSelector((state) => state.bankReconciliation);
  const historyState = { ...(history.location.state as any) };
  const { bankid, bankStatementId } = useParams<{ bankid: string; bankStatementId: any }>();
  const dispatch = useDispatch<AppDispatch>();
  const [isUndoModalOpen, setIsUndoModalOpen] = useState<boolean>(false);
  const { alert } = useAppSelector((state) => state.ui);
  const { selectedRow } = useAppSelector((state) => state.bankReconciliation);
  const {
    isLoading,
    VerifyBalaceStatus,
    reconciledDetails,
    unreconciledDetails,
    filterState: brsFilterState
  } = useAppSelector((state) => state.bankReconciliationStatement);
  let flag = false;

  const addedUniqueIds = reconciledDetails?.map((addedRow) => addedRow?.unique_id);
  const removedUniqueIds = unreconciledDetails?.map((removedRow) => removedRow?.unique_id);

  const onClickDelete = () => {
    dispatch(
      deleteRecord({
        isDetails: bankid === undefined,
        bankid: selectedRow?.bank_id,
        bankStatementId: selectedRow?.bank_statement_id,
        t,
        callback: (data, row) => {
          dispatch(bankRecStatementActions.resetDeleteStatus());
          if (row && bankid) {
            const { bankreconciledDetailsLink } = redirectToBankReconciledDetails(row);
            history.push({
              pathname: bankreconciledDetailsLink,
              state: {
                selectedRowState: row,
                bankRreconciliationList: data
              }
            });
          }
        }
      })
    );
  };

  const printDocument = async (bankID: string, statementId: string, statementNumber: string) => {
    const res = await dispatch(getBankReconciliationDocument({ bankID, statementId, statementNumber }));
    const pdfData = (res as unknown as MyResponseType).payload;
    try {
      const byteCharacters = atob(pdfData);
      const byteNumbers = new Array(byteCharacters.length);
      let i = 0;
      while (i < byteCharacters.length) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
        i += 1; // Use compound assignment instead of increment operator
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "application/pdf" });
      const pdfUri = URL.createObjectURL(blob);
      if (pdfUri) {
        fetch(pdfUri)
          .then((response) => response.blob())
          .then((responseBlob) => {
            // Create a link element
            const link = document.createElement("a");
            link.href = window.URL.createObjectURL(responseBlob);
            link.download = statementNumber; // Set the download attribute with file extension
            link.click();
            // Revoke the Blob URL to free up memory
            window.URL.revokeObjectURL(link.href);
          })

          .catch((error) => {
            // TODO:Add error handler and remove console
            // console.error("Error downloading file:", error);
          });
      }
      // setIsLoading(true);
    } catch (error) {
      // TODO:Add error handler and remove console
      // console.error("Error decoding base64 string:", error);
      // Handle the error gracefully, e.g., set pdfUrl to null
    }
  };

  useEffect(() => {
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      const isDirty = (location as any)?.state?.isDirty;
      if (!location.pathname.includes("/bank-reconciliation") && getSessionItem("uniqueIdentifier")) {
        dispatch(closeDetails());
      }
      if (
        location.pathname === "/general-ledger/bank-reconciliation" &&
        !alert?.enable &&
        isDirty &&
        history.location.pathname.includes("/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details")
      ) {
        dispatch(
          uiActions.confirmPopup({
            enable: true,
            message: t("alertMessage.keepChangesMsg"),
            title: t("common.simsFMSModule"),
            type: MODAL_TYPE.CONFIRMV2,
            yesCallback: () => {
              flag = true;
              dispatch(
                saveBankreconStatement({
                  opening_bal: historyState.selectedRowState?.opening_bal,
                  closing_bal: statementBalance,
                  bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
                  uniqueIdAdded: addedUniqueIds,
                  uniqueIdRemoved: removedUniqueIds
                })
              );
              history.push("/general-ledger/bank-reconciliation");
            },
            noCallback: () => {
              flag = true;
              if (historyState?.from === "add statement") {
                dispatch(
                  deleteBankreconStatement({ bank_statement_id: historyState.selectedRowState.bank_statement_id })
                );
              }
              history.push("/general-ledger/bank-reconciliation");
            },
            isCancelBtnEnable: true
          })
        );

        if (!flag) {
          return false;
        }
      }
    });
    return () => {
      unblock();
    };
  }, [history, alert?.enable, historyState?.isDirty]);

  const checkSaveChanges = (resolve?: any) => {
    dispatch(
      uiActions.alertPopup({
        enable: true,
        type: "invalidData",
        callback: () => {
          if (resolve) resolve(true);
        }
      })
    );
  };

  const handleOnKeyPress = () => {
    if (handleVerifyBalance) {
      handleVerifyBalance();
    }
  };

  const selectRowHandler = (row: { [key: string]: any } | undefined, data?: any) => {
    const bankReconciledDetailsLink = row
      ? `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${row.bank_id}/bankStatementId/${row.bank_statement_id}`
      : "";
    history.push(bankReconciledDetailsLink, {
      ...(history.location.state as any),
      bankRreconciliationList: data || historyState.bankRreconciliationList,
      selectedRowState: row,
      isDirty: false,
      sccDetails: undefined
    });
  };

  const buttons: ToolbarType[] = [
    {
      title: "Focus Mode",
      /* eslint-disable react/jsx-pascal-case */
      element: <Thumbnail_2 size={18} />,
      size: ButtonSize.Small,
      onClick: async () => {
        if (bankid) {
          dispatch(bankRecActions.setFilters({ highLightedRecordId: selectedRow?.bank_statement_id }));
          if (
            history.location.pathname.includes(
              "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details"
            )
          ) {
            history.push("/general-ledger/bank-reconciliation", {
              ...(history.location.state as any)
            });
          }
        } else {
          const { bankreconciledDetailsLink } = redirectToBankReconciledDetails(selectedRow);
          history.push(bankreconciledDetailsLink, {
            ...(history.location.state as any),
            selectedRowState: selectedRow,
            bankRreconciliationList,
            isDirty: false
          });
        }
      }
    },
    {
      title: "Previous Record",
      element: <ArrowUp size={18} />,
      size: ButtonSize.Small,
      onClick: async (e) => {
        if (goToPrevRecord) goToPrevRecord(e);
      }
    },
    {
      title: "Next Record",
      element: <ArrowDown size={18} />,
      size: ButtonSize.Small,
      id: "btnNextRec",
      onClick: async (e) => {
        let result: boolean | undefined;
        if (
          history.location.pathname !== "/general-ledger/bank-reconciliation" &&
          historyState?.isDirty &&
          history.location.pathname.includes(
            "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details"
          )
        ) {
          result = await setPromise((resolve: any) => checkSaveChanges(resolve));
          if (result !== undefined) {
            if (result === false && historyState?.from === "add statement") {
              dispatch(
                deleteBankreconStatement({
                  bank_statement_id: historyState.selectedRowState.bank_statement_id,
                  callback: (data) => {
                    if (result === false) {
                      if (goToNextRecord) {
                        goToNextRecord(e);
                      }
                    }
                  }
                })
              );
            } else if (goToNextRecord && result === false) {
              goToNextRecord(e);
            } else if (goToNextRecord && result === true) {
              dispatch(
                saveBankreconStatement({
                  opening_bal: historyState.selectedRowState?.opening_bal,
                  closing_bal: statementBalance,
                  bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
                  uniqueIdAdded: addedUniqueIds,
                  uniqueIdRemoved: removedUniqueIds
                })
              );
              goToNextRecord(e);
            }
          }
        } else if (goToNextRecord) {
          goToNextRecord(e);
        }
      }
    },
    {
      title: "Add Record",
      element: <AddLarge size={18} />,
      onClick: async (e) => {
        let result;
        if (
          history.location.pathname !== "/general-ledger/bank-reconciliation" &&
          historyState?.isDirty &&
          history.location.pathname.includes(
            "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details"
          )
        ) {
          result = await setPromise((resolve: any) => checkSaveChanges(resolve));
          if (result !== undefined) {
            if (historyState?.from === "add statement" && result === false) {
              dispatch(
                deleteBankreconStatement({ bank_statement_id: historyState.selectedRowState.bank_statement_id })
              );
            } else if (result === true) {
              dispatch(
                saveBankreconStatement({
                  opening_bal: historyState.selectedRowState?.opening_bal,
                  closing_bal: statementBalance,
                  bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
                  uniqueIdAdded: addedUniqueIds,
                  uniqueIdRemoved: removedUniqueIds
                })
              );
            }
            history.push({
              pathname: "/general-ledger/bank-reconciliation/add",
              state: {
                ...historyState,
                nextYearStartDate,
                isDirty: false
              }
            });
          }
        } else {
          history.push({
            pathname: "/general-ledger/bank-reconciliation/add",
            state: {
              ...historyState,
              nextYearStartDate,
              isDirty: false
            }
          });
        }
      },
      size: ButtonSize.Small
    },
    {
      title: "Delete Record",
      element: <Subtract size={18} />,
      size: ButtonSize.Small,
      onClick: onClickDelete
    },
    {
      title: "Save Record Changes",
      element: <Save size={18} />,
      onClick: async () => {
        dispatch(
          saveBankreconStatement({
            opening_bal: historyState.selectedRowState?.opening_bal,
            closing_bal: statementBalance,
            bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
            uniqueIdAdded: addedUniqueIds,
            uniqueIdRemoved: removedUniqueIds
          })
        );
        history.replace({
          ...history.location,
          state: {
            ...(history.location.state as any),
            ...historyState,
            isDirty: false
          }
        });
      },
      size: ButtonSize.Small
    },
    {
      title: "Undo Record Changes",
      element: <Undo size={18} />,
      size: ButtonSize.Small,
      onClick: async () => {
        if (
          (history.location.pathname !== "/general-ledger/bank-reconciliation" && (isDirty || historyState?.isDirty)) ||
          history.location.pathname === "/general-ledger/bank-reconciliation/add"
        ) {
          setIsUndoModalOpen(true);
        }
      }
    },
    {
      title: "Print Record",
      element: <Printer size={18} />,
      size: ButtonSize.Small,
      onClick: async (e) => {
        let result;
        if (
          history.location.pathname !== "/general-ledger/bank-reconciliation" &&
          historyState?.isDirty &&
          history.location.pathname.includes(
            "/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details"
          )
        ) {
          result = await setPromise((resolve: any) => checkSaveChanges(resolve));

          if (result !== undefined) {
            if (historyState?.from === "add statement" && result === false) {
              dispatch(
                deleteBankreconStatement({
                  bank_statement_id: historyState.selectedRowState.bank_statement_id,
                  callback: (data) => {
                    dispatch(
                      getBankReconciliations({
                        ...filterState,
                        lookingFor: "",
                        viewname: "All",
                        highLightedRecordId: undefined,
                        callback: (data, selectedRow) => {
                          const index = data.data.indexOf(selectedRow);
                          if (bankid) {
                            historyState.bankRreconciliationList = data;
                            dispatch(bankRecActions.setSelectedRow(selectedRow));
                            selectRowHandler(data.data?.at(index));
                            printDocument(
                              selectedRow?.bank_id,
                              selectedRow?.bank_statement_id,
                              selectedRow?.statement_no
                            );
                          }
                        }
                      })
                    );
                  }
                })
              );
            } else if (result === false) {
              history.replace({
                ...history.location,
                state: {
                  ...historyState,
                  isDirty: false,
                  sccDetails: undefined
                }
              });
              printDocument(
                historyState?.selectedRowState?.bank_id,
                historyState?.selectedRowState?.bank_statement_id,
                historyState?.selectedRowState?.statement_no
              );
            } else if (result === true) {
              dispatch(
                saveBankreconStatement({
                  opening_bal: historyState.selectedRowState?.opening_bal,
                  closing_bal: statementBalance,
                  bank_statement_id: Number(historyState.selectedRowState.bank_statement_id),
                  uniqueIdAdded: addedUniqueIds,
                  uniqueIdRemoved: removedUniqueIds
                })
              );
              history.replace({
                ...history.location,
                state: {
                  ...(history.location.state as any),
                  ...historyState,
                  isDirty: false
                }
              });
              printDocument(
                historyState?.selectedRowState?.bank_id,
                historyState?.selectedRowState?.bank_statement_id,
                historyState?.selectedRowState?.statement_no
              );
            }
          }
        } else {
          printDocument(selectedRow?.bank_id, selectedRow?.bank_statement_id, selectedRow?.statement_no);
        }
      }
    },
    {
      title: "Verify Balances",
      element: <ScalesTipped size={18} />,
      size: ButtonSize.Small,
      onClick: async () => {
        handleOnKeyPress();
      }
    }
  ];

  useHotKeys({
    keyName: "F7",
    handleOnKeyPress
  });

  const handleKeyDown = (e: any) => {
    if (e.key === "Escape" && bankid) {
      e.preventDefault();
      if (
        (history.location.pathname !== "/general-ledger/bank-reconciliation" && (isDirty || historyState?.isDirty)) ||
        history.location.pathname === "/general-ledger/bank-reconciliation/add"
      ) {
        setIsUndoModalOpen(true);
      }
    }
  };

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleKeyDown]);

  return (
    <div className="bank-reconciliation-toolbar">
      <Toolbar buttons={removeLastElement ? buttons.slice(0, -1) : buttons} />
      <div className="loader-wrapper">
        {(isLoading || VerifyBalaceStatus) && (
          <Loader
            loaderType={LoaderType.Circular}
            loaderText="Please wait"
            isLoaderModal
          />
        )}
      </div>
      <ConfirmModal
        className="undu-alert"
        isOpen={isUndoModalOpen}
        setOpen={setIsUndoModalOpen}
        title={t("alertMessage.title")}
        message={t("alertMessage.undoAlert.message")}
        confirm={async () => {
          await dispatch(
            getBankReconciliationStatement({
              bankId: bankid,
              bank_statement_id: bankStatementId,
              statementChooser: false,
              sequence: brsFilterState?.sequence,
              uniqueIdentifier: getSessionData("uniqueIdentifier") ? getSessionData("uniqueIdentifier") : ""
            })
          );
          dispatch(sccActions.resetSccRow());

          history.replace({
            ...history.location,
            state: {
              ...(history.location.state as any),
              isDirty: false,
              sccDetails: undefined
            }
          });
        }}
      />
    </div>
  );
};

BankReconciliationToolbar.defaultProps = {
  onSubmit: undefined,
  goToPrevRecord: undefined,
  goToNextRecord: undefined,
  isDirty: undefined,
  nextYearStartDate: undefined,
  removeLastElement: undefined,
  handleVerifyBalance: undefined,
  statementBalance: undefined
};

export default withRouter(BankReconciliationToolbar);
