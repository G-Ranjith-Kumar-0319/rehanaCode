import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize
} from "@essnextgen/ui-kit";

import Input from "@/components/Input/Input";
import "./Style.scss";
import Layout from "@/components/Layout/Layout";

const PettyCashDetails = () => (
  <>
    <Layout
      pageTitle="Petty Cash Details"
      className="petty-cash-details"
    >
      <div className="container">
        <Grid
          container
          dataTestId="test-id"
          className="row-gap-16"
        >
          <GridItem
            lg={4}
            md={4}
            sm={2}
            xl={4}
            xxl={4}
          >
            <div>
              <div className="essui-form-label mb-5">Pretty Cash Account</div>
              <div>Petty Cash</div>
            </div>
          </GridItem>
          <GridItem
            lg={4}
            md={4}
            sm={2}
            xl={4}
            xxl={4}
          >
            <div>
              <div className="essui-form-label mb-5">Cash In Hand</div>
              <div>200.00</div>
            </div>
          </GridItem>
          <GridItem
            lg={4}
            md={4}
            sm={2}
            xl={4}
            xxl={2}
          >
            <div>
              <div className="essui-form-label mb-5">Unposted Expenditure</div>
              <div>0.00</div>
            </div>
          </GridItem>
        </Grid>
      </div>
    </Layout>
    <Layout
      isBreadcrumbRequired={false}
      className="petty-cash-details"
    >
      <div className="container">
        <Grid
          container
          dataTestId="test-id"
          className="row-gap-16"
        >
          <GridItem
            lg={12}
            md={12}
            sm={12}
            xl={12}
            xxl={12}
          >
            <div>
              <div className="essui-form-label mb-5">Transaction Number</div>
              <div>00001234</div>
            </div>
          </GridItem>
        </Grid>

        <Divider />

        <div className=" mt-10">
          <Grid
            container
            dataTestId="test-id"
            className="row-gap-16"
          >
            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">Date</div>
                <div>12 Jan 2024</div>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">General Ledger Journal</div>
                <div>123456</div>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={12}
              sm={12}
              xl={3}
              xxl={3}
            >
              <div>
                <FormLabel
                  className="essui-form-label mb-5"
                  forId="txtPeriod"
                  id="abc"
                >
                  Period
                </FormLabel>
                <Grid className="">
                  <GridItem>
                    <Input
                      id="txtPeriod"
                      searchable={false}
                      labelText=""
                      inputWidth={45}
                      value="6"
                      disabled
                      button={
                        <>
                          <Input
                            disabled
                            searchable={false}
                            inputWidth={55}
                            value="Mar"
                          />
                          <Button
                            color={ButtonColor.Secondary}
                            onClick={() => {}}
                            className="essui-button-icon-only--small"
                            disabled
                            size={ButtonSize.Small}
                            aria-label="search"
                          >
                            <Icon
                              color={IconColor.Primary500}
                              size={IconSize.Medium}
                              name="search"
                            />
                          </Button>
                        </>
                      }
                    />
                  </GridItem>
                </Grid>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">Amount</div>
                <div>340.00</div>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">Drawn from bank</div>
                <div>Bank Account</div>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <FormLabel
                  className="mb-5"
                  forId="ChequeBook"
                >
                  Cheque Book
                </FormLabel>
                <Grid className="">
                  <GridItem
                    lg={6}
                    md={6}
                    sm={6}
                    xl={6}
                    xxl={6}
                    className="pr-8"
                  >
                    <Input
                      value="008001-009000"
                      searchable
                      disabled
                      id="ChequeBook"
                    />
                  </GridItem>
                  <GridItem
                    lg={6}
                    md={6}
                    sm={6}
                    xl={6}
                    xxl={6}
                    className="pl-0"
                  >
                    <Input
                      value="008508"
                      button={
                        <Button
                          size={ButtonSize.Small}
                          color={ButtonColor.Secondary}
                          disabled
                          aria-label="search"
                          className="essui-button-icon-only--small"
                        >
                          <Icon
                            color={IconColor.Primary500}
                            size={IconSize.Medium}
                            name="search"
                          />
                        </Button>
                      }
                      searchable
                      disabled
                    />
                  </GridItem>
                </Grid>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <FormLabel
                  className="mb-5"
                  forId="ChequeNumber"
                >
                  Cheque Number
                </FormLabel>
                <Input
                  value="008507"
                  id="ChequeNumber"
                  button={
                    <Button
                      size={ButtonSize.Small}
                      color={ButtonColor.Secondary}
                      disabled
                    >
                      Print Cheque
                    </Button>
                  }
                  searchable
                  disabled
                />
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">Reconciled on Bank Statement</div>
                <div>1234</div>
              </div>
            </GridItem>
            <GridItem
              lg={3}
              md={4}
              sm={4}
              xl={3}
              xxl={3}
            >
              <div>
                <div className="essui-form-label mb-5">Cheque Payee</div>
                <div>Pay to Stationary</div>
              </div>
            </GridItem>
            <GridItem
              lg={12}
              md={4}
              sm={4}
              xl={12}
              xxl={12}
            >
              <div>
                <div className="essui-form-label mb-5">Narrative</div>
                <div>Petty cash top up 27th Feb, 2024</div>
              </div>
            </GridItem>
          </Grid>
        </div>
      </div>
    </Layout>

    <Layout
      isBreadcrumbRequired={false}
      className="petty-cash-details"
    >
      <div className="container">
        <div className="mt-30">
          <Grid container>
            <GridItem
              sm={6}
              md={{
                offset: 2,
                span: 6
              }}
              lg={{
                offset: 6,
                span: 6
              }}
              xl={{
                offset: 6,
                span: 6
              }}
            >
              <div className="rightbtn">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  disabled
                >
                  View Adjustment
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  disabled
                >
                  View Original
                </Button>
              </div>
            </GridItem>
          </Grid>
        </div>
      </div>
    </Layout>
  </>
);

export default PettyCashDetails;
