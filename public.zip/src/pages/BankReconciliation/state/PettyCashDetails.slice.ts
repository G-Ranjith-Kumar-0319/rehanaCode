import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { OrderType, STATUS } from "@/types/UseStateType";

type TPettyCashDetailsState = {
  error: string | undefined;
  status?: STATUS;
  pcDetails: { [key: string]: any }[];
  postingPeriodDetails: { [key: string]: any }[];
};
const initialState: TPettyCashDetailsState = {
  error: "",
  pcDetails: [],
  postingPeriodDetails: []
};
/** Thunks */
export const getBankReconViewPC = createAsyncThunk(
  "bankReconciliationViewPC",
  async ({ pcId, transId, callback }: any) => {
    const response = await client.get(`${apiRoot}/bankrecon/bankrecon-view-pc?pcId=${pcId}&transId=${transId}`);
    return response.data;
  }
);

export const getPCPostingPeriod = createAsyncThunk("invoiceNote/paymentFromDetails", async (sequence?: any) => {
  const response = await client.get(`${apiRoot}/common/open-period?sequence=${sequence || 0}`);
  return response.data;
});
/**
 * This slice of state is responsible for storing PCView details state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** PCView details state */
    builder
      .addCase(getBankReconViewPC.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getBankReconViewPC.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.pcDetails = action.payload;
      })
      .addCase(getBankReconViewPC.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
      })
      /** PCPostingPeriod details state */
      .addCase(getPCPostingPeriod.pending, (state) => {
        state.status = STATUS.LOADING;
      })
      .addCase(getPCPostingPeriod.fulfilled, (state, action: PayloadAction<any>) => {
        const filtetedPositingPeriod = [...action.payload].map((period) => {
          const newPeriod = { ...period };
          newPeriod.code = newPeriod.code.toString();
          return newPeriod;
        });
        state.postingPeriodDetails = filtetedPositingPeriod;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getPCPostingPeriod.rejected, (state, action: PayloadAction<any>) => {
        state.status = STATUS.FAILED;
        state.error = action.payload?.error.message;
      });
  },
  initialState,
  name: "pcDetails",
  reducers: {}
});
export const { actions, reducer } = slice;
export default reducer;
