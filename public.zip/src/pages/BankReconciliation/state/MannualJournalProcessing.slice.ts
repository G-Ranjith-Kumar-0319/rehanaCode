import { ISelectedItem } from "@essnextgen/ui-kit";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "../../../config";

type bankReconViewGLType = {
  journalDetails: { [key: string]: any }[];
  headerDetails: { [key: string]: any } | null;
};

type bankReconGLDataType = {
  bankReconGLData: bankReconViewGLType;
  status?: STATUS;
  error: string | undefined;
};

const initialState: bankReconGLDataType = {
  bankReconGLData: {
    headerDetails: {},
    journalDetails: []
  },
  error: ""
};

/** Thunks */
export const getBankReconViewGL = createAsyncThunk(
  "bankrecon/bankrecon-view-gl",
  async ({ voucherID, callback }: { voucherID: number; callback: (res: any) => void }) => {
    const response = await client.get(`${apiRoot}/bankrecon/bankrecon-view-gl?voucherLineId=${voucherID}`);
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * # Bank Reconcilation Manula Journal processing
 * This slice of state is responsible for view manual journal processing data
 */
const slice = createSlice({
  extraReducers: (builder) => {
    /** Purchase Orders List */
    builder
      .addCase(getBankReconViewGL.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getBankReconViewGL.fulfilled, (state, action: PayloadAction<any>) => {
        state.bankReconGLData = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getBankReconViewGL.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  initialState,
  name: "manualJournalProcessing",
  reducers: {}
});

export const { actions, reducer } = slice;
export default reducer;
