import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { OrderType, STATUS, transactionTypes } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";
import {
  findDifferencesByProperty,
  getDatasourceUrl,
  getDateTime,
  getSessionItem,
  stringToDate
} from "@/utils/getDataSource";
import { RootState } from "@/store/store";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { MODAL_TYPE, uiActions } from "@/store/state/ui.slice";
import { TFunction, useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { NotificationStatus } from "@essnextgen/ui-kit";
import { number } from "yup";
import columnDef from "../BankReconciliationList/Grid/columnDef";

export type PurchaseOrdersListType = { [key: string]: any }[];
export type TaggedValueType = { [key: string]: any };

export type PurchaseOrdersType = {
  data: PurchaseOrdersListType;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: string;
  highLightedRecordId: number;
};

type TgetPurchaseOrder = {
  pageNumber?: number;
  pageSize?: string;
  viewname?: string;
  status?: number;
  sequence?: number;
  sequenceValue?: string;
  applyFilter?: boolean;
  lookingFor?: string | undefined;
  isFocus?: boolean;
  orderId?: string;
  highLightedRecordId?: number;
  index?: number;
  sortOrder?: number;
};

type TgetBankreconStatement = {
  bankId?: number;
  StatementNo?: number;
  statementDate?: string;
  uniqueIdentifier?: string;
  seriesNo?: number;
};

type PurchaseOrderStateType = {
  adding: boolean;
  filterState?: TgetPurchaseOrder;
  selectedRow?: { [key: string]: any };
  bankRreconciliationList: PurchaseOrdersType;
  bankReconStatementDetails?: {
    bankLedger: string;
    bankReconciliationStatement?: { [key: string]: any };
    uniqueIdentifier: string | null;
  };
  tagStatusList: PurchaseOrdersListType;
  conlumnDef: TColumnDef;
  error: string | undefined;
  checkedRows: { [key: string]: any }[];
  checkedOrders: Number[];
  allPurchaseOrders: { [key: string]: any }[];
  unAuthorisedRows?: { [key: string]: any };
  authorisedRows?: { [key: string]: any };
  authoriseFullOrderNumber?: string;
  getFullOrderNumberStatus?: STATUS;
  status?: STATUS;
  pageStatus?: STATUS;
  viewStatus?: STATUS;
  cancelStatus?: STATUS;
  deleteStatus?: STATUS;
  authoriseStatus?: STATUS;
  validateStatus?: STATUS;
  addBankreconStatus?: STATUS;
  cancelError?: { [key: string]: any };
  deleteError?: { [key: string]: any };
  authoriseError?: { [key: string]: any };
  allStatus?: STATUS;
  tagAPIStatus?: STATUS;
  isFocus?: boolean;
  validateStatement?: { [key: string]: any };
  nextYearStartDate?: any;
};

const initialState: PurchaseOrderStateType = {
  adding: false,
  checkedRows: [],
  checkedOrders: [],
  filterState: {
    pageNumber: 1,
    pageSize: "10",
    sortOrder: 1,
    sequence: 0,
    sequenceValue: columnDef.filter((col) => !!col.sequence)[0].field,
    viewname: "All",
    applyFilter: false,
    lookingFor: "",
    highLightedRecordId: 0
  },
  conlumnDef: columnDef,
  allPurchaseOrders: [],
  authorisedRows: {},
  unAuthorisedRows: {},
  tagStatusList: [],
  bankRreconciliationList: {
    data: [],
    currentPage: 1,
    totalCount: "",
    pageSize: 10,
    totalPages: 0,
    highLightedRecordId: 0
  },
  error: "",
  isFocus: false
};

type Page = { pageNumber?: number; pageSize?: number };

type PageView = { pageNumber?: number; pageSize?: number; viewname?: string };

type PageViewAndSequence = {
  pageNumber?: number;
  pageSize?: string;
  viewname?: string;
  status?: number;
  sequence?: number;
  sequenceValue?: string;
  applyFilter?: boolean;
  lookingFor?: string | undefined;
};

/** Thunks */
export const getBankReconciliations = createAsyncThunk(
  "bankReconciliations/list",
  async (
    {
      pageSize,
      pageNumber,
      viewname,
      sortOrder,
      sequence,
      lookingFor,
      applyFilter,
      callback,
      orderId,
      highLightedRecordId,
      index
    }: TgetPurchaseOrder & { callback?: (data: any, selectedRow?: any) => void },
    thunkAPI
  ) => {
    try {
      const { dispatch } = thunkAPI;
      const { data }: { data: { [key: string]: any } } = await client.post(
        `${apiRoot}/bankrecon/bankrecon-details-filter`,
        {
          pageNumber,
          pageSize: 10,
          sequence,
          viewName: viewname,
          sortOrder,
          lookingFor,
          highLightedRecordId
        }
      );
      if (data) {
        const row = index
          ? ((data?.data as { [key: string]: any }[]) || []).at(index)
          : ((data?.data as { [key: string]: any }[]) || [])
              ?.filter((p) => p.bank_statement_id === data?.highLightId)
              .at(0);
        dispatch(bankRecActions.setSelectedRow(row));
        if (callback) {
          callback(data, row);
        }
      }

      return data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const bankreconValidateStatement = createAsyncThunk(
  "bankrecon/bankreconValidateStatement",
  async (
    {
      bankId,
      StatementNo,
      statementDate,
      callback,
      uniqueIdentifier
    }: TgetBankreconStatement & { callback?: (data: any) => void },
    thunkAPI
  ) => {
    try {
      const { data }: { data: { [key: string]: any } } = await client.get(
        `${apiRoot}/bankrecon/bankrecon-validate-statement?bankId=${bankId}&StatementNo=${StatementNo}&statementDate=${statementDate}&uniqueIdentifier=${uniqueIdentifier}`
      );
      if (data && callback) {
        callback(data);
      }
      return data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const addBankreconStatement = createAsyncThunk(
  "bankrecon/addBankreconStatement",
  async (
    {
      bankId,
      StatementNo,
      statementDate,
      callback,
      uniqueIdentifier,
      seriesNo
    }: TgetBankreconStatement & { callback?: (data: any) => void },
    thunkAPI
  ) => {
    try {
      const { data }: { data: { [key: string]: any } } = await client.post(
        `${apiRoot}/bankrecon/bankrecon-add-statement`,
        {
          bankId,
          StatementNo,
          statementDate,
          uniqueIdentifier,
          seriesNo
        }
      );
      if (data && callback) {
        callback(data);
      }
      return data;
    } catch (e) {
      throw thunkAPI.rejectWithValue({
        error: e
      });
    }
  }
);

export const closeDetails = createAsyncThunk("bankrec/closeDetails", async (_, thunkAPI) => {
  try {
    await client.delete(`${apiRoot}/bankrecon/bankrecon-close-details`, {
      params: { uniqueIdentifier: getSessionItem("uniqueIdentifier") }
    });
  } catch (e) {
    throw thunkAPI.rejectWithValue({
      error: e
    });
  }
});

/**
 * # Bank Rreconciliation Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  initialState,
  name: "bankRreconciliations",
  extraReducers: (builder) => {
    /** Purchase Orders List */
    builder
      .addCase(getBankReconciliations.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getBankReconciliations.fulfilled, (state, action: PayloadAction<any>) => {
        state.bankRreconciliationList = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getBankReconciliations.rejected, (state) => {
        state.status = STATUS.FAILED;
        state.bankRreconciliationList = initialState.bankRreconciliationList;
      });
    builder
      .addCase(addBankreconStatement.pending, (state) => {
        state.addBankreconStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(addBankreconStatement.fulfilled, (state, action: PayloadAction<any>) => {
        state.bankReconStatementDetails = action.payload;
        state.addBankreconStatus = STATUS.SUCCESS;
      })
      .addCase(addBankreconStatement.rejected, (state) => {
        state.addBankreconStatus = STATUS.FAILED;
      });
    builder
      .addCase(bankreconValidateStatement.pending, (state) => {
        state.validateStatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(bankreconValidateStatement.fulfilled, (state, action: PayloadAction<any>) => {
        state.validateStatus = STATUS.SUCCESS;
        state.validateStatement = action.payload;
      })
      .addCase(bankreconValidateStatement.rejected, (state) => {
        state.validateStatus = STATUS.FAILED;
      });
  },
  reducers: {
    initialState: (state) => {
      state.filterState = { ...initialState.filterState };
    },

    resetAuthoriseRows: (state) => {
      state.authorisedRows = {};
      state.unAuthorisedRows = {};
      state.authoriseStatus = undefined;
    },
    resetErrors: (state) => {
      state.cancelError = undefined;
      state.authoriseError = undefined;
      state.deleteError = undefined;
    },
    resetValidateStatement: (state) => {
      state.validateStatement = {};
    },
    handleCheckbox: (state, action: PayloadAction<any>) => {
      const sortRows = action.payload.row.sort((a: any, b: any) => a.order_id - b.order_id);

      const mergedCheckedOrders = current(state.checkedOrders)?.concat(sortRows);
      const uniqueCheckedOrdersMap = new Map();
      mergedCheckedOrders.forEach((order: any) => {
        uniqueCheckedOrdersMap.set(order.order_id, order);
      });
      const uniqueCheckedOrders = Array.from(uniqueCheckedOrdersMap.values());
      const unCheckedRows = findDifferencesByProperty(current(state.checkedRows), [...action.payload.row], "order_id");

      const finalCheckedOrders = uniqueCheckedOrders?.filter(
        (row: any) => !unCheckedRows.some((checkedRow: any) => checkedRow.order_id === row.order_id)
      );
      const sortedCheckedOrders = finalCheckedOrders.sort((a: any, b: any) => a.order_id - b.order_id);
      state.checkedOrders = sortedCheckedOrders;
      state.checkedRows = [...sortRows];
    },
    unCheckAll: (state) => {
      state.checkedRows = [];
    },
    checkAll: (state) => {
      const poList = state.bankRreconciliationList?.data ? current(state.bankRreconciliationList?.data) : [];
      state.checkedRows = [...poList];
    },
    checkFiltered: (state) => {
      if (state?.bankRreconciliationList) {
        const { data } = state.bankRreconciliationList;
        if (data) {
          const checkedRows = data.filter((row) =>
            current(state.checkedOrders).some((checkedOrdersRow: any) => checkedOrdersRow.order_id === row.order_id)
          );
          state.checkedRows = [...checkedRows];
        }
      }
    },
    setCheckedOrders: (state, action: PayloadAction<any>) => {
      state.checkedOrders = [...state.checkedOrders, ...action.payload];
      const checkedRows = current(state.bankRreconciliationList?.data).filter((row) =>
        state.checkedOrders.some((checkedOrdersRow: any) => checkedOrdersRow.order_id === row.order_id)
      );

      state.checkedRows = checkedRows;
    },
    resetCheckedOrders: (state) => {
      state.checkedOrders = [];
    },
    addBankReconStatement: (state, action: PayloadAction<any>) => {
      const bankReconRecord = {
        ...action.payload
      };
      state.bankRreconciliationList.data.push(bankReconRecord);
      state.selectedRow = bankReconRecord;
    },
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.conlumnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TgetPurchaseOrder>) => {
      state.filterState = {
        ...state.filterState,
        ...action.payload
      };
    },
    isAddingEnabled: (state, action: PayloadAction<boolean>) => {
      state.adding = action.payload;
    },
    setNextYearStartDate: (state, action: PayloadAction<any>) => {
      state.nextYearStartDate = action.payload;
    }
  }
});

export const { actions: bankRecActions, reducer } = slice;
export default reducer;
