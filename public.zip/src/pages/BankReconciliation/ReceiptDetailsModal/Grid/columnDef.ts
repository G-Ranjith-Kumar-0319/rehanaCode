import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const receiptDetailsDef: TColumnDef = [
  {
    headerName: "CC Code",
    field: "cost_code"
  },
  {
    headerName: "CC Name",
    field: "cost_des",
    enableTooltip: true
  },
  {
    headerName: "LC Code",
    field: "ledger_code"
  },
  {
    headerName: "LC Name",
    field: "ledger_des",
    enableTooltip: true
  },
  {
    headerName: "Fund",
    field: "fund_code"
  },
  {
    headerName: "Gross Amount",
    field: "gross_amount",
    align: "right",
    cellRenderer: "GridCellLink"
  }
];

export default receiptDetailsDef;
