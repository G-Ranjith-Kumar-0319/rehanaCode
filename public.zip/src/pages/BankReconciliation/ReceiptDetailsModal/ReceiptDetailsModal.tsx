import { AppDispatch, useAppSelector } from "@/store/store";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  Divider,
  FormLabel,
  Grid,
  GridItem
} from "@essnextgen/ui-kit";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { getDate, usNumberFormat } from "@/utils/getDataSource";
import { receiptMethodDescription, vatDes } from "@/utils/constants";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import { STATUS, specialCharacters } from "@/types/UseStateType";
import BodyUtil from "@/shared/utils/NoScroll";
import { actions, getBankReconciliationViewNI } from "../state/ReceiptDetails.slice";
import receiptDetailsDef from "./Grid/columnDef";
import "./Style.scss";

type TReceiptDetailsModal = {
  setOpen: (flag: boolean) => void;
  isOpen: boolean;
  row: { [key: string]: any };
};

const ReceiptDetailsModal = ({ setOpen, isOpen, row }: TReceiptDetailsModal) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { status, selectedRow } = useAppSelector((state) => state.receiptDetails);
  const { bankReconciliationNiHeader, bankReconciliationNiListing } = useAppSelector(
    (state) => state.receiptDetails.receiptDetails
  );
  const [vatTotal, setVatTotal] = useState<number>(0.0);

  const selectedRowHandler = (row?: { [key: string]: any }) => {
    if (status === STATUS.SUCCESS) {
      dispatch(actions.setSelectedRow(row));
    }
  };

  const CustomCell = ({ field, row }: any) => {
    if (field === "gross_amount") {
      return <>{usNumberFormat(row?.gross_amount)}</>;
    }
    return null;
  };

  useEffect(() => {
    if (bankReconciliationNiListing.length > 0) {
      const totalAmount = bankReconciliationNiListing.reduce((acc, row) => acc + row.vat_amount, 0);
      setVatTotal(totalAmount);
    }
  }, [bankReconciliationNiListing]);

  const getDisplayValue = (code: any, description: any) => {
    if (code || description) {
      return `${code || ""} ${description || ""}`;
    }
    return specialCharacters.HYPHEN;
  };

  useEffect(() => {
    const receiptId = parseInt(row?.unique_id.replace(/^\D+/g, ""), 10);
    dispatch(
      getBankReconciliationViewNI({
        receiptId,
        callback: (data: any) => {
          dispatch(actions.setSelectedRow(data?.bankReconciliationNiListing?.at(0)));
        }
      })
    );
  }, []);
  return (
    <Grid
      container
      className="receipt-details-modal"
    >
      <Dialog
        className="dialog__divider"
        isOpen={isOpen}
        dataTestId="test-id"
        escapeExits
        id="element-id"
        onClose={() => {
          BodyUtil.NoScroll.remove();
          setOpen(false);
        }}
        returnFocusOnDeactivate
        title={t("bankReconciliation.receiptDetails")}
      >
        <DialogContent>
          <div className="overflow-hidden">
            <Grid className="wrap-data row-gap-16 marginb15">
              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={4}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.date")}</FormLabel>
                <div>{getDate(bankReconciliationNiHeader?.receipt_date)}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={4}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.reference")}</FormLabel>
                <div>{bankReconciliationNiHeader?.ref_text ?? specialCharacters.HYPHEN}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={4}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.method")}</FormLabel>
                <div>{receiptMethodDescription[bankReconciliationNiHeader?.method] ?? specialCharacters.HYPHEN}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={4}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.amount")}</FormLabel>
                <div>{usNumberFormat(bankReconciliationNiHeader?.gross_amount)}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={4}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.receivedFrom")}</FormLabel>
                <div>{bankReconciliationNiHeader?.receipt_source_freetext ?? specialCharacters.HYPHEN}</div>
              </GridItem>

              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={4}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.destination")}</FormLabel>
                <div>{bankReconciliationNiHeader?.process ?? specialCharacters.HYPHEN}</div>
              </GridItem>
            </Grid>
            <GridTableNew
              isScrollable
              columnDef={receiptDetailsDef}
              customCell={CustomCell}
              dataSource={bankReconciliationNiListing}
              isLoading={status === STATUS.LOADING}
              selectedRowHandler={selectedRowHandler}
            />
            <Grid className="wrap-data row-gap-16 marginb15 margint15">
              <GridItem
                sm={3}
                md={3}
                lg={3}
                xl={3}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.costCentre")}</FormLabel>
                <div>{getDisplayValue(selectedRow?.cost_code, selectedRow?.cost_des)}</div>
              </GridItem>
              <GridItem
                sm={5}
                md={5}
                lg={5}
                xl={5}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.ledgerCode")}</FormLabel>

                <div>{getDisplayValue(selectedRow?.ledger_code, selectedRow?.ledger_des)}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={4}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.fund")}</FormLabel>
                <div>{getDisplayValue(selectedRow?.fund_code, selectedRow?.fund_des)}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={12}
                lg={12}
                xl={12}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.narrative")}</FormLabel>
                <div>{selectedRow?.narrative ?? specialCharacters.HYPHEN}</div>
              </GridItem>
              <GridItem
                sm={3}
                md={3}
                lg={3}
                xl={3}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.grossAmount")}</FormLabel>
                <div>{usNumberFormat(selectedRow?.gross_amount)}</div>
              </GridItem>
              <GridItem
                sm={5}
                md={5}
                lg={5}
                xl={5}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.vatCode")}</FormLabel>
                <div>{getDisplayValue(selectedRow?.vat_code, vatDes[selectedRow?.vat_code])}</div>
              </GridItem>
              <GridItem
                sm={4}
                md={4}
                lg={4}
                xl={4}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.netAmount")}</FormLabel>
                <div>{usNumberFormat(selectedRow?.net_amount)}</div>
              </GridItem>
            </Grid>
            <Divider />
            <Grid className="row-gap-16 marginb15 margint10 ">
              <GridItem
                sm={3}
                md={3}
                lg={3}
                xl={3}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.vatTotal")}</FormLabel>
                <div>{usNumberFormat(vatTotal)}</div>
              </GridItem>
              <GridItem
                sm={5}
                md={5}
                lg={5}
                xl={5}
              >
                <FormLabel className="mb-8">{t("bankReconciliation.receiptTotal")}</FormLabel>
                <div>{usNumberFormat(bankReconciliationNiHeader?.gross_amount)}</div>
              </GridItem>
            </Grid>
          </div>
        </DialogContent>
        <DialogFooter>
          <Grid
            container
            className="justify-end"
          >
            <GridItem>
              <div className="rightbtn">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Primary}
                  onClick={() => {
                    BodyUtil.NoScroll.remove();
                    setOpen(false);
                  }}
                >
                  {t("common.close")}
                </Button>
              </div>
            </GridItem>
          </Grid>
        </DialogFooter>
      </Dialog>
    </Grid>
  );
};
export default ReceiptDetailsModal;
