import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  FormLabel,
  Grid,
  GridItem,
  ProgressBar
} from "@essnextgen/ui-kit";

const FileRetrievalCompleted = () => (
  <>
    <Layout pageTitle="Import Progress">
      <Button color={ButtonColor.Secondary}>Show Dialog</Button>
      <Dialog
        dataTestId="test-id"
        escapeExits
        id="element-id"
        returnFocusOnDeactivate
      >
        <DialogContent>
          <Grid
            container
            className="marginb15"
          >
            <GridItem
              sm={12}
              md={12}
              lg={12}
              xl={12}
            >
              <FormLabel className="lable">File retrieval completed</FormLabel>
              <FormLabel className="lable">1 file(s) ready to process</FormLabel>
              <ProgressBar
                dataTestId="progressBar"
                bars={[
                  {
                    percentage: 100,
                    stripedBackground: false,
                    color: "#88D991",
                    insideTextShow: true,
                    insideText: "100%",
                    className: "right-radius"
                  }
                ]}
              />
            </GridItem>
          </Grid>
        </DialogContent>
        <DialogFooter>
          <div className="rightbtn">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
            >
              OK
            </Button>
          </div>
        </DialogFooter>
      </Dialog>
    </Layout>
  </>
);
export default FileRetrievalCompleted;
