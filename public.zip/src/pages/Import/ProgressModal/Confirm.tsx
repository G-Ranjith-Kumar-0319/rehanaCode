import "./Style.scss";
import { Button, ButtonColor, Dialog, DialogContent, DialogFooter } from "@essnextgen/ui-kit";

const Confirm = () => (
  <>
    <Button
      color={ButtonColor.Primary}
      // onClick={function noRefCheck(){}}
    >
      Show Dialog
    </Button>
    <Dialog
      dataTestId="test-id"
      escapeExits
      id="element-id"
      returnFocusOnDeactivate
      title="Confirmation?"
    >
      <DialogContent>
        <div className="essui-global-typography-default-h2">Unsaved changes</div>
        <div>Do you want to save the changes?</div>
      </DialogContent>
      <DialogFooter>
        <Button dataTestId="close-btn">Close</Button>
      </DialogFooter>
    </Dialog>
  </>
);
export default Confirm;
