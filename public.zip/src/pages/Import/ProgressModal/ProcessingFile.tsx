import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  FormLabel,
  Grid,
  GridItem,
  ProgressBar,
  TextInput
} from "@essnextgen/ui-kit";

const ProcessingFile = () => (
  <>
    <Layout pageTitle="Processing File">
      <Button color={ButtonColor.Secondary}>Show Dialog</Button>
      <Dialog
        dataTestId="test-id"
        escapeExits
        id="element-id"
        returnFocusOnDeactivate
      >
        <DialogContent>
          <Grid
            container
            className="marginb15"
          >
            <GridItem
              sm={12}
              md={12}
              lg={12}
              xl={12}
            >
              <FormLabel className="lable">Processing 1 of 1 XML Orders...</FormLabel>
              <ProgressBar
                dataTestId="progressBar"
                bars={[
                  {
                    percentage: 100,
                    stripedBackground: false,
                    color: "#88D991",
                    insideTextShow: true,
                    insideText: "100%",
                    className: "right-radius"
                  }
                ]}
              />
            </GridItem>
          </Grid>
          <Grid
            container
            className="margint10"
          >
            <GridItem
              sm={12}
              md={3}
              lg={3}
              xl={3}
            >
              <div>
                <FormLabel>Imported:</FormLabel>
                <TextInput
                  className="playmodetxt"
                  dataTestId="txtName"
                  value="1"
                />
              </div>
            </GridItem>
            <GridItem
              sm={4}
              md={3}
              lg={3}
              xl={3}
            >
              <div>
                <FormLabel>Failed:</FormLabel>
                <TextInput
                  className="playmodetxt"
                  dataTestId="txtName"
                  value="0"
                />
              </div>
            </GridItem>
          </Grid>
        </DialogContent>
        <DialogFooter>
          <div className="rightbtn">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
            >
              OK
            </Button>
          </div>
        </DialogFooter>
      </Dialog>
    </Layout>
  </>
);
export default ProcessingFile;
