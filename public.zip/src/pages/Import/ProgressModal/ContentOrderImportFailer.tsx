import "./Style.scss";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableUtility,
  TableWrapper,
  TextInput
} from "@essnextgen/ui-kit";

const ContentOrderImportFailer = () => (
  <>
    <section className="layout mt-8 pb-8">
      <div className="wrapper padding-0">
        <TableWrapper>
          <TableUtility>
            <p className="essui-global-typography-default-h4">XML Content Order Import Failer</p>
          </TableUtility>
          <Table
            dataTestId="test-id"
            id="element-id"
          >
            <TableHead>
              <TableRow>
                <TableCell header>FIle Name</TableCell>
                <TableCell header>From</TableCell>
                <TableCell header>Date</TableCell>

                <TableCell header>Reason for Failure</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow>
                <TableCell>Advanced_Catering</TableCell>
                <TableCell>Advanced_Catering</TableCell>
                <TableCell>15 Apr 2024 5:22:30 PM</TableCell>

                <TableCell>The system will only iport content orders.</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableWrapper>
      </div>
    </section>
    <section className="layout mt-8 pb-8">
      <div className="wrapper">
        <Grid
          container
          className="margint10"
        >
          <GridItem
            sm={4}
            md={2}
            lg={3}
            xl={3}
          >
            <div>
              <FormLabel>Reason For Failure</FormLabel>
              <TextInput
                className="playmodetxt"
                dataTestId="txtName"
                value="The system will only Import content orders."
              />
            </div>
          </GridItem>
        </Grid>
        <Divider />
        <Grid
          container
          className="margint10"
        >
          <GridItem
            sm={3}
            md={4}
            lg={6}
            xl={6}
          >
            <div>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Tertiary}
              >
                Help
              </Button>
            </div>
          </GridItem>
          <GridItem
            sm={5}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="rightbtn">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
              >
                OK
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
              >
                Print
              </Button>
            </div>
          </GridItem>
        </Grid>
      </div>
    </section>
  </>
);
export default ContentOrderImportFailer;
