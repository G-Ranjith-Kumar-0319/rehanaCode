import "../Style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  FormLabel,
  Grid,
  GridItem,
  ProgressBar
} from "@essnextgen/ui-kit";

const ImportProgressactive = () => (
  <>
    <Layout pageTitle="Import Progress">
      <Grid className="row-gap-24 mb-16">
        <GridItem
          sm={4}
          md={8}
          lg={12}
          xl={12}
        >
          <ProgressBar
            dataTestId="progressBar"
            bars={[
              {
                percentage: 100,
                stripedBackground: false,
                color: "#e0e0e0",
                insideTextShow: true,
                insideText: "0%",
                className: "right-radius"
              }
            ]}
          />
        </GridItem>
        <GridItem
          sm={4}
          md={8}
          lg={12}
          xl={12}
        >
          <ProgressBar
            dataTestId="progressBar"
            bars={[
              {
                percentage: 100,
                stripedBackground: false,
                color: "#e0e0e0",
                insideTextShow: true,
                insideText: "0%",
                className: "right-radius"
              }
            ]}
          />
        </GridItem>
      </Grid>
      <div className="progress__data--field d-flex flex-wrap row-gap-16">
        <div className="progress__data">
          <div className="essui-form-label mb-5">Imported</div>
          <div className="">0</div>
        </div>
        <div className="progress__data">
          <div className="essui-form-label mb-5">Content Orders</div>
          <div className="">0</div>
        </div>
        <div className="progress__data">
          <div className="essui-form-label mb-5">Invoices</div>
          <div className="">0</div>
        </div>
        <div className="progress__data">
          <div className="essui-form-label mb-5">Credit Notes</div>
          <div className="">0</div>
        </div>
        <div className="progress__data">
          <div className="essui-form-label mb-5">Failed</div>
          <div className="">0</div>
        </div>
      </div>
      <Grid>
        <GridItem
          sm={4}
          md={8}
          lg={12}
          xl={12}
          className="d-flex justify-end"
        >
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Primary}
          >
            Import
          </Button>
        </GridItem>
      </Grid>
    </Layout>
    <Layout isBreadcrumbRequired={false}>
      <Grid>
        <GridItem
          sm={4}
          md={8}
          lg={12}
          xl={12}
          className="d-flex justify-end"
        >
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Primary}
          >
            Ok
          </Button>
        </GridItem>
      </Grid>
    </Layout>
    <Dialog
      dataTestId="test-id"
      escapeExits
      id="element-id"
      returnFocusOnDeactivate
    >
      <DialogContent>
        <Grid
          container
          className="marginb15"
        >
          <GridItem
            sm={12}
            md={12}
            lg={12}
            xl={12}
          >
            <FormLabel className="lable">File retrieval completed</FormLabel>
            <FormLabel className="lable">1 file(s) ready to process</FormLabel>
            <ProgressBar
              dataTestId="progressBar"
              bars={[
                {
                  percentage: 100,
                  stripedBackground: false,
                  color: "#88D991",
                  insideTextShow: true,
                  insideText: "100%",
                  className: "right-radius"
                }
              ]}
            />
          </GridItem>
        </Grid>
      </DialogContent>
      <DialogFooter>
        <div className="rightbtn">
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Primary}
          >
            OK
          </Button>
        </div>
      </DialogFooter>
    </Dialog>
  </>
);
export default ImportProgressactive;
