import "../Style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  Grid,
  GridItem,
  ProgressBar
} from "@essnextgen/ui-kit";

const ImportProgressSuccess = () => (
  <>
    <Layout pageTitle="Import Progress">
      <Grid
        container
        className="marginb15"
      >
        <GridItem
          sm={12}
          md={12}
          lg={12}
          xl={12}
        >
          <div className="essui-form-label">File retrieval completed</div>
          <ProgressBar
            dataTestId="progressBar"
            bars={[
              {
                percentage: 100,
                stripedBackground: false,
                color: "#88D991",
                insideTextShow: true,
                insideText: "100%",
                className: "right-radius"
              }
            ]}
          />
        </GridItem>
      </Grid>
      <Grid
        container
        className="marginb15"
      >
        <GridItem
          sm={12}
          md={12}
          lg={12}
          xl={12}
        >
          <div className="essui-form-label">0 file(s) ready to process</div>
          <ProgressBar
            dataTestId="progressBar"
            bars={[
              {
                percentage: 100,
                stripedBackground: false,
                color: "#88D991",
                insideTextShow: true,
                insideText: "100%",
                className: "right-radius"
              }
            ]}
          />
        </GridItem>
      </Grid>
      <Grid
        container
        className="margint10"
      >
        <GridItem
          sm={12}
          md={3}
          lg={3}
          xl={3}
        >
          <div>
            <div className="essui-form-label">Imported:</div>
            <div className="mt-12">4</div>
          </div>
        </GridItem>
        <GridItem
          sm={4}
          md={3}
          lg={3}
          xl={3}
        >
          <div>
            <div className="essui-form-label">Content Orders:</div>
            <div className="mt-12">6</div>
          </div>
        </GridItem>
        <GridItem
          sm={12}
          md={3}
          lg={3}
          xl={3}
        >
          <div>
            <div className="essui-form-label">Invoices:</div>
            <div className="mt-12">7</div>
          </div>
        </GridItem>
        <GridItem
          sm={12}
          md={3}
          lg={3}
          xl={3}
        >
          <div>
            <div className="essui-form-label">Credit Notes:</div>
            <div className="mt-12">5</div>
          </div>
        </GridItem>
      </Grid>
      <Grid
        container
        className="margint10"
      >
        <GridItem
          sm={12}
          md={3}
          lg={3}
          xl={3}
        >
          <div>
            <div className="essui-form-label">Failed:</div>
            <div className="mt-12">0</div>
          </div>
        </GridItem>
      </Grid>
      <Grid
        container
        className="margint10"
      >
        <GridItem
          sm={12}
          md={12}
          lg={12}
          xl={12}
        >
          <div className="rightbtn">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
            >
              Import
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
            >
              OK
            </Button>
          </div>
        </GridItem>
      </Grid>
      <Button color={ButtonColor.Secondary}>Show Dialog</Button>
      <Dialog
        dataTestId="test-id"
        escapeExits
        id="element-id"
        returnFocusOnDeactivate
      >
        <DialogContent>
          <Grid
            container
            className="marginb15"
          >
            <GridItem
              sm={12}
              md={12}
              lg={12}
              xl={12}
            >
              <div className="essui-form-label mb-12">File retrieval completed</div>
              <div className="essui-form-label mb-12">1 file(s) ready to process</div>
              <ProgressBar
                dataTestId="progressBar"
                bars={[
                  {
                    percentage: 100,
                    stripedBackground: false,
                    color: "#88D991",
                    insideTextShow: true,
                    insideText: "100%",
                    className: "right-radius"
                  }
                ]}
              />
            </GridItem>
          </Grid>
        </DialogContent>
        <DialogFooter>
          <div className="rightbtn">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
            >
              OK
            </Button>
          </div>
        </DialogFooter>
      </Dialog>
    </Layout>
  </>
);
export default ImportProgressSuccess;
