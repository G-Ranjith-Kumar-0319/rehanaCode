import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";

import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

import { Sequence } from "@/utils/constants";

import UseStateType, { TAGTYPES, specialCharacters } from "@/types/UseStateType";
import { TTagDataParams } from "@/shared/components/TagAll/types";
import { FMSSessionStorage } from "@/utils/Storage";

import {
  CHEQUE_PROCESSING_CHEQUE_RUN,
  CHEQUE_PROCESSING_STORAGE_KEY,
  CMAXNOOFINVONFIRSTCHEQUE,
  CMAXNOOFINVONSUBSEQUENTCHEQUES
} from "../constants";

import {
  actions as ItPayment,
  ChequeProcessingPostTagData,
  getChequeGetDetails,
  getChequeOptionsBrowse,
  getChequePaymentItems,
  getTaggedSuppliers,
  chequeOptionsUpdate
} from "../state/ItemsPayment.slice";

import { ChequeItemsForPaymentDef } from "./Grid/ChequeItemsForPaymentDef";

const useItemsForPayment = () => {
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  // const [selectedRadio, setSelectedRadio] = useState<any>(Sequence.SEQ);
  // const [bacsCheck, setBacsCheck] = useState<any>();
  // const [sundryCheck, setSundryCheck] = useState<any>();
  // const [diff, setDiff] = useState<any>();
  const [isUnTagAll, setIsUnTagAll] = useState<boolean>(false);
  const [isTaggedOpen, setIsTaggedOpen]: UseStateType<boolean> = useState<boolean>(false);
  const { defaultPeriod } = useAppSelector((state) => state.chequeDetails);
  const { chequePayeeDetails } = useAppSelector((state) => state.summaryOfCheques);
  const { chequeBooks } = useAppSelector((state) => state.availableChequeBooks);
  const {
    selectedCheckedView,
    chequeBankDetails,
    filterState,
    filterState: { sequence, showBACS, showSundry },
    selectedView,
    checkedPaymentItems,
    currentBalance,
    checkedRows,
    columnDef
  } = useAppSelector((state) => state.chequePaymentItems);

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const [taggedBalance, setTaggedBalance] = useState<number>(0.0);
  const [newBalance, setNewBalance] = useState<number>(0.0);
  const [paymentPeriod, setPaymentPeriod] = useState<number | string>(specialCharacters.HYPHEN);
  const [orderNumber, setOrderNumber] = useState<number | string>(specialCharacters.HYPHEN);
  const [orderNumberLabel, setOrderNumberLabel] = useState<string>(t("chequeProcessing.order"));
  const { clientId, payeeId } = useParams<{ clientId: string; payeeId: string }>();
  const [columns, setColumn] = useState<TColumnDef>([...ChequeItemsForPaymentDef]);
  const [openKeepChangeModal, setOpenKeepChangeModal] = useState<boolean>(false);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<string>("");
  const [redirectUrl, setRedirectUrl] = useState<string>("");

  useEffect(() => {
    setNewBalance(currentBalance);
  }, [currentBalance]);

  useEffect(() => {
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      if (
        (location.pathname === "/cheque-processing/add-cheque-run" || location.pathname === "/cheque-processing") &&
        !(location.state as any)?.moveToAddPage
      ) {
        setOpenKeepChangeModal(true);
        setRedirectUrl(location.pathname);
        return undefined;
      }
    });
    return () => unblock();
  }, []);

  useEffect(() => {
    const initialValue = 0.0;
    const taggedAmount = checkedRows.reduce(
      (accumulator: any, currentValue: { [key: string]: any }) => accumulator + currentValue.payment_amount,
      initialValue
    );
    const taggedAmountUpto2Decimals = Number(taggedAmount.toFixed(2));
    setTaggedBalance(taggedAmountUpto2Decimals);
  }, [checkedRows]);

  useEffect(() => {
    const newBalance = currentBalance - taggedBalance;
    const newBalanceUpto2Decimals = Number(newBalance.toFixed(2));
    setNewBalance(newBalanceUpto2Decimals);
  }, [taggedBalance]);

  useEffect(() => {
    const isChecked = columns[0].checkboxSelection === true ? 1 : 0;

    let field: string;
    let field2: string;
    switch (sequence) {
      case Sequence.SEQ:
      default:
        field = "client_name";
        break;
      case Sequence.IDSEQ:
        field = "client_name";
        field2 = "client_code";
        break;
      case Sequence.INVCR:
        field = "invoice_num";
        break;
      case Sequence.PAYDATE:
        field = "disp_pay_by";
        break;
    }
    const found = columns.find((row) => row?.field === field);
    columns.splice(columns.indexOf(found!), 1); // delete
    columns.splice(isChecked, 0, found!);
    if (sequence === Sequence.IDSEQ) {
      const found2 = columns.find((row) => row?.field === field2);
      columns.splice(columns.indexOf(found2!), 1); // delete
      columns.splice(isChecked, 0, found2!);
    }
    setColumn([...columns]);
    dispatch(ItPayment.setColumnDef(columns));
  }, [sequence]);

  useEffect(() => {
    dispatch(getChequeOptionsBrowse());
  }, []);

  useEffect(() => {
    const storageData = FMSSessionStorage.getItem(CHEQUE_PROCESSING_STORAGE_KEY);

    const { bankId, period } = storageData;

    if (bankId && period) {
      dispatch(
        getChequePaymentItems({
          bankId,
          period,
          order: sequence,
          sundryType: showSundry,
          bacsPayable: showBACS,
          callback: (response) => {
            if (response) {
              const selectedData = response?.filter((item: any) => item.unique_id === selectedView?.unique_id)?.at(0);
              if (selectedData) {
                dispatch(ItPayment.setChequeProcessingView(selectedData));
              } else {
                dispatch(ItPayment.setChequeProcessingView(response?.at(0)));
              }
            }
          }
        })
      );
    }
  }, [sequence, showBACS, showSundry]);

  // useEffect(() => {

  //   console.log("chequeBooks", chequeBooks, "defaultPeriod", defaultPeriod);
  //   if (chequeBooks[0]?.bank_id && defaultPeriod) {
  //     dispatch(
  //       getChequePaymentItems({
  //         bankId: chequeBooks[0]?.bank_id ?? 0,
  //         period: defaultPeriod ? defaultPeriod.toString() : "",
  //         order: selectedRadio,
  //         sundryType: sundryCheck,
  //         bacsPayable: bacsCheck
  //       })
  //     );
  //   }
  // }, [chequeBooks, sequence, showBACS, showSundry]);

  useEffect(() => {
    if (chequeBooks[0]?.bank_id) {
      dispatch(
        getChequeGetDetails({
          bankId: chequeBooks[0]?.bank_id ?? 0
        })
      );
    }
  }, [chequeBooks]);

  const onSequenceChange = (e: any) => {
    dispatch(
      ItPayment.setFilters({
        ...filterState,
        sequence: e.target.value
      })
    );
  };

  const onSelectBACSCheckbox = (e: any) => {
    dispatch(ItPayment.setCheckedPaymentItems([]));
    if (e.target.checked) {
      dispatch(
        ItPayment.setFilters({
          ...filterState,
          showBACS: true
        })
      );
    } else {
      dispatch(
        ItPayment.setFilters({
          ...filterState,
          showBACS: false
        })
      );
    }
  };

  const onSelectSundryInvCheckbox = (e: any) => {
    dispatch(ItPayment.setCheckedPaymentItems([]));
    if (e.target.checked) {
      dispatch(
        ItPayment.setFilters({
          ...filterState,
          showSundry: "T"
        })
      );
    } else {
      dispatch(
        ItPayment.setFilters({
          ...filterState,
          showSundry: "F"
        })
      );
    }
  };

  const tagSubmitHandler = (type: string, params: TTagDataParams) => {
    const chequeRunDetailsSessionData = JSON.parse(sessionStorage.getItem("chequeProcessing")!) || {};
    const initialReqData: ChequeProcessingPostTagData = {
      sundryInvoiceChecked: showSundry === "T",
      exclBACSSupplChecked: showBACS,
      supplierTag_TagAllChecked: false,
      supplierTag_SpecificChecked: false,
      supplierTag_Client_Id: "",
      supplierTag_Not_ClientChecked: false,
      amountTag_AllChecked: false,
      amountTag_GreaterChecked: false,
      amountTag_LessChecked: false,
      amount: 0,
      payByTag_All_DateChecked: false,
      payByTag_Specific_DateChecked: false,
      payByTag_Not_DateChecked: false,
      payByTag_DateCode: "",
      payByTag_StartDateTag: "",
      payByTag_EndDateTag: "",
      bankId: Object.keys(chequeRunDetailsSessionData).length > 0 ? chequeRunDetailsSessionData.bankId : 0,
      period: Object.keys(chequeRunDetailsSessionData).length > 0 ? chequeRunDetailsSessionData.period : 0
    };
    if (params.supplier) {
      initialReqData.supplierTag_Client_Id = params.supplier.toString();
      initialReqData.supplierTag_TagAllChecked = false;
      initialReqData.supplierTag_SpecificChecked = true;
    } else {
      initialReqData.supplierTag_TagAllChecked = true;
      initialReqData.supplierTag_SpecificChecked = false;
    }
    if (params.amount) {
      initialReqData.amount = Number(params.amount);
      initialReqData.amountTag_AllChecked = false;
      if (params.amountType === TAGTYPES.GREATER_THAN) {
        initialReqData.amountTag_GreaterChecked = true;
        initialReqData.amountTag_LessChecked = false;
      } else {
        initialReqData.amountTag_GreaterChecked = false;
        initialReqData.amountTag_LessChecked = true;
      }
    } else {
      initialReqData.amountTag_AllChecked = true;
    }

    if (params.tagBy.length > 0) {
      initialReqData.payByTag_All_DateChecked = false;
      initialReqData.payByTag_Specific_DateChecked = true;
      initialReqData.payByTag_DateCode = params.tagBy;
      initialReqData.payByTag_StartDateTag = params.date1;
      initialReqData.payByTag_EndDateTag = params.date2;
    } else {
      initialReqData.payByTag_All_DateChecked = true;
      initialReqData.payByTag_Specific_DateChecked = false;
    }

    if (params.notInsupplier) initialReqData.supplierTag_Not_ClientChecked = true;
    if (params.notInDate) initialReqData.payByTag_Not_DateChecked = true;

    dispatch(
      getTaggedSuppliers({
        reqData: initialReqData,
        callback: tagFiltersApiCallback
      })
    );
    setIsTaggedOpen(false);
  };

  const tagFiltersApiCallback = (response: Array<string>) => {
    setIsUnTagAll(false);
    dispatch(ItPayment.setCheckedPaymentItems(response));
  };

  useEffect(() => {
    const historyState = history.location.state as any;
    if (historyState?.checkedPaymentItems) {
      setTimeout(() => {
        dispatch(ItPayment.setCheckedRows(historyState?.checkedPaymentItems));
      }, 300);
    }
  }, [history.location.state]);

  const onSelectCheckbox = (val: any) => {
    dispatch(ItPayment.handleCheckbox({ val }));
  };

  const onRowSelection = (row?: { [key: string]: any }) => {
    setPaymentDetails(row);
    dispatch(ItPayment.setChequeProcessingView(row));
  };

  const unTagAll = () => {
    setIsUnTagAll(true);
    dispatch(ItPayment.clearCheckedInvoices());
    dispatch(ItPayment.unCheckAll());
  };

  const setPaymentDetails = (row?: { [key: string]: any }) => {
    if (row?.payment_type === "I") {
      setOrderNumberLabel(t("chequeProcessing.order"));
      setOrderNumber(row?.order_no || specialCharacters.HYPHEN);
    } else {
      setOrderNumberLabel(t("chequeProcessing.invoice"));
      setOrderNumber(row?.matched_invoice || specialCharacters.HYPHEN);
    }

    setPaymentPeriod(row?.period);
  };
  const goBack = () => {
    const historyState = {
      ...(history?.location?.state as any),
      checkedPaymentItems
    };
    const chequeRunData = FMSSessionStorage.getItem(CHEQUE_PROCESSING_CHEQUE_RUN);
    history.push({
      pathname: clientId
        ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/add-cheque-run`
        : "/cheque-processing/add-cheque-run",
      state: history?.location?.state ? { ...historyState } : { ...chequeRunData }
    });
  };

  const validateCheckedAmounts = () => {
    const clientIds = checkedPaymentItems.map((row) => row?.client_id);
    const uniqueClientIds = Array.from(new Set(clientIds));
    const chequeRunData = FMSSessionStorage.getItem(CHEQUE_PROCESSING_CHEQUE_RUN);
    const { chequeList } = chequeRunData;
    let isError = false;
    const newGridData: { [key: string]: any }[] = [];
    let chequesCount = 0;
    uniqueClientIds.forEach((clientId, index) => {
      const clientDetails = checkedPaymentItems.filter((row) => row.client_id === clientId);
      const totalAmount = clientDetails.reduce((sum, row) => sum + row.payment_amount, 0);
      const clientName = clientDetails[0]?.client_name;
      chequesCount += Math.ceil(clientDetails.length / 16);
      if (totalAmount < 0) {
        setAlertMessage(
          t("chequeProcessing.validateChequeAmounts", {
            clientName
          })
        );
        setIsAlertModalOpen(true);
        isError = true;
      }

      const payeeName = clientDetails[0]?.payee_name;
      newGridData.push({
        client_id: clientId,
        payee_name: payeeName,
        client_name: clientName,
        amount: totalAmount
      });
    });

    if (chequesCount > chequeList.length) {
      setAlertMessage(t("chequeProcessing.validateChequeNumber"));
      setIsAlertModalOpen(true);
      isError = true;
    }

    const newGridDataSort = newGridData.sort((a, b) => {
      const diff1 = a?.payee_name ? a?.payee_name : a?.client_name;
      const diff2 = b?.payee_name ? b?.payee_name : b?.client_name;
      return diff1.localeCompare(diff2);
    });
    for (let i = 0; i < newGridDataSort.length; i += 1) {
      const row = newGridDataSort[i];
      if (row?.amount < 0) {
        setAlertMessage(
          t("chequeProcessing.validateChequeAmounts", {
            clientName: row?.payee_name ? row?.payee_name : row?.client_name
          })
        );
        setIsAlertModalOpen(true);
        isError = true;
        break;
      }
    }
    return isError;
  };

  const goToNext = () => {
    const checkedAmountValidationFailed = validateCheckedAmounts();

    if (!checkedAmountValidationFailed) {
      dispatch(
        chequeOptionsUpdate({
          displayBacsPayable: showBACS,
          displaySundryInvoicesOnly: showSundry === "T"
        })
      );
      storeSessionData();
      const historyState = {
        ...(history?.location?.state as any),
        checkedPaymentItems,
        moveToAddPage: true
      };
      history.push({
        pathname: clientId
          ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/add-cheque-run/items-for-payment/summary-of-cheques`
          : "/cheque-processing/add-cheque-run/items-for-payment/summary-of-cheques",
        state: { ...historyState }
      });
    }
  };

  const storeSessionData = () => {
    const uniqueIds = checkedPaymentItems.map((row) => row?.unique_id);
    const paymentDetails = {
      current: currentBalance,
      taggedItems: taggedBalance,
      new: newBalance
    };

    const storedData = FMSSessionStorage.getItem("chequeProcessing");
    const updatedStoredData = { ...storedData, uniqueId: uniqueIds, paymentDetails };
    FMSSessionStorage.setItem("chequeProcessing", updatedStoredData);
  };

  return {
    t,
    onSelectCheckbox,
    isTaggedOpen,
    setIsTaggedOpen,
    isAlertModalOpen,
    setIsAlertModalOpen,
    alertMessage,
    tagSubmitHandler,
    goToNext,
    onRowSelection,
    goBack,
    currentBalance,
    taggedBalance,
    newBalance,
    paymentPeriod,
    orderNumber,
    orderNumberLabel,
    unTagAll,
    sequence,
    showBACS,
    showSundry,
    onSequenceChange,
    onSelectBACSCheckbox,
    onSelectSundryInvCheckbox,
    openKeepChangeModal,
    setOpenKeepChangeModal,
    history,
    redirectUrl
  };
};

export default useItemsForPayment;
