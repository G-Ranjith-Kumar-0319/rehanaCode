import { CheckBox, FormLabel, Grid, GridItem, RadioButton, RadioLabelPosition } from "@essnextgen/ui-kit";

import { Sequence } from "@/utils/constants";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";

/* eslint-disable import/prefer-default-export */
export const Filter = (props: any) => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();

  const { sequence, showBACS, showSundry, onSequenceChange, onSelectBACSCheckbox, onSelectSundryInvCheckbox } = props;

  return (
    <Grid className="row-gap-16">
      <GridItem>
        <div>
          <FormLabel>{t("chequeProcessing.sequence")}</FormLabel>
          <div className="sequence">
            <div className="essui-textinput sequence-fields flex-wrap row-gap-16">
              {/* {(ChequeItemsForPaymentDef.filter((col: any) => !!col.sequence) || []).map((column: any, index: number) => {
                  const sequenceId = `sequence=${index + 1}`;
                  return (
                    <RadioButton
                      label={column.sequenceName ? column.sequenceName : column.headerName}
                      name={column.sequenceName ? column.sequenceName : column.headerName}
                      labelPosition={RadioLabelPosition.Right}
                      value={column.field}
                      onChange={() => onSequenceChange(column, index)}
                      isSelected={filters?.sequenceValue === column.field}
                      key={sequenceId}
                    />
                }))} */}
              <RadioButton
                label={t("chequeProcessing.supplier")}
                labelPosition={RadioLabelPosition.Right}
                value={Sequence.SEQ}
                isSelected={sequence === Sequence.SEQ}
                onChange={onSequenceChange}
              />
              <RadioButton
                label={t("chequeProcessing.idSupplier")}
                labelPosition={RadioLabelPosition.Right}
                value={Sequence.IDSEQ}
                isSelected={sequence === Sequence.IDSEQ}
                onChange={onSequenceChange}
              />
              <RadioButton
                label={t("chequeProcessing.invoiceCreditNoteNo")}
                labelPosition={RadioLabelPosition.Right}
                value={Sequence.INVCR}
                isSelected={sequence === Sequence.INVCR}
                onChange={onSequenceChange}
              />
              <RadioButton
                label={t("chequeProcessing.payByDate")}
                labelPosition={RadioLabelPosition.Right}
                value={Sequence.PAYDATE}
                isSelected={sequence === Sequence.PAYDATE}
                onChange={onSequenceChange}
              />
            </div>
          </div>
        </div>
      </GridItem>
      <GridItem>
        <div className="mt-32">
          <CheckBox
            label={t("chequeProcessing.showBACSEnabledSupplierTransactions")}
            value={showBACS}
            isSelected={showBACS}
            onChange={onSelectBACSCheckbox}
          />
        </div>
      </GridItem>
      <GridItem>
        <div className="mt-32">
          <CheckBox
            label={t("chequeProcessing.showSundryInvoicesOnly")}
            value={showSundry}
            isSelected={showSundry === "T"}
            onChange={onSelectSundryInvCheckbox}
          />
        </div>
      </GridItem>
    </Grid>
  );
};
