import { useDispatch } from "react-redux";

import GridTableNew from "@/components/GridTableNew/GridTableNew";
import Layout from "@/components/Layout/Layout";

import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  Dialog,
  DialogContent,
  Divider,
  FormLabel,
  Grid,
  GridItem,
  NotificationStatus
} from "@essnextgen/ui-kit";
import { AppDispatch, useAppSelector } from "@/store/store";
import { STATUS, specialCharacters } from "@/types/UseStateType";

import { TagAll } from "@/shared/components/TagAll/TagAll";
import { usNumberFormat, getDate } from "@/utils/getDataSource";
import AlertModal from "@/shared/components/AlertModal/AlertModal";

import HelpButton from "@/components/OpenLinkButton/HelpButton";
import ConfirmModal from "@/shared/components/ConfirmModal/ConfirmModal";
import { Filter } from "./Grid/Filter/Filter";

import useItemsForPayment from "./useItemsForPayment";

import "./Style.scss";

const ItemsForPayment = () => {
  const { chequePaymentItem, status, selectedView, checkedPaymentItems, checkedRows, columnDef } = useAppSelector(
    (state) => state.chequePaymentItems
  );

  const {
    t,
    goToNext,
    isTaggedOpen,
    setIsTaggedOpen,
    isAlertModalOpen,
    setIsAlertModalOpen,
    alertMessage,
    tagSubmitHandler,
    onSelectCheckbox,
    onRowSelection,
    currentBalance,
    taggedBalance,
    newBalance,
    goBack,
    paymentPeriod,
    orderNumber,
    orderNumberLabel,
    unTagAll,
    sequence,
    showBACS,
    showSundry,
    onSequenceChange,
    onSelectBACSCheckbox,
    onSelectSundryInvCheckbox,
    openKeepChangeModal,
    setOpenKeepChangeModal,
    history,
    redirectUrl
  } = useItemsForPayment();

  const CustomCell = ({ field, row }: any) => {
    const getContent = () => {
      const formatDate = (dateString: any) => {
        const [day, month, year] = dateString.split("/");
        const dateObj = new Date(`${year}-${month}-${day}`);
        const options: any = { day: "2-digit", month: "short", year: "numeric" };
        return dateObj.toLocaleDateString("en-GB", options);
      };
      const numberFormatter: any = new Intl.NumberFormat("en-US", {
        style: "decimal",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });

      if (field === "disp_pay_by") {
        return <span>{formatDate(row?.disp_pay_by)}</span>;
      }
      if (field === "amount") {
        return (
          <span>{row?.payment_amount ? numberFormatter.format(row?.payment_amount) : specialCharacters.HYPHEN}</span>
        );
      }

      return null;
    };
    return getContent();
  };

  return (
    <>
      <Layout
        className="items-for-payment"
        pageTitle={t("chequeProcessing.itemsForPayment")}
        isBreadcrumbRequired
      >
        <Grid
          container
          className="marginb15"
        >
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
            className="bankbalance-padding-left"
          >
            <div className="essui-global-typography-default-subtitle">{t("chequeProcessing.bankBalance")}</div>
          </GridItem>
        </Grid>
        <Grid className="row-gap-16">
          <GridItem
            sm={12}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{t("chequeProcessing.current")}</div>
              <div className="mt-12 balance">{usNumberFormat(currentBalance)}</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{t("chequeProcessing.taggedItems")}</div>
              <div className="mt-12">{usNumberFormat(taggedBalance)}</div>
            </div>
          </GridItem>
          <GridItem
            sm={12}
            md={3}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{t("chequeProcessing.new")}</div>
              <div className="mt-12">{usNumberFormat(newBalance)}</div>
            </div>
          </GridItem>
        </Grid>
      </Layout>

      <Layout
        isBreadcrumbRequired={false}
        type="transparent"
        className="items-for-payment mt-8 pb-8"
      >
        <GridTableNew
          filters={
            <Filter
              sequence={sequence}
              showBACS={showBACS}
              showSundry={showSundry}
              onSequenceChange={onSequenceChange}
              onSelectBACSCheckbox={onSelectBACSCheckbox}
              onSelectSundryInvCheckbox={onSelectSundryInvCheckbox}
            />
          }
          dataSource={chequePaymentItem}
          isLoading={status === STATUS.LOADING}
          columnDef={columnDef}
          customCell={CustomCell}
          selectedRow={selectedView}
          checkedRows={checkedRows}
          checkedRowHandler={onSelectCheckbox}
          selectedRowHandler={onRowSelection}
          isScrollable
        />
      </Layout>

      <Layout
        isBreadcrumbRequired={false}
        className="items-for-payment layout mt-8 pb-8"
      >
        <Grid>
          <GridItem
            sm={4}
            md={2}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{t("chequeProcessing.period")}</div>
              <div className="mt-12">{paymentPeriod}</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={2}
            lg={3}
            xl={3}
          >
            <div>
              <div className="essui-form-label">{orderNumberLabel}</div>
              <div className="mt-12">{orderNumber}</div>
            </div>
          </GridItem>
          <GridItem
            sm={4}
            md={4}
            lg={6}
            xl={6}
            className="end-txt rsp-justify-start"
          >
            <FormLabel className="mr-bt8">{t("chequeProcessing.selection")}</FormLabel>
            <div className="selection">
              <div className="right-end">
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  iconPosition={ButtonIconPosition.Left}
                  disabled={chequePaymentItem.length === 0 || checkedRows.length === 0}
                  onClick={unTagAll}
                >
                  {t("tagUntag.unTagAll")}
                </Button>
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  iconPosition={ButtonIconPosition.Right}
                  disabled={chequePaymentItem.length === 0}
                  onClick={() => setIsTaggedOpen(true)}
                >
                  {t("tagUntag.tag")}
                </Button>
              </div>
            </div>
          </GridItem>
        </Grid>
        <Divider />
        <Grid className="margint10">
          <GridItem
            sm={3}
            md={4}
            lg={6}
            xl={6}
          >
            <div>
              {/* <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Tertiary}
                >
                  {t("common.help")}
                </Button> */}
              <HelpButton
                identifier="testIdentifier"
                labelName={t("common.help")}
              />
            </div>
          </GridItem>
          <GridItem
            sm={5}
            md={4}
            lg={6}
            xl={6}
          >
            <div className="rightbtn">
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Primary}
                onClick={goToNext}
                disabled={checkedRows.length === 0}
              >
                {t("common.next")}
              </Button>
              <Button
                size={ButtonSize.Small}
                color={ButtonColor.Secondary}
                onClick={goBack}
              >
                {t("common.back")}
              </Button>
              {/* <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                >
                  Cancel
                </Button> */}
            </div>
          </GridItem>
        </Grid>
      </Layout>
      <Dialog
        title={t("chequeProcessing.chequeProcessingTagModalTitle")}
        className="invoice-note-tag modal__adjust--spacing"
        isOpen={isTaggedOpen}
        onClose={() => setIsTaggedOpen(false)}
      >
        <DialogContent className="overflow-hidden">
          <TagAll
            filters={["supplier", "date", "amount"]}
            onSubmit={tagSubmitHandler}
            onCancel={() => setIsTaggedOpen(false)}
            showAllSupplierSundry
            supplierModalHeaderTitle={t("chequeProcessing.chequeProcessingTagModalTitle")}
            dateLabelByCheque
          />
        </DialogContent>
      </Dialog>
      <AlertModal
        isOpen={isAlertModalOpen}
        setOpen={setIsAlertModalOpen}
        title={t("alertMessage.title")}
        notificationType={NotificationStatus.WARNING}
        message={alertMessage}
      />
      <ConfirmModal
        className="modal-width"
        isOpen={openKeepChangeModal}
        setOpen={setOpenKeepChangeModal}
        title={t("alertMessage.title")}
        message={t("common.keepChangesMsg")}
        confirm={() => {}}
        callback={({ confirm }) => {
          const historyState = {
            ...(history?.location?.state as any),
            checkedPaymentItems,
            moveToAddPage: true
          };
          if (!confirm) {
            history.push({
              pathname: redirectUrl,
              state: {
                ...historyState
              }
            });
          }
        }}
      />
    </>
  );
};
export default ItemsForPayment;
