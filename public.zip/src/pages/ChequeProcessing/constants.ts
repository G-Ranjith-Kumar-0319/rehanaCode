/* eslint-disable import/prefer-default-export */
export const CHEQUE_PROCESSING_STORAGE_KEY = "chequeProcessing";
export const CHEQUE_PROCESSING_CHEQUE_RUN = "chequeRun";
export const CMAXNOOFINVONFIRSTCHEQUE = 16;
export const CMAXNOOFINVONSUBSEQUENTCHEQUES = CMAXNOOFINVONFIRSTCHEQUE - 1;
