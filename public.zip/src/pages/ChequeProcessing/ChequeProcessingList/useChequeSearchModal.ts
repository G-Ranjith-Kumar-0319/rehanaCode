import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { searchCheques, actions as chequeActions } from "../state/ChequeProcessing.slice";

type ChequeSearchPopupHooksProps = {
  setOpen: (isOpen: boolean) => void;
  isOpen: boolean;
};

const useChequeSearchModal = ({ setOpen, isOpen }: ChequeSearchPopupHooksProps) => {
  const dispatch = useDispatch<AppDispatch>();
  const { modalSelectedRow } = useAppSelector((state) => state.newChequeProcessingList);
  const [chequeList, setChequeList] = useState<{ [key: string]: any }[]>([]);
  const [isListLoading, setIsListLoading] = useState<boolean>(false);
  const [selectedRow, setSelectedRow] = useState<any>(null);

  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const closeHandler = () => {
    dispatch(chequeActions.setFindChequeNumber(true));
    dispatch(
      chequeActions.setFilters({
        sequenceValue: "payment_run_number" || "cheque_number",
        lookingFor: selectedRow?.cheque_run_number || selectedRow?.cheque_number,
        sequence: 1,
        applyFilterChange: true
      })
    );
    setOpen(false);
  };

  const handleSelectedRowChange = (row: any) => {
    setSelectedRow(row);
    const indexOfRow = chequeList.findIndex((item) => item.cheque_number === row.cheque_number);
    const element = document.getElementById(`rowIndex-chequeTableId-${indexOfRow}`);
    setTimeout(() => {
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }, 10);
  };

  useEffect(() => {
    if (isOpen) {
      setIsListLoading(true);
      const fetchChequeData = async () => {
        const res: any = await dispatch(searchCheques(""));
        setIsListLoading(false);
        setChequeList(res?.payload?.cheques);
        if (res?.payload?.cheques?.length > 0) {
          setSelectedRow(res.payload.cheques[0]);
        }
      };
      fetchChequeData();
    }
  }, [isOpen]);

  return {
    t,
    chequeList,
    isListLoading,
    modalSelectedRow,
    closeHandler,
    selectedRow,
    handleSelectedRowChange
  };
};

export default useChequeSearchModal;
