import { TColumnDef } from "@/components/GridTableNew/GridTableNew";

const chequeProcessingDef: TColumnDef = [
  {
    headerName: "Run Date",
    field: "run_date",
    sequenceName: "Date",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Run Number",
    field: "payment_run_number",
    sequenceName: "Run",
    cellRenderer: "GridCellLink",
    sequence: true
  },
  {
    headerName: "Narrative",
    field: "narrative",
    cellRenderer: "GridCellLink"
  },
  {
    headerName: "Cross Year",
    field: "transfer_code"
  },
  {
    headerName: "",
    field: "detailLink",
    cellRenderer: "GridCellLink",
    columnWidth: 5
  }
];

export const ChequeSearchColumnDef: TColumnDef = [
  {
    headerName: "Cheque Number",
    field: "cheque_number",
    align: "left"
  },
  {
    headerName: "Cheque Run Number",
    field: "cheque_run_number",
    align: "left"
  }
];

export default chequeProcessingDef;
