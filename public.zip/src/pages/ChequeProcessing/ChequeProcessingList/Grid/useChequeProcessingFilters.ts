import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { TColumnDef } from "@/components/GridTable/GridTable";
import { AppDispatch, useAppSelector } from "@/store/store";
import { IPaginationProps, ISelectedItem } from "@essnextgen/ui-kit";
import columnDef from "./columnDef";
import "react-datepicker/dist/react-datepicker.css";
import { getChequeProcessingList, actions as cpAction } from "../../state/ChequeProcessing.slice";
import { actions as cpStatusAction, getChequeProcessingStatus } from "../../state/ChequeProcessingStatus.slice";

const useChequeProcessingFilters = () => {
  const [sequenceIndex, setSequenceIndex] = useState<number>(1);
  const [lookingFor, setLookingFor] = useState<string>("");
  const [lookingForSearch, setLookingForSearch] = useState<boolean>(false);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const [columns, setColumn] = useState<TColumnDef>([...columnDef]);
  const dispatch = useDispatch<AppDispatch>();

  const { filterState, chequeList, status, selectedRow } = useAppSelector((state) => state.newChequeProcessingList);

  const { chequeProcessingStatus: chequeProcessingViews, selectedView } = useAppSelector((state) => state.chequeView);

  const handleSequenceChange = (value: React.SetStateAction<string>, sequenceNewIndex: number) => {
    const getRow = columns.find((row) => row.field === value);
    columns.splice(columns.indexOf(getRow!), 1); // delete
    columns.splice(0, 0, getRow!);
    setColumn([...columnDef]);
    setSequenceIndex(sequenceNewIndex);
    dispatch(cpAction.setColumnDef(columns));

    dispatch(
      cpAction.setFilters({
        lookingFor: "",
        sequence: sequenceNewIndex,
        sequenceValue: String(value),
        applyFilterChange: true
      })
    );
  };

  const onViewSelection = (e: React.SyntheticEvent, item: ISelectedItem) => {
    dispatch(cpStatusAction.setChequeProcessingView(item));
    lookingForChangehandler("");
    dispatch(cpAction.setFilters({ lookingFor: "", pageNumber: "1", status: item.value }));
    dispatch(
      getChequeProcessingList({
        ...filterState,
        lookingFor: "",
        pageNumber: "1",
        status: item.value,
        callback: (data) => dispatch(cpAction.setSelectedRow(data.data?.at(0)))
      })
    );
  };

  const onSequenceChange = (column: any, index: number) => {
    lookingForChangehandler("");
    handleSequenceChange(column.field, index);
  };

  const onAscendingSort = () => {
    lookingForChangehandler("");
    dispatch(
      cpAction.setFilters({
        lookingFor: "",
        orderBy: 0,
        applyFilterChange: true
      })
    );
  };

  const onDescendingSort = () => {
    lookingForChangehandler("");
    dispatch(
      cpAction.setFilters({
        lookingFor: "",
        orderBy: 1,
        applyFilterChange: true
      })
    );
  };

  const lookingForChangehandler = (value: string) => {
    dispatch(cpAction.setFindChequeNumber(false));
    const regex = /^\d+$/;
    if (regex.test(value) || filterState?.sequenceValue !== "payment_run_number") {
      setLookingForSearch(true);
      setLookingFor(value);
    }
  };

  const lookingForCallback = () => {
    if (lookingForSearch) {
      dispatch(cpAction.setFilters({ lookingFor, applyFilterChange: true }));
      setLookingForSearch(false);
    }
  };

  return {
    t,
    lookingFor,
    lookingForChangehandler,
    lookingForCallback,
    status,
    onDescendingSort,
    onAscendingSort,
    onSequenceChange,
    chequeProcessingViews,
    selectedView,
    onViewSelection,
    filterState
  };
};

export default useChequeProcessingFilters;
