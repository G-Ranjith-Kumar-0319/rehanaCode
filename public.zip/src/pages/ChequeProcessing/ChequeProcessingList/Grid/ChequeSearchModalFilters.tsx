import { Grid, GridItem } from "@essnextgen/ui-kit";
import React, { KeyboardEvent, useEffect, useState } from "react";
import { LookingFor } from "@/shared/components/LookingFor/LookingFor";
import { STATUS } from "@/types/UseStateType";
import useDebounce from "@/hooks/useDebounce";
import findNearest from "@/utils/nearestSearch";
import { useAppSelector } from "@/store/store";
import useChequeSearchModal from "../useChequeSearchModal";
import useChequeSearchModalFilter from "../useChequeSearchModalFilters";

type TLookingFor = {
  lookingForChangehandler: Function;
};

const ChequeSearchModalFilters = (props: TLookingFor) => {
  const { lookingForChangehandler } = props;

  const { lookingFor, status, filterState } = useChequeSearchModalFilter();
  const extraKey = ["Backspace", "Delete", "Tab"];

  const restrictSpecialChar = (e: KeyboardEvent<Element>) => {
    if (/^[a-zA-Z0-9\s]$/.test(e.key) === false && !extraKey.includes(e.key)) {
      e.preventDefault();
    }
  };

  return (
    <>
      <Grid
        className="custom-table"
        align="center"
        justify="space-between"
      >
        <GridItem xl={5}>
          <div className="essui-global-typography-default-h2 mr-l-4">
            <div className="looking-for">
              <LookingFor
                restrictInput={restrictSpecialChar}
                initialValue={lookingFor}
                callback={() => {}}
                changeHandler={lookingForChangehandler}
                hasDatePicker={false}
                disableDatePicker={filterState?.sequenceValue !== "run_date"}
                isInputReadOnly={status === STATUS.LOADING}
                className="essui-global-typography-default-h2 looking-for-container"
              />
            </div>
          </div>
        </GridItem>
      </Grid>
    </>
  );
};

export default ChequeSearchModalFilters;
