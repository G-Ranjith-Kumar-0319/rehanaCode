import { AppDispatch } from "@/store/store";
import { CHECK_PAYMENT_STATUS, specialCharacters } from "@/types/UseStateType";
import { Button, ButtonColor, ButtonSize } from "@essnextgen/ui-kit";
import { useDispatch } from "react-redux";
import { actions as cpActions } from "../../state/CheckProcessingList.slice";

const CustomCell = ({ field, row }: any) => {
  const dispatch = useDispatch<AppDispatch>();
  const numberFormatter = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const getContent = () => {
    if (field === "action") {
      return (
        <>
          <Button
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            className="small__white--btn"
            onClick={() => dispatch(cpActions.setCancelChequePayment(row))}
            disabled={
              !(
                row?.payment_status === CHECK_PAYMENT_STATUS.PAYMENT_STATUS_ONE ||
                (row?.payment_type === CHECK_PAYMENT_STATUS.PAYMENT_TYPE &&
                  row?.payment_status !== CHECK_PAYMENT_STATUS.PAYMENT_STATUS_TWO)
              )
            }
          >
            Cancel
          </Button>
        </>
      );
    }
    if (field === "amount") {
      const formattedAmount =
        row?.amount !== undefined && row?.amount !== null
          ? numberFormatter.format(row?.amount)
          : specialCharacters.zero;
      return <>{formattedAmount}</>;
    }
    return null;
  };
  return getContent();
};
export default CustomCell;
