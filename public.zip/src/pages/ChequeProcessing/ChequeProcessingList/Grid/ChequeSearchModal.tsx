import React from "react";
import GridTableNew from "@/components/GridTableNew/GridTableNew";
import findNearest from "@/utils/nearestSearch";
import Modal from "../../../../components/Modal/Modal";
import ChequeSearchModalFilters from "./ChequeSearchModalFilters";
import { ChequeSearchColumnDef } from "./columnDef";
import useChequeSearchModal from "../useChequeSearchModal";

type ChequeSearchPopupProps = {
  isOpen: boolean;
  setOpen: (isOpen: boolean) => void;
};

const ChequeSearchPopup: React.FC<ChequeSearchPopupProps> = ({ isOpen, setOpen }) => {
  const { t, chequeList, isListLoading, selectedRow, modalSelectedRow, closeHandler, handleSelectedRowChange } =
    useChequeSearchModal({ setOpen, isOpen });

  const lookingForChangehandler = (value: string) => {
    if (value !== "") {
      let found;
      found = [...chequeList]
        .filter((element) => (value ? element.toString()?.toUpperCase().startsWith(value!) : false))
        .at(0);

      if (found === undefined) {
        found = findNearest(
          [
            ...chequeList.map((c) => {
              if (c.cheque_number === null) {
                c.cheque_number = "";
              }
              return c;
            })
          ],
          [{ fieldName: "cheque_number", searchValue: value }],
          true
        );
      }

      if (found) {
        handleSelectedRowChange(found);
      }
    }
  };

  return (
    <Modal
      header={t("chequeProcessing.findChequeNo")}
      isOpen={isOpen}
      primaryBtnText={t("common.ok")}
      tertiaryBtnText={t("common.cancel")}
      primaryBtnClick={closeHandler}
      onClose={() => {
        setOpen(false);
      }}
      className="cheque-modal"
    >
      <div className="cheque-table">
        <GridTableNew
          dataTestId="chequeTableId"
          filters={<ChequeSearchModalFilters lookingForChangehandler={lookingForChangehandler} />}
          dataSource={chequeList as any}
          columnDef={ChequeSearchColumnDef}
          selectedRow={selectedRow}
          selectedRowHandler={handleSelectedRowChange}
          isLoading={isListLoading}
          className={chequeList.length ? "" : ""}
          isScrollable
          enableScrollIntoView
        />
      </div>
    </Modal>
  );
};

export default ChequeSearchPopup;
