import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { getChequePaymentRun } from "../../state/ChequePaymentRun.slice";

/* eslint-disable import/prefer-default-export */
export const useChequeProcessingToolBar = () => {
  const history = useHistory();
  const dispatch = useDispatch<AppDispatch>();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { chequePaymentRun } = useAppSelector(({ chequePaymentRun }) => chequePaymentRun);
  const { data } = useAppSelector(({ newChequeProcessingList }) => newChequeProcessingList?.chequeList);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState<boolean>(false);
  const [paymentRunNumberAlert, setPaymentRunNumberAlert] = useState<string>("");

  const goToAdd = () => {
    if (chequePaymentRun.length === 0) {
      history.push("/cheque-processing/add-cheque-run");
    } else {
      setIsAlertModalOpen(true);
    }
  };

  useEffect(() => {
    dispatch(getChequePaymentRun());
  }, []);

  return {
    t,
    goToAdd,
    isAlertModalOpen,
    setIsAlertModalOpen,
    chequePaymentRun
  };
};
