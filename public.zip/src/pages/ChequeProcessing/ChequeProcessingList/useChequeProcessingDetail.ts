import { AppDispatch, useAppSelector } from "@/store/store";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { useHistory, useLocation, useParams } from "react-router-dom";
import { STATUS } from "@/types/UseStateType";
import { actions as cplAction, getChequeProcessingDetailData } from "../state/CheckProcessingList.slice";
import { actions as cpAction, getChequeProcessingList } from "../state/ChequeProcessing.slice";

const useChequeDetail = () => {
  const { paymentRunId } = useParams<{ paymentRunId: string }>();
  const [cheque, setCheque] = useState();
  const [isYesClicked, setIsYesClicked] = useState(false);
  const [PaymentRunNumber, setPaymentRunNumber] = useState<any>("");
  const [printedDate, setPrintedDate] = useState();
  const [cancelledOn, setCancelledOn] = useState();
  const [enableCancel, setEnableCancel] = useState(true);
  const [zeroPayReport, setDisableZeroPayReport] = useState(true);
  const [checkRunReport, setEnableCheckRunReport] = useState(false);
  const dispatch = useDispatch<AppDispatch>();
  const history = useHistory();
  const state = history.location.state as any;
  const location = useLocation();
  const { bankid, bankStatementId } = useParams<{ bankid: string; bankStatementId: any }>();
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const { chequePayments, chequePaymentDetails, firstTableStatus, detailStatus } = useAppSelector(
    (state: any) => state.chequeProcessingList
  );

  const { filterState, selectedRow } = useAppSelector((state) => state.newChequeProcessingList);

  const { data, currentPage, totalPages, pageSize } = useAppSelector(
    ({ newChequeProcessingList }) => newChequeProcessingList?.chequeList
  );

  useEffect(() => {
    if (selectedRow) {
      setPaymentRunNumber(selectedRow?.payment_run_number);
    }
  }, [selectedRow]);

  const getBankReconUrl = () => {
    const wordsToSearch = ["cheque-payment", "debit-payment", "bacs-payment"];
    const foundWord = wordsToSearch.find((word) => location.pathname.includes(word));
    let bankReconUrl = "";
    if (foundWord) {
      switch (foundWord) {
        case "cheque-payment":
          bankReconUrl = `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}/cheque-payment`;
          break;
        case "debit-payment":
          bankReconUrl = `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}/debit-payment`;
          break;
        case "bacs-payment":
          bankReconUrl = `/general-ledger/bank-reconciliation/save-bank-statement/view-bank-details/bankid/${bankid}/bankStatementId/${bankStatementId}/bacs-payment`;
          break;
        default:
          break;
      }
    }
    return bankReconUrl;
  };

  const redirectToViewPage = (row: any) => {
    const bankReconUrl = getBankReconUrl();
    let navUrl = "";
    if (row?.item_type === "Invoice" && row?.order_id === null) {
      navUrl = `${bankReconUrl}/cheque-processing/cheque-processing-detail/${paymentRunId}/invoice-credit-note/nonorder-invoice/invoiceId/${row?.invoice_id}`;
    } else if (row?.item_type === "Invoice" && row?.order_id !== null) {
      navUrl = `${bankReconUrl}/cheque-processing/cheque-processing-detail/${paymentRunId}/invoice-credit-note/order-invoice/orderno/${row?.order_id}/invoiceId/${row?.invoice_id}`;
    } else if (row?.item_type === "Credit Note") {
      navUrl = `${bankReconUrl}/cheque-processing/cheque-processing-detail/${paymentRunId}/invoice-credit-note/credite-note/invoiceId/${row?.invoice_id}`;
    } else {
      navUrl = `${bankReconUrl}/cheque-processing/cheque-processing-detail/${paymentRunId}/invoice-credit-note/sundry-invoice/invoiceId/${row?.invoice_id}`;
    }
    history.push(navUrl, { ...state });
  };

  const selectedRowHandler = (row: any) => {
    if (row && Object.keys(chequePayments).length > 0) {
      const isPaymentIdInChequePayments = chequePayments.some((payment: any) => payment.payment_id === row.payment_id);
      if (isPaymentIdInChequePayments) {
        dispatch(getChequeProcessingDetailData({ payemntId: row?.payment_id }));
        setCheque(row?.cheque_number);
        setPrintedDate(row?.printed_on_date);
        setCancelledOn(row?.cancelled_on);

        if (row.payment_type === "Z" && row.payment_status === "F") {
          setDisableZeroPayReport(false);
        } else {
          setDisableZeroPayReport(true);
        }
        if (row.payment_type === "Z" || (row.payment_status === "B" && row.payment_status !== "C")) {
          setEnableCancel(false);
        }
        if (row.payment_id) {
          setEnableCheckRunReport(false);
        } else {
          setEnableCheckRunReport(true);
        }
        dispatch(cplAction.setSelectedRow(row));
      }
    }
  };

  const onChangeHandler = (page: any) => {
    dispatch(
      cpAction.setFilters({
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: ""
      })
    );
    dispatch(
      getChequeProcessingList({
        ...filterState,
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: "",
        callback: (data) => {
          const row = data.data?.at(0);
          dispatch(cpAction.setSelectedRow(row));
          history.push(
            `/cheque-processing/cheque-processing-detail/${row?.payment_run_id ? row?.payment_run_id : "0"}`
          );
        }
      })
    );
  };

  const onChangePrevRecord = (page: any) => {
    dispatch(
      cpAction.setFilters({
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: ""
      })
    );
    dispatch(
      getChequeProcessingList({
        ...filterState,
        pageNumber: page,
        pageSize: String(pageSize),
        lookingFor: "",
        callback: (data) => {
          const row = data.data?.at(data.data?.length - 1);
          dispatch(cpAction.setSelectedRow(row));
          history.push(
            `/cheque-processing/cheque-processing-detail/${row?.payment_run_id ? row?.payment_run_id : "0"}`
          );
        }
      })
    );
  };

  const selectPrevRecord = () => {
    if (selectedRow && data) {
      const indexNo = data.indexOf(selectedRow);
      if (indexNo > 0) {
        const row = data[indexNo - 1];
        dispatch(cpAction.setSelectedRow(data[indexNo - 1]));
        history.push(`/cheque-processing/cheque-processing-detail/${row?.payment_run_id ? row?.payment_run_id : "0"}`);
      } else if (currentPage > 1) {
        onChangePrevRecord(currentPage - 1);
      }
    }
  };
  const selectNextRecord = () => {
    if (selectedRow && data) {
      const indexNo = data.indexOf(selectedRow);
      if (indexNo < 9) {
        const row = data[indexNo + 1];
        dispatch(cpAction.setSelectedRow(data[indexNo + 1]));
        history.push(`/cheque-processing/cheque-processing-detail/${row?.payment_run_id ? row?.payment_run_id : "0"}`);
      } else if (currentPage < totalPages) {
        onChangeHandler(currentPage + 1);
      }
    }
  };

  return {
    t,
    redirectToViewPage,
    selectedRowHandler,
    selectPrevRecord,
    selectNextRecord,
    PaymentRunNumber,
    setPaymentRunNumber,
    chequePayments,
    cancelledOn,
    cheque,
    printedDate,
    detailStatus,
    chequePaymentDetails,
    firstTableStatus,
    zeroPayReport,
    setDisableZeroPayReport,
    enableCancel,
    checkRunReport,
    paymentRunId,
    isYesClicked,
    setIsYesClicked
  };
};

export default useChequeDetail;
