import { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { useAppSelector } from "@/store/store";
import findNearest from "@/utils/nearestSearch";
import { actions as checkSearchAtions } from "../state/ChequeProcessing.slice";
import useChequeProcessingFilters from "./Grid/useChequeProcessingFilters";

const useChequeSearchModalFilter = () => {
  const { chequereferenceList } = useAppSelector((state) => state.newChequeProcessingList);
  const { t, lookingFor, lookingForChangehandler, lookingForCallback, status, filterState } =
    useChequeProcessingFilters();

  const dispatch = useDispatch();
  useEffect(() => {
    if (lookingFor !== "" && chequereferenceList && chequereferenceList.chequeReferences.length) {
      let found;
      found = [...chequereferenceList.chequeReferences]
        .filter((element) =>
          lookingFor ? element.cheque_reference.toString()?.toUpperCase().startsWith(lookingFor!) : false
        )
        .at(0);
      if (found && found !== undefined) dispatch(checkSearchAtions.setModalSelectedRow(found!));

      if (found === undefined) {
        found = findNearest(
          [...chequereferenceList.chequeReferences],
          [
            { fieldName: "cheque_run_number", searchValue: lookingFor },
            { fieldName: "cheque_number", searchValue: lookingFor }
          ],
          true
        );
        dispatch(checkSearchAtions.setModalSelectedRow(found!));
      }
      const element = document.getElementById(`rowIndex-${chequereferenceList.chequeReferences.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [lookingFor]);

  useEffect(() => {
    dispatch(checkSearchAtions.setModalSelectedRow(chequereferenceList ? chequereferenceList.chequeReferences[0] : {}));
  }, [chequereferenceList.chequeReferences]);

  return {
    lookingFor,
    lookingForChangehandler,
    lookingForCallback,
    status,
    filterState
  };
};

export default useChequeSearchModalFilter;
