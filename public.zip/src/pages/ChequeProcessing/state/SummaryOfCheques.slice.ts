import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";
import { ca } from "date-fns/locale";

export type TGetPayeeDetailsParams = {
  uniqueId: string[];
  callback?: (response: any) => void;
};
export type TPrintDocumentsParams = {
  bankId: number;
  narration: string;
  period: string;
  uniqueId: string[];
  chequePrintData: {
    payeeName: string;
    chequeNo: string;
    bookId: string;
    amount: string;
    payeeId: number;
    clientId: number;
  }[];
  callback?: (response: any) => void;
};
export type TSummaryOfChequesState = {
  error: string | undefined;
  status?: STATUS;
  zeroPaymentstatus?: STATUS;
  chequePayeeDetails: { [key: string]: any }[];
  pdfByteArrayData: { [key: string]: any };
  zeroPayFailureResp: { [key: string]: any }[];
  zeroPayResp: { [key: string]: any }[];
  confirmRunResp: { [key: string]: any }[];
};

const initialState: TSummaryOfChequesState = {
  error: "",
  chequePayeeDetails: [],
  pdfByteArrayData: [],
  zeroPayFailureResp: [],
  zeroPayResp: [],
  confirmRunResp: []
};

/** Thunks */
export const getPayeeDetails = createAsyncThunk(
  "chequeProcessing/getPayeeDetails",
  async ({ uniqueId, callback }: TGetPayeeDetailsParams) => {
    const response = await client.post(`${apiRoot}/Cheques/get-payee-details`, {
      uniqueId
    });
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);
export const printPdfDocument = createAsyncThunk(
  "document/cheque-print",
  async ({ bankId, narration, period, uniqueId, chequePrintData, callback }: TPrintDocumentsParams) => {
    const response = await client.post(`${apiRoot}/document/cheque-print`, {
      bankId,
      narration,
      period,
      uniqueId,
      chequePrintData
    });
    if (callback) {
      callback(response.data);
    }
    // if (response.status === 200 && callback) {
    //   callback(response.data);
    // }
    return response.data;
  }
);

export const zeroPaymentFailure = createAsyncThunk(
  "document/zero-payment-failure",
  async ({ bankId, narration, period, uniqueId, chequePrintData, callback }: TPrintDocumentsParams) => {
    const response = await client.post(`${apiRoot}/document/Zero-payment-Failure`, {
      bankId,
      narration,
      period,
      uniqueId,
      chequePrintData
    });
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getChequeZeroRunReport = createAsyncThunk(
  "document/cheque-zero-run-report",
  async ({ paymentRunId, callback }: { paymentRunId: any; callback: (data: any) => void }) => {
    const response = await client.get(
      `${apiRoot}/document/cheque-zero-run-report?paymentId=0&?paymentRunId=${paymentRunId}`
    );
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const getChequeZeroPayConfirm = createAsyncThunk(
  "Cheques/zero-pay-confirm",
  async ({ paymentRunId, callback }: any) => {
    const response = await client.get(`${apiRoot}/Cheques/zero-pay-confirm?paymentRunId=${paymentRunId}`);
    if (response.status === 200) {
      callback();
    }
    return response.data;
  }
);
export const getChequeConfirmRun = createAsyncThunk("Cheques/confirm-run", async ({ paymentRunId, callback }: any) => {
  const response = await client.get(`${apiRoot}/Cheques/confirm-run?paymentRunId=${paymentRunId}`);
  if (response.status === 200) {
    callback();
  }
  return response.data;
});

const slice = createSlice({
  initialState,
  name: "summaryOfCheques",
  extraReducers: (builder) => {
    /** Cheque Processing List */
    builder
      .addCase(getPayeeDetails.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getPayeeDetails.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.chequePayeeDetails = action.payload;
      })
      .addCase(getPayeeDetails.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(printPdfDocument.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(printPdfDocument.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.pdfByteArrayData = action.payload;
      })
      .addCase(printPdfDocument.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(zeroPaymentFailure.pending, (state) => {
        state.zeroPaymentstatus = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(zeroPaymentFailure.fulfilled, (state, action: PayloadAction<any>) => {
        state.zeroPaymentstatus = STATUS.SUCCESS;
        state.zeroPayFailureResp = action.payload;
      })
      .addCase(zeroPaymentFailure.rejected, (state) => {
        state.zeroPaymentstatus = STATUS.FAILED;
      });
    builder
      .addCase(getChequeZeroPayConfirm.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeZeroPayConfirm.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.zeroPayResp = action.payload;
      })
      .addCase(getChequeZeroPayConfirm.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
    builder
      .addCase(getChequeConfirmRun.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeConfirmRun.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.confirmRunResp = action.payload;
      })
      .addCase(getChequeConfirmRun.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {
    resetPDFData: (state) => {
      state.pdfByteArrayData = [];
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
