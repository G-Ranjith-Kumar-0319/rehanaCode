import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";

export type TChequePaymentRunState = {
  error: string | undefined;
  status?: STATUS;
  chequePaymentRun: { [key: string]: any }[];
};

const initialState: TChequePaymentRunState = {
  error: "",
  chequePaymentRun: []
};

/** Thunks */
export const getChequePaymentRun = createAsyncThunk("chequeProcessing/getChequePaymentRun", async () => {
  const response = await client.get(`${apiRoot}/Cheques/cheque-paymentRun`);
  return response.data;
});

const slice = createSlice({
  initialState,
  name: "chequePaymentRun",
  extraReducers: (builder) => {
    /** Cheque Processing List */
    builder
      .addCase(getChequePaymentRun.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequePaymentRun.fulfilled, (state, action: PayloadAction<any>) => {
        state.status = STATUS.SUCCESS;
        state.chequePaymentRun = action.payload;
      })
      .addCase(getChequePaymentRun.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {}
});

export const { actions, reducer } = slice;
export default reducer;
