import { createSlice, createAsyncThunk, PayloadAction, current } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";

export type TChequeBookParams = {
  bankId: number;
  callback?: (response: any) => void;
};

export type TChequeBookState = {
  error: string | undefined;
  status?: STATUS;
  chequeBooks: { [key: string]: any }[];
  availableChequeBooks: { [key: string]: any }[];
  tobeUsedChequeBooks: { [key: string]: any }[];
  availableChequeBookSelectedRow?: { [key: string]: any };
  tobeUsedChequeBookSelectedRow?: { [key: string]: any };
};

const initialState: TChequeBookState = {
  error: "",
  chequeBooks: [],
  availableChequeBooks: [],
  tobeUsedChequeBooks: []
};

/** Thunks */
export const getChequeBooks = createAsyncThunk(
  "chequeProcessing/chequebooks",
  async ({ bankId, callback }: TChequeBookParams) => {
    const response = await client.get(`${apiRoot}/Cheques/cheque-books/${bankId}`);
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

const slice = createSlice({
  initialState,
  name: "availableChequeBooks",
  extraReducers: (builder) => {
    /** Cheque Processing List */
    builder
      .addCase(getChequeBooks.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeBooks.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequeBooks = action.payload;
        state.availableChequeBooks = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getChequeBooks.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {
    setAvailableChequeBookSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.availableChequeBookSelectedRow = action.payload;
    },
    resetAvailableChequeBookSelectedRow: (state) => {
      state.availableChequeBookSelectedRow = state.availableChequeBooks.length
        ? state.availableChequeBooks.at(0)
        : undefined;
    },
    setTobeUsedChequeBookSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.tobeUsedChequeBookSelectedRow = action.payload;
    },
    resetTobeUsedChequeBookSelectedRow: (state) => {
      const totalLength = state.tobeUsedChequeBooks.length;
      state.tobeUsedChequeBookSelectedRow = totalLength ? state.tobeUsedChequeBooks.at(totalLength - 1) : undefined;
    },
    setTobeUsedChequeBooks: (state, action: PayloadAction<{ [key: string]: any }>) => {
      state.tobeUsedChequeBooks.push(action.payload);
    },
    resetTobeUsedChequeBooks: (state) => {
      state.tobeUsedChequeBooks = [];
    },
    setAvailableChequeBooks: (state, action: PayloadAction<{ [key: string]: any }>) => {
      state.availableChequeBooks.push(action.payload);
    },
    resetAvailableChequeBooks: (state) => {
      state.availableChequeBooks = [];
    },
    removeFromAvailableChequeBooks: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const index = current(state.availableChequeBooks).findIndex(
        (row: { [key: string]: any }) => row.book_id === action.payload.book_id
      );
      if (index > -1) {
        // only splice array when item is found
        state.availableChequeBooks.splice(index, 1); // 2nd parameter means remove one item only
      }
    },
    removeFromTobeUsedChequeBooks: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const index = current(state.tobeUsedChequeBooks).findIndex(
        (row: { [key: string]: any }) => row.book_id === action.payload.book_id
      );
      if (index > -1) {
        // only splice array when item is found
        state.tobeUsedChequeBooks.splice(index, 1); // 2nd parameter means remove one item only
      }
    },
    shiftTobeUsedChequeBooks: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const { oldIndex, newIndex, chequeBook } = action.payload;

      const replacedChequeBook = state.tobeUsedChequeBooks.splice(newIndex, 1, chequeBook);
      state.tobeUsedChequeBooks.splice(oldIndex, 1, replacedChequeBook[0]);
    },
    replaceTobeUsedChequeBooks: (state, action: PayloadAction<{ [key: string]: any }>) => {
      const { index, row } = action.payload;
      state.tobeUsedChequeBooks.splice(index, 1, row);
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
