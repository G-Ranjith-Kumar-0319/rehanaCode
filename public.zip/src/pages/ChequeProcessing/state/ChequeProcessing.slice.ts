import { createSlice, createAsyncThunk, PayloadAction, current, createAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "@/config";
import { TColumnDef } from "@/components/GridTable/GridTable";
import columnDef from "../ChequeProcessingList/Grid/columnDef";

export type ChequeProcessingListType = { [key: string]: any }[];

export type TCheques = {
  data: ChequeProcessingListType;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: string;
  lookingFor?: string | undefined;
  orderBy?: number;
  sequence?: number;
};

type TfindChecque = {
  chequeReferences: { [key: string]: any }[];
};
type TgetChequeDetail = {
  pageNumber?: string;
  pageSize?: string;
  view?: string;
  orderBy?: number;
  sequence?: number;
  status?: string;
  skip?: string;
  lookingFor?: string | undefined;
  highlightId?: number;
  sequenceValue?: string;
  applyFilterChange?: boolean;
  modalSelectedRow?: any;
};

type ChequeDetailStateType = {
  selectedRow?: { [key: string]: any };
  checkedRows: { [key: string]: any }[];
  columnDef: TColumnDef;
  filterState?: TgetChequeDetail;
  chequeList: TCheques;
  error: string | undefined;
  applyFilterChange?: boolean;
  status?: STATUS;
  pageStatus?: STATUS;
  isFocus?: boolean;
  isFindCheque?: boolean;
  modalSelectedRow?: any;
  chequereferenceList: TfindChecque;
};

const initialState: ChequeDetailStateType = {
  chequereferenceList: {
    chequeReferences: []
  },
  selectedRow: undefined,
  checkedRows: [],
  filterState: {
    pageNumber: "1",
    pageSize: "10",
    orderBy: 1,
    sequence: 0,
    status: "A",
    skip: "",
    lookingFor: "",
    highlightId: 0,
    applyFilterChange: true,
    sequenceValue: columnDef.filter((col) => !!col.sequence)[0].field
  },
  modalSelectedRow: null,
  isFindCheque: false,
  columnDef,
  chequeList: {
    data: [],
    currentPage: 1,
    totalCount: "",
    pageSize: 10,
    totalPages: 0,
    lookingFor: ""
  },
  error: "",
  isFocus: false
};

/** Thunks */
export const getChequeProcessingList = createAsyncThunk(
  "chequeProcessing/list",
  async ({
    pageSize,
    pageNumber,
    orderBy,
    sequence,
    status,
    skip,
    lookingFor,
    highlightId,
    callback
  }: TgetChequeDetail & { callback?: (response: any) => void }) => {
    const response = await client.post(
      `${apiRoot}/Cheques?PageNumber=${pageNumber}&Skip=${skip}&PageSize=${pageSize}`,
      {
        orderBy: Number(orderBy),
        sequence,
        status,
        lookingFor,
        paymentRunId: highlightId,
        pageNumber,
        pageSize
      }
    );
    if (response.status === 200 && callback) {
      callback(response.data);
    }
    return response.data;
  }
);

export const searchCheques = createAsyncThunk("cheques/search", async (term: string) => {
  const response = await client.get(`${apiRoot}/Cheques/FilterByCheque`);
  return response.data;
});

/**
 * # Cheque Processing Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  initialState,
  name: "newChequeProcessingList",
  extraReducers: (builder) => {
    /** Cheque Processing List */
    builder
      .addCase(getChequeProcessingList.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeProcessingList.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequeList = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getChequeProcessingList.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  reducers: {
    unCheckAll: (state) => {
      state.checkedRows = [];
    },
    checkAll: (state) => {
      const poList = current(state.chequeList?.data);
      state.checkedRows = [...poList];
    },
    setSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.selectedRow = action.payload;
    },
    setModalSelectedRow: (state, action: PayloadAction<{ [key: string]: any } | undefined>) => {
      state.modalSelectedRow = action.payload;
    },
    setColumnDef: (state, action: PayloadAction<TColumnDef>) => {
      state.columnDef = [...action.payload];
    },
    setFilters: (state, action: PayloadAction<TgetChequeDetail>) => {
      state.filterState = {
        ...current(state.filterState),
        ...action.payload
      };
    },
    resetFilters: (state) => {
      state.filterState = {
        ...initialState.filterState
      };
    },
    setFocus: (state) => {
      state.isFocus = true;
    },
    resetFocus: (state) => {
      state.isFocus = false;
    },
    setFindChequeNumber: (state, action: PayloadAction<any>) => {
      state.isFindCheque = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
