import { ISelectedItem } from "@essnextgen/ui-kit";
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { STATUS } from "@/types/UseStateType";
import { apiRoot, client } from "../../../config";

type chequeProcessingState = {
  chequeProcessingStatus: { [key: string]: any }[];
  error: string | undefined;
  status?: STATUS;
  selectedView: ISelectedItem;
};

const initialState: chequeProcessingState = {
  chequeProcessingStatus: [],
  selectedView: {
    text: "",
    value: "A"
  },
  error: ""
};

/** Thunks */
export const getChequeProcessingStatus = createAsyncThunk(
  "Cheques/Status",
  async ({ callback }: { callback?: (data: any) => void }) => {
    const response = await client.get(`${apiRoot}/Cheques/view-status`);
    if (callback) {
      callback(response.data);
    }
    return response.data;
  }
);

/**
 * # Cheque Processing Status Slice
 * This slice of state is responsible for storing authentication state
 */
const slice = createSlice({
  extraReducers: (builder) => {
    builder
      .addCase(getChequeProcessingStatus.pending, (state) => {
        state.status = STATUS.LOADING;
        state.error = undefined;
      })
      .addCase(getChequeProcessingStatus.fulfilled, (state, action: PayloadAction<any>) => {
        state.chequeProcessingStatus = action.payload;
        state.status = STATUS.SUCCESS;
      })
      .addCase(getChequeProcessingStatus.rejected, (state) => {
        state.status = STATUS.FAILED;
      });
  },
  initialState,
  name: "chequeProcessingStatus",
  reducers: {
    setChequeProcessingView: (state, action: PayloadAction<any>) => {
      state.selectedView = action.payload;
    }
  }
});

export const { actions, reducer } = slice;
export default reducer;
