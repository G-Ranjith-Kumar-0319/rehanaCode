import { usNumberFormat } from "@/utils/getDataSource";

const CustomCell = ({ field, row }: any) => {
  const getContent = () => {
    switch (field) {
      case "amount":
        return <>{usNumberFormat(row?.amount)}</>;
      default: {
        return <div />;
      }
    }
  };
  return getContent();
};
export default CustomCell;
