import GridTableNew from "@/components/GridTableNew/GridTableNew";
import Input from "@/components/Input/Input";
import "./Style.scss";
import Layout from "@/components/Layout/Layout";
import {
  Button,
  ButtonColor,
  ButtonSize,
  CheckBox,
  DateInput,
  Divider,
  Dropdown,
  DropdownItem,
  FormLabel,
  Grid,
  GridItem,
  Icon,
  IconColor,
  IconSize,
  ISelectedItem,
  Pagination,
  RadioButton,
  RadioLabelPosition,
  TextInput,
  ValidationTextLevel
} from "@essnextgen/ui-kit";

const AddChequeRun1 = () => (
  <>
    <Layout pageTitle="Add Cheque Run">
      <Grid
        container
        className="marginT10"
      >
        <GridItem
          sm={12}
          md={3}
          lg={3}
          xl={3}
        >
          <div className="">
            <FormLabel>Select bank account to print cheques from: </FormLabel>
            <Input
              button={
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="essui-button-icon-only--small"
                >
                  <Icon
                    color={IconColor.Primary500}
                    size={IconSize.Medium}
                    name="search"
                  />
                </Button>
              }
              searchable
              value="Bank Account"
            />
          </div>
        </GridItem>
        <GridItem
          sm={12}
          md={2}
          lg={2}
          xl={2}
        >
          <div>
            <FormLabel>Account No.</FormLabel>
            <TextInput
              className="playmodetxt"
              dataTestId="txtName"
              value="01177112"
            />
          </div>
        </GridItem>
        <GridItem
          sm={12}
          md={2}
          lg={2}
          xl={2}
        >
          <div>
            <FormLabel>Sort Code</FormLabel>
            <TextInput
              className="playmodetxt"
              dataTestId="txtName"
              value="20-40-29"
            />
          </div>
        </GridItem>
      </Grid>
      <Divider />
      <Grid
        container
        className="margint10"
      >
        <GridItem sm={4}>
          <div className="essui-global-typography-default-subtitle">BACS</div>
        </GridItem>
      </Grid>
      <Divider />
      <Grid
        container
        className="margint10"
      >
        <GridItem
          sm={12}
          md={4}
          lg={4}
          xl={4}
        >
          <div>
            <FormLabel>By Amount</FormLabel>
            <div className="sequence">
              <div className="essui-textinput sequence-fields">
                <RadioButton
                  label="All"
                  labelPosition={RadioLabelPosition.Right}
                  value={0}
                />
                <RadioButton
                  label="Greater Than"
                  labelPosition={RadioLabelPosition.Right}
                  value={1}
                  isSelected
                />
                <RadioButton
                  label="Less Than"
                  labelPosition={RadioLabelPosition.Right}
                  value={1}
                />
              </div>
            </div>
          </div>
        </GridItem>

        <GridItem
          sm={12}
          md={4}
          lg={5}
          xl={5}
        >
          <div className="padding-top16">
            <FormLabel> </FormLabel>
            <TextInput
              className="w-100"
              value="1st Glass"
            />
          </div>
        </GridItem>
      </Grid>

      <Grid container>
        <GridItem
          sm={4}
          md={3}
          lg={2}
          xl={2}
        >
          <div>
            <FormLabel>By Pay By Date</FormLabel>
            <div className="sequence">
              <div className="essui-textinput sequence-fields">
                <RadioButton
                  label="All"
                  labelPosition={RadioLabelPosition.Right}
                  value={0}
                />
                <RadioButton
                  label="Specific"
                  labelPosition={RadioLabelPosition.Right}
                  value={1}
                  isSelected
                />
              </div>
            </div>
          </div>
        </GridItem>
      </Grid>

      <Grid container>
        <GridItem
          sm={2}
          md={1}
          lg={1}
          xl={1}
        >
          <div className="midchkbox2">
            <CheckBox label="Not" />
          </div>
        </GridItem>
        <GridItem
          sm={12}
          md={3}
          lg={3}
          xl={3}
        >
          <div className="">
            <Dropdown
              className="w-100"
              placeholderText="Between"
            >
              <DropdownItem
                id="1"
                text="Menu Item 1"
                value="1"
              >
                Menu Item 1
              </DropdownItem>
              <DropdownItem
                id="2"
                text="Menu Item 2"
                value="2"
              >
                Menu Item 2
              </DropdownItem>
              <DropdownItem
                id="3"
                text="Menu Item 3"
                value="3"
              >
                Menu Item 3
              </DropdownItem>
            </Dropdown>
          </div>
        </GridItem>
        <GridItem
          sm={12}
          md={4}
          lg={2}
          xl={3}
        >
          <div className=" datelable">
            <Input
              value="10/04/2024"
              button={
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="essui-button-icon-only--small"
                >
                  <Icon
                    color={IconColor.Primary500}
                    size={IconSize.Medium}
                    name="calendar"
                  />
                </Button>
              }
              searchable
            />
            <FormLabel className="andp-t16px">and</FormLabel>
          </div>
        </GridItem>
        <GridItem
          sm={12}
          md={4}
          lg={2}
          xl={2}
        >
          <div className="">
            <Input
              value="10/04/2024"
              button={
                <Button
                  size={ButtonSize.Small}
                  color={ButtonColor.Secondary}
                  className="essui-button-icon-only--small"
                >
                  <Icon
                    color={IconColor.Primary500}
                    size={IconSize.Medium}
                    name="calendar"
                  />
                </Button>
              }
              searchable
            />
          </div>
        </GridItem>
      </Grid>
      <Grid
        container
        className="marginT10"
      >
        <GridItem
          sm={12}
          md={4}
          lg={6}
          xl={6}
        >
          <div>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Tertiary}
            >
              Help
            </Button>
          </div>
        </GridItem>
        <GridItem
          sm={12}
          md={4}
          lg={6}
          xl={6}
        >
          <div className="rightbtn">
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Primary}
            >
              Tag
            </Button>
            <Button
              size={ButtonSize.Small}
              color={ButtonColor.Secondary}
            >
              Cancel
            </Button>
          </div>
        </GridItem>
      </Grid>
    </Layout>
  </>
);
export default AddChequeRun1;
