import React, { useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useForm } from "react-hook-form";

import { ISelectedItem } from "@essnextgen/ui-kit";

import { AppDispatch, useAppSelector } from "@/store/store";
import { FMSSessionStorage } from "@/utils/Storage";
import { useTranslation, UseTranslationResponse } from "@essnextgen/ui-intl-kit";
import { actions, actions as periodActions } from "@/pages/Invoice/State/InvoicePostingPeriod.slice";
import { getCurrentDate, getDefaultPaymentPeriod } from "@/store/state/defaultYear.slice";
import { actions as bankActions, getBankAccountAll } from "@/shared/components/BankAccount/state/BankAccount.slice";
import { apiRoot } from "@/config";
import { actions as ItPayment } from "../state/ItemsPayment.slice";
import { actions as chequeBookActions, getChequeBooks } from "../state/AddChequeRun.slice";
import { CHEQUE_PROCESSING_CHEQUE_RUN, CHEQUE_PROCESSING_STORAGE_KEY } from "../constants";

type FormData = {
  bankAccount: string;
  accountNo: string;
  sortCode: string;
  nextChequeNumber: string;
  paymentPeriod: string;
  paymentDescription: string;
  chequeRunNarrative: string;
};

/* eslint-disable import/prefer-default-export */
export const useAddChequeRun = () => {
  const history = useHistory();
  const { t, i18n }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const { bankAccounts, selectedBankAccount } = useAppSelector(({ bankAccount }) => bankAccount);
  const { availableChequeBooks, tobeUsedChequeBooks, availableChequeBookSelectedRow, tobeUsedChequeBookSelectedRow } =
    useAppSelector(({ availableChequeBooks }) => availableChequeBooks);
  const { postingPeriodDetails } = useAppSelector((state) => state.invoicePostingPeriod);
  const { defaultPeriod } = useAppSelector(({ defaultPeriod }) => defaultPeriod);
  const { clientId, payeeId } = useParams<{ clientId: string; payeeId: string }>();
  const [showBankAccountModal, setShowBankAccountModal] = useState<boolean>(false);
  const [paymentPeriod, setPaymentPeriod] = useState<boolean>(false);
  const [showPostingPeriodModal, setShowPostingPeriodModal] = useState<boolean>(false);
  const [postingPeriodSelectedRow, setPostingPeriodSelectedRow] = useState<any>(undefined);
  const [isDisabled, setIsDisabled] = useState<boolean>(true);
  const [showEmptyChequeBookModal, setShowEmptyChequeBookModal] = useState<boolean>(false);
  const [openKeepChangeModal, setOpenKeepChangeModal] = useState<boolean>(false);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");

  const {
    register,
    reset,
    setError,
    handleSubmit,
    formState: { errors },
    getValues,
    setValue,
    trigger,
    clearErrors
  } = useForm<FormData>({
    shouldFocusError: false
  });

  useEffect(() => {
    dispatch(ItPayment.setCheckedPaymentItems([]));
    dispatch(ItPayment.unCheckAll());
    // eslint-disable-next-line consistent-return
    const unblock = history.block((location, action) => {
      if (location.pathname === "/cheque-processing" && !(location.state as any)?.moveToListingPage) {
        setOpenKeepChangeModal(true);
        return false;
      }
    });
    return () => unblock();
  }, []);

  useEffect(() => {
    dispatch(
      getBankAccountAll({
        callback: (bankAccounts) => {
          dispatch(chequeBookActions.resetAvailableChequeBooks());
          dispatch(chequeBookActions.resetTobeUsedChequeBooks());
          dispatch(chequeBookActions.resetTobeUsedChequeBookSelectedRow());
          if (bankAccounts.length === 1) {
            setBankAccountDetails(bankAccounts[0]);
          }
        }
      })
    );
  }, []);

  useEffect(() => {
    const historyState = history?.location?.state as any;

    if (bankAccounts) {
      const bankAccount = historyState?.bankAccount;
      const found = bankAccounts.find((row) => row?.bank_id === bankAccount?.bank_id);
      if (found) {
        setBankAccountDetails(found, false);
        dispatch(bankActions.selectBankAccountRow(bankAccount));
      }
    }

    const availableChequeBooks = historyState?.availableChequeBooks;
    dispatch(chequeBookActions.resetAvailableChequeBooks());
    if (availableChequeBooks && availableChequeBooks.length) {
      availableChequeBooks.forEach((book: { [key: string]: any }) =>
        dispatch(chequeBookActions.setAvailableChequeBooks(book))
      );
    }

    setTimeout(() => {
      const tobeUsedChequeBooks = historyState?.tobeUsedChequeBooks;
      console.log("tobeUsedChequeBooks", tobeUsedChequeBooks);
      dispatch(chequeBookActions.resetTobeUsedChequeBooks());
      if (tobeUsedChequeBooks && tobeUsedChequeBooks.length) {
        tobeUsedChequeBooks.forEach((book: { [key: string]: any }) =>
          dispatch(chequeBookActions.setTobeUsedChequeBooks(book))
        );
      }
    }, 0);

    setTimeout(() => {
      const paymentPeriod = historyState?.paymentPeriod;
      const foundPeriod = postingPeriodDetails.find((row) => row?.code === paymentPeriod);
      if (foundPeriod) {
        dispatch(periodActions.selectPostingPeriod(foundPeriod));
        setPaymentPeriodDetails(foundPeriod);
      }
    }, 0);

    setValue("nextChequeNumber", historyState?.nextChequeNumber);
    setValue("chequeRunNarrative", historyState?.narrative);
  }, [history?.location?.state, bankAccounts]);

  useEffect(() => {
    if (tobeUsedChequeBookSelectedRow) {
      setValue("nextChequeNumber", tobeUsedChequeBookSelectedRow?.new_next_no);
    } else {
      setValue("nextChequeNumber", "000000");
    }

    trigger("nextChequeNumber");
  }, [tobeUsedChequeBookSelectedRow]);

  useEffect(() => {
    dispatch(getDefaultPaymentPeriod({ date: getCurrentDate() }));
  }, []);

  useEffect(() => {
    const found = postingPeriodDetails.find((t) => t.id === defaultPeriod);
    if (found) {
      setPaymentPeriodDetails(found);
      dispatch(actions.selectPostingPeriod(found));
    }
  }, [defaultPeriod]);

  const goToNext = handleSubmit(
    () => {
      /**
       * Saving data to session storage
       */
      if (paymentPeriod === false) {
        const chequeRunDetails = {
          bankId: selectedBankAccount?.bank_id,
          narration: getValues("chequeRunNarrative") || "",
          period: getValues("paymentPeriod"),
          bookId: tobeUsedChequeBookSelectedRow?.book_id,
          uniqueId: [],
          MasterchequeNo: getValues("nextChequeNumber"),
          lastChequeNo: tobeUsedChequeBookSelectedRow?.last_no
        };

        FMSSessionStorage.setItem(CHEQUE_PROCESSING_STORAGE_KEY, chequeRunDetails);
        console.log("goToNext tobeUsedChequeBooks", tobeUsedChequeBooks);
        const addChequeRunState = {
          bankAccount: selectedBankAccount,
          paymentPeriod: getValues("paymentPeriod"),
          narrative: getValues("chequeRunNarrative"),
          availableChequeBooks,
          tobeUsedChequeBooks,
          nextChequeNumber: getValues("nextChequeNumber"),
          chequeList: makeChequeList()
        };

        const historyState = {
          ...(history.location.state as any),
          ...addChequeRunState
        };

        FMSSessionStorage.setItem(CHEQUE_PROCESSING_CHEQUE_RUN, addChequeRunState);
        history.push({
          pathname: clientId
            ? `/accounts-payable/supplier/edit/${clientId}/${payeeId}/cheque-processing/add-cheque-run/items-for-payment`
            : "/cheque-processing/add-cheque-run/items-for-payment",
          state: { ...historyState }
        });
      } else {
        setShowEmptyChequeBookModal(true);
      }
    },
    (error) => {
      setMessage(t("common.invalidData"));
      setIsAlertModalOpen(true);
      return false;
    }
  );

  useEffect(() => {
    if (errors.nextChequeNumber) {
      setMessage(t("common.invalidData"));
      setIsAlertModalOpen(true);
    }
  }, [errors]);

  const makeChequeList = () => {
    const chequeList: { [key: string]: any }[] = [];
    tobeUsedChequeBooks.forEach((chequeBook) => {
      for (let i = 0; i < chequeBook.un_used; i += 1) {
        const chequeNumber = (parseInt(chequeBook.new_next_no, 10) + i).toString().padStart(6, "0");
        chequeList.push({
          chequeNumber,
          bookId: chequeBook?.book_id
        });
      }
    });
    console.log("chequeList", chequeList);

    return chequeList;
  };

  const cancelClicked = () => {
    history.push("/cheque-processing");
  };
  const setBankAccountDetails = async (row?: { [key: string]: any }, fetchChequeBooks: boolean = true) => {
    if (row) {
      reset((prev: any) => ({
        ...prev,
        bankAccount: row?.ledger_des,
        accountNo: row?.bank_account,
        sortCode: row?.bank_sort_code
      }));

      if (row.bank_id) {
        setIsDisabled(false);

        /**
         * fetch cheque books only on refresh and not on click of back button
         */
        if (fetchChequeBooks) {
          const chequebooklist: any = await dispatch(getChequeBooks({ bankId: row.bank_id }));

          if (!chequebooklist?.payload?.length) {
            setShowEmptyChequeBookModal(true);
          } else {
            setShowEmptyChequeBookModal(false);
            dispatch(chequeBookActions.resetAvailableChequeBookSelectedRow());
          }
        }
      }
    }
  };

  const onBankAccountNoSelection = () => {
    setShowBankAccountModal(true);
    setValue("bankAccount", "");
    clearErrors("bankAccount");
  };

  const onBankAccountSelection = (selectedItem: ISelectedItem | undefined) => {
    const selectBank = bankAccounts.filter((s) => s.ledger_des === selectedItem?.value)?.at(0);
    if (selectedItem?.text) {
      dispatch(bankActions.setFilters({ lookingFor: "" }));
      setBankAccountDetails(selectBank);
      dispatch(bankActions.selectBankAccountRow(selectBank));
    } else {
      setBankAccountDetails(undefined);
      dispatch(bankActions.selectBankAccountRow(undefined));
    }
  };

  const onBankAccountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    register("bankAccount").onChange(e);

    const { value } = e.target;
    if (!value.trim()) {
      dispatch(chequeBookActions.resetAvailableChequeBooks());
      dispatch(chequeBookActions.resetTobeUsedChequeBooks());
      dispatch(bankActions.selectBankAccountRow(undefined));
      dispatch(bankActions.setFilters({ lookingFor: "" }));
    } else {
      dispatch(bankActions.setFilters({ lookingFor: value }));
    }
  };

  const onBankAccountBlur = (e: React.SyntheticEvent<Element, Event>) => {
    const { value } = e.target as HTMLInputElement;
    if (value.trim().length === 0 && showBankAccountModal === false) {
      setError("bankAccount", { type: "custom" });
    } else {
      clearErrors("bankAccount");
    }
  };

  const onBankAccountSelectedRow = (row: any) => {
    dispatch(bankActions.selectBankAccountRow(row));
    setBankAccountDetails(row);
    dispatch(chequeBookActions.resetTobeUsedChequeBooks());
  };

  const moveRecordsToRight = () => {
    if (availableChequeBookSelectedRow) {
      const rowToveMovedRight = {
        ...availableChequeBookSelectedRow,
        new_next_no: availableChequeBookSelectedRow?.next_no
      };
      dispatch(chequeBookActions.setTobeUsedChequeBooks(rowToveMovedRight));
      dispatch(chequeBookActions.removeFromAvailableChequeBooks(availableChequeBookSelectedRow));
      dispatch(chequeBookActions.resetAvailableChequeBookSelectedRow());
      dispatch(chequeBookActions.setTobeUsedChequeBookSelectedRow(rowToveMovedRight));
    }
  };

  const moveRecordsToLeft = () => {
    if (tobeUsedChequeBookSelectedRow) {
      const rowTobeMovedLeft = { ...tobeUsedChequeBookSelectedRow };
      dispatch(chequeBookActions.setAvailableChequeBooks(rowTobeMovedLeft));
      dispatch(chequeBookActions.removeFromTobeUsedChequeBooks(rowTobeMovedLeft));
      dispatch(chequeBookActions.resetTobeUsedChequeBookSelectedRow());
      dispatch(chequeBookActions.setAvailableChequeBookSelectedRow(rowTobeMovedLeft));
    }
  };

  const moveUp = () => {
    if (tobeUsedChequeBookSelectedRow) {
      const index = tobeUsedChequeBooks.findIndex(
        (row: { [key: string]: any }) => row.book_id === tobeUsedChequeBookSelectedRow.book_id
      );
      if (index > 0) {
        const newIndex = index - 1;
        dispatch(
          chequeBookActions.shiftTobeUsedChequeBooks({
            oldIndex: index,
            newIndex,
            chequeBook: tobeUsedChequeBookSelectedRow
          })
        );
      }
    }
  };

  const moveDown = () => {
    if (tobeUsedChequeBookSelectedRow) {
      const total = tobeUsedChequeBooks.length;
      const lastIndex = total - 1;
      const index = tobeUsedChequeBooks.findIndex(
        (row: { [key: string]: any }) => row.book_id === tobeUsedChequeBookSelectedRow.book_id
      );

      if (index < lastIndex) {
        const newIndex = index + 1;
        dispatch(
          chequeBookActions.shiftTobeUsedChequeBooks({
            oldIndex: index,
            newIndex,
            chequeBook: tobeUsedChequeBookSelectedRow
          })
        );
      }
    }
  };

  const availableChequeBookSelectedRowHandler = (row: { [key: string]: any } | undefined) => {
    dispatch(chequeBookActions.setAvailableChequeBookSelectedRow(row));
  };

  const tobeUsedChequeBookSelectedRowHandler = (row: { [key: string]: any } | undefined) => {
    dispatch(chequeBookActions.setTobeUsedChequeBookSelectedRow(row));
  };

  const setPaymentPeriodDetails = (row: any) => {
    setValue("paymentPeriod", row.code);
    setValue("paymentDescription", row.description);
    trigger("paymentPeriod");
    trigger("paymentDescription");
  };

  const onPaymentPeriodSelection = (selectedItem: ISelectedItem | undefined) => {
    const found = postingPeriodDetails.find((s) => s.code === selectedItem?.text);
    if (selectedItem?.text) {
      dispatch(periodActions.setFilters({ lookingFor: "" }));
      setValue("paymentDescription", found?.description);
      dispatch(periodActions.selectPostingPeriod(found));
    } else {
      dispatch(periodActions.selectPostingPeriod(undefined));
    }
  };

  const onPaymentPeriodNoSelection = () => {
    setShowPostingPeriodModal(true);
    setValue("paymentPeriod", "");
    setValue("paymentDescription", "");
  };

  const onPaymentPeriodChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    register("paymentPeriod").onChange(e);

    const { value } = e.target;
    if (!value.trim()) {
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
      setPaymentPeriod(true);
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
      setPaymentPeriod(false);
    }
  };

  const onPostingPeriodSelectedRow = (row: any) => {
    dispatch(periodActions.selectPostingPeriod(row));
    setPaymentPeriodDetails(row);
  };

  const onSelectRowDate = (value: any) => {
    if (!value.trim()) {
      dispatch(periodActions.selectPostingPeriod(undefined));
      dispatch(periodActions.setFilters({ lookingFor: "" }));
      setPaymentPeriod(true);
    } else {
      dispatch(periodActions.setFilters({ lookingFor: value }));
      setPaymentPeriod(false);
    }
  };

  const validateNextChequeNumber = (event: any) => {
    const value = event?.target?.value;

    if (tobeUsedChequeBookSelectedRow) {
      if (!(value < tobeUsedChequeBookSelectedRow?.next_no || value > tobeUsedChequeBookSelectedRow?.last_no)) {
        const newUnused = parseInt(tobeUsedChequeBookSelectedRow?.last_no, 10) - parseInt(value, 10) + 1;
        const newSelectedRow = {
          ...tobeUsedChequeBookSelectedRow,
          un_used: newUnused,
          new_next_no: value
        };

        dispatch(chequeBookActions.setTobeUsedChequeBookSelectedRow(newSelectedRow));

        const index = tobeUsedChequeBooks.findIndex(
          (row: { [key: string]: any }) => row.book_id === tobeUsedChequeBookSelectedRow.book_id
        );
        dispatch(
          chequeBookActions.replaceTobeUsedChequeBooks({
            index,
            row: newSelectedRow
          })
        );
      }
    }
  };

  return {
    bankAccounts,
    goToNext,
    cancelClicked,
    onBankAccountSelection,
    onBankAccountChange,
    getValues,
    setValue,
    register,
    errors,
    dispatch,
    isAlertModalOpen,
    setIsAlertModalOpen,
    message,
    showBankAccountModal,
    setShowBankAccountModal,
    onBankAccountSelectedRow,
    availableChequeBooks,
    tobeUsedChequeBooks,
    moveRecordsToRight,
    moveRecordsToLeft,
    availableChequeBookSelectedRowHandler,
    tobeUsedChequeBookSelectedRowHandler,
    availableChequeBookSelectedRow,
    tobeUsedChequeBookSelectedRow,
    showPostingPeriodModal,
    setShowPostingPeriodModal,
    postingPeriodSelectedRow,
    postingPeriodDetails,
    onPaymentPeriodSelection,
    onPaymentPeriodChange,
    onPostingPeriodSelectedRow,
    onBankAccountNoSelection,
    onBankAccountBlur,
    onPaymentPeriodNoSelection,
    moveUp,
    moveDown,
    paymentPeriod,
    isDisabled,
    showEmptyChequeBookModal,
    setShowEmptyChequeBookModal,
    selectedBankAccount,
    onSelectRowDate,
    openKeepChangeModal,
    setOpenKeepChangeModal,
    validateNextChequeNumber
  };
};
