import "regenerator-runtime/runtime.js"; // Required for async/await to work with ES5 browserlist target
import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";
import reportWebVitals from "./reportWebVitals";
import App from "./App";

ReactDOM.render(
  <BrowserRouter basename="UI">
    <App isStandaloneApp />
  </BrowserRouter>,
  document.getElementById("root")
);

module?.hot?.accept();
