import {
  Button,
  ButtonColor,
  ButtonSize,
  IOverflowMenuItemProps,
  ISelectedItem,
  OverflowMenu,
  OverflowMenuItem,
  useOutsideClick
} from "@essnextgen/ui-kit";
import React, { useState, useEffect, useRef } from "react";
import "./Style.scss";
import UseStateType, { ESCAPE_TAB, KEYBOARD_STRING } from "@/types/UseStateType";
import { useHistory } from "react-router-dom";
import { localRoutes } from "@/utils/constants";

export type OptionsType = IOverflowMenuItemProps;

type GridRowActionsType = {
  name: string | React.ReactNode;
  onClick: (e: React.SyntheticEvent, selectedItem: ISelectedItem) => void;
  options: OptionsType[];
  selectedRow?: { [key: string]: any };
};

const GridRowActions: React.FC<GridRowActionsType> = ({ name, onClick, options, selectedRow }) => {
  const history = useHistory();
  const [isOpenActions, setIsOpenActions] = useState<boolean>(false);
  const [isIntersecting, setIsIntersecting] = useState(false);
  const ref: React.Ref<HTMLUListElement> = useRef(null);
  const MenuRef: React.Ref<HTMLDivElement> = useRef(null);
  const { isOutsideClicked } = useOutsideClick(MenuRef);
  const [optionsList, setOptionsList]: UseStateType<React.ReactElement[] | undefined> = useState();

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsIntersecting(entry.isIntersecting);
      },
      { rootMargin: "-120px 0px 80px 0px", threshold: 0, root: document.querySelector("#gridTable") }
    );
    if (selectedRow && isOpenActions) {
      observer.observe(document.getElementsByClassName("selected-row")[0]);
    }

    return () => observer.disconnect();
  }, [selectedRow, isOpenActions]);

  useEffect(() => {
    if ((isIntersecting === false || isOutsideClicked) && isOpenActions === true) {
      setIsOpenActions(false);
    }
  }, [isIntersecting, isOutsideClicked]);

  useEffect(() => {
    if (options?.length) {
      const newOptions = options?.map((item, index) => {
        const id = `menu-${index + 1}`;
        return (
          <OverflowMenuItem
            onClick={item?.onClick}
            key={id}
            id={String(index + 1)}
            text={item?.text}
            value={item?.value}
            disabled={item?.disabled}
          >
            {item?.children}
          </OverflowMenuItem>
        );
      });
      setOptionsList(newOptions);
    }
  }, [options]);

  useEffect(() => {
    const handleKeyDown = (e: any) => {
      if (e.key === ESCAPE_TAB.ESCAPE) {
        setIsOpenActions(false);
      }
      if (e.key === KEYBOARD_STRING.ArrowDown || e.key === KEYBOARD_STRING.ArrowUp) {
        setIsOpenActions(false);
      }
    };
    if (isOpenActions) {
      document?.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpenActions]);

  return (
    <div
      className="grid-actions grid-action-button"
      ref={MenuRef}
    >
      {optionsList?.length === 1 ? (
        <Button
          color={ButtonColor.Utility}
          className="segments-buttons"
          onClick={(e: any) => {
            onClick(e, { text: options?.at(0)?.text, value: options?.at(0)?.value });
          }}
        >
          {options?.at(0)?.children}
        </Button>
      ) : (
        <>
          {isOpenActions ? (
            <>
              <OverflowMenu
                id="module-menu"
                menuRef={ref}
                dataTestId="gird-table-actions"
                onClick={(e, selectedItem) => {
                  onClick(e, selectedItem);
                  setIsOpenActions(false);
                }}
                isScrollbarVisible
              >
                {optionsList ? optionsList?.map((item) => item) : []}
              </OverflowMenu>
            </>
          ) : null}
          <Button
            className="grid-actions__button m-auto"
            size={ButtonSize.Small}
            color={ButtonColor.Utility}
            onClick={(e: any) => setIsOpenActions((state) => !state)}
          >
            {name}
          </Button>
        </>
      )}
    </div>
  );
};

GridRowActions.defaultProps = {
  selectedRow: undefined
};

export default GridRowActions;
