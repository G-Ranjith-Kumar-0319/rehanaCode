import {
  CheckBox,
  IGridItemProps,
  RowBasedTable,
  RowBasedTableBody,
  RowBasedTableCell,
  RowBasedTableFoot,
  RowBasedTableHead,
  RowBasedTableRow,
  RowBasedTableUtility,
  RowBasedTableWrapper,
  TableRowType,
  Tooltip
} from "@essnextgen/ui-kit";
import React, { useEffect, useRef, useState } from "react";
import "./Style.scss";
import { deepEqual } from "@/utils/constants";
import "./GridStyle.scss";
import { useLocation } from "react-router-dom";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";
import { KEYBOARD_STRING } from "@/types/UseStateType";

export type RowType = { [key: string]: any };

export enum ResponseCode {
  Default = "Default",
  Error = "Error",
  Info = "Info"
}

export type TColumnDef = {
  field: string;
  key?: string;
  headerName?: string;
  primary?: boolean;
  sequenceName?: string;
  sequence?: boolean;
  sequenceIndex?: number;
  checkboxSelection?: boolean;
  headerCheckboxSelection?: boolean;
  align?: "left" | "right" | "center";
  cellRenderer?: "GridCellLink";
  className?: string;
  val?: number;
  enableTooltip?: boolean;
  columnWidth?: 5 | 10 | 15 | 20 | 25 | 30 | 50 | 70 | 80 | 90;
}[];

export type TColumnHeadDef = {
  headerName?: string;
  primary?: boolean;
  sequenceName?: string;
  sequence?: boolean;
  sequenceIndex?: number;
  checkboxSelection?: boolean;
  headerCheckboxSelection?: boolean;
  align?: "left" | "right" | "center";
  cellRenderer?: "GridCellLink";
  className?: string;
  val?: number;
  colSpan?: number;
}[];

export type cellRendererType = {
  field?: string;
  row?: RowType;
};

type GridTableType = {
  dataSource: RowType[];
  columnDef: TColumnDef;
  columnDefHeader?: TColumnHeadDef;
  isLoading: boolean;
  isRowSelectionEnabled?: boolean;
  isRowSelectOnArrowkey?: boolean;
  loadingMsg?: string;
  emptyDataMsg?: string;
  displayErrorMsg?: string;
  selectedRow?: RowType;
  id?: string;
  selectedRowHandler?: (row?: RowType) => void;
  checkedRowHandler?: (row: RowType) => void;
  headerClickHandler?: () => void;
  filters?: React.ReactNode;
  footer?: React.ReactNode;
  actions?: React.ReactNode;
  customCell?: any;
  checkedRows?: RowType[];
  toolTipAllow?: boolean;
  isScrollable?: boolean;
  enableScrollIntoView?: boolean;
  stickyHeader?: boolean;
  useDeepSearch?: boolean;
  dataTestId?: string;
  onEnterKeyPress?: () => void;
  hideHeader?: boolean;
  isAutoFocusInitially?: boolean;
  onFocus?: React.FocusEventHandler<HTMLDivElement> | undefined;
} & Omit<IGridItemProps, "children">;

const GridTableNew = ({
  id,
  dataSource,
  isLoading,
  loadingMsg = "Please wait",
  emptyDataMsg = "Register taken",
  columnDef,
  columnDefHeader,
  selectedRow,
  displayErrorMsg,
  selectedRowHandler,
  checkedRowHandler,
  headerClickHandler,
  filters,
  footer,
  checkedRows = [],
  toolTipAllow,
  isRowSelectionEnabled = true,
  isRowSelectOnArrowkey = true,
  isScrollable = false,
  enableScrollIntoView,
  stickyHeader,
  useDeepSearch,
  onEnterKeyPress,
  actions,
  dataTestId = "gridTable",
  hideHeader = false,
  isAutoFocusInitially = true,
  onFocus,
  ...rest
}: GridTableType) => {
  const [newSelectRow, setNewSelectRow] = useState<RowType | undefined>(selectedRow);
  const [gridRowIndex, setGridRowIndex] = useState<number>(0);
  const [rows, setRows] = useState<RowType[]>([]);
  const gridRef: React.Ref<HTMLDivElement> = useRef(null);
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const location = useLocation();
  const getIndex = (dataTestId: string, rowIndex: number) =>
    `rowIndex-${dataTestId ? `${dataTestId}-` : ""}${rowIndex}`;

  const rowHandler = () => {
    const row = dataSource.filter((row) => deepEqual(newSelectRow, row))[0];
    const index = dataSource.indexOf(row || dataSource[0]);
    setGridRowIndex(index);
    const element = document.getElementById(getIndex(dataTestId, index));
    element?.scrollIntoView({ block: "center", behavior: "smooth" });
    gridRef.current?.querySelectorAll("input")[0].focus();
  };

  const toggleTabIndex = () => {
    gridRef.current?.querySelectorAll("tbody .essui-rowbasedtable__row").forEach((itemEl) => {
      itemEl.setAttribute("tabindex", "-1");

      itemEl.querySelectorAll("button").forEach((buttonEl) => {
        buttonEl.setAttribute("tabindex", "-1");
      });
      itemEl.querySelectorAll("[type='checkbox']").forEach((buttonEl) => {
        buttonEl.setAttribute("tabindex", "-1");
      });
    });
    const selectedRowEl = gridRef.current?.querySelector("tbody .essui-rowbasedtable__row.selected-row");
    selectedRowEl?.setAttribute("tabindex", "0");
    selectedRowEl?.querySelectorAll("button").forEach((buttonEl) => {
      buttonEl.setAttribute("tabindex", "0");
    });
    selectedRowEl?.querySelectorAll("[type='checkbox']").forEach((buttonEl) => {
      buttonEl.setAttribute("tabindex", "0");
    });
  };

  useEffect(() => {
    if (!isLoading && dataSource.length && newSelectRow) {
      setTimeout(toggleTabIndex, 1000);
    }
  }, [isLoading, newSelectRow]);

  useEffect(() => {
    if (enableScrollIntoView && !isScrollable && dataSource.length) {
      setTimeout(rowHandler, 0);
    }
  }, [enableScrollIntoView, isScrollable, dataSource]);

  useEffect(() => {
    if (isLoading === false) {
      const found = document.querySelectorAll("input")[0];
      if (!found && isAutoFocusInitially) {
        gridRef.current?.getElementsByTagName("tr")[0]?.focus();
      } else {
        found?.focus({ preventScroll: true });
      }
    }
  }, [isLoading, gridRef]);

  useEffect(() => {
    if (selectedRowHandler && newSelectRow !== undefined) {
      selectedRowHandler(newSelectRow);
    }
  }, [newSelectRow]);

  useEffect(() => {
    if (selectedRow !== undefined && dataSource?.length) {
      setNewSelectRow(selectedRow);
      if (useDeepSearch) {
        setGridRowIndex(dataSource.findIndex((obj) => deepEqual(obj, selectedRow)));
      } else {
        setGridRowIndex(dataSource.indexOf(selectedRow));
      }
    }
  }, [selectedRow, dataSource]);

  useEffect(() => {
    if (dataSource?.length > 0) {
      setRows(dataSource);
      const index = newSelectRow ? selectedRow : dataSource?.at(0);
      const rowIndexOf = dataSource.indexOf(index || dataSource[0]);
      if (rowIndexOf !== -1) {
        setNewSelectRow(index);
        setGridRowIndex(dataSource.indexOf(index || dataSource[0]));
      }
    } else {
      setRows([]);
    }
  }, [dataSource]);

  useEffect(() => {
    let timer: any;
    if (
      gridRef.current &&
      isLoading === false &&
      dataSource?.length &&
      isScrollable &&
      enableScrollIntoView !== undefined
    ) {
      timer = setTimeout(() => {
        if (gridRef.current?.querySelectorAll("input")[0]) {
          rowHandler();
        }
      }, 0);
    }

    return () => clearTimeout(timer);
  }, [enableScrollIntoView, isLoading, dataSource, isScrollable]);

  const handleCheckboxChange = (e: any, row: RowType) => {
    if (checkedRowHandler) {
      const updatedRows = [...checkedRows];
      const rowIndex = updatedRows.findIndex((r) => deepEqual(r, row));
      if (e.target.checked) {
        if (rowIndex === -1) {
          updatedRows.push(row);
        }
      } else if (rowIndex !== -1) {
        updatedRows.splice(rowIndex, 1);
      }
      checkedRowHandler(updatedRows);
    }
  };

  const getClassName = (index: number) => (index === gridRowIndex ? "essui-rowbasedtable__row-focus selected-row" : "");

  const handleSelectedRow = (row: RowType) => {
    const exactPath = location.pathname;
    const checkboxDef = columnDef.filter((column) => column.checkboxSelection)[0];
    const key = checkboxDef.key || 0;
    if (row[key]) {
      return (checkedRows || []).some((checkedRow) => checkedRow[key] === row[key]);
    }
    if (row.line_number) {
      return (checkedRows || []).some((checkedRow) => checkedRow?.line_number === row?.line_number);
    }
    if (row.order_line_id) {
      /** this condition is for line item order data into purchase order */
      return (checkedRows || []).some((checkedRow) => checkedRow?.order_line_id === row?.order_line_id);
    }
    /** This condition is for invoice listing checkbox selection */
    if (exactPath.includes("/invoice-credit-note")) {
      return (checkedRows || []).some((checkedRow) => checkedRow?.invoice_id === row?.invoice_id);
    }
    /** This is for returning the checked value in purchase order */
    return (checkedRows || []).some((checkedRow) => checkedRow?.order_id === row?.order_id);
  };

  const getRow = (row: RowType, column: RowType) => {
    if (column?.cellRenderer === "GridCellLink") {
      return (
        rest.customCell && (
          <rest.customCell
            field={column?.field}
            row={row}
          />
        )
      );
    }
    if (row[column?.field]) {
      const { length } = row[column?.field];
      const formatText = (text: string, maxLength: number) => {
        const words = String(text)?.trim().split(/\s+/);

        let formattedText = "";
        let lineLength = 0;

        words.forEach((word) => {
          if (lineLength + word.length > maxLength) {
            formattedText += `\n${word} `;
            lineLength = word.length + 1;
          } else {
            formattedText += `${word} `;
            lineLength += word.length + 1;
          }
        });

        return formattedText.trim();
      };
      const formattedContent = formatText(row[column?.field], 40);

      return column.enableTooltip && length >= 30 ? (
        <>
          <Tooltip
            content={formattedContent}
            className="custom-tooltip"
          >
            <div className={`tooltip ${column.columnWidth === 10 && "tooltip-new-width"}`}>{row[column?.field]}</div>
          </Tooltip>
        </>
      ) : (
        row[column?.field]
      );
    }
    return "-";
  };

  const getCustomHeader = () => (
    <>
      <RowBasedTableRow
        rowType={TableRowType.Head}
        className="is-height-zero"
      >
        {columnDefHeader?.map((column, index: number) => {
          const rowKey = `row-${index}`;
          return (
            <RowBasedTableCell
              key={rowKey}
              header
              colSpan={column.colSpan}
              align={column.align}
            >
              <h1>Test....</h1>
              {column?.headerName}
            </RowBasedTableCell>
          );
        })}
      </RowBasedTableRow>
    </>
  );

  useEffect(() => {
    if (gridRowIndex !== 0 && gridRowIndex !== -1) {
      setNewSelectRow(dataSource.at(gridRowIndex));
    }
  }, [gridRef, gridRowIndex]);

  const handleKeyDown: React.KeyboardEventHandler<HTMLDivElement> = (event) => {
    if (event.key === "ArrowUp" || event.key === "ArrowLeft") {
      event.preventDefault();
      const index = gridRowIndex !== 0 ? gridRowIndex - 1 : 0;
      document.getElementById(getIndex(dataTestId, index))?.focus();
      document.getElementById(getIndex(dataTestId, index))?.scrollIntoView({ block: "center", behavior: "smooth" });
      setGridRowIndex(index);
      if (index === 0) {
        setNewSelectRow(dataSource.at(0));
      }
    } else if (event.key === "ArrowDown" || event.key === "ArrowRight") {
      event.preventDefault();
      const index = dataSource.length - 1 > gridRowIndex ? gridRowIndex + 1 : dataSource.length - 1;
      document.getElementById(getIndex(dataTestId, index))?.focus();
      setGridRowIndex(index);
    } else if (event.key === "Enter" && onEnterKeyPress) {
      onEnterKeyPress();
    }
  };

  return (
    <div
      className={`generic-table ${rest.className || ""}`}
      ref={gridRef}
      onFocus={onFocus}
      onKeyDown={isRowSelectOnArrowkey ? handleKeyDown : () => {}}
    >
      <RowBasedTableWrapper
        dataTestId={`grid-table-${id}`}
        id={id}
        isLoading={isLoading}
        loadingMsg={loadingMsg}
        isEmptyData={false}
        emptyDataMsg={emptyDataMsg}
        buttonText="Finish"
      >
        {filters && !stickyHeader ? <RowBasedTableUtility>{filters}</RowBasedTableUtility> : null}
        <div
          id={`gridTable${id ?? ""}`}
          className={`${isScrollable ? "fixed-header-table " : ""}${stickyHeader ? "sticky-header" : ""}`}
        >
          {filters && stickyHeader ? <RowBasedTableUtility>{filters}</RowBasedTableUtility> : null}
          <RowBasedTable>
            {!hideHeader && (
              <RowBasedTableHead
                id="gridTableHead"
                className="scroll-zindex"
              >
                {columnDefHeader ? getCustomHeader() : null}
                <RowBasedTableRow
                  rowType={TableRowType.Head}
                  onClick={() => (headerClickHandler ? headerClickHandler() : undefined)}
                >
                  {columnDef.map((column, index: number) => {
                    const rowKey = `row-${index}`;
                    return column?.headerCheckboxSelection ? (
                      <RowBasedTableCell
                        key={rowKey}
                        className="w-5"
                        header
                      >
                        <CheckBox />
                      </RowBasedTableCell>
                    ) : (
                      <RowBasedTableCell
                        key={rowKey}
                        header
                        align="left"
                        className={column?.className ?? ""}
                      >
                        {t(`${column?.headerName ? column?.headerName : ""}`)
                          ? t(`${column?.headerName}`)
                          : column?.headerName}
                      </RowBasedTableCell>
                    );
                  })}
                </RowBasedTableRow>
              </RowBasedTableHead>
            )}
            <RowBasedTableBody>
              {(rows || []).map((row: any, rowIndex: number) => {
                const index = getIndex(dataTestId, rowIndex);
                return (
                  <RowBasedTableRow
                    rowType={TableRowType.Default}
                    key={index}
                    onClick={(e) => {
                      if (isRowSelectionEnabled) {
                        setGridRowIndex(rowIndex);
                        setNewSelectRow(row);
                      }
                    }}
                    className={getClassName(rowIndex)}
                    id={index}
                    dataTestId={String(rowIndex)}
                  >
                    {columnDef.map((column, colIndex: any) => {
                      const colKey = `colIndex-${colIndex}`;
                      return column?.checkboxSelection ? (
                        <RowBasedTableCell
                          key={colKey}
                          className="w-5"
                        >
                          <CheckBox
                            isSelected={handleSelectedRow(row)}
                            value={String(rowIndex)}
                            onChange={(e) => handleCheckboxChange(e, row)}
                          />
                        </RowBasedTableCell>
                      ) : (
                        <RowBasedTableCell
                          key={colKey}
                          align={column?.align}
                          className={`${toolTipAllow ? "tool-tip-ellipse" : ""} ${
                            column?.columnWidth ? `w-${column.columnWidth}` : null
                          }`}
                        >
                          {toolTipAllow ? (
                            <>
                              <span title={row[column?.field]}>
                                {column?.cellRenderer === "GridCellLink"
                                  ? rest.customCell && (
                                      <rest.customCell
                                        field={column?.field}
                                        row={row}
                                      />
                                    )
                                  : row[column?.field]}
                              </span>
                            </>
                          ) : (
                            <>{getRow(row, column)}</>
                          )}
                        </RowBasedTableCell>
                      );
                    })}
                  </RowBasedTableRow>
                );
              })}
              {rows?.length === 0 ? (
                <RowBasedTableRow rowType={TableRowType.Info}>
                  <RowBasedTableCell
                    responseCode={ResponseCode.Info}
                    responseMessage={displayErrorMsg || t("common.noDataDisplay")}
                  />
                </RowBasedTableRow>
              ) : null}
            </RowBasedTableBody>
            {footer ? (
              <RowBasedTableFoot>
                <RowBasedTableRow rowType={TableRowType.Foot}>
                  <RowBasedTableCell
                    colSpan={columnDef.length}
                    align="right"
                  >
                    {footer}
                  </RowBasedTableCell>
                </RowBasedTableRow>
              </RowBasedTableFoot>
            ) : null}
          </RowBasedTable>
        </div>
        {actions ? <div className="grid-footer-actions">{actions}</div> : undefined}
      </RowBasedTableWrapper>
    </div>
  );
};

GridTableNew.defaultProps = {
  loadingMsg: undefined,
  emptyDataMsg: undefined,
  id: undefined,
  selectedRowHandler: undefined,
  checkedRowHandler: undefined,
  filters: undefined,
  footer: undefined,
  customCell: undefined,
  checkedRows: undefined,
  selectedRow: undefined,
  toolTipAllow: undefined,
  columnDefHeader: undefined,
  isRowSelectionEnabled: undefined,
  isAutoFocusInitially: undefined,
  headerClickHandler: undefined,
  isScrollable: undefined,
  displayErrorMsg: undefined,
  enableScrollIntoView: undefined,
  stickyHeader: undefined,
  dataTestId: undefined,
  onEnterKeyPress: undefined,
  useDeepSearch: undefined,
  actions: undefined,
  hideHeader: undefined,
  onFocus: undefined,
  isRowSelectOnArrowkey: undefined
};

export default GridTableNew;
