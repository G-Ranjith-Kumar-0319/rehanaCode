import React, { ReactNode } from "react";
import {
  Button,
  ButtonColor,
  ButtonIconPosition,
  ButtonSize,
  Dialog,
  DialogContent,
  DialogFooter,
  Grid,
  GridItem,
  IDialogProps
} from "@essnextgen/ui-kit";
import "./Style.scss";
import HelpButton from "../OpenLinkButton/HelpButton";

type modal = {
  children: ReactNode;
  primaryBtnText?: string;
  secondaryBtnText?: string;
  tertiaryBtnText?: string;
  fourthiaryBtnText?: string;
  fourthiaryBtnType?: ButtonColor;
  tertiaryBtnType?: ButtonColor;
  secondaryBtnType?: ButtonColor;
  primaryBtnType?: ButtonColor;
  secondaryBtnStatus?: any;
  primaryBtnStatus?: any;
  primaryBtnClick?: (e: React.SyntheticEvent) => void;
  secondaryBtnClick?: (e: React.SyntheticEvent) => void;
  tertiaryBtnClick?: (e: React.SyntheticEvent) => void;
  fourthiaryBtnClick?: (e: React.SyntheticEvent) => void;
  onClose?: (e: React.SyntheticEvent) => void;
  header?: string;
  isOpen: boolean;
  className?: string;
  modalFooter?: React.ReactNode;
  escapeExits?: boolean;
  primaryBtnId?: string;
};

const Modal = ({
  children,
  primaryBtnText = "Save",
  secondaryBtnText = "Next Line",
  tertiaryBtnText = "Cancel",
  fourthiaryBtnText = "Help",
  primaryBtnClick,
  secondaryBtnClick,
  tertiaryBtnClick,
  fourthiaryBtnClick,
  onClose,
  fourthiaryBtnType,
  tertiaryBtnType,
  secondaryBtnType,
  primaryBtnType,
  primaryBtnStatus,
  secondaryBtnStatus,
  header,
  isOpen,
  className,
  modalFooter,
  primaryBtnId,
  escapeExits = true
}: modal) => (
  <Grid
    container
    className="generic-modal"
  >
    <GridItem>
      <Dialog
        isOpen={isOpen}
        dataTestId="modal"
        escapeExits={escapeExits}
        initialFocusElementId="essui-modal"
        id="essui-modal"
        onClose={onClose || tertiaryBtnClick}
        returnFocusOnDeactivate
        title={header}
        className={className}
      >
        <DialogContent>{children}</DialogContent>
        {modalFooter ? (
          <DialogFooter>{modalFooter}</DialogFooter>
        ) : (
          <DialogFooter>
            <Grid className="footer-buttons">
              <GridItem xl={6}>
                <div className="dialog-right-button">
                  {primaryBtnClick && primaryBtnText && (
                    <Button
                      size={ButtonSize.Small}
                      onClick={primaryBtnClick}
                      color={primaryBtnType || ButtonColor.Primary}
                      disabled={!!primaryBtnStatus}
                      id={primaryBtnId ?? primaryBtnId}
                    >
                      {primaryBtnText}
                    </Button>
                  )}
                  {secondaryBtnClick && secondaryBtnText && (
                    <Button
                      size={ButtonSize.Small}
                      onClick={secondaryBtnClick}
                      color={secondaryBtnType || ButtonColor.Tertiary}
                      disabled={!!secondaryBtnStatus}
                    >
                      {secondaryBtnText}
                    </Button>
                  )}
                  {tertiaryBtnClick && tertiaryBtnText && (
                    <Button
                      // className="cancel-btn"
                      className="tertiary-btn"
                      size={ButtonSize.Small}
                      color={tertiaryBtnType || ButtonColor.Secondary}
                      onClick={tertiaryBtnClick}
                    >
                      {tertiaryBtnText}
                    </Button>
                  )}
                </div>
              </GridItem>
              <GridItem xl={6}>
                {fourthiaryBtnClick && fourthiaryBtnText && (
                  // <Button
                  //   size={ButtonSize.Small}
                  //   onClick={fourthiaryBtnClick}
                  //   color={fourthiaryBtnType || ButtonColor.Tertiary}
                  //   iconPosition={ButtonIconPosition.Left}
                  // >
                  //   {fourthiaryBtnText}
                  // </Button>
                  <HelpButton
                    identifier="testIdentifier"
                    labelName=""
                  />
                )}
              </GridItem>
            </Grid>
          </DialogFooter>
        )}
      </Dialog>
    </GridItem>
  </Grid>
);

Modal.defaultProps = {
  primaryBtnText: undefined,
  secondaryBtnText: undefined,
  tertiaryBtnText: undefined,
  fourthiaryBtnText: undefined,
  primaryBtnClick: undefined,
  secondaryBtnClick: undefined,
  tertiaryBtnClick: undefined,
  fourthiaryBtnType: undefined,
  primaryBtnId: undefined,
  tertiaryBtnType: undefined,
  secondaryBtnType: undefined,
  primaryBtnType: undefined,
  secondaryBtnStatus: undefined,
  primaryBtnStatus: undefined,
  onClose: undefined,
  fourthiaryBtnClick: undefined,
  header: undefined,
  className: undefined,
  modalFooter: undefined,
  escapeExits: undefined
};
export default Modal;
