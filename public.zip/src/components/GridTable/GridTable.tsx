import {
  CheckBox,
  IGridItemProps,
  RowBasedTable,
  RowBasedTableBody,
  RowBasedTableCell,
  RowBasedTableFoot,
  RowBasedTableHead,
  RowBasedTableRow,
  RowBasedTableWrapper,
  TableRowType
} from "@essnextgen/ui-kit";
import React, { useEffect, useRef, useState } from "react";
import "./Style.scss";
import { deepEqual } from "@/utils/constants";

export enum ResponseCode {
  Default = "Default",
  Error = "Error",
  Info = "Info"
}

export type TColumnDef = {
  field: string;
  headerName?: string;
  primary?: boolean;
  sequenceName?: string;
  sequence?: boolean;
  sequenceIndex?: number;
  checkboxSelection?: boolean;
  headerCheckboxSelection?: boolean;
  align?: "left" | "right" | "center";
  cellRenderer?: "GridCellLink";
  val?: number;
}[];

export type cellRendererType = {
  field?: string;
  row?: { [key: string]: any };
};

type GridTableType = {
  dataSource: { [key: string]: any }[];
  columnDef: TColumnDef;
  isLoading: boolean;
  loadingMsg?: string;
  emptyDataMsg?: string;
  selectedRow?: { [key: string]: any };
  id?: string;
  isScrollable?: boolean;
  enableScrollIntoView?: boolean;
  selectedRowHandler?: (row?: { [key: string]: any }) => void;
  checkedRowHandler?: (row: { [key: string]: any }) => void;
  filters?: React.ReactNode;
  footer?: React.ReactNode;
  customCell?: React.ComponentType<{
    field?: string;
    row?: { [key: string]: any };
  }>;
  checkedRows?: { [key: string]: any }[];
} & Omit<IGridItemProps, "children">;

const GridTable = ({
  id,
  dataSource,
  isLoading,
  loadingMsg = "Please wait",
  emptyDataMsg = "Register taken",
  columnDef,
  selectedRow,
  selectedRowHandler,
  checkedRowHandler,
  filters,
  footer,
  isScrollable = false,
  enableScrollIntoView = false,
  checkedRows,
  ...rest
}: GridTableType) => {
  const [newSelectRow, setNewSelectRow] = useState<{ [key: string]: any }>();
  const [rows, setRows] = useState<{ [key: string]: any }[]>([]);
  const gridRef: React.Ref<HTMLDivElement> = useRef(null);
  const getSelectedRow = (row: { [key: string]: any } | undefined) => {
    setNewSelectRow(row);
    if (selectedRowHandler) selectedRowHandler(row);
  };
  useEffect(() => {
    if (gridRef.current) {
      const element = document.getElementById(`rowIndex-${dataSource.indexOf(newSelectRow!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [enableScrollIntoView]);
  useEffect(() => {
    setRows(dataSource);
    if (selectedRow) {
      setNewSelectRow(selectedRow);
    } else {
      if (dataSource?.length) setNewSelectRow(dataSource?.at(0));
      if (selectedRowHandler) selectedRowHandler(dataSource?.at(0));
    }
  }, [dataSource, selectedRow]);

  const handleCheckboxChange = (e: any, row: { [key: string]: any }) => {
    if (checkedRowHandler) {
      if (e.target.checked) {
        checkedRowHandler(row);
      } else {
        // const updatedRow = checkedRows?.filter((obj) => obj.order_id !== row.order_id);
        checkedRowHandler({ ...row, unchecked: true });
      }
    }
  };

  const getClassName = (row: { [key: string]: any }) => (deepEqual(newSelectRow, row) ? "selected-row" : "");

  const handleSelectedRow = (row: { [key: string]: any }) => {
    if (row.order_line_id) {
      /** this condition is for line item order data into purchase order */
      return (checkedRows || []).some((checkedRow) => checkedRow?.order_line_id === row?.order_line_id);
    }
    return (checkedRows || []).some((checkedRow) => checkedRow?.order_id === row?.order_id);
  };

  const getRowValue = (row: any, column: any) => {
    if (row[column?.field] && row[column?.field] !== "") {
      return row[column?.field];
    }
    return "-";
  };
  return (
    <div
      className="generic-table-old"
      ref={gridRef}
    >
      {filters ?? null}
      <RowBasedTableWrapper
        dataTestId={`grid-table-${id}`}
        isLoading={isLoading}
        loadingMsg={loadingMsg}
        isEmptyData={false}
        emptyDataMsg={emptyDataMsg}
        buttonText="Finish"
      >
        <div className={isScrollable ? "fixed-header-table" : undefined}>
          <RowBasedTable>
            <RowBasedTableHead>
              <RowBasedTableRow rowType={TableRowType.Head}>
                {columnDef.map((column, index: number) => {
                  const rowKey = `row-${index}`;
                  return column?.headerCheckboxSelection ? (
                    <RowBasedTableCell
                      key={rowKey}
                      className="w-5"
                      header
                    >
                      <CheckBox />
                    </RowBasedTableCell>
                  ) : (
                    <RowBasedTableCell
                      key={rowKey}
                      header
                      align="left"
                    >
                      {column?.headerName}
                    </RowBasedTableCell>
                  );
                })}
              </RowBasedTableRow>
            </RowBasedTableHead>
            <RowBasedTableBody>
              {(rows || []).map((row: any, rowIndex: any) => {
                const index = `rowIndex-${rowIndex}`;
                return (
                  <RowBasedTableRow
                    rowType={TableRowType.Default}
                    key={index}
                    onClick={() => getSelectedRow(row)}
                    className={getClassName(row)}
                  >
                    {columnDef.map((column, colIndex: any) => {
                      const colKey = `colIndex-${colIndex}`;
                      return column?.checkboxSelection ? (
                        <RowBasedTableCell
                          key={colKey}
                          className="w-5"
                        >
                          <CheckBox
                            isSelected={handleSelectedRow(row)}
                            value={rowIndex}
                            onChange={(e) => handleCheckboxChange(e, row)}
                          />
                        </RowBasedTableCell>
                      ) : (
                        <RowBasedTableCell
                          key={colKey}
                          align={column?.align}
                        >
                          {column?.cellRenderer === "GridCellLink"
                            ? rest.customCell && (
                                <rest.customCell
                                  field={column?.field}
                                  row={row}
                                />
                              )
                            : getRowValue(row, column)}
                        </RowBasedTableCell>
                      );
                    })}
                  </RowBasedTableRow>
                );
              })}
              {rows?.length === 0 ? (
                <RowBasedTableRow rowType={TableRowType.Info}>
                  <RowBasedTableCell
                    responseCode={ResponseCode.Info}
                    responseMessage="No data to display"
                  />
                </RowBasedTableRow>
              ) : null}
            </RowBasedTableBody>
            {footer ? (
              <RowBasedTableFoot>
                <RowBasedTableRow rowType={TableRowType.Foot}>
                  <RowBasedTableCell
                    colSpan={columnDef.length}
                    align="right"
                  >
                    {footer}
                  </RowBasedTableCell>
                </RowBasedTableRow>
              </RowBasedTableFoot>
            ) : null}
          </RowBasedTable>
        </div>
      </RowBasedTableWrapper>
    </div>
  );
};

GridTable.defaultProps = {
  loadingMsg: undefined,
  emptyDataMsg: undefined,
  id: undefined,
  selectedRowHandler: undefined,
  checkedRowHandler: undefined,
  filters: undefined,
  footer: undefined,
  customCell: undefined,
  checkedRows: undefined,
  isScrollable: undefined,
  enableScrollIntoView: undefined,
  selectedRow: undefined
};

export default GridTable;
