import UseStateType, { specialCharacters } from "@/types/UseStateType";
import {
  Button,
  ButtonColor,
  ButtonSize,
  FormLabel,
  ISelectedItem,
  ITextInputProps,
  Icon,
  IconColor,
  IconSize,
  OverflowMenu,
  OverflowMenuItem,
  TextInput
} from "@essnextgen/ui-kit";
import React, { useEffect, useRef, useState } from "react";
import "./Style.scss";

export type InputPropsType = ITextInputProps & {
  labelText?: string;
  searchable?: boolean;
  searchItems?: Array<ISelectedItem>;
  button?: React.JSX.Element;
  searchBtnClick?: (e: React.SyntheticEvent<Element, Event>) => void;
  buttonPosition?: "Left" | "Right";
  onNoSelection?: () => void;
  onSelect?: (selectedItem?: ISelectedItem) => void;
  onPending?: (selectedItem?: ISelectedItem, index?: number, flag?: boolean) => void;
  isViewOnly?: boolean;
};
type InputType = ({}: InputPropsType) => JSX.Element;
type keyDownType = (event: React.KeyboardEvent) => void;

const Input = ({
  labelText,
  searchable = false,
  searchItems,
  button,
  searchBtnClick,
  buttonPosition = "Right",
  onSelect,
  onNoSelection,
  onPending,
  isViewOnly,
  ...rest
}: InputPropsType) => {
  const [searchTerm, setSearchTerm]: UseStateType<string | null> = useState<string | null>(null);
  const [showMenu, setShowMenu]: UseStateType<boolean> = useState(false);
  const [items, setItems]: UseStateType<React.ReactElement[] | undefined> = useState();
  const [dropdownItems, setDropdownItems]: UseStateType<Array<React.ReactElement> | undefined> = useState();
  const [inputValue, setInputValue] = useState<string>();

  useEffect(() => {
    if (searchItems?.length) {
      setItems(
        searchItems?.map((item, index) => {
          const id = `menu-${index + 1}`;
          return (
            <OverflowMenuItem
              key={id}
              id={String(index + 1)}
              text={item.text}
              value={item.value}
              disabled
            >
              {item.text}
            </OverflowMenuItem>
          );
        })
      );
    }
  }, [searchItems]);

  useEffect(() => {
    if (rest.value === dropdownItems?.at(0)?.props.text && !showMenu) {
      setDropdownItems(undefined);
    }
  }, [rest.value, dropdownItems, showMenu]);

  const handleKeyDown: keyDownType = (event) => {
    if (rest.onKeyDown) {
      rest.onKeyDown(event);
    }
  };

  const handleSearchTerm: (value: string | null) => void = (value) => {
    // The menu appears initially with all the items and then shows the filtered items, causing a flash which can be jarring
    // Deferring with a zero delay setTimeout removes the initial flash

    // We want to toggle menu on or off based on the search term length only when we are typing into it
    // Hence the condition to check if the input is currently the focused element or not
    if (value !== null && value !== "") {
      setShowMenu(value.trim().length >= 0);
      setInputValue(value);
    }

    setSearchTerm(value);
  };

  const createFilteredDropdownItems: (childItems: React.ReactElement[] | undefined) => React.ReactElement[] = (
    childItems: React.ReactElement[] | undefined
  ) => {
    if (!Array.isArray(childItems)) return [];
    const filteredItems: any[] = [];
    let rowIndex;
    /* eslint-disable no-plusplus */
    for (let index = 0; index <= childItems.length - 1; index++) {
      const item: React.ReactElement<any, string | React.JSXElementConstructor<any>> = childItems[index];

      if (item.props.text.toString()?.toLowerCase().startsWith(searchTerm?.toLowerCase())) {
        filteredItems.push(
          React.cloneElement(item, {
            key: item.key === null ? `menu-option-${rest.id}-${index}` : item.key,
            id: `menu-option-${rest.id}-${item.props.value}`,
            dataTestId: `menu-option-${rest.dataTestId}-${item.props.value}`
          })
        );
        rowIndex = index;
        break;
      }
    }

    if (filteredItems.length === 0) {
      if (onPending) onPending(undefined, undefined, false);
      if (onSelect && rest.value !== "") {
        onSelect(undefined);
      }
      if (onNoSelection && searchTerm !== undefined) {
        onNoSelection();
      }
      setSearchTerm("");
    } else if (onPending) {
      onPending({ text: filteredItems?.at(0)?.props.text, value: filteredItems?.at(0)?.props.value }, rowIndex);
    }

    return filteredItems;
  };

  const createDropdownItems: (childItems: React.ReactElement[] | undefined) => React.ReactElement[] | undefined = (
    childItems: React.ReactElement[] | undefined
  ) => {
    if (searchTerm === "") setShowMenu(false);

    if (searchable && searchTerm !== null && searchTerm !== "") return createFilteredDropdownItems(childItems);
    return undefined;
  };

  useEffect(() => {
    if (inputValue === searchTerm) {
      setDropdownItems(createDropdownItems(items));
    }
  }, [searchTerm, inputValue]);

  const handleBlur: (e: any) => void = (e: any) => {
    if (rest.value === dropdownItems?.at(0)?.props.text) {
      setDropdownItems(undefined);
    }

    // Trigger callback only when input loses focus by Tab keypress, not by outside click
    // To avoid calling the function twice, once onBlur and once again onOutsideClick
    if (dropdownItems?.length && onSelect) {
      onSelect({ text: dropdownItems?.at(0)?.props.text, value: dropdownItems?.at(0)?.props.value });
    }
    setShowMenu(false);

    if (rest.onBlur) {
      rest.onBlur(e);
    }
  };

  const SearchButton = (
    <>
      {searchBtnClick ? (
        <Button
          color={ButtonColor.Secondary}
          size={ButtonSize.Small}
          className="essui-button-icon-only--small"
          onClick={searchBtnClick}
        >
          <Icon
            color={IconColor.Primary500}
            size={IconSize.Medium}
            name="search"
          />
        </Button>
      ) : null}
    </>
  );

  return (
    <div className="input-search">
      {labelText ? <FormLabel forId={rest.id}>{labelText}</FormLabel> : null}
      <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
        {!isViewOnly && buttonPosition === "Left" ? button || SearchButton : null}
        {!isViewOnly ? (
          <TextInput
            {...rest}
            autoComplete={false}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            onKeyDown={handleKeyDown}
            onBlur={handleBlur}
            onFocus={(e) => {
              if (rest?.onFocus) rest?.onFocus(e);
            }}
            value={rest.value}
            inputRef={rest.inputRef}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              setInputValue(e.currentTarget.value);
              handleSearchTerm(e.target.value);
              if (rest.onChange) rest.onChange(e);
              if (e.target.value === "") {
                if (onPending) onPending(undefined);
              }
            }}
          />
        ) : (
          <div className="essui-textinput-container">
            <div className="disabled essui-textinput essui-textinput--medium w-100">
              {rest.value ?? specialCharacters.HYPHEN}
            </div>
          </div>
        )}
        {!isViewOnly && buttonPosition === "Right" ? button || SearchButton : null}
      </div>
      {showMenu && onSelect !== undefined ? (
        <OverflowMenu
          menuWidth={rest.inputWidth}
          isScrollbarVisible
        >
          {dropdownItems ? dropdownItems?.map((item) => item) : []}
        </OverflowMenu>
      ) : null}
    </div>
  );
};

Input.defaultProps = {
  labelText: undefined,
  searchItems: undefined,
  button: undefined,
  buttonPosition: undefined,
  onSelect: undefined,
  onNoSelection: undefined,
  onPending: undefined,
  searchable: undefined,
  searchBtnClick: undefined,
  isViewOnly: undefined
};

export default Input;
