import InputMask from "react-input-mask";
import React, {
  ChangeEventHandler,
  EventHandler,
  FocusEventHandler,
  HTMLInputTypeAttribute,
  KeyboardEventHandler,
  useEffect
} from "react";

type InputMaskPropsType = {
  maskElement: string | Array<string | RegExp>;
  maskChar: string | null | undefined;
  maskType?: HTMLInputTypeAttribute | undefined;
  maskId?: string | undefined;
  maskName?: string | undefined;
  inputRef?: React.Ref<HTMLInputElement> | undefined;
  onChange?: ChangeEventHandler | undefined;
  onBlur?: FocusEventHandler | undefined;
  name?: string | undefined;
  value?: string | readonly string[] | number | undefined;
  disabled?: boolean;
  className?: string | undefined;
  onKeyDown?: KeyboardEventHandler<HTMLDivElement> | undefined;
};
const TextInputMask = React.forwardRef(
  (
    {
      maskElement,
      maskChar,
      maskType,
      maskId,
      maskName,
      onChange,
      name,
      disabled,
      value,
      className,
      onBlur,
      onKeyDown,
      ...rest
    }: InputMaskPropsType,
    inputRef: any
  ) => (
    <InputMask
      {...rest}
      onKeyDown={onKeyDown ?? undefined}
      className={className ?? "essui-textinput essui-textinput--medium"}
      mask={maskElement}
      maskChar={maskChar}
      type={maskType}
      id={maskId}
      inputRef={inputRef}
      value={value}
      disabled={disabled}
      onChange={(e) => (onChange ? onChange(e) : null)}
      name={name}
      onBlur={onBlur}
    />
  )
);

TextInputMask.defaultProps = {
  maskType: undefined,
  maskId: undefined,
  maskName: undefined,
  inputRef: undefined,
  onChange: undefined,
  onBlur: undefined,
  name: undefined,
  value: undefined,
  disabled: undefined,
  className: undefined,
  onKeyDown: undefined
};
export default TextInputMask;
