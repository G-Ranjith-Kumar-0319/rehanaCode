import { createAsyncThunk } from "@reduxjs/toolkit";
import { apiRoot, client } from "@/config";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/store/store";
import { UseTranslationResponse, useTranslation } from "@essnextgen/ui-intl-kit";

const useHelpButton = () => {
  const { t }: UseTranslationResponse<"translation", {}> = useTranslation();
  const dispatch = useDispatch<AppDispatch>();
  const urlHelp = "https://customer.support-ess.com/csm";

  const findHelpIdentifier = createAsyncThunk(
    "common/findHelpIdentifier",
    async ({
      requestIdentifier,
      locale,
      controlID
    }: {
      requestIdentifier: string;
      locale: string;
      controlID: string;
    }) => {
      const response = await client.post(`${apiRoot}/your-endpoint`, {
        requestIdentifier,
        locale,
        controlID
      });
      return response.data;
    }
  );

  const handleClick = () => {
    //   const response: any = dispatch(findHelpIdentifier({
    //     requestIdentifier: 'some-unique-identifier', // Replace with actual identifier
    //     locale: 'en-US', // Replace with actual locale
    //     controlID: 'control-12345' // Replace with actual ControlID
    //   }));
    //   console.log(JSON.stringify(response));
    window.open(urlHelp, "_blank");
  };

  return {
    handleClick
  };
};
export default useHelpButton;
