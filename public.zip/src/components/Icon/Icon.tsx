import { IIconProps, Icon } from "@essnextgen/ui-kit";

type TiconWithText = IIconProps & { text: string };
const IconWithText = ({ size, name, text }: TiconWithText) => (
  <span className="icon">
    <Icon
      size={size}
      name={name}
    />
    <span>{text}</span>
  </span>
);

export default IconWithText;
