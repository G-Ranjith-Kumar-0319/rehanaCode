import {
  Accordion,
  AccordionHeader,
  AccordionPanel,
  Header,
  Icon,
  OverflowMenu,
  OverflowMenuItem,
  ProfileMenu,
  ProfileMenuItem,
  TextInput,
  IconSize,
  useOutsideClick,
  Link
} from "@essnextgen/ui-kit";
import { URL_HELP } from "@/types/UseStateType";
import { IHeaderViewProps } from "./HeaderProps";
import "./Style.scss";
import { SidebarMenu } from "../SidebarMenu/SidebarMenu";

const HeaderView: ({}: IHeaderViewProps) => JSX.Element = ({
  toggleMenu,
  toggleProfileMenu,
  showMenu,
  showProfileMenu
}: IHeaderViewProps) => (
  <>
    <Header
      applicationName="FMS"
      dataTestId="header"
      userInitials=""
      showNotificationIcon={false}
      onClickMenu={toggleMenu}
      onClickAvatar={toggleProfileMenu}
      onClickHelp={() => window.open(URL_HELP.URLHELP)}
    />
    <SidebarMenu
      isOpen={showMenu}
      onClose={toggleMenu}
    />
    {showProfileMenu && (
      <ProfileMenu
        dataTestId="header-profile-menu"
        emailId="holly.chris@domain.com"
        id="element-id"
        onClickSignout={() => {}}
        userFullname="Holly Chris"
        userInitials="HC"
        className="elr-header__profile-menu"
      >
        <ProfileMenuItem iconName="register">Menu Item 1</ProfileMenuItem>
        <ProfileMenuItem iconName="add">Menu Item 2</ProfileMenuItem>
        <ProfileMenuItem iconName="grid">Menu Item 3</ProfileMenuItem>
      </ProfileMenu>
    )}
  </>
);

export default HeaderView;
