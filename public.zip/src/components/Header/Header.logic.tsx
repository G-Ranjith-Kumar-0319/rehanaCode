import React, { useEffect, useRef, useState } from "react";
import { useOutsideClick } from "@essnextgen/ui-kit";
import { useLocation } from "react-router-dom";
import HeaderView from "./Header.view";
import UseStateType from "../../types/UseStateType";
import { IHeaderProps } from "./HeaderProps";

const Header: React.FC<IHeaderProps> = () => {
  const [showMenu, setShowMenu]: UseStateType<boolean> = useState(false);
  const [showProfileMenu, setShowProfileMenu]: UseStateType<boolean> = useState(false);

  const toggleMenu: (e: React.SyntheticEvent) => void = (e: React.SyntheticEvent) => {
    e.preventDefault();
    setShowMenu(!showMenu);
  };

  const toggleProfileMenu: () => void = () => {
    setShowProfileMenu(!showProfileMenu);
  };

  const applicationMenuRef: React.Ref<HTMLDivElement> = useRef(null);
  const { isOutsideClicked } = useOutsideClick(applicationMenuRef);

  useEffect(() => {
    if (isOutsideClicked) {
      setTimeout(() => {
        setShowMenu(false);
        setShowProfileMenu(false);
      }, 100);
    }
  }, [isOutsideClicked]);

  const location = useLocation();

  useEffect(() => setShowMenu(false), [location]);

  return (
    <div
      className="header"
      ref={applicationMenuRef}
    >
      <HeaderView
        toggleMenu={toggleMenu}
        toggleProfileMenu={toggleProfileMenu}
        showMenu={showMenu}
        showProfileMenu={showProfileMenu}
      />
    </div>
  );
};

export default Header;
