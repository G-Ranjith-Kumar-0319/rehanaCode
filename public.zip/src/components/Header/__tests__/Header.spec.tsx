import { render } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Header from "../Header.logic";

describe.skip("Sample", () => {
  test("should render the component", () => {
    const { getByTestId } = render(<Header />);
    expect(getByTestId("header")).toBeInTheDocument();
  });

  test("when clicking hamburger, then the menus should be populated", async () => {
    const { getByTestId } = render(<Header />);
    await userEvent.click(getByTestId("header-menu-icon-btn"));
    expect(getByTestId("header")).toBeInTheDocument();
  });

  test("when clicking avatar, then the profile menu should be populated", async () => {
    const { getByTestId } = render(<Header />);
    await userEvent.click(getByTestId("header-avatar"));
    expect(getByTestId("header-profile-menu")).toBeInTheDocument();
  });
});
