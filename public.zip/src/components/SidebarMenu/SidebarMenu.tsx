import { Link } from "react-router-dom";
import {
  Accordion,
  AccordionHeader,
  AccordionPanel,
  ISideNavigationPanelProps,
  SideNavigationPanel,
  SideNavigationPanelContent,
  Tag,
  TagColor,
  TagSize,
  useOutsideClick
} from "@essnextgen/ui-kit";
import { useSidebarMenu } from "./useSidebarMenu";

import "./style.scss";

type TSidebarMenu = Omit<ISideNavigationPanelProps, "title" | "hasCloseBtn" | "id">;

/**
 * SidebarMenu component renders a sidebar menu with collapsible sections and menu links.
 *
 * @param {Object} props - The component props.
 * @param {boolean} props.isOpen - Flag indicating whether the sidebar menu is open or closed.
 * @param {Function} props.onClose - Callback function to handle the close event of the sidebar menu.
 * @returns {JSX.Element|null} The rendered SidebarMenu component.
 */

/* eslint-disable import/prefer-default-export */
export const SidebarMenu = ({ isOpen, onClose }: TSidebarMenu): JSX.Element | null => {
  const { menuList, activeId, setActiveId, applicationMenuRef, changeHandler } = useSidebarMenu(onClose);

  const generateMenu = () =>
    menuList.map((menuItem: any, i: number) =>
      menuItem.children && menuItem.children.length ? generateSubMenus(menuItem) : generateMenuLink(menuItem)
    );

  const generateSubMenus = (menuItem: any) => (
    <Accordion
      id={menuItem.id}
      ariaLabelledBy="false"
      key={menuItem.id}
    >
      <AccordionHeader
        id={`header-${menuItem.id}`}
        ariaControls={`panel-${menuItem.id}`}
        key={`header-${menuItem.id}`}
      >
        <span className="icon">
          {menuItem.icon}
          <span>{menuItem.label}</span>
        </span>
      </AccordionHeader>
      <AccordionPanel
        id={`panel-${menuItem.id}`}
        ariaLabelledBy={`header-${menuItem.id}`}
        key={`panel-${menuItem.id}`}
      >
        {menuItem.submenus.map((childMenuItem: any, j: number) =>
          childMenuItem.submenus && childMenuItem.submenus.length
            ? generateSubMenus(childMenuItem)
            : generateMenuLink(childMenuItem)
        )}
      </AccordionPanel>
    </Accordion>
  );

  const generateMenuLink = (menuItem: any) => (
    <Link
      to={(menuItem.href as string) || "/not-found"}
      className="essui-link"
    >
      <span className="icon">
        <span>{menuItem.label}</span>
      </span>
    </Link>
  );

  return menuList.length ? (
    <div
      ref={applicationMenuRef}
      style={{ background: "red" }}
    >
      <SideNavigationPanel
        dataTestId="breadcrumb-menu"
        id="breadcrumb-menu"
        className="sidebar-navigation"
        title=""
        isOpen={isOpen}
        onClose={onClose}
      >
        <SideNavigationPanelContent>{generateMenu()}</SideNavigationPanelContent>
      </SideNavigationPanel>
    </div>
  ) : null;
};
