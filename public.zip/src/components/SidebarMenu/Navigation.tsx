import { CenterSquare, LicenseThirdParty, Notebook, ToolKit } from "@carbon/icons-react";

/* eslint-disable import/prefer-default-export */
export const Menu = [
  {
    id: "focus",
    label: "Focus",
    icon: <CenterSquare className="menuicon" />,
    href: "",
    children: ["accounts-payable", "general-ledger"],
    index: 1,
    tags: "PI1"
  },
  {
    id: "accounts-payable",
    label: "Accounts Payable",
    icon: <LicenseThirdParty className="menuicon" />,
    href: "",
    children: ["supplier", "purchase-order", "invoice-credit-note", "cheque-processing", "bacs-processing"],
    index: 1,
    tags: "PI1"
  },
  {
    id: "supplier",
    label: "Supplier",
    href: "/accounts-payable/supplier",
    children: [],
    index: 2,
    tags: "PI1"
  },
  {
    id: "purchase-order",
    label: "Purchase Order",
    href: "/purchase-orders",
    children: [],
    index: 3,
    tags: "PI1"
  },
  {
    id: "invoice-credit-note",
    label: "Invoice/Credit Note",
    href: "/invoice-credit-note",
    children: [],
    index: 4,
    tags: "PI1"
  },
  {
    id: "cheque-processing",
    label: "Cheque Processing",
    href: "/cheque-processing",
    children: [],
    index: 5,
    tags: "PI1"
  },
  {
    id: "general-ledger",
    label: "General Ledger",
    icon: <Notebook className="menuicon" />,
    href: "",
    children: ["bank-recon", "petty-cash", "charts-of-accounts-review", "manual-journal-processing", "journal-review"],
    index: 2,
    tags: "PI2"
  },
  {
    id: "bank-recon",
    label: "Bank Reconciliation",
    href: "/general-ledger/bank-reconciliation",
    children: [],
    index: 1,
    tags: "PI2"
  },
  {
    id: "petty-cash",
    label: "Petty Cash",
    href: "/general-ledger/petty-cash",
    children: [],
    index: 4,
    tags: "PI2"
  },
  {
    id: "charts-of-accounts-review",
    label: "Charts of Accounts Review",
    href: "/general-ledger/chart-accounts-review",
    children: [],
    index: 2,
    tags: "PI2"
  },

  {
    id: "manual-journal-processing",
    label: "Manual Journal Processing",
    href: "/general-ledger/manual-journal-list",
    children: [],
    index: 3,
    tags: "PI2"
  },
  {
    id: "tools",
    label: "Tools",
    icon: <ToolKit className="menuicon" />,
    href: "",
    children: ["general-ledger-setup"],
    index: 2,
    tags: "PI2"
  },
  {
    id: "general-ledger-setup",
    label: "General Ledger Setup",
    icon: "",
    href: "/tools/general-ledger-setup/fund-codes",
    children: [],
    index: 1,
    tags: "PI2"
  },
  {
    id: "journal-review",
    label: "Journal Review",
    icon: "",
    href: "/general-ledger/journal-review",
    children: [],
    index: 5,
    tags: "PI2"
  }
];
