import { Breadcrumbs, Grid, GridItem } from "@essnextgen/ui-kit";
import { useEffect, useState } from "react";
import { useHistory, useParams, useRouteMatch } from "react-router-dom";
import { useDispatch } from "react-redux";
import { AppDispatch, useAppSelector } from "@/store/store";
import useQuery from "@/hooks/useQuery";
import { useAppContext } from "@/routes/Routes";
import { actions as bankReconActions } from "@/shared/components/BankReconciliationBankAccount/state/BankAccount.slice";
import { pettyCashActions } from "@/pages/GeneralLedger/PettyCashProcessing/state/PettyCashList.slice";
import routes from "../../routes/routesConstants";
import { actions as ioactions } from "../../pages/Invoice/State/InvoiceNoteList.slice";
import { actions as statusAction } from "../../pages/Invoice/State/InvoiceNoteStatus.slice";
import { actions as TypeAction } from "../../pages/Invoice/State/InvoiceNoteType.slice";
import { actions as cpActions } from "../../pages/ChequeProcessing/state/ChequeProcessing.slice";
import { actions as supplierModuleActions } from "../../pages/Supplier/state/SupplierCatalogue.slice";

const notIncludeBreadcrumFor = [
  "/accounts-payable/supplier/edit/:clientId/0/purchase-orders",
  "/accounts-payable/supplier/edit/:clientId/:payeeId/cheque-processing",
  "/accounts-payable/supplier/edit/:clientId/:payeeId/cheque-processing/add-cheque-run"
];

const AppBreadcrumbs = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { catalogueData } = useAppSelector((state) => state.supplierCatalogue);
  const { orderno } = useParams<{ orderno: string }>();
  const searchParams = useQuery();
  const defaultPath = {
    path: "/UI",
    linkName: "Home",
    active: true
  };
  const { setGlobalPaths } = useAppContext();

  const [paths, setPaths] = useState([defaultPath]);
  const history = useHistory();
  const location = history?.location;
  const state = { ...(history?.location?.state as any) };
  const newPaths: {
    path: string;
    linkName: string;
    active: boolean;
  }[] = [];

  routes.forEach((items) => {
    const match = useRouteMatch(items.path);
    if (match && Object.keys(match?.params ? match?.params : {})?.length && items.path !== "*") {
      if (!notIncludeBreadcrumFor.includes(match.path)) {
        newPaths.push({
          path: `${match.url}${state.searchParams ? state.searchParams : ""}`,
          linkName: items.name,
          active: false
        });
      }
    } else if (match && items.path !== "*") {
      newPaths.push({
        path: match.url,
        linkName: items.name,
        active: false
      });
    }
  });

  useEffect(() => {
    const exactPath = location?.pathname;
    setPaths([defaultPath, ...newPaths]);
    if (setGlobalPaths) setGlobalPaths([defaultPath, ...newPaths]);

    if (!exactPath?.includes("/invoice-credit-note")) {
      dispatch(ioactions.resetSelectedRow());
      dispatch(ioactions.resetFilters());
      dispatch(statusAction.resetFilters());
      dispatch(TypeAction.resetFilters());
      dispatch(ioactions.resetFocus());
    }

    if (!exactPath?.includes("/cheque-processing")) {
      dispatch(cpActions.resetFilters());
    }

    if (!exactPath?.includes("/general-ledger/bank-reconciliation/add")) {
      dispatch(bankReconActions.setSelectedRow(undefined));
      dispatch(bankReconActions.selectBankAccountRow(undefined));
    }

    if (!exactPath?.includes("/general-ledger/petty-cash")) {
      dispatch(pettyCashActions.setFilters({ pcTransId: 0 }));
    }

    // This is used for supplier, to make review tab by default open, if clicked from breadcrum
    if (history?.location?.pathname?.includes("/accounts-payable/supplier/edit/")) {
      if (catalogueData.catalogueList.activeStatus !== 2) dispatch(supplierModuleActions.setSupplierActiveTab(3));
    } else {
      dispatch(supplierModuleActions.setSupplierActiveTab(0));
    }
  }, [location]);

  return (
    <Grid className="breadcrumb">
      <GridItem className="pl-0">
        <Breadcrumbs
          breadcrumbActions={paths}
          onItemClick={(path) => {
            const currentPath = path.split("?");

            history.push(
              {
                pathname: currentPath?.at(0),
                search: currentPath?.at(1) && currentPath?.at(1) !== undefined ? currentPath?.at(1) : ""
              },
              searchParams.get("prefix") === null && orderno ? {} : state
            );
          }}
          getClass={(ele) => ele.path}
          isTextTruncate={false}
          isTrailTruncate={false}
        />
      </GridItem>
    </Grid>
  );
};

export default AppBreadcrumbs;
