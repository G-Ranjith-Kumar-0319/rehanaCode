import { FormLabel, RadioButton, RadioLabelPosition } from "@essnextgen/ui-kit";
import React, { useLayoutEffect, useState } from "react";
import { TColumnDef } from "../GridTable/GridTable";

type SequenceType = {
  columnDef: TColumnDef;
  setColumns?: (columns: TColumnDef) => void;
};

const Sequence = ({ columnDef, setColumns }: SequenceType) => {
  const [sequences, setSequences] = useState<TColumnDef>([]);
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [columns, setColumn] = useState<TColumnDef>(columnDef);

  useLayoutEffect(() => {
    setSequences(columnDef.filter((col) => !!col.sequence));
  }, []);

  const handleRadioChange = (value: React.SetStateAction<string>) => {
    setSelectedOption(value);
    if (columnDef.find((col) => col.checkboxSelection === true)) {
      columnDef.map((col, index) => {
        if (col.field === value) {
          const temp = columns[1];
          columns[1] = columns[index];
          columns[index] = temp;
        }
        return col;
      });
    } else {
      columnDef.map((col, index) => {
        if (col.field === value) {
          const temp = columns[0];
          columns[0] = columns[index];
          columns[index] = temp;
        }
        return col;
      });
    }
    if (setColumns) setColumns(columns);
  };

  return (
    <div className="essui-global-typography-default-h2">
      <FormLabel>Sequence</FormLabel>
      <div className="essui-textinput sequence">
        {(sequences || []).map((column) => (
          <>
            <RadioButton
              label={column.headerName}
              labelPosition={RadioLabelPosition.Right}
              value={column.field}
              onChange={() => handleRadioChange(column.field)}
              isSelected={selectedOption === column.field}
            />
          </>
        ))}
      </div>
    </div>
  );
};

Sequence.defaultProps = {
  setColumns: undefined
};

export default Sequence;
