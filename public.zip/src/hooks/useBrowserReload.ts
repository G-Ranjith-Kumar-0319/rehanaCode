import { useState, useEffect } from "react";

const useBrowserReload = () => {
  const [isReload, setIsReload] = useState(false);

  useEffect(() => {
    // Check if there's an existing reload flag in localStorage
    const reloadFlag = sessionStorage.getItem("isBrowserReload");

    if (reloadFlag) {
      setIsReload(true);
      // Clear the flag after detecting
      sessionStorage.removeItem("isBrowserReload");
    } else {
      // Set the flag when the component mounts
      sessionStorage.setItem("isBrowserReload", "true");
    }

    // Clear the flag on component unmount
    return () => {
      sessionStorage.removeItem("isBrowserReload");
    };
  }, []);

  return isReload;
};

export default useBrowserReload;
