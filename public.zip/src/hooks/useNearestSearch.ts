import { RowType } from "@/components/GridTableNew/GridTableNew";
import { Dispatch, SetStateAction, useEffect } from "react";
import findNearest from "@/utils/nearestSearch";

type SearchType = {
  key: string;
  value: string;
  rows: RowType[];
  dataTestId: string;
  selectRow: Dispatch<SetStateAction<RowType | undefined>>;
};

export default ({ key, value, rows, dataTestId, selectRow }: SearchType) => {
  useEffect(() => {
    if (value !== "" && rows && rows.length) {
      let found;
      found = [...rows]
        .filter((element) => {
          if (value) {
            if (typeof element[key] === "string") {
              return element[key].toString()?.toUpperCase()?.startsWith(value!);
            }
            return element[key] === Number(value || 0);
          }
          return false;
        })
        .at(0);
      if (found && found !== undefined) selectRow(found);
      if (found === undefined) {
        found = findNearest([...rows], [{ fieldName: key, searchValue: value }], true);
        selectRow(found!);
      }
      const element = document.getElementById(`rowIndex-${dataTestId}-${rows.indexOf(found!)}`);
      element?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [value]);
};
