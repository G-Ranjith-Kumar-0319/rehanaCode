import { getCurrentFinancialYear, getTempDefaultUserEmail } from "@/types/UseStateType";
import axios from "axios";

// Logging utility
let enableLogging = true;

export const setLogging = (value: boolean) => {
  enableLogging = value;
};

export const log = (message: string) => {
  if (enableLogging) {
    // console.log(message);
  }
};

const convertString = (input: any) => {
  // Replace all instances of '/' with '|'
  const output = input.replace(/\//g, "|");

  // Remove the leading and trailing '|' if present
  return output.startsWith("|") ? output.slice(1) : output;
};

// Getter and Setter for request log metadata
let requestLogData = {
  description: ""
};

export const getLogdata = () => requestLogData;
export const setLogdata = (logdata = {}) => {
  requestLogData = { ...requestLogData, ...logdata };
};

let clickeventName: any;
const handleClick = (event: any) => {
  clickeventName = event.target.textContent;
};

// Add event listener for clicks
document.addEventListener("click", handleClick);

// const history = useHistory();
axios.interceptors.request.use(
  (config) => {
    if (config.headers) {
      // Add any additional headers if needed

      config.headers.FinancialYear = getCurrentFinancialYear();
      config.headers.Email = getTempDefaultUserEmail();
      config.headers.Breadcrumb = convertString(window.location.pathname);
      config.headers.URL = `${config.url}`;
      config.headers.userid = "Test User";

      const { description } = getLogdata();
      config.headers.description = description;

      // Log the request details including headers
      log(`Request made to ${config.url} with headers: ${JSON.stringify(config.headers)}`);
    }

    return config;
  },
  (error) =>
    // Do something with request error
    Promise.reject(error)
);

export const apiRoot = process.env.CUSTOM_ENV === "local" ? process.env.API_PATH : process.env.API_URL;
export const client = axios;
