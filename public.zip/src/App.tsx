import { Provider as ReduxProvider } from "react-redux";
import { IntlProvider, I18nextProvider } from "@essnextgen/ui-intl-kit";
import { uiKitTranslation } from "@essnextgen/ui-kit";
import { useEffect } from "react";
import { uiAppKitTranslation } from "@essnextgen/ui-application-kit";
import translationEn from "@/locales/en/translation.json";
import translationCy from "@/locales/cy/translation.json";
import Routes from "./routes/Routes";
import ErrorBoundary from "./shared/components/ErrorBoundary/Index";
import { setupStore } from "./store/store";
import { IRoutesProps } from "./routes/Routes.type";

export interface IAppProps extends IRoutesProps {}

const App: (props: IAppProps) => JSX.Element = ({ isStandaloneApp }: IAppProps) => {
  const i18n = IntlProvider.init({
    translation: {
      en: {
        ...uiKitTranslation.en,
        ...uiAppKitTranslation.en,
        ...translationEn,
        Test: "Test english",
        message: "click <homelink>here</homelink> to go to home pages",
        message1: "test"
      },
      cy: {
        ...uiKitTranslation.cy,
        ...uiAppKitTranslation.cy,
        ...translationCy,
        Test: "Test welsh",
        message: "click <1>here</1> to go towerewrw home page2."
      }
    }
  });

  /* To clear cached language from localStorage 
     so that lanuguage can be detected from navigator.language 
     after user changes language from browser settings and restarts browser
  */
  useEffect(() => localStorage.removeItem("i18nextLng"), []);

  return (
    <>
      <ErrorBoundary>
        <ReduxProvider store={setupStore()}>
          <I18nextProvider i18n={i18n}>
            <Routes isStandaloneApp />
          </I18nextProvider>
        </ReduxProvider>
      </ErrorBoundary>
    </>
  );
};

export default App;
