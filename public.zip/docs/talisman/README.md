# Talisman

- [Talisman](#talisman)
  - [Overview](#overview)

## Overview

We are using talisaman tool as a github hook to validates wheather the secrets or sensitive information being pushed into the github.

Basic topics covered in the talisman

- example source code.
- pre-commit hooks
