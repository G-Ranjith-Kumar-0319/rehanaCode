const { merge } = require("webpack-merge");
const { baseConfig } = require("./webpack.base");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const path = require("path");

const webpackDevServerSettings = {
  compress: true,
  hot: true,
  port: process.env.PORT || 3002,
  open: ['/'],
  proxy: {
    '/api': {
      target: 'https://fms7-dev.parentpaygroup.com',
      secure: false
    },
  },
  client: {
    overlay: false
  }
};

module.exports = merge(baseConfig, {
  devtool: "eval-source-map",
  devServer: webpackDevServerSettings
});