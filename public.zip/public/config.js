window.AUTH_API_URL = "http://localhost:5069/api";
window.REACT_API_URL = "http://localhost:5069";
window.REACT_CLIENT_ID = "pm-sso-33678133-0330-4341-95e6-6b46b549eb1d";
window.REACT_AUTH_ENDPOINT =
  "https://simsid-partner-stsserver.azurewebsites.net/connect";
window.REACT_REDIRECT_URI = "http://localhost:3002/auth";
window.AppInsightsConnectionString = "";
window.REACT_ENVIRONMENT = "localhost";
window.REACT_GA_TRACKING_ID = "";
window.APPLICATION = "FMS07";
window.HOME_URL = "https://dev.home.sims.co.uk/";
window.REACT_ONETRUST_DOMAIN_ID = "e025a41c-b4c9-4895-a6af-b28f3ca27ba0-test";
window.USE_SCHOOL_PERMISSION = "false";
window.REDIRECT_URI = "https://fms7-dev.parentpaygroup.com/UI";
window.LANDING_PAGE_URL = "http://localhost:3002/UI";
